package me.j360.dubbo.web.response;

import lombok.Data;

/**
 * Package: me.j360.dubbo.web.response
 * UserVo: min_xu
 * Date: 16/8/25 下午1:37
 * 说明：
 */

@Data
public class UserVo {


    private Long id;
    private String name;
}
