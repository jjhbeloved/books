/**
 * Package: me.j360.dubbo.api.model.query
 * User: min_xu
 * Date: 2017/3/16 下午2:38
 * 说明：需要传输进行查询的参数封装,由接口方定义
 * service
 * param:query
 * return:result
 */
package me.j360.dubbo.api.model.query;