package me.j360.dubbo.api.model.query;

import me.j360.dubbo.api.model.param.user.UserDTO;
import me.j360.dubbo.base.model.query.BaseQuery;

/**
 * Package: me.j360.dubbo.api.model.query.user
 * User: min_xu
 * Date: 16/8/23 下午3:52
 * 说明：
 */
public class UserQuery extends BaseQuery<UserDTO> {

}
