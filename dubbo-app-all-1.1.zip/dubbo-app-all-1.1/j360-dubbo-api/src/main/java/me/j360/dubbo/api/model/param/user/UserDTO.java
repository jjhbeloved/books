package me.j360.dubbo.api.model.param.user;

import lombok.ToString;

import java.io.Serializable;

/**
 * Package: me.j360.dubbo.api.model.param.user
 * User: min_xu
 * Date: 16/8/23 下午3:54
 * 说明：
 */
@ToString
public class UserDTO implements Serializable{

    private static final long serialVersionUID = 2883382561235637056L;

    private Long userId;


}
