/**
 * Package: me.j360.dubbo.api.model.param
 * User: min_xu
 * Date: 16/8/23 下午3:54
 * 说明：进行封装成rpc返回的内部对象(result.dto),内部进行传递的对象(service,manger层传输的对象)
 */
package me.j360.dubbo.api.model.param;