package me.j360.dubbo.api.model.result;

import lombok.Data;
import me.j360.dubbo.base.model.domian.BaseDO;

/**
 * Package: me.j360.dubbo.api.model.result
 * User: min_xu
 * Date: 2017/5/17 上午10:38
 * 说明：
 */
@Data
public class UserBindResultDTO extends BaseDO {

}
