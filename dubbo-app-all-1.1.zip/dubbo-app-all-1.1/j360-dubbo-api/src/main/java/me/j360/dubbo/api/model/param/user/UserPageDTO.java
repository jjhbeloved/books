package me.j360.dubbo.api.model.param.user;


import me.j360.dubbo.base.model.query.PageQuery;

/**
 * Package: me.j360.dubbo.api.model.param.user
 * User: min_xu
 * Date: 16/8/23 下午3:57
 * 说明：
 */
public class UserPageDTO extends PageQuery {

}
