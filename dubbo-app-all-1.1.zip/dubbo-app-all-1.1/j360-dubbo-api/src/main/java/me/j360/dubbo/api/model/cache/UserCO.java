package me.j360.dubbo.api.model.cache;

import java.io.Serializable;

/**
 * Package: me.j360.dubbo.api.model.cache
 * User: min_xu
 * Date: 16/8/23 下午4:14
 * 说明：用于存放到缓存的bean
 */
public class UserCO implements Serializable{

}
