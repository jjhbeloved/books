/**
 * Package: me.j360.dubbo.api.model.result
 * User: min_xu
 * Date: 2017/5/17 上午10:38
 * 说明：
 */
package me.j360.dubbo.api.model.result;