package me.j360.dubbo.modules.util.base.annotation;

public @interface NotNull {

}
