package me.j360.dubbo.base.model.domian;

import java.io.Serializable;

public class BaseDO implements Serializable {
    
	private static final long serialVersionUID = -7304713318859825120L;

}