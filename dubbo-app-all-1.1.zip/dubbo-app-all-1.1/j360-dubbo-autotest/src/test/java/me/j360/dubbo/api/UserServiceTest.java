package me.j360.dubbo.api;

public class UserServiceTest {

}
