/**
 * Package: me.j360.dubbo.dao
 * User: min_xu
 * Date: 16/8/23 下午2:02
 * 说明：
 */
package me.j360.dubbo.dao;