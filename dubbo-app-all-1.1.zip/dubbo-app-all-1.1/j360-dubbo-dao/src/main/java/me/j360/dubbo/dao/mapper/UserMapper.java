package me.j360.dubbo.dao.mapper;


import me.j360.dubbo.api.model.domain.UserDO;

import java.util.List;

/**
 * Package: me.j360.dubbo.dao.mapper
 * User: min_xu
 * Date: 16/8/23 下午2:59
 * 说明：
 */
public interface UserMapper {

    /**
     * 添加商品服务配置
     * @param
     */
    void add(UserDO userDO);

    int count();

    List<UserDO> list();
}
