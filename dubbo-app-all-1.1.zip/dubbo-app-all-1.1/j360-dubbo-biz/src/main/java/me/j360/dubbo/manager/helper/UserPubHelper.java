package me.j360.dubbo.manager.helper;

import me.j360.dubbo.base.exception.ServiceException;

/**
 * Package: me.j360.dubbo.manager.helper
 * User: min_xu
 * Date: 16/8/23 下午2:55
 * 说明：
 */
public abstract class UserPubHelper {


    public void validateForInsert() throws ServiceException {

    }
}
