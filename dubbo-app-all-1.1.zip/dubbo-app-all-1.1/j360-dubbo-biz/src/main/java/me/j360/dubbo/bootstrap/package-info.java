/**
 * Package: me.j360.dubbo.biz
 * User: min_xu
 * Date: 16/8/23 下午2:02
 * 说明：需要定义aop拦截掉service层的所有的serviceException，其他异常无视
 */
package me.j360.dubbo.bootstrap;