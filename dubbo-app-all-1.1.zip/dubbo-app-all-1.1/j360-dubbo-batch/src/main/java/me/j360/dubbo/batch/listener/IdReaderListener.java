package me.j360.dubbo.batch.listener;

import org.springframework.batch.core.ItemReadListener;

/**
 * Package: cn.paomiantv.batch.listener
 * User: min_xu
 * Date: 2017/8/8 下午2:21
 * 说明：
 */
public class IdReaderListener implements ItemReadListener {

    @Override
    public void beforeRead() {

    }

    @Override
    public void afterRead(Object item) {

    }

    @Override
    public void onReadError(Exception ex) {

    }
}