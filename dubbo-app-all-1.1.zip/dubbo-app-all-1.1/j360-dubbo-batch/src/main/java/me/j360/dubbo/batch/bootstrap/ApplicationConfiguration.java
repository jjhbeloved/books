package me.j360.dubbo.batch.bootstrap;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;



@Configuration
@ImportResource({"classpath:/application-context.xml"})
public class ApplicationConfiguration {


}
