package me.j360.dubbo.batch.domain;

import lombok.Builder;
import lombok.Data;

/**
 * Package: cn.paomiantv.batch.domain
 * User: min_xu
 * Date: 2017/8/9 上午10:44
 * 说明：
 */

@Builder
@Data
public class UserID {

    private Long id;
}
