package net.pocrd.client;

public class SecurityType {
	public static final int None = 0;
	public static final int SNValid = 1;
	public static final int UserStatic = 2;
	public static final int UserDynamic = 4;
}
