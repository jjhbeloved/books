/**
 * Package: me.j360.trace.mq
 * User: min_xu
 * Date: 16/9/20 下午3:37
 * 说明：
 */
package me.j360.trace.mq;