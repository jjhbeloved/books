package me.j360.trace.example.dubbo.service;

/**
 * Package: me.j360.trace.example.dubbo.service
 * User: min_xu
 * Date: 16/9/22 下午2:42
 * 说明：
 */
public interface UserService {

    public String getUserName(Long uid);
}
