export const defaultTemplate = require('../templates/index.mustache');
export const layoutTemplate = require('../templates/layout.mustache');
export const dependenciesTemplate = require('../templates/dependency.mustache');
export const traceTemplate = require('../templates/trace.mustache');
