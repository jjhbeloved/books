package me.j360.trace.http;


public interface HttpResponse {

    int getHttpStatusCode();
}
