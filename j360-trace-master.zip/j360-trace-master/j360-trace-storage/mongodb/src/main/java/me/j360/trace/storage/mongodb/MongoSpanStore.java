package me.j360.trace.storage.mongodb;

/**
 * Package: me.j360.trace.storage.mongodb
 * User: min_xu
 * Date: 2016/9/26 下午3:35
 * 说明：
 */
public class MongoSpanStore {
}
