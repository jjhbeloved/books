package com.pajk.plutus.client.model.enums.voucher;

/**
 * Created by lizhijun on 2017/12/14.
 */

import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

/**
 * 单据子类型
 */
public enum VoucherSubType {
    ADD_DEPOSIT              (1001, "+", VoucherProcNameType.DEPOSIT_PAYMENT ,       true,  VoucherType.PAYMENT, true, "合同缴费"   ),
    PAY_IN_BACK_DEPOSIT      (1002, "+", VoucherProcNameType.DEPOSIT_PAYMENT ,       true,   VoucherType.PAYMENT, true,"补充缴费"   ),
    //REFUND_DEPOSIT           (1003, "-", null ,                                      true,   VoucherType.PAYMENT, false,"退保证金"   ),
    //ADD_ANNUAL_FEE           (1101, "+", null ,                                      true,   VoucherType.PAYMENT, false,"缴技术服务年费"   ),
    //CREDITS_EXCHANGE         (1201, "+", null ,                                      true,   VoucherType.PAYMENT, false,"服务费现金换积分"),

    DELAY_DELIVERY_VIOLATION (2001, "-", VoucherProcNameType.DEPOSIT_VIOLATION_DELIVERY ,  false, VoucherType.VIOLATION, true, "发货延迟" ),
    FAKE_VIOLATION           (2002, "-", VoucherProcNameType.DEPOSIT_VIOLATION_COMMON   ,  true,  VoucherType.VIOLATION, true, "假货" ),
    FALSE_CONDUCT_VIOLATION  (2003, "-", VoucherProcNameType.DEPOSIT_VIOLATION_COMMON   ,  true,  VoucherType.VIOLATION, true, "虚假宣传" ),

    //USER_COMPENSATE          (3001, "-", null ,                                             true, VoucherType.COMPENSATE, false,"用户赔偿"),

    //TO_ZERO                  (4001, "",  null ,                                             true, VoucherType.TO_ZERO, false,"清零(保证金, 积分 多个账本清零)"   ),

    UNKNOWN                  (9999, "",  VoucherProcNameType.UNKNOWN ,                      false, VoucherType.UNKNOWN,               false ,"未知"),
    ;

    private int code;
    // 金额符号 "+ 或者 -"
    private String symbol;
    //流程模版名
    private VoucherProcNameType proc;
    //能否收到创建
    private boolean canHandelCreate;
    //所属单据大类
    private VoucherType parent;
    //能否再下拉框展示
    private boolean show;

    private String desc;

    VoucherSubType(int code,String symbol,VoucherProcNameType proc,boolean canHandelCreate ,VoucherType parent,boolean show,String desc){
        this.code = code;
        this.symbol = symbol;
        this.proc = proc;
        this.canHandelCreate = canHandelCreate;
        this.parent = parent;
        this.show = show;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public int getCode() {
        return code;
    }

    public VoucherProcNameType getProc() {
        return proc;
    }

    public String getSymbol() {
        return symbol;
    }

    public boolean getCanHandelCreate() {
        return canHandelCreate;
    }

    public VoucherType getParent() {
        return parent;
    }

    public boolean getShow(){
        return show;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(VoucherSubType item) {
        return null != item && isEquals(item.getCode());
    }

    public static VoucherSubType valueOf(int code){
        for(VoucherSubType item: values()){
            if(item.isEquals(code)){
                return item;
            }
        }
        return UNKNOWN;
    }

    public static List<VoucherSubType> getListByType(int voucherType,boolean canHandelCreate){
        List<VoucherSubType> list = new LinkedList<>();

        VoucherType uVoucherType = VoucherType.valueOf(voucherType);

        for(VoucherSubType item: values()){
            if(! uVoucherType.isEquals(item.getParent())  || !item.getShow()){
                continue;
            }

            //查询的全部
            if(!canHandelCreate){
                list.add(item);
                continue;
            }
            //查询的可手动创建的
            if(item.getCanHandelCreate()){
                list.add(item);
            }

        }
        return list;
    }
}
