package com.pajk.plutus.client.model.enums.account;

/**
 * Created by lizhijun on 2017/12/14.
 */

/**
 * 订单结算模式
 */
public enum StatementMode {
}
