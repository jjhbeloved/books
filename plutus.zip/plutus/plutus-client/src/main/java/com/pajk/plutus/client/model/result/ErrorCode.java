package com.pajk.plutus.client.model.result;

import java.io.Serializable;

/**
 * Created by fanhuafeng on 17/2/23.
 * Modify by fanhuafeng on 17/2/23
 * 错误码取值范围[160001, 165000]
 */
public class ErrorCode implements Serializable {

    private static final long serialVersionUID = -4537592464367400359L;


    public static final int C_SUCCESS = 0;
    public static final ErrorCode SUCCESS =
            new ErrorCode(C_SUCCESS, "成功");

    /****************************错误码160001以上为基础通用错误信息***************************************/


    public static final int C_ERROR = 160001;
    public static final ErrorCode ERROR =
            new ErrorCode(C_ERROR, "错误");

    public static final int C_FAILURE = 160002;
    public static final ErrorCode FAILURE =
            new ErrorCode(C_FAILURE, "失败");

    public static final int C_EXCEPTION = 160003;
    public static final ErrorCode EXCEPTION =
            new ErrorCode(C_EXCEPTION, "异常抛出");

    public static final int C_UNSUPPORTED = 160004;
    public static final ErrorCode UNSUPPORTED = new ErrorCode(C_UNSUPPORTED, "接口暂不支持");


    public static final int C_NO_PERMISSION_TO_OPT = 160011;
    public static final ErrorCode NO_PERMISSION_TO_OPT =
            new ErrorCode(C_NO_PERMISSION_TO_OPT, "没有权限操作");

    public static final int C_STATUS_NOT_MATCH = 160012;
    public static final ErrorCode STATUS_NOT_MATCH =
            new ErrorCode(C_STATUS_NOT_MATCH, "状态不匹配");

    public static final int C_PARAM_ERROR = 160013;
    public static final ErrorCode PARAM_ERROR =
            new ErrorCode(C_PARAM_ERROR, "参数错误");

    public static final int C_QUERY_FAILURE = 160014;
    public static final ErrorCode QUERY_FAILURE =
            new ErrorCode(C_QUERY_FAILURE, "查询失败");

    public static final int C_UPDATE_FAILURE = 160015;
    public static final ErrorCode UPDATE_FAILURE =
            new ErrorCode(C_UPDATE_FAILURE, "更新失败");

    public static final int C_QUERY_INTERVAL_OVER_THRESHOLD = 160018;
    public static final ErrorCode QUERY_INTERVAL_OVER_THRESHOLD =
            new ErrorCode(C_QUERY_INTERVAL_OVER_THRESHOLD, "查询区间超过阀值");

    public static final int C_QUERY_TOO_OLD = 160019;
    public static final ErrorCode QUERY_TOO_OLD =
            new ErrorCode(C_QUERY_TOO_OLD, "查询时间太久远不支持查询");

    public static final int C_STATUS_HAS_CHANGED = 160020;
    public static final ErrorCode STATUS_HAS_CHANGED =
            new ErrorCode(C_STATUS_HAS_CHANGED, "状态已变更");

    public static final int C_PLATFORM_ERROR = 160021;
    public static final ErrorCode PLATFORM_ERROR =
            new ErrorCode(C_PLATFORM_ERROR, "不支持该平台");

    public static final int C_STORE_DB_FAILED = 160099;
    public static final ErrorCode STORE_DB_FAILED =
            new ErrorCode(C_STORE_DB_FAILED, "保存数据库失败");

    public static final int C_SELLER_NOT_EXISTS = 1600100;
    public static final ErrorCode SELLER_NOT_EXISTS =
            new ErrorCode(C_SELLER_NOT_EXISTS, "商户不存在");


    /**************************错误码160101以上为业务错误信息***************************************/

    public static final int C_TRADE_NOT_EXIST = 160101;
    public static final ErrorCode TRADE_NOT_EXIST = new ErrorCode(
            C_TRADE_NOT_EXIST, "订单不存在");

    public static final int C_REFUND_NOT_EXIST = 160102;
    public static final ErrorCode REFUND_NOT_EXIST = new ErrorCode(
            C_REFUND_NOT_EXIST, "退款单不存在");

    public static final int C_FILE_NOT_EXIST = 160103;
    public static final ErrorCode FILE_NOT_EXIST = new ErrorCode(
            C_FILE_NOT_EXIST, "文件不存在");

    public static final int C_SALES_ORDER_NOT_EXIST = 160104;
    public static final ErrorCode SALES_ORDER_NOT_EXIST = new ErrorCode(
            C_SALES_ORDER_NOT_EXIST, "对账订单不存在");

    public static final int C_SALES_SUMMARY_NOT_EXIST = 160105;
    public static final ErrorCode SALES_SUMMARY_NOT_EXIST = new ErrorCode(
            C_SALES_SUMMARY_NOT_EXIST, "对账汇总单不存在");

    public static final int C_SALES_REFUND_NOT_EXIST = 160106;
    public static final ErrorCode SALES_REFUND_NOT_EXIST = new ErrorCode(
            C_SALES_REFUND_NOT_EXIST, "对账退款单不存在");

    public static final int C_FILE_NAME_IS_EMPTY = 160107;
    public static final ErrorCode FILE_NAME_IS_EMPTY = new ErrorCode(C_FILE_NAME_IS_EMPTY, "文件名称为空");

    public static final int C_FILE_TOKEN_NOT_EXIST = 160108;
    public static final ErrorCode FILE_TOKEN_NOT_EXIST = new ErrorCode(C_FILE_TOKEN_NOT_EXIST, "文件令牌不存在");

    public static final int C_FILE_TOKEN_ENCODE_ERROR = 160109;
    public static final ErrorCode FILE_TOKEN_ENCODE_ERROR = new ErrorCode(C_FILE_TOKEN_ENCODE_ERROR, "编码文件令牌错误");

    public static final int C_FILE_EXPORT_DB_AND_SEND_MSG_FAIL = 160110;
    public static final ErrorCode FILE_EXPORT_DB_AND_SEND_MSG_FAIL =
            new ErrorCode(C_FILE_EXPORT_DB_AND_SEND_MSG_FAIL, "文件落库并发送消息失败");

    public static final int C_HTTP_NETWORK_ERROR = 160151;
    public static final ErrorCode HTTP_NETWORK_ERROR = new ErrorCode(
            C_HTTP_NETWORK_ERROR, "网络请求错误");

    public static final int C_HTTP_SERVICE_ERROR = 160152;
    public static final ErrorCode HTTP_SERVICE_ERROR = new ErrorCode(
            C_HTTP_SERVICE_ERROR, "网络请求返回结果错误");

    public static final int C_PAGE_SIZE_OUT_OF_MAX_VALUE = 160165;
    public static final ErrorCode PAGE_SIZE_OUT_OF_MAX_VALUE = new ErrorCode(
            C_PAGE_SIZE_OUT_OF_MAX_VALUE, "pageSize超出最大值");


    public static final int C_BILL_NOT_EXIST = 160200;
    public static final ErrorCode BILL_NOT_EXIST = new ErrorCode(
            C_BILL_NOT_EXIST, "结算账单不存在");

    public static final int C_BILL_ITEM_NOT_EXIST = 160201;
    public static final ErrorCode BILL_ITEM_NOT_EXIST = new ErrorCode(
            C_BILL_ITEM_NOT_EXIST, "结算账单结算项不存在");

    public static final int C_INVOICE_AMT_ERROR = 160202;
    public static final ErrorCode INVOICE_AMT_ERROR = new ErrorCode(
            C_INVOICE_AMT_ERROR, "发票金额不对");

    public static final int C_PROCESS_CREATE = 160210;
    public static final ErrorCode PROCESS_CREATE = new ErrorCode(
            C_PROCESS_CREATE, "流程创建异常");

    public static final int C_PROCESS_COMPLETE = 160211;
    public static final ErrorCode PROCESS_COMPLETE = new ErrorCode(
            C_PROCESS_COMPLETE, "流程审批异常");

    public static final int C_QUERY_AUDIT_FLOW_FAIL = 160220;
    public static final ErrorCode QUERY_AUDIT_FLOW_FAIL = new ErrorCode(
            C_QUERY_AUDIT_FLOW_FAIL, "查询流程审批记录失败");

    public static final int C_QUERY_APP_RESOURCE_FAIL = 160221;
    public static final ErrorCode QUERY_APP_RESOURCE_FAIL = new ErrorCode(
            C_QUERY_APP_RESOURCE_FAIL, "查询文案中心失败");

    public static final int C_FLOW_STATUS_NOT_EXIST = 160222;
    public static final ErrorCode FLOW_STATUS_NOT_EXIST = new ErrorCode(
            C_FLOW_STATUS_NOT_EXIST, "流程状态列表不存在");

    public static final int C_FLOW_ROLE_NOT_MATCH = 160223;
    public static final ErrorCode FLOW_ROLE_NOT_MATCH = new ErrorCode(
            C_FLOW_ROLE_NOT_MATCH, "流程角色不匹配");

    public static final int C_QUERY_ROLE_FAIL = 160224;
    public static final ErrorCode QUERY_ROLE_FAIL = new ErrorCode(
            C_QUERY_ROLE_FAIL, "查询角色失败");

    public static final int C_FLOW_OPT_NOT_MATCH = 160225;
    public static final ErrorCode FLOW_OPT_NOT_MATCH = new ErrorCode(
            C_FLOW_OPT_NOT_MATCH, "流程操作和节点不匹配");

    public static final int C_REMARK_TOO_LONG = 160226;
    public static final ErrorCode REMARK_TOO_LONG = new ErrorCode(
            C_REMARK_TOO_LONG, "备注长度过长");

    public static final int C_PAYMENT_NO_TOO_LONG = 160227;
    public static final ErrorCode PAYMENT_NO_TOO_LONG = new ErrorCode(
            C_PAYMENT_NO_TOO_LONG, "支付流水号长度过长");


    /************************************业务操作-保证金 160501 ~  161001***************************************/

    public static final int C_VOUCHER_NOT_EXISTS = 160501;
    public static final ErrorCode VOUCHER_NOT_EXISTS = new ErrorCode(
            C_VOUCHER_NOT_EXISTS, "单据不存在");

    public static final int C_BOOK_NOT_EXISTS = 160502;
    public static final ErrorCode BOOK_NOT_EXISTS = new ErrorCode(
            C_BOOK_NOT_EXISTS, "账本不存在");
    public static final int C_VOUCHER_DELIVERY_NOT_EXISTS = 160503;
    public static final ErrorCode VOUCHER_DELIVERY_NOT_EXISTS = new ErrorCode(
            C_VOUCHER_DELIVERY_NOT_EXISTS, "违规单据违规发货扩展属性不存在");


    public static final int C_WRITE_OFF_FLOW_NOT_EXISTS = 160504;
    public static final ErrorCode WRITE_OFF_FLOW_NOT_EXISTS = new ErrorCode(
            C_WRITE_OFF_FLOW_NOT_EXISTS, "需销帐账本流水不存在");

    public static final int C_BOOK_IS_IN_VALID = 160505;
    public static final ErrorCode BOOK_IS_IN_VALID = new ErrorCode(
            C_BOOK_IS_IN_VALID, "账本已经冻结");
    public static final int C_ADD_FAIL_CASE_AMOUNT_ZERO = 160506;
    public static final ErrorCode ADD_FAIL_CASE_AMOUNT_ZERO = new ErrorCode(
            C_ADD_FAIL_CASE_AMOUNT_ZERO, "新建失败,当前商家无需缴费");

    public static final int C_ADD_FAIL_EXPECT_GT_CONTRACT = 160507;
    public static final ErrorCode ADD_FAIL_EXPECT_GT_CONTRACT = new ErrorCode(
            C_ADD_FAIL_EXPECT_GT_CONTRACT, "新建失败，违规金额不能大于合同保证金");

    public static final int C_ADD_FAIL_EXPECT_NOT_CONTRACT = 160508;
    public static final ErrorCode ADD_FAIL_EXPECT_NOT_CONTRACT = new ErrorCode(
            C_ADD_FAIL_EXPECT_NOT_CONTRACT, "新建失败，未缴纳合同保证金");


    private String desc;
    private int code;

    public ErrorCode() {
    }

    public ErrorCode(int code, String desc) {
        this.desc = desc;
        this.code = code;
    }

    public boolean eq(ErrorCode obj) {
        return this.getCode() == obj.getCode();
    }

    public boolean eq(int code) {
        return this.getCode() == code;
    }

    public int getCode() {
        return this.code;
    }

    public String getDesc() {
        return this.desc;
    }

}
