package com.pajk.plutus.client.model.result.gw.voucher;

import com.pajk.plutus.client.model.result.gw.bill.ButtonGW;
import net.pocrd.annotation.Description;

import java.io.Serializable;
import java.util.List;

/**
 * Created by  guguangming on 2017/12/13
 **/
@Description("商家单据列表概要数据")
public class VoucherSummaryGW implements Serializable {
    private static final long serialVersionUID = 7742737998130647990L;

    @Description("单据id")
    public String voucherId;

    @Description("单据大类")
    public String voucherType ;

    @Description("单据子类")
    public String voucherSubType;

    @Description("金额(单位分)")
    public long amount;

    @Description("状态：表示字段node_cat_key中文名称")
    public String nodeCatKeyName;

    @Description("接收日期")
    public String procStartTime;

    @Description("关键信息")
    public String keyStr;

    @Description("操作")
    public List<ButtonGW> buttons;
}
