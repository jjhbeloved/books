package com.pajk.plutus.client.model.topic;

/**
 * Created by fanhuafeng on 17/3/27.
 * Modify by fanhuafeng on 17/3/27
 */
public interface ITopic {
    String getTopic();

    String getTags();

    String getTopicStr();
}
