package com.pajk.plutus.client.model.enums.bill;

/**
 * @author david
 * @since created by on 17/12/14 14:27
 */
public enum SettlementType {

    PA_NO(0, "平安待确定"),

    PA_RECEIPT(1, "平安应收"),

    PA_PAY(2, "平安应付");

    private int code;
    private String desc;

    SettlementType(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(SettlementType item) {
        return null != item && isEquals(item.getCode());
    }

    public static SettlementType valueOf(int code) {
        for (SettlementType settlementType : values()) {
            if (settlementType.isEquals(code)) {
                return settlementType;
            }
        }
        return PA_NO;
    }
}
