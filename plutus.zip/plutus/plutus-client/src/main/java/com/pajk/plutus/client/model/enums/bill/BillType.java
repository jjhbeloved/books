package com.pajk.plutus.client.model.enums.bill;

/**
 * @author david
 * @since created by on 17/12/14 14:54
 */
public enum BillType {

    PA_NO(0, "未知合计"),

    ITEM_COMMISSION_AMT(1, "商品佣金_总金额"),

    ITEM_SETTLEMENT_PROFIT_AMT(2, "结算商品利润_总金额"),

    PA_ITEM_AMT(3, "平安承担商品金额合计"),

    PA_POST_AMT(4, "平安承担邮费金额合计"),

    PA_TAX_AMT(5, "平安承担关税金额合计"),

    POST_OTHER_AMT(6, "平安承担其它费用"),

    ITEM_COST(7, "应付商品成本合计"),

    POST_AMT(8, "应付邮费合计"),

    TAX_AMT(9, "应付关税合计"),

    SELLER_COD_AMT(10, "商家自收货到付款现金_商品");

    private int code;
    private String desc;

    BillType(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(BillType item) {
        return null != item && isEquals(item.getCode());
    }

    public static BillType valueOf(int code) {
        for (BillType billType : values()) {
            if (billType.isEquals(code)) {
                return billType;
            }
        }
        return PA_NO;
    }
}
