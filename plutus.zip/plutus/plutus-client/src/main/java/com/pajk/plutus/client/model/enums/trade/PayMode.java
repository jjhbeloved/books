package com.pajk.plutus.client.model.enums.trade;

/**
 * Created by fanhuafeng on 17/2/21.
 * Modify by fanhuafeng on 17/2/21
 */
public enum PayMode {
    PAY_ONLINE       ( 1    , "在线支付" ) ,
    CASH_ON_DELIVERY ( 2    , "货到付款" ) ,
    UNKNOWN          ( 9999 , "未知"     )
    ;

    private int code;
    private String desc;

    PayMode(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(PayMode item) {
        return null != item && isEquals(item.getCode());
    }

    public static PayMode valueOf(int code){
        for(PayMode item: values()){
            if(item.isEquals(code)){
                return item;
            }
        }
        return UNKNOWN;
    }

}
