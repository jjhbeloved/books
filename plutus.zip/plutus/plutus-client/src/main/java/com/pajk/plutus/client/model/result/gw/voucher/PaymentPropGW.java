package com.pajk.plutus.client.model.result.gw.voucher;

import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * Created by  guguangming on 2017/12/13
 **/
@Description("缴费单相关属性实体")
public class PaymentPropGW implements Serializable {
    private static final long serialVersionUID = 5742700998130647997L;


    @Description("银行流水")
    public String evidenceFlow;
}
