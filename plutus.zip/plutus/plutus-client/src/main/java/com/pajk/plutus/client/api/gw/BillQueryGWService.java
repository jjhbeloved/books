package com.pajk.plutus.client.api.gw;

import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.bill.ConfirmSettlementGW;
import com.pajk.plutus.client.model.result.gw.bill.PageSettlementGW;
import com.pajk.plutus.client.model.result.gw.bill.SettlementOrderGW;
import net.pocrd.annotation.*;
import net.pocrd.define.CommonParameter;
import net.pocrd.define.SecurityType;

/**
 * Created by arjaylv on 2017/12/13.
 *
 * @author arjaylv
 */
@ApiGroup(name = "plutus", minCode = 50281000, maxCode = 50282000, codeDefine = JkApiCode.class, owner = "yangxuan@jk.cn")
public interface BillQueryGWService {

    @HttpApi(owner = "yangxuan@jk.cn", desc = "[商户对账]-[明细]-[查询]",
            name = "plutus.querySettlement", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
            JkApiCode.C_BILL_NOT_EXIST,
            JkApiCode.C_BILL_ITEM_NOT_EXIST,
    })
    SettlementOrderGW querySettlement(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiAutowired(CommonParameter.domainId) long domainId,
            @ApiParameter(required = true, name = "sellerId", desc = "卖家id") long sellerId,
            @ApiParameter(required = true, name = "billId", desc = "账单id") long billId
    );

    @HttpApi(owner = "yangxuan@jk.cn", desc = "[商户对账]-(总账)确认账单查询",
            name = "plutus.queryConfirmSettlement", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
            JkApiCode.C_BILL_NOT_EXIST,
            JkApiCode.C_BILL_ITEM_NOT_EXIST,
            JkApiCode.C_FILE_NOT_EXIST,
    })
    ConfirmSettlementGW queryConfirmSettlement(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiAutowired(CommonParameter.domainId) long domainId,
            @ApiParameter(required = true, name = "sellerId", desc = "卖家id") long sellerId,
            @ApiParameter(required = true, name = "billId", desc = "账单id") long billId
    );

    @HttpApi(owner = "dutianyi", desc = "商户对账-总账-查询列表",
            name = "plutus.pageQuerySettlement", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
            JkApiCode.C_QUERY_INTERVAL_OVER_THRESHOLD,
            JkApiCode.C_QUERY_TIME_TOO_EARLY,
    })
    PageSettlementGW pageQuerySettlement(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiAutowired(CommonParameter.domainId) long domainId,
            @ApiParameter(required = true, name = "sellerId", desc = "卖家id") long sellerId,
            @ApiParameter(required = true, name = "startTime", desc = "统计月份,区间-开始时间,格式:yyyy-MM") String startTime,
            @ApiParameter(required = true, name = "endTime", desc = "统计月份,区间-结束时间,格式:yyyy-MM") String endTime,
            @ApiParameter(required = true, name = "pageNo", desc = "起始页,默认从1开始") int pageNo,
            @ApiParameter(required = true, name = "pageSize", desc = "每页显示条数") int pageSize
    );

}
