package com.pajk.plutus.client.model.enums.voucher;

import com.pajk.plutus.client.model.enums.account.BookFlowOutType;
import org.apache.commons.lang3.StringUtils;

/**
 * Created by  guguangming on 2017/12/18
 **/
public enum VoucherObjType {
    TRADE    ("trade", "订单类型违规单"   ),
    SKU    ("sku", "sku类型违规单"   ),
    UNKNOWN       ("unknown"   , "未知")
    ;

    private String code;
    private String desc;

    VoucherObjType(String code, String desc){
        this.code = code;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public String getCode() {
        return code;
    }

    public boolean isEquals(String code) {
        return StringUtils.equals(this.code,code);
    }

    public boolean isEquals(BookFlowOutType item) {
        return null != item && isEquals(item.getCode());
    }

    public static VoucherObjType valueOfCode(String code){
        for(VoucherObjType item: values()){
            if(item.isEquals(code)){
                return item;
            }
        }
        return UNKNOWN;
    }

}
