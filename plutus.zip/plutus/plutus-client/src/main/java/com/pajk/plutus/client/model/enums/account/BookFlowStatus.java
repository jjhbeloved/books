package com.pajk.plutus.client.model.enums.account;

/**
 * Created by lizhijun on 2017/12/14.
 */
public enum BookFlowStatus {
    NO_FINISHED (0,     "未完成"),
    FINISHED    (1,     "已完成"),
    UNKNOWN     (9999 , "未知" )
    ;

    private int code;
    private String desc;

    BookFlowStatus(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(BookFlowStatus item) {
        return null != item && isEquals(item.getCode());
    }

    public static BookFlowStatus valueOf(int code){
        for(BookFlowStatus item: values()){
            if(item.isEquals(code)){
                return item;
            }
        }
        return UNKNOWN;
    }
}
