package com.pajk.plutus.client.model.result.gw.bill;

import net.pocrd.annotation.Description;

import java.io.Serializable;
import java.util.List;

/**
 * Created by dutianyi on 2017/12/14.
 */
@Description("对账单总账列表分页数据")
public class PageSettlementGW implements Serializable {
    private static final long serialVersionUID = -6828050599600271918L;
    @Description("分页总数")
    public int totalCount;

    @Description("每页数量")
    public int pageSize;

    @Description("页码")
    public int pageNo;

    @Description("平安对应发票信息，取自seller_invoice_info表，seller_id=1，没确认开票的发票信息取自此表")
    public SellerInvoiceGW	sellerInvoice;

    @Description("平安对应的账户信息，取自seller_account_info表，seller_id=1，没确认付款的账户信息取自此表")
    public SellerAccountGW	sellerAccount;

    @Description("结果列表")
    public List<SettlementGW> settlements;
}
