package com.pajk.plutus.client.model.result.gw.process;

 import net.pocrd.annotation.Description;

import java.io.Serializable;
import java.util.List;

/**
 * Created by guguangming on 2017-12-15
 */
@Description("批量节点")
public class BatchNodeCatKeyGW implements Serializable{

    private static final long serialVersionUID = 970237998122647997L;

    @Description("节点结合")
    public List<NodeCatKeyGW> nodeKeys;

}
