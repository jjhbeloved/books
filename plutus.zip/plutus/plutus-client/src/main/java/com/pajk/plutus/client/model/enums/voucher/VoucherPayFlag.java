package com.pajk.plutus.client.model.enums.voucher;

/**
 * Created by lizhijun on 2017/12/14.
 */

/**
 * 单据扣减余额标志
 */
public enum VoucherPayFlag {
    NO_FINISHED (10,     "未完成"),
    FINISHED    (20,     "已完成"),
    NO_NEED_DEAL(30,     "无需处理"),
    UNKNOWN     ( 9999 , "未知"  );

    private int code;
    private String desc;

    VoucherPayFlag(int code, String desc){
        this.code = code;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public int getCode() {
        return code;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(VoucherPayFlag item) {
        return null != item && isEquals(item.getCode());
    }

    public static VoucherPayFlag valueOf(int code){
        for(VoucherPayFlag item: values()){
            if(item.isEquals(code)){
                return item;
            }
        }
        return UNKNOWN;
    }
}
