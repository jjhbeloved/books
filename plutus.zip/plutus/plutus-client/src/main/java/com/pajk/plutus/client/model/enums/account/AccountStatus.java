package com.pajk.plutus.client.model.enums.account;

/**
 * Created by lizhijun on 2017/12/14.
 */
public enum AccountStatus {
    FREEZE       ( 0    , "冻结" ) ,
    COMMON       ( 1    , "正常" ) ,
    UNKNOWN      ( 9999 , "未知"     )
    ;

    private int code;
    private String desc;

    AccountStatus(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(AccountStatus item) {
        return null != item && isEquals(item.getCode());
    }

    public static AccountStatus valueOf(int code){
        for(AccountStatus item: values()){
            if(item.isEquals(code)){
                return item;
            }
        }
        return UNKNOWN;
    }


}
