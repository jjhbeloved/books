package com.pajk.plutus.client.model.enums.bill;

import static com.pajk.plutus.client.model.enums.bill.SettlementType.PA_PAY;
import static com.pajk.plutus.client.model.enums.bill.SettlementType.PA_RECEIPT;
import static com.pajk.plutus.client.model.enums.trade.PayToType.PAY_TO_PLATFORM;
import static com.pajk.plutus.client.model.enums.trade.PayToType.PAY_TO_SELLER;

/**
 * @author david
 * @since created by on 17/12/14 16:19
 */
public enum ProcNameType {

    BillNO(0, "平安待确定"),

    BillSJSKPAYS(createProcNameType(PAY_TO_SELLER.getCode(), PA_RECEIPT.getCode()), "商家收款-平安应收"),

    BillSJSKPAYF(createProcNameType(PAY_TO_SELLER.getCode(), PA_PAY.getCode()), "商家收款-平安应付"),

    BillPTSKPAYF(createProcNameType(PAY_TO_PLATFORM.getCode(), PA_PAY.getCode()), "平台收款-平安应付");

    private int code;
    private String desc;

    ProcNameType(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(ProcNameType item) {
        return null != item && isEquals(item.getCode());
    }

    public static ProcNameType valueOf(int code) {
        for (ProcNameType procNameType : values()) {
            if (procNameType.isEquals(code)) {
                return procNameType;
            }
        }
        return BillNO;
    }

    private static int createProcNameType(int payToType, int settlementType) {
        return settlementType * 1000 + payToType;
    }

    public static String createProcName(int payToType, int settlementType) {
        return valueOf(createProcNameType(payToType, settlementType)).name();
    }
}
