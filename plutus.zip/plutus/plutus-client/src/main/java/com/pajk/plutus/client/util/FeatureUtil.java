package com.pajk.plutus.client.util;

import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by fanhuafeng on 17/2/20.
 * Modify by fanhuafeng on 17/2/20
 */
public class FeatureUtil {

    static final String SP = ";";
    static final String SSP = ":";
    static final String R_SP = "#3A";
    static final String R_SSP = "#3B";

    private FeatureUtil() {
        //私有化构造方法
    }

    /**
     * 通过Map转换成String
     *
     * @param attrs
     * @return
     */
    public static String toString(Map<String, String> attrs) {
        StringBuilder sb = new StringBuilder();

        if (null != attrs && !attrs.isEmpty()) {
            sb.append(SP);
            for (Map.Entry<String, String> item : attrs.entrySet()) {
                if (StringUtils.isNotEmpty(item.getKey())) {
                    sb.append(encode(item.getKey())).append(SSP).append(encode(item.getValue())).append(SP);
                }
            }
        }
        return sb.toString();
    }

    public static String toString(String key, String val) {
        StringBuilder sb = new StringBuilder();
        if (StringUtils.isNotEmpty(key) && StringUtils.isNotEmpty(val)) {
            sb.append(SP);
            sb.append(encode(key)).append(SSP).append(encode(val));
            sb.append(SP);
        }
        return sb.toString();
    }

    /**
     * 通过字符串解析成attributes
     *
     * @param str
     * @return
     */
    public static Map<String, String> fromString(String str) {
        Map<String, String> attrs = new HashMap<>();

        if (StringUtils.isBlank(str)) {
            return attrs;
        }
        String[] arr = str.split(SP);

        for (String kv : arr) {
            if (StringUtils.isBlank(kv)) {
                continue;
            }
            String[] ar = kv.split(SSP);
            if (ar.length == 2) {
                String key = decode(ar[0]);
                String val = decode(ar[1]);
                if (StringUtils.isNotEmpty(val)) {
                    attrs.put(key, val);
                }
            }
        }
        return attrs;
    }

    private static String encode(String val) {
        return StringUtils.replace(StringUtils.replace(val, SP, R_SP), SSP, R_SSP);
    }

    private static String decode(String val) {
        return StringUtils.replace(StringUtils.replace(val, R_SP, SP), R_SSP, SSP);
    }

}
