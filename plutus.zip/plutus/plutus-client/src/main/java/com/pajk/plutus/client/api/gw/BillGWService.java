package com.pajk.plutus.client.api.gw;

import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.VoidGwEntity;
import com.pajk.plutus.client.model.result.gw.bill.SettlementItemConfirmGW;
import net.pocrd.annotation.*;
import net.pocrd.define.CommonParameter;
import net.pocrd.define.SecurityType;

import java.util.List;

/**
 * Created by arjaylv on 2017/12/13.
 *
 * @author arjaylv
 */
@ApiGroup(name = "plutus", minCode = 50281000, maxCode = 50282000, codeDefine = JkApiCode.class, owner = "yangxuan@jk.cn")
public interface BillGWService {

    @HttpApi(owner = "yangxuan@jk.cn", desc = "[商户对账]-(总账)确认账单",
            name = "plutus.confirmSettlement", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
            JkApiCode.C_BILL_NOT_EXIST,
            JkApiCode.C_BILL_ITEM_NOT_EXIST,
            JkApiCode.C_BILL_ITEM_AMT_ERROR,
            JkApiCode.C_REMARK_TOO_LONG,
    })
    VoidGwEntity confirmSettlement(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiParameter(required = true, name = "sellerId", desc = "卖家id") long sellerId,
            @ApiParameter(required = true, name = "billId", desc = "账单id") long billId,
            @ApiParameter(required = true, name = "settlementItemConfirms", desc = "单据明细") List<SettlementItemConfirmGW> settlementItemConfirms,
            @ApiParameter(required = true, name = "buttonKey", desc = "操作按钮的key") String buttonKey,
            @ApiParameter(required = false, name = "confirmFileId", desc = "商户账单确认附件tfs文件id, 前端控制大小不超过4M") String confirmFileId,
            @ApiParameter(required = false, name = "confirmFileName", desc = "商户账单确认附件tfs文件名称, 与confirmFileId同时出现") String confirmFileName,
            @ApiParameter(required = false, name = "confirmRemark", desc = "商户账单确认备注") String confirmRemark
    );

    @HttpApi(owner = "yangxuan@jk.cn", desc = "[商户对账]-(总账)确认开票",
            name = "plutus.confirmInvoice", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
            JkApiCode.C_BILL_NOT_EXIST,
            JkApiCode.C_INVOICE_AMT_ERROR,
    })
    VoidGwEntity confirmInvoice(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiParameter(required = true, name = "sellerId", desc = "卖家id") long sellerId,
            @ApiParameter(required = true, name = "billId", desc = "账单id") long billId,
            @ApiParameter(required = true, name = "invoiceAmt", desc = "发票本金(分)") long invoiceAmt,
            @ApiParameter(required = true, name = "invoiceTaxAmt", desc = "发票税额(分)") long invoiceTaxAmt,
            @ApiParameter(required = true, name = "invoiceTrackingNumber", desc = "寄送发票物流单号") String invoiceTrackingNumber,
            @ApiParameter(required = true, name = "invoiceId", desc = "发票id号") String invoiceId,
            @ApiParameter(required = true, name = "buttonKey", desc = "操作按钮的key") String buttonKey
    );

    @HttpApi(owner = "yangxuan@jk.cn", desc = "[商户对账]-(总账)确认/驳回收票",
            name = "plutus.receiveInvoice", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
            JkApiCode.C_BILL_NOT_EXIST,
            JkApiCode.C_REMARK_TOO_LONG,
    })
    VoidGwEntity receiveInvoice(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiParameter(required = true, name = "sellerId", desc = "卖家id") long sellerId,
            @ApiParameter(required = true, name = "billId", desc = "账单id") long billId,
            @ApiParameter(required = true, name = "buttonKey", desc = "操作按钮的key") String buttonKey,
            @ApiParameter(required = false, name = "remark", desc = "备注") String remark
    );

    @HttpApi(owner = "yangxuan@jk.cn", desc = "[商户对账]-(总账)确认付款",
            name = "plutus.confirmPayment", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
            JkApiCode.C_BILL_NOT_EXIST,
            JkApiCode.C_PAYMENT_NO_TOO_LONG,
            JkApiCode.C_EMPTY_PAYMENT_NO,
    })
    VoidGwEntity confirmPayment(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiParameter(required = true, name = "sellerId", desc = "卖家id") long sellerId,
            @ApiParameter(required = true, name = "billId", desc = "账单id") long billId,
            @ApiParameter(required = true, name = "paymentNo", desc = "支付流水号") String paymentNo,
            @ApiParameter(required = true, name = "buttonKey", desc = "操作按钮的key") String buttonKey,
            @ApiParameter(required = false, name = "paymentFileId", desc = "支付附件tfs文件id, 前端控制大小不超过4M") String paymentFileId,
            @ApiParameter(required = false, name = "paymentFileName", desc = "支付附件tfs文件名称，与paymentFileId同时出现") String paymentFileName
    );

    @HttpApi(owner = "yangxuan@jk.cn", desc = "[商户对账]-(总账)确认/驳回收款",
            name = "plutus.confirmReceivePayment", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
            JkApiCode.C_BILL_NOT_EXIST,
            JkApiCode.C_REMARK_TOO_LONG,
    })
    VoidGwEntity confirmReceivePayment(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiParameter(required = true, name = "sellerId", desc = "卖家id") long sellerId,
            @ApiParameter(required = true, name = "billId", desc = "账单id") long billId,
            @ApiParameter(required = true, name = "buttonKey", desc = "操作按钮的key") String buttonKey,
            @ApiParameter(required = false, name = "remark", desc = "备注") String remark
    );


}
