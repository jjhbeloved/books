package com.pajk.plutus.client.model.result.gw.voucher;

import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * Created by  guguangming on 2017/12/15
 **/
@Description("单据类型 - 子类")
public class VoucherSubTypeGW implements Serializable {

    private static final long serialVersionUID = 2928656610242046796L;

    @Description("存储值")
    public int type;

    @Description("展示名称")
    public String name;

}
