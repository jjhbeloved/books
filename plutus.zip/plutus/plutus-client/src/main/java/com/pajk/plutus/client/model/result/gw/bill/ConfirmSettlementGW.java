package com.pajk.plutus.client.model.result.gw.bill;

import net.pocrd.annotation.Description;

import java.io.Serializable;
import java.util.List;

/**
 * @author david
 * @since created by on 17/12/13 19:27
 */
@Description("确认结算订单信息")
public class ConfirmSettlementGW implements Serializable {

    private static final long serialVersionUID = -4186203003284645331L;

    @Description("商家名称")
    public String sellerName;

    @Description("结算类型, PA_RECEIPT:平安应收, PA_PAY:平安应付")
    public String settlementType;

    @Description("收款方式、合作模式, PAY_TO_SELLER:平台模式, PAY_TO_PLATEFORM:自营模式")
    public String payToType;

    @Description("账单总金额(分)")
    public long billAmt;

    @Description("商家确认总金额(分)")
    public long actualBillAmt;

    @Description("单据明细")
    public List<SettlementItemGW> settlementItems;

    @Description("商户账单确认附件url，，根据confirmFileId去tfs获取文件url，商户确认账单后被驳回时有值")
    public String confirmFileUrl;

    @Description("商户账单确认附件名称，商户确认账单后被驳回时有值")
    public String confirmFileName;

    @Description("商户账单确认备注，商户确认账单后被驳回时有值")
    public String confirmRemark;

    @Description("操作记录，流程引擎查询操作记录接口返回")
    public List<SettlementOperationGW> settlementOperations;

    @Description("操作按钮")
    public List<ButtonGW> actionButtons;


}
