package com.pajk.plutus.client.model.enums.voucher;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by  guguangming on 2017/12/17
 **/
public enum VoucherStatus {
    CREATED("created", "已创建"),
    DELETED("deleted", "删除"),
    SELLER_DEAL("sellerDeal","待处理"),
    UNKNOWN("unknown", "未知");
    private String code;
    private String desc;

    VoucherStatus(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public String getCode() {
        return code;
    }

    public boolean isEquals(String code) {
        return StringUtils.equals(this.code, code);
    }

    public boolean isEquals(VoucherStatus item) {
        return null != item && isEquals(item.getCode());
    }

    public static VoucherStatus valueOfCode(String code) {
        for (VoucherStatus item : values()) {
            if (item.isEquals(code)) {
                return item;
            }
        }
        return UNKNOWN;
    }
}
