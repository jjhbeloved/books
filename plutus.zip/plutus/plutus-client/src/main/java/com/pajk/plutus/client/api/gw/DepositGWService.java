package com.pajk.plutus.client.api.gw;

import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.VoidGwEntity;
import net.pocrd.annotation.*;
import net.pocrd.define.CommonParameter;
import net.pocrd.define.SecurityType;

/**
 * Created by  guguangming on 2017/12/13
 **/
@ApiGroup(name = "plutus", minCode = 50281000, maxCode = 50282000, codeDefine = JkApiCode.class, owner = "guguangming@jk.cn")
public interface DepositGWService {

    @HttpApi(owner = "guguangming@jk.cn", desc = "[保证金]上传缴费凭证确认缴费接口",
            name = "plutus.sellerConfirmPayment", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_NO_PERMISSION_TO_VIEW,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
            JkApiCode.C_FAILURE,
            JkApiCode.C_VOUCHER_NOT_EXISTS,
            JkApiCode.C_STATUS_NOT_MATCH
    })
    VoidGwEntity sellerConfirmPayment(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiParameter(required = true, name = "sellerId", desc = "商家Id") long sellerId,
            @ApiParameter(required = true, name = "voucherId", desc = "违规单据id") String voucherId,
            @ApiParameter(required = true, name = "transitionKey", desc = "操作") String transitionKey,
            @ApiParameter(required = true, name = "nodeKey", desc = "节点") String nodeKey,
            @ApiParameter(required = false, name = "remark", desc = "备注") String remark,
            @ApiParameter(required = true, name = "evidenceFlow", desc = "银行流水") String evidenceFlow,
            @ApiParameter(required = false, name = "evidenceFile", desc = "缴费文件 格式:json数组") String evidenceFile
    );


    @HttpApi(owner = "guguangming@jk.cn", desc = "[保证金]商家同意/申诉违规单",
            name = "plutus.sellerDealPunish", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_NO_PERMISSION_TO_VIEW,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
            JkApiCode.C_FAILURE,
            JkApiCode.C_VOUCHER_NOT_EXISTS,
            JkApiCode.C_STATUS_NOT_MATCH
    })
    VoidGwEntity sellerDealPunish(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiParameter(required = true, name = "sellerId", desc = "商家Id") long sellerId,
            @ApiParameter(required = true, name = "voucherId", desc = "违规单据id") String voucherId,
            @ApiParameter(required = true, name = "transitionKey", desc = "操作") String transitionKey,
            @ApiParameter(required = true, name = "nodeKey", desc = "节点") String nodeKey,
            @ApiParameter(required = false, name = "evidenceRemark", desc = "证据备注") String evidenceRemark,
            @ApiParameter(required = false, name = "evidenceFile", desc = "缴费文件 格式:json数组") String evidenceFile
    );

}
