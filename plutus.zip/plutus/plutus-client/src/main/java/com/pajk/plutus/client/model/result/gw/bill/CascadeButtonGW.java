package com.pajk.plutus.client.model.result.gw.bill;

import com.pajk.plutus.client.model.result.gw.process.TransitionGW;
import net.pocrd.annotation.Description;

import java.io.Serializable;
import java.util.List;

/**
 * @author dutianyi
 * @since created by on 17/12/21 19:31
 */
@Description("层叠流程按钮")
public class CascadeButtonGW implements Serializable {
    private static final long serialVersionUID = 7712125052021375093L;
    @Description("操作按钮中文展示, transitionName的值")
    public String name;

    @Description("操作按钮的transition列表")
    public List<TransitionGW> transitions;

    @Description("流程操作接口名称apiName")
    public String path;
}
