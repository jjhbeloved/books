package com.pajk.plutus.client.model.enums.voucher;

/**
 * Created by cuidongchao on 2017/12/18.
 */
public enum VoucherProcNameType {

    DEPOSIT_PAYMENT("DepositPayment", "缴费单"),
    DEPOSIT_VIOLATION_DELIVERY("DepositViolationDelivery", "违规单（发货延迟）"),
    DEPOSIT_VIOLATION_COMMON("DepositViolationCommon", "违规单（非发货延迟）"),
    UNKNOWN("UNKNOWN","未知"),
    ;

    private String code;
    private String desc;

    VoucherProcNameType(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isEquals(String code) {
        return this.code.equals(code);
    }

    public static VoucherProcNameType valueOfCode(String code) {
        for (VoucherProcNameType procNameType : values()) {
            if (procNameType.isEquals(code)) {
                return procNameType;
            }
        }
        return null;
    }

}
