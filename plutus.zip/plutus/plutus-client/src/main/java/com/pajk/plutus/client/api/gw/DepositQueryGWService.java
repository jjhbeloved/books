package com.pajk.plutus.client.api.gw;

import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.account.AccountBookGW;
import com.pajk.plutus.client.model.result.gw.account.PageAccountBookFlowGW;
import com.pajk.plutus.client.model.result.gw.process.BatchNodeCatKeyGW;
import com.pajk.plutus.client.model.result.gw.voucher.BatchVoucherSubTypeGW;
import com.pajk.plutus.client.model.result.gw.voucher.PageVoucherGW;
import com.pajk.plutus.client.model.result.gw.voucher.VoucherGW;
import net.pocrd.annotation.*;
import net.pocrd.define.CommonParameter;
import net.pocrd.define.SecurityType;

/**
 * Created by  guguangming on 2017/12/13
 **/
@ApiGroup(name = "plutus", minCode = 50281000, maxCode = 50282000, codeDefine = JkApiCode.class, owner = "guguangming@jk.cn")
public interface DepositQueryGWService {

    @HttpApi(owner = "guguangming@jk.cn", desc = "[保证金]分页查询收支明细列表",
            name = "plutus.pageQuerySellerBookFlow", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_NO_PERMISSION_TO_VIEW,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
            JkApiCode.C_QUERY_INTERVAL_OVER_THRESHOLD
    })
    PageAccountBookFlowGW pageQuerySellerBookFlow(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiParameter(required = true, name = "sellerId", desc = "商家Id") long sellerId,
            @ApiParameter(required = true, name = "flowType", desc = "流水类型 如 缴费单 1000  违规单2000 全部-1") int flowType,
            @ApiParameter(required = false, name = "startTime", desc = "1、若为缴费单-为缴费成功的时间,2.违规单-确认缴费的时间,格式:yyyy-MM-dd HH:mm:ss") String startTime,
            @ApiParameter(required = false, name = "endTime", desc = "1、若为缴费单-为缴费成功的时间,2.违规单-确认缴费的时间,格式:yyyy-MM-dd HH:mm:ss") String endTime,
            @ApiParameter(required = false, name = "pageNo", desc = "页码", defaultValue = "1") int pageNo,
            @ApiParameter(required = false, name = "pageSize", desc = "每页显示条数,默认20条", defaultValue = "20") int pageSize
    );


    @HttpApi(owner = "guguangming@jk.cn", desc = "[保证金]查询保证金账户余额接口",
            name = "plutus.querySellerAccountBook", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_NO_PERMISSION_TO_VIEW,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
            JkApiCode.C_BOOK_NOT_EXISTS
    })
    AccountBookGW querySellerAccountBook(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiParameter(required = true, name = "sellerId", desc = "商家Id") long sellerId
    );

    @HttpApi(owner = "fuyongda@jk.cn", desc = "[保证金]查询单据详情接口",
            name = "plutus.querySellerVoucher", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_VIEW,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
            JkApiCode.C_VOUCHER_NOT_EXISTS,
            JkApiCode.C_VOUCHER_DELIVERY_NOT_EXISTS
    })
    VoucherGW querySellerVoucher(
            @ApiAutowired(CommonParameter.domainId) long domainId,
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiParameter(required = true, name = "sellerId", desc = "商家Id") long sellerId,
            @ApiParameter(required = true, name = "voucherId", desc = "单据id") String voucherId
    );

    @HttpApi(owner = "fuyongda@jk.cn", desc = "[保证金]查询单据详情接口 附带按钮",
            name = "plutus.querySellerOptVoucher", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_NO_PERMISSION_TO_VIEW,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR
    })
    VoucherGW querySellerOptVoucher(
            @ApiAutowired(CommonParameter.domainId) long domainId,
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiParameter(required = true, name = "sellerId", desc = "商家Id") long sellerId,
            @ApiParameter(required = true, name = "voucherId", desc = "单据id") String voucherId
    );


    @HttpApi(owner = "guguangming@jk.cn", desc = "[保证金]查询单据分页列表接口",
            name = "plutus.pageQuerySellerVoucher", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_NO_PERMISSION_TO_VIEW,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
            JkApiCode.C_QUERY_INTERVAL_OVER_THRESHOLD
    })
    PageVoucherGW pageQuerySellerVoucher(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiParameter(required = true, name = "sellerId", desc = "商家Id") long sellerId,
            @ApiParameter(required = false, name = "voucherId", desc = "单据id") String voucherId,
            @ApiParameter(required = true, name = "nodeCatKey", desc = "对应nodeCatKey后端给到全部这个值") String nodeCatKey,
            @ApiParameter(required = true, name = "voucherType", desc = "对应大类") int voucherType,
            @ApiParameter(required = false, name = "voucherSubType", desc = "类型（大类子类型）全部为-1 1001追加保证金 1002 补齐保证金等参考查询类型接口", defaultValue = "-1") int voucherSubType,
            @ApiParameter(required = false, name = "commitStart", desc = "商家接收时间  即商管或系统提交时间") String commitStart,
            @ApiParameter(required = false, name = "commitEnd", desc = "商家接收时间  即商管或系统提交时间") String commitEnd,
            @ApiParameter(required = false, name = "pageNo", desc = "页码", defaultValue = "1") int pageNo,
            @ApiParameter(required = false, name = "pageSize", desc = "每页显示条数,默认20条", defaultValue = "20") int pageSize
    );

    @HttpApi(owner = "fuyongda@jk.cn", desc = "[保证金]根据单据类型查询下拉框列表",
            name = "plutus.queryStatusByType", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_NO_PERMISSION_TO_VIEW,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR
    })
    BatchNodeCatKeyGW queryStatusByType(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiParameter(required = true, name = "sellerId", desc = "商家Id") long sellerId,
            @ApiParameter(required = true, name = "voucherType", desc = "单据类型如1000缴费单 2000违规单") int voucherType
    );


    @HttpApi(owner = "guguangming@jk.cn", desc = "[保证金]根据单据大类查询的单据子类型",
            name = "plutus.queryVoucherSubType", security = SecurityType.UserLogin)
    @DesignedErrorCode({
            JkApiCode.C_NO_PERMISSION_TO_OPT,
            JkApiCode.C_NO_PERMISSION_TO_VIEW,
            JkApiCode.C_EXCEPTION,
            JkApiCode.C_PARAM_ERROR,
    })
    BatchVoucherSubTypeGW queryVoucherSubType(
            @ApiAutowired(CommonParameter.applicationId) long appId,
            @ApiAutowired(CommonParameter.userId) long userId,
            @ApiParameter(required = true, name = "sellerId", desc = "商家Id") long sellerId,
            @ApiParameter(required = true, name = "voucherType", desc = "单据类型 1000缴费单  2000 违规单") int voucherType,
            @ApiParameter(required = true, name = "isCanHandleCreate", desc = "是否是可手动操作的, true查询的为可以手动创建的类型, false查询的是全部") boolean isCanHandleCreate
    );
}
