package com.pajk.plutus.client.model.result.gw.account;

import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * Created by  guguangming on 2017/12/13
 **/
@Description("账户余额")
public class AccountBookGW implements Serializable {
    private static final long serialVersionUID = -6462336260829911503L;

    @Description("商户id")
    public long sellerId;

    @Description("商户名称")
    public String sellerName;

    @Description("合同金额")
    public long contractAmt;

    @Description("余额 单位分")
    public long balanceAmt;

}
