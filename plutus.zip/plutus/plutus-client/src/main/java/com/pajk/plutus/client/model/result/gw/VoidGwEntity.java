package com.pajk.plutus.client.model.result.gw;

import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * Created by  guguangming on 2017/12/13
 **/
@Description("不需要返回结果类")
public class VoidGwEntity implements Serializable {

    @Description("不需要返回结果, 只需要关注返回的errCode")
    public String value ;
}
