package com.pajk.plutus.client.model.result.gw.process;

 import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * Created by lizhijun on 2017/12/14.
 */
@Description("节点类")
public class NodeCatKeyGW implements Serializable {
    private static final long serialVersionUID = 5702737998130647997L;

    @Description("节点key")
    public String key;

    @Description("节点中文名称")
    public String name;

}
