package com.pajk.plutus.client.model.result.gw.bill;

import net.pocrd.annotation.Description;

import java.io.Serializable;
import java.util.List;

/**
 * Created by dutianyi on 2017/12/14.
 */
@Description("平安对应发票信息，取自seller_invoice_info表，seller_id=1，没确认开票的发票信息取自此表")
public class SettlementGW implements Serializable {
    private static final long serialVersionUID = 4536505932900493216L;
    @Description("统计月份,格式:yyyy-MM")
    public String month;

    @Description("结算类型, PA_RECEIPT:平安应收, PA_PAY:平安应付")
    public String settlementType;

    @Description("收款方式、合作模式, PAY_TO_SELLER:平台模式, PAY_TO_PLATEFORM:自营模式")
    public String payToType;

    @Description("待确认金额(分)")
    public long	billAmt;

    @Description("商家确认金额(分)")
    public long	actualBillAmt;

    @Description("商户看到的账单节点状态（中文描述）")
    public String nodeCatKeyName;

    @Description("账单id")
    public long	billId;

    @Description("发票本金(分)")
    public long	invoiceAmt;

    @Description("发票税额(分)")
    public long	invoiceTaxAmt;

    @Description("寄送发票物流单号")
    public String invoiceTrackingNumber;

    @Description("发票id号")
    public String invoiceId;

    @Description("支付流水号")
    public String paymentNo;

    @Description("支付附件url，根据paymentFileId去tfs获取文件url")
    public String paymentFileUrl;

    @Description("支付附件名称")
    public String paymentFileName;

    @Description("发票信息快照表，发票确认之后的账单发票信息")
    public InvoiceSnapshotGW invoiceSnapshot;

    @Description("账户信息快照表，付款确认之后的账户信息")
    public AccountSnapshotGW accountSnapshot;

    @Description("操作按钮，真正的流程操作动作")
    public List<CascadeButtonGW> actionButtons;
}
