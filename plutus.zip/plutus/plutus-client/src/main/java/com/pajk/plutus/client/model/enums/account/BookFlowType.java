package com.pajk.plutus.client.model.enums.account;

/**
 * Created by lizhijun on 2017/12/14.
 */

import java.util.LinkedList;
import java.util.List;

/**
 * 账本流水类型
 */
public enum BookFlowType {
    PAYMENT    (1000, "缴费单"    , true   ),
    VIOLATION  (2000, "违规单", true    ),
    //COMPENSATE (3000, "赔偿单(扣保证金扣积分)", false   ),
    //TO_ZERO    (4000, "清零单(清算保证金和积分)",false ),
    UNKNOWN    (9999 , "未知"                    ,false)

    ;
    private int code;
    private String desc;
    private boolean canShow;


    BookFlowType(int code, String desc, boolean canShow){
        this.code = code;
        this.desc = desc;
        this.canShow = canShow;
    }

    public String getDesc() {
        return desc;
    }

    public int getCode() {
        return code;
    }

    public boolean getCanShow(){
        return canShow;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(BookFlowType item) {
        return null != item && isEquals(item.getCode());
    }

    public static BookFlowType valueOf(int code){
        for(BookFlowType item: values()){
            if(item.isEquals(code)){
                return item;
            }
        }
        return UNKNOWN;
    }

    public static List<BookFlowType> getCanShowList(){
        List<BookFlowType> canShowList = new LinkedList<>();
        for(BookFlowType item: values()){
            if(item.getCanShow()){
                canShowList.add(item);
            }
        }

        return canShowList;
    }
}
