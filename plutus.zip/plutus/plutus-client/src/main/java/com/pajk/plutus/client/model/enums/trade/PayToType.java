package com.pajk.plutus.client.model.enums.trade;

/**
 * Created by arjaylv on 2017/12/13.
 *
 * @author arjaylv
 */
public enum PayToType {
    PAY_TO_NO(0, "无收款方"),
    PAY_TO_PLATFORM(1, "平台收款"),
    PAY_TO_SELLER(2, "商家收款");

    private int code;
    private String desc;

    PayToType(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(PayToType item) {
        return null != item && isEquals(item.getCode());
    }

    public static PayToType valueOf(int code) {
        for (PayToType payToType : values()) {
            if (payToType.isEquals(code)) {
                return payToType;
            }
        }
        return PAY_TO_NO;
    }
}
