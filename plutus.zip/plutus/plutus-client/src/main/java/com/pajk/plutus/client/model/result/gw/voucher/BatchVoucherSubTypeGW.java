package com.pajk.plutus.client.model.result.gw.voucher;

import net.pocrd.annotation.Description;

import java.io.Serializable;
import java.util.List;

/**
 * Created by  guguangming on 2017/12/15
 **/
@Description("批量返回单据子类")
public class BatchVoucherSubTypeGW implements Serializable {

    private static final long serialVersionUID = 970237998122647997L;

    @Description("子类集合")
    public List<VoucherSubTypeGW> voucherSubTypes;
}
