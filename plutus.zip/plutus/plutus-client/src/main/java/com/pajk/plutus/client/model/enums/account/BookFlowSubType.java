package com.pajk.plutus.client.model.enums.account;

/**
 * Created by lizhijun on 2017/12/14.
 */

/**
 * 账本流水子类型
 */
public enum BookFlowSubType {
    ADD_DEPOSIT              (1001, "+", "payment" ,          BookFlowType.PAYMENT, "合同缴费"   ),
    PAY_IN_BACK_DEPOSIT      (1002, "+", "payment" ,          BookFlowType.PAYMENT, "补充缴费"   ),
    //REFUND_DEPOSIT           (1003, "-", "payment2",          BookFlowType.PAYMENT, "退保证金"   ),
    //ADD_ANNUAL_FEE           (1101, "+",  ""       ,          BookFlowType.PAYMENT, "缴技术服务年费"   ),
    //CREDITS_EXCHANGE         (1201, "+",  ""       ,          BookFlowType.PAYMENT, "服务费现金换积分"),

    DELAY_DELIVERY_VIOLATION (2001, "-", "violationDelivery", BookFlowType.VIOLATION, "发货延迟" ),
    FAKE_VIOLATION           (2002, "-", "violationComm" ,    BookFlowType.VIOLATION, "假货" ),
    FALSE_CONDUCT_VIOLATION  (2003, "-", "violationComm" ,    BookFlowType.VIOLATION, "虚假宣传" ),

    //USER_COMPENSATE          (3001, "-", "",                  BookFlowType.COMPENSATE, "用户赔偿"),

    //TO_ZERO                  (4001, "", "",                   BookFlowType.TO_ZERO, "清零(保证金, 积分 多个账本清零)"   ),

    UNKNOWN                  (9999, "", "",                   null,                "未知"                  ),
    ;

    private int code;
    // 金额符号 "+ 或者 -"
    private String symbol;
    //流程模版名
    private String procName;
    //所属单据大类
    private BookFlowType parent;
    private String desc;

    BookFlowSubType(int code,String symbol,String procName,BookFlowType parent,String desc){
        this.code = code;
        this.symbol = symbol;
        this.procName = procName;
        this.parent = parent;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public int getCode() {
        return code;
    }

    public String getProcName() {
        return procName;
    }

    public String getSymbol() {
        return symbol;
    }

    public BookFlowType getParent() {
        return parent;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(BookFlowSubType item) {
        return null != item && isEquals(item.getCode());
    }

    public static BookFlowSubType valueOf(int code){
        for(BookFlowSubType item: values()){
            if(item.isEquals(code)){
                return item;
            }
        }
        return UNKNOWN;
    }
}
