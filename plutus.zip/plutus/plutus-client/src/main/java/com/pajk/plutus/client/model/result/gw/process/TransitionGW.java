package com.pajk.plutus.client.model.result.gw.process;

import net.pocrd.annotation.Description;

/**
 * Created by  guguangming on 2017/12/19
 **/
@Description("表示详情中操作按钮属性")
public class TransitionGW {

    @Description("按钮名称")
    public String transitionName ;

    @Description("按钮key 做参数请求地址参数传递")
    public String transitionKey ;

    @Description("对应 弹出框提示文案")
    public String tips ;
}
