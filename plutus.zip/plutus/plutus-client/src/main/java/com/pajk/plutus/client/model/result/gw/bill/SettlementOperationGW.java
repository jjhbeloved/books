package com.pajk.plutus.client.model.result.gw.bill;

import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * @author david
 * @since created by on 17/12/21 14:21
 */
@Description("结算操作记录")
public class SettlementOperationGW implements Serializable {

    private static final long serialVersionUID = 1132913967780286539L;

    @Description("节点状态，nodeKey文案")
    public String operationDesc;

    @Description("任务分配时间, 格式:yyyy-MM-dd HH:mm:ss")
    public String operationStartTime;

    @Description("实际审批时间, 格式:yyyy-MM-dd HH:mm:ss")
    public String operationEndTime;

    @Description("审批角色")
    public String operationRole;

    @Description("审批意见")
    public String operationVote;

    @Description("审批备注")
    public String operationMemo;


}
