package com.pajk.plutus.client.model.enums.voucher;

/**
 * Created by lizhijun on 2017/12/14.
 */

/**
 * 单据类型
 */
public enum VoucherType {
    PAYMENT    (1000, "缴费单"   , "缴钱缴积分"       ),
    VIOLATION  (2000, "违规单"   , "扣保证金扣积分"   ),
    //COMPENSATE (3000, "赔偿单"   , "扣保证金扣积分"   ),
    //TO_ZERO    (4000, "清零单"   , "清算保证金和积分" ),
    UNKNOWN    (9999 , "未知"    , ""                 )

    ;
    private int code;
    private String desc;
    private String remark;

    VoucherType(int code, String desc, String remark){
        this.code = code;
        this.desc = desc;
        this.remark = remark;
    }

    public String getDesc() {
        return desc;
    }

    public int getCode() {
        return code;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(VoucherType item) {
        return null != item && isEquals(item.getCode());
    }

    public static VoucherType valueOf(int code){
        for(VoucherType item: values()){
            if(item.isEquals(code)){
                return item;
            }
        }
        return UNKNOWN;
    }
}
