package com.pajk.plutus.client.model.enums.account;

/**
 * Created by lizhijun on 2017/12/14.
 * 账本类型
 */
public enum BookType {
    DEPOSIT       ( 1     , "保证金" ) ,
    INTEGRATION   ( 2     , "积分"   ) ,
    GIFT          ( 3     , "馈赠金" ) ,
    ANNUAL_FEE    ( 4     , "年费"   ) ,
    UNKNOWN       ( 99999 , "未知"   ) ,
    ;

    private int code;
    private String desc;

    BookType(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(BookType item) {
        return null != item && isEquals(item.getCode());
    }

    public static BookType valueOf(int code){
        for(BookType item: values()){
            if(item.isEquals(code)){
                return item;
            }
        }
        return UNKNOWN;
    }
}
