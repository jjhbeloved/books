package com.pajk.plutus.client.model.result.gw.voucher;

import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * Created by  guguangming on 2017/12/13
 **/
@Description("上传附件信息")
public class FileInfoGW implements Serializable {
    private static final long serialVersionUID = 4742738998130647997L;

    @Description("文件TFS地址")
    public String fileKey;

    @Description("文件名称")
    public String fileName;
}
