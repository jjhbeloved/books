package com.pajk.plutus.client.model.result;

import net.pocrd.entity.AbstractReturnCode;

import java.io.Serializable;

/**
 * Created by guguangming on 2017/12/13
 */
public class JkApiCode extends AbstractReturnCode implements Serializable {
    /***************[50281000, 50282000)为基础错误信息***********************************/

    public static final int C_NO_PERMISSION_TO_VIEW = 50281001;
    public static final JkApiCode NO_PERMISSION_TO_VIEW =
            new JkApiCode("没有权限查看", C_NO_PERMISSION_TO_VIEW);

    public static final int C_NO_PERMISSION_TO_OPT = 50281002;
    public static final JkApiCode NO_PERMISSION_TO_OPT =
            new JkApiCode("没有权利操作", C_NO_PERMISSION_TO_OPT);

    public static final int C_EXCEPTION = 50281003;
    public static final JkApiCode EXCEPTION =
            new JkApiCode("发生异常", C_EXCEPTION);

    public static final int C_QUERY_FAILURE = 50281004;
    public static final JkApiCode QUERY_FAILURE =
            new JkApiCode("查询失败", C_QUERY_FAILURE);

    public static final int C_PARAM_ERROR = 50281005;
    public static final JkApiCode PARAM_ERROR =
            new JkApiCode("参数错误", C_PARAM_ERROR);

    public static final int C_FAILURE = 50281006;
    public static final JkApiCode FAILURE =
            new JkApiCode("失败", C_FAILURE);

    public static final int C_COUNT_OVER_MAX = 50281007;
    public static final JkApiCode COUNT_OVER_MAX =
            new JkApiCode("数量超过最大阈值", C_COUNT_OVER_MAX);

    public static final int C_QUERY_INTERVAL_OVER_THRESHOLD = 50281009;
    public static final JkApiCode QUERY_INTERVAL_OVER_THRESHOLD =
            new JkApiCode("查询区间超过阈值", C_QUERY_INTERVAL_OVER_THRESHOLD);

    public static final int C_QUERY_TIME_ILLEGAL = 50281010;
    public static final JkApiCode QUERY_TIME_ILLEGAL =
            new JkApiCode("查询时间不合法", C_QUERY_TIME_ILLEGAL);

    public static final int C_STATUS_NOT_MATCH = 50281011;
    public static final JkApiCode STATUS_NOT_MATCH =
            new JkApiCode("状态不匹配", C_STATUS_NOT_MATCH);

    public static final int C_QUERY_TIME_TOO_EARLY = 50281013;
    public static final JkApiCode QUERY_TIME_TOO_EARLY =
            new JkApiCode("查询时间开始太早", C_QUERY_TIME_TOO_EARLY);


    /***************[50281101, 50281200)为自动化对账相关错误信息***********************************/
    public static final int C_BILL_NOT_EXIST = 50281015;
    public static final JkApiCode BILL_NOT_EXIST =
            new JkApiCode("账单不存在", C_BILL_NOT_EXIST);

    public static final int C_BILL_ITEM_NOT_EXIST = 50281016;
    public static final JkApiCode BILL_ITEM_NOT_EXIST =
            new JkApiCode("单据不存在", C_BILL_ITEM_NOT_EXIST);

    public static final int C_BILL_ITEM_AMT_ERROR = 50281018;
    public static final JkApiCode BILL_ITEM_AMT_ERROR =
            new JkApiCode("单据金额错误", C_BILL_ITEM_AMT_ERROR);

    public static final int C_REMARK_TOO_LONG = 50281019;
    public static final JkApiCode REMARK_TOO_LONG =
            new JkApiCode("备注长度过长", C_REMARK_TOO_LONG);

    public static final int C_INVOICE_INFO_NOT_EXIST = 50281020;
    public static final JkApiCode INVOICE_INFO_NOT_EXIST =
            new JkApiCode("发票信息不存在", C_INVOICE_INFO_NOT_EXIST);

    public static final int C_INVOICE_AMT_ERROR = 50281021;
    public static final JkApiCode INVOICE_AMT_ERROR =
            new JkApiCode("发票金额不对", C_INVOICE_AMT_ERROR);

    public static final int C_EMPTY_PAYMENT_NO = 50281022;
    public static final JkApiCode EMPTY_PAYMENT_NO =
            new JkApiCode("支付流水号为空", C_EMPTY_PAYMENT_NO);

    public static final int C_ACCOUNT_INFO_NOT_EXIST = 50281023;
    public static final JkApiCode ACCOUNT_INFO_NOT_EXIST =
            new JkApiCode("账户信息不存在", C_ACCOUNT_INFO_NOT_EXIST);

    public static final int C_PAYMENT_NO_TOO_LONG = 50281025;
    public static final JkApiCode PAYMENT_NO_TOO_LONG =
            new JkApiCode("支付流水号长度过长", C_PAYMENT_NO_TOO_LONG);

    /***************[50281201, 50281300)为保证金相关错误信息***********************************/

    public static final int C_VOUCHER_TYPE_NOT_EXISTS = 50281201;
    public static final JkApiCode VOUCHER_TYPE_NOT_EXISTS =
            new JkApiCode("单据类型不存在", C_VOUCHER_TYPE_NOT_EXISTS);

    public static final int C_VOUCHER_NOT_EXISTS = 50281202;
    public static final JkApiCode VOUCHER_NOT_EXISTS =
            new JkApiCode("单据不存在", C_VOUCHER_NOT_EXISTS);

    public static final int C_VOUCHER_DELIVERY_NOT_EXISTS = 50281203;
    public static final JkApiCode VOUCHER_DELIVERY_NOT_EXISTS = new JkApiCode(
            "违规单据违规发货扩展属性不存在", C_VOUCHER_DELIVERY_NOT_EXISTS);

    public static final int C_BOOK_NOT_EXISTS = 50281204;
    public static final JkApiCode BOOK_NOT_EXISTS = new JkApiCode(
            "账本不存在", C_BOOK_NOT_EXISTS);


    /***************[50281300, 50281400)为文件导出相关错误信息***********************************/
    public static final int C_FILE_NOT_EXIST = 50281301;
    public static final JkApiCode FILE_NOT_EXIST =
            new JkApiCode("文件不存在", C_FILE_NOT_EXIST);

    public static final int C_FILE_TYPE_ERROR = 50281302;
    public static final JkApiCode FILE_TYPE_ERROR =
            new JkApiCode("文件类型错误", C_FILE_TYPE_ERROR);

    public static final int C_FILE_MODE_ERROR = 50281303;
    public static final JkApiCode FILE_MODE_ERROR =
            new JkApiCode("文件格式错误", C_FILE_MODE_ERROR);


    public JkApiCode(String desc, int code) {
        super(desc, code);
    }

}
