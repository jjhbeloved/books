package com.pajk.plutus.client.model.result.gw.bill;

import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * @author david
 * @since created by on 17/12/13 20:03
 */
@Description("单据明细")
public class SettlementItemConfirmGW implements Serializable {

    private static final long serialVersionUID = -7994268412292844650L;

    @Description("单据项id")
    public long id;

    @Description("商家确认金额(分), 每项单据明细想加的值为bill_settlement的商家确认总金额字段的值")
    public long actualBillAmt;
}
