package com.pajk.plutus.client.model.enums.account;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by lizhijun on 2017/12/14.
 */

/**
 * 财务应收应付来源(类型)
 */
public enum StatementOutType {
    FC_VOUCHER("fc_voucher", "商城保证金系统单据"),
    FC_BILL("fc_bill", "商城对账系统单据"),
    UNKNOWN("unknown", "未知");
    private String code;
    private String desc;

    StatementOutType(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public String getCode() {
        return code;
    }

    public boolean isEquals(String code) {
        return StringUtils.equals(this.code, code);
    }

    public boolean isEquals(StatementOutType item) {
        return null != item && isEquals(item.getCode());
    }

    public static StatementOutType valueOfCode(String code) {
        for (StatementOutType item : values()) {
            if (item.isEquals(code)) {
                return item;
            }
        }
        return UNKNOWN;
    }
}
