package com.pajk.plutus.client.model.result.gw.voucher;

import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * Created by guguangming on 2017/12/13
 */
@Description("违规发货扩展信息")
public class VoucherDeliveryGW implements Serializable {
    private static final long serialVersionUID = 3374137998130647997L;

    @Description("订单id")
    public String tradeId;

    @Description("支付时间")
    public String payTime;

    @Description("物流揽收时间")
    public String lgTime;

    @Description("物流时间")
    public String deliveryTime;

    @Description("物流运单号")
    public String trackingNumber;

    @Description("物流公司id")
    public String companyId;

    @Description("物流公司名称")
    public String companyName;

    @Description("收货地址(省和市)")
    public String address;

    @Description("交易金额(单位分)")
    public long amount;

    @Description("交易类型")
    public String payMode;

}
