package com.pajk.plutus.client.model.result.gw.account;

import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * Created by  guguangming on 2017/12/13
 **/
@Description("退款订单")
public class AccountBookFlowGW implements Serializable {

    private static final long serialVersionUID = -6462336260829910503L;

    @Description("单据id")
    public String voucherId;

    @Description("类型")
    public String flowType;

    @Description("金额")
    public long amount;

    @Description("时间")
    public String gmtFinish;

}
