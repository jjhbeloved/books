package com.pajk.plutus.client.model.enums.account;

/**
 * Created by lizhijun on 2017/12/14.
 */

/**
 * 财务科目
 */
public enum SubjectEnum {
    DEPOSIT(1, "合同保证金"),
    SERVICE_FEE(2, "保证金服务费"),
    PTMS_PAYS(3, "平台模式-平安应收"),
    PTMS_PAYF(4, "平台模式-平安应付"),
    ZYMS_PAYF(5, "自营模式-平安应付"),
    UNKNOWN(9999, "未知"),;

    private int code;
    private String desc;

    SubjectEnum(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public int getCode() {
        return code;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(SubjectEnum item) {
        return null != item && isEquals(item.getCode());
    }

    public static SubjectEnum valueOf(int code) {
        for (SubjectEnum item : values()) {
            if (item.isEquals(code)) {
                return item;
            }
        }
        return UNKNOWN;
    }
}
