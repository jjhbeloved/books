package com.pajk.plutus.client.model.enums.seller;

/**
 * Created by lizhijun on 2017/12/17.
 */
public enum SellerServiceType {
    B2C      (700, "B2C"       ),
    O2O      (1000, "O2O"        ),
    BBDB_B2C (500, "BBDB_B2C"   ),
    UNKNOWN  (9999 , "未知"     )
    ;
    private int code;
    private String desc;

    SellerServiceType(int code, String desc){
        this.code = code;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public int getCode() {
        return code;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(SellerServiceType item) {
        return null != item && isEquals(item.getCode());
    }

    public static SellerServiceType valueOf(Integer code){
        if(null == code){
            return UNKNOWN;
        }
        for(SellerServiceType item: values()){
            if(item.isEquals(code)){
                return item;
            }
        }
        return UNKNOWN;
    }

}
