package com.pajk.plutus.client.model.result.gw.bill;

import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * @author david
 * @since created by on 17/12/13 19:30
 */
@Description("结算商品信息")
public class SettlementItemGW implements Serializable {

    private static final long serialVersionUID = 7481802695868349079L;

    @Description("单据项id")
    public long id;

    @Description("单据id")
    public long billId;

    @Description("单据类型")
    public String billType;

    @Description("账单金额(分)")
    public long billAmt;

    @Description("商家确认金额(分)")
    public long actualBillAmt;

}
