package com.pajk.plutus.client.model.enums.account;

/**
 * Created by lizhijun on 2017/12/14.
 */

/**
 * 账本状态
 */
public enum BookStatus {
    INVALID       ( 0    , "已冻结" ) ,
    VALID         ( 1    , "未冻结" ) ,
    UNKNOWN       ( 9999 , "未知"     )
    ;

    private int code;
    private String desc;

    BookStatus(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(BookStatus item) {
        return null != item && isEquals(item.getCode());
    }

    public static BookStatus valueOf(int code){
        for(BookStatus item: values()){
            if(item.isEquals(code)){
                return item;
            }
        }
        return UNKNOWN;
    }

}
