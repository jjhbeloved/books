package com.pajk.plutus.client.model.topic;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by lizhijun on 2017/8/17.
 */
public enum KylinTopic implements ITopic{
    /*====== 订单级别消息 ======*/
    KYLIN_ADD_SELLER  ("KYLIN" , "KYLIN_ADD_SELLER" , "创建商户" ),

    ;

    /**
     * 主题
     */
    private String topic;

    /**
     * 标签
     */
    private String tags;

    /**
     * 描述
     */
    private String desc;

    KylinTopic(String topic, String tags, String desc) {
        this.topic = topic;
        this.tags = tags;
        this.desc = desc;
    }

    @Override
    public String getTopic() {
        return topic;
    }

    @Override
    public String getTags() {
        return tags;
    }

    public String getDesc() {
        return desc;
    }

    @Override
    public String getTopicStr() {
        return topic + "," + tags;
    }

    public boolean isEquals(String topic, String tags) {
        return  StringUtils.equals(getTopic(), topic)
                && StringUtils.equals(getTags(), tags);
    }

}
