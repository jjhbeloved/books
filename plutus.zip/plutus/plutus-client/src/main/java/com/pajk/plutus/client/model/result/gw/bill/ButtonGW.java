package com.pajk.plutus.client.model.result.gw.bill;

import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * @author david
 * @since created by on 17/12/13 19:31
 */
@Description("流程按钮")
public class ButtonGW implements Serializable {

    private static final long serialVersionUID = 8717331402348417437L;

    @Description("操作按钮中文展示, transitionName的值")
    public String name;

    @Description("操作按钮的key, transitionKey的值")
    public String key;

    @Description("流程操作接口名称apiName")
    public String path;
}
