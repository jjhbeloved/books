package com.pajk.plutus.client.model.result.gw.process;

import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * Created by guguangming on 2017/12/13
 */
@Description("审批记录")
public class AuditFlowGW implements Serializable {

    private static final long serialVersionUID = 5742737998130642397L;

    @Description("审批备注")
    public String remark;

    @Description("分配时间格式 yyyy-MM-dd HH:mm:ss")
    public String allocatingTime;

    @Description("审批时间 格式 yyyy-MM-dd HH:mm:ss")
    public String auditTime;

    @Description("审批角色")
    public String role;

    @Description("描述 对应文案中心配置值")
    public String nodeKeyDesc;

    @Description("审批意见")
    public String transitionName;

}
