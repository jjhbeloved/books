package com.pajk.plutus.client.model.enums.voucher;

/**
 * Created by  guguangming on 2017/12/17
 **/
public enum  VoucherDeleteFlag {
    NOT_DELETE    (0,     "未删除"),
    IS_DELETE (1,     "已经删除"),
    UNKNOWN     ( 9999 , "未知"  );

    private int code;
    private String desc;

    VoucherDeleteFlag(int code, String desc){
        this.code = code;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public int getCode() {
        return code;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(VoucherPayFlag item) {
        return null != item && isEquals(item.getCode());
    }

    public static VoucherDeleteFlag valueOf(int code){
        for(VoucherDeleteFlag item: values()){
            if(item.isEquals(code)){
                return item;
            }
        }
        return UNKNOWN;
    }
}
