package com.pajk.plutus.client.model.result.gw.bill;

import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * Created by dutianyi on 2017/12/14.
 */
@Description("平安对应发票信息，取自seller_invoice_info表，seller_id=1，没确认开票的发票信息取自此表")
public class InvoiceSnapshotGW implements Serializable {
    private static final long serialVersionUID = -8580101796265043208L;
    @Description("发票抬头")
    public String invoiceTitle;

    @Description("发票联系人")
    public String contact;

    @Description("发票联系人电话")
    public String contactTel;

    @Description("发票地址信息")
    public String invoiceAddress;

    @Description("纳税人识别号")
    public String taxpayerNumber;

    @Description("发票电话信息")
    public String invoiceTel;

    @Description("发票寄送地址")
    public String address;

    @Description("发票开户行信息")
    public String invoiceBankName;

    @Description("发票开户行账户信息")
    public String invoiceBankAccount;
}
