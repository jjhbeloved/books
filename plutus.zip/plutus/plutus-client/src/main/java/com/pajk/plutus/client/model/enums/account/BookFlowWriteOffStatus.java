package com.pajk.plutus.client.model.enums.account;

/**
 * Created by lizhijun on 2017/12/14.
 */

/**
 * 账本流水销帐状态
 */
public enum BookFlowWriteOffStatus {
    NO_WRITE_OFF (0,     "未销帐"),
    WRITE_OFF    (1,     "已销帐"),
    UNKNOWN      (9999 , "未知"  )
    ;

    private int code;
    private String desc;

    BookFlowWriteOffStatus(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isEquals(int code) {
        return this.code == code;
    }

    public boolean isEquals(BookFlowWriteOffStatus item) {
        return null != item && isEquals(item.getCode());
    }

    public static BookFlowWriteOffStatus valueOf(int code){
        for(BookFlowWriteOffStatus item: values()){
            if(item.isEquals(code)){
                return item;
            }
        }
        return UNKNOWN;
    }

}
