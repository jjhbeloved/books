package com.pajk.plutus.client.model.result.gw.bill;

import net.pocrd.annotation.Description;

import java.io.Serializable;

/**
 * Created by dutianyi on 2017/12/14.
 */
@Description("平安对应发票信息，取自seller_invoice_info表，seller_id=1，没确认开票的发票信息取自此表")
public class SellerAccountGW implements Serializable {
    private static final long serialVersionUID = -2466534478016635290L;
    @Description("收款的银行账户")
    public String purchaserAccount;

    @Description("收款的银行账户名称")
    public String purchaserAccountName;

    @Description("收款的开户行")
    public String purchaserBankName;
}
