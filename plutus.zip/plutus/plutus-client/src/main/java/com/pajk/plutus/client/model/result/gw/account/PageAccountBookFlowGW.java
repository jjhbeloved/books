package com.pajk.plutus.client.model.result.gw.account;

import net.pocrd.annotation.Description;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by  guguangming on 2017/12/13
 **/
@Description("保证金收支明细列表页")
public class PageAccountBookFlowGW implements Serializable {
    private static final long serialVersionUID = 5742737998130647997L;

    @Description("分页总数")
    public int totalCount;

    @Description("每页数量")
    public int pageSize;

    @Description("页码")
    public int pageNo;

    @Description("保证金收支明细列表")
    public List<AccountBookFlowGW> depositFlows = new LinkedList<>();
}
