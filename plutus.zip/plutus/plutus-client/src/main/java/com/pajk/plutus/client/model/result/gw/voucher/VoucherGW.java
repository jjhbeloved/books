package com.pajk.plutus.client.model.result.gw.voucher;

import com.pajk.plutus.client.model.result.gw.process.AuditFlowGW;
import com.pajk.plutus.client.model.result.gw.process.TransitionGW;
import net.pocrd.annotation.Description;

import java.io.Serializable;
import java.util.List;

/**
 * Created by guguangming on 2017/12/13
 */
@Description("商家单据详情接口")
public class VoucherGW implements Serializable {

    private static final long serialVersionUID = 9042737998130647997L;

    @Description("单据id")
    public String voucherId;

    @Description("单据大类 String类型前台展示")
    public String voucherType;

    @Description("单据子类  String类型前台展示")
    public String voucherSubType;

    @Description("金额(单位分)")
    public long amount;

    @Description("扩展key3表示操作按钮的文案")
    public String nodeCatKeyName;

    @Description("表示数据库node_key")
    public String nodeKey;

    @Description("发起备注")
    public String createRemark;

    @Description("发起附件集合")
    public List<FileInfoGW> createFiles;

    @Description("证据备注")
    public String evidenceRemark;

    @Description("证据备注")
    public List<FileInfoGW> evidenceFiles;

    @Description("缴费单相关属性")
    public PaymentPropGW paymentProp;

    @Description("违规订单相关扩展属性")
    public VoucherDeliveryGW tradeDeliveryProp;

    @Description("审批记录")
    public List<AuditFlowGW> auditFlows;

    @Description("审批按钮")
    public List<TransitionGW> flowButtons;

    @Description("返回给前端api请求path")
    public String apiName;

}
