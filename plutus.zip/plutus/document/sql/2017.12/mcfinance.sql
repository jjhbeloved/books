USE mcfinance;

CREATE TABLE `bill_settlement` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id 创建流程时用作obj_id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `version` int(11) NOT NULL DEFAULT '0' COMMENT '版本号',
  `seller_id` bigint(20) NOT NULL COMMENT '卖家id',
  `bill_no` bigint(20) NOT NULL COMMENT '单据编号 idgen生成',
  `month` date NOT NULL COMMENT '统计月份\nBI中获取的数据是yyyy-MM字符串格式，为了更好的支持范围查询，保存的时候类型变为date型，默认日期为1号',
  `pay_to_type` tinyint(3) NOT NULL COMMENT '收款方式、合作模式 1:平台收款 2:商家收款',
  `settlement_type` tinyint(3) NOT NULL COMMENT '结算类型 1:平安应收 2:平安应付',
  `bill_amt` bigint(20) NOT NULL DEFAULT '0' COMMENT '对账总金额(分)',
  `actual_bill_amt` bigint(20) NOT NULL DEFAULT '0' COMMENT '实际确认对账总金额(分)\n默认为bill_amt的值',
  `proc_inst_id` bigint(20) DEFAULT NULL COMMENT '流程返回的实例id',
  `node_key` varchar(256) DEFAULT NULL COMMENT '账单状态',
  `node_cat_key` varchar(256) DEFAULT NULL COMMENT '商户看到的节点',
  `role` varchar(256) DEFAULT NULL COMMENT '当前状态可执行角色',
  `start_time` datetime DEFAULT NULL COMMENT '流程开始时间',
  `finish_time` datetime DEFAULT NULL COMMENT '流程完成时间',
  `confirm_info` varchar(2048) DEFAULT NULL COMMENT '商户账单确认上传的附件信息 JSON字符串格式',
  `payment_info` varchar(2048) DEFAULT NULL COMMENT '确认支付时提交的相关信息 JSON字符串格式',
  `invoice_info` varchar(2048) DEFAULT NULL COMMENT '发票信息 JSON字符串格式 发票本金+发票税额=实际确认对账金额(分)',
  `ext_props` varchar(2048) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_seller_month` (`seller_id`,`month`,`pay_to_type`,`settlement_type`),
  UNIQUE KEY `uniq_bill_no` (`bill_no`),
  KEY `idx_month` (`month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='账单-对账月结算总表';


CREATE TABLE `bill_settlement_item` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `version` int(11) NOT NULL DEFAULT '0' COMMENT '版本号',
  `seller_id` bigint(20) NOT NULL COMMENT '卖家id',
  `bill_id` bigint(20) NOT NULL COMMENT '账单id',
  `bill_type` tinyint(3) NOT NULL COMMENT '单据类型',
  `bill_amt` bigint(20) NOT NULL DEFAULT '0' COMMENT '单据金额(分)',
  `actual_bill_amt` bigint(20) NOT NULL DEFAULT '0' COMMENT '实际确认单据金额(分)\n默认bill_amt的值',
  PRIMARY KEY (`id`),
  KEY `idx_seller_id` (`seller_id`,`bill_id`),
  KEY `idx_bill_id` (`bill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='账单-对账月结算项';


CREATE TABLE `bill_log` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `bill_id` bigint(20) NOT NULL COMMENT '账单id',
  `seller_id` bigint(20) DEFAULT NULL COMMENT '记录商户操作时的商户id，平安操作时为空',
  `operator_id` varchar(64) NOT NULL COMMENT '操作者id(用户id)',
  `operator_name` varchar(64) NOT NULL COMMENT '操作者名称(用户名称)',
  `role` varchar(64) DEFAULT NULL COMMENT '操作者角色',
  `desc` varchar(128) DEFAULT NULL COMMENT '操作描述',
  `remark` varchar(1024) DEFAULT NULL COMMENT '操作备注',
  `action` varchar(32) NOT NULL COMMENT '操作动作，账单被操作之后的状态',
  `bill_info` varchar(2048) DEFAULT NULL COMMENT '商户账单确认上传信息、开票填写信息、付款填写信息在这里也保存一份 JSON字符串格式',
  PRIMARY KEY (`id`),
  KEY `idx_bill_id` (`bill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='账单流程操作记录表';


CREATE TABLE `seller_invoice_info` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `version` int(11) NOT NULL DEFAULT '0' COMMENT '版本号',
  `seller_id` bigint(20) NOT NULL COMMENT '卖家id',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态 0:可用 1:不可用',
  `invoice_title` varchar(256) NOT NULL COMMENT '发票抬头',
  `contact` varchar(256) DEFAULT NULL COMMENT '发票联系人',
  `contact_tel` varchar(128) DEFAULT NULL COMMENT '发票联系人电话',
  `invoice_address` varchar(256) DEFAULT NULL COMMENT '发票地址信息',
  `taxpayer_number` varchar(64) NOT NULL COMMENT '纳税人识别号',
  `invoice_tel` varchar(128) DEFAULT NULL COMMENT '发票电话信息',
  `address` varchar(1024) DEFAULT NULL COMMENT '发票寄送地址',
  `invoice_bank_name` varchar(256) DEFAULT NULL COMMENT '发票开户行信息',
  `invoice_bank_account` varchar(256) DEFAULT NULL COMMENT '发票开户行账户信息',
  `invoice_type` tinyint(3) DEFAULT NULL COMMENT '发票类型 1:增值税专用发票 2:增值税普通发票',
  PRIMARY KEY (`id`),
  KEY `idx_seller_status` (`seller_id`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商户发票信息表';


CREATE TABLE `seller_account_info` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `version` int(11) NOT NULL DEFAULT '0' COMMENT '版本号',
  `seller_id` bigint(20) NOT NULL COMMENT '卖家id',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态 0:可用 1:不可用',
  `account_type` tinyint(3) NOT NULL COMMENT '账户类型 1:收款账户 2:打款账户',
  `purchaser_account` varchar(256) DEFAULT NULL COMMENT '银行账户',
  `purchaser_account_name` varchar(256) DEFAULT NULL COMMENT '银行账户名称',
  `purchaser_bank_name` varchar(256) DEFAULT NULL COMMENT '开户行',
  PRIMARY KEY (`id`),
  KEY `idx_seller_status` (`seller_id`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商户账户信息表';


CREATE TABLE `invoice_info_snapshot` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `bill_id` bigint(20) NOT NULL COMMENT '单据id',
  `invoice_title` varchar(256) DEFAULT NULL COMMENT '发票抬头',
  `contact` varchar(256) DEFAULT NULL COMMENT '发票联系人',
  `contact_tel` varchar(128) DEFAULT NULL COMMENT '发票联系人电话',
  `invoice_address` varchar(256) DEFAULT NULL COMMENT '发票地址信息',
  `taxpayer_number` varchar(64) DEFAULT NULL COMMENT '纳税人识别号',
  `invoice_tel` varchar(128) DEFAULT NULL COMMENT '发票电话信息',
  `address` varchar(1024) DEFAULT NULL COMMENT '发票寄送地址',
  `invoice_bank_name` varchar(256) DEFAULT NULL COMMENT '发票开户行信息',
  `invoice_bank_account` varchar(256) DEFAULT NULL COMMENT '发票开户行账户信息',
  `invoice_type` tinyint(3) DEFAULT NULL COMMENT '发票类型 1:增值税专用发票 2:增值税普通发票',
  PRIMARY KEY (`id`),
  KEY `idx_bill_gmt_created` (`bill_id`, `gmt_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='发票信息快照表';


CREATE TABLE `account_info_snapshot` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `bill_id` bigint(20) NOT NULL COMMENT '单据id',
  `purchaser_account` varchar(256) DEFAULT NULL COMMENT '银行账户',
  `purchaser_account_name` varchar(256) DEFAULT NULL COMMENT '银行账户名称',
  `purchaser_bank_name` varchar(256) DEFAULT NULL COMMENT '开户行',
  PRIMARY KEY (`id`),
  KEY `idx_bill_gmt_created` (`bill_id`, `gmt_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='账户信息快照表';
