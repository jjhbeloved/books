USE mcfinance;

CREATE TABLE `fc_account` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id 创建流程时用作obj_id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `version` int(11) NOT NULL DEFAULT '0' COMMENT '版本号',
  `seller_id` bigint(20) NOT NULL COMMENT '卖家id',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '是否冻结 0 冻结 1 正常',
  `name` varchar(100) NOT NULL COMMENT '账户名',
  `customer_id` varchar(128) DEFAULT NULL COMMENT '财务系统seller对应的客户id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_seller` (`seller_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='账户表';


CREATE TABLE `fc_account_book` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id 创建流程时用作obj_id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `version` int(11) NOT NULL DEFAULT '0' COMMENT '版本号',
  `seller_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '卖家id',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '是否冻结 0 已冻结 1 未冻结',
  `account_id` bigint(20) NOT NULL COMMENT '账户id',
  `book_type` tinyint(2) NOT NULL  COMMENT '类型,1保证金 2积分 3馈赠金 4 年费',
  `contract_amt` bigint(20) NOT NULL DEFAULT '0' COMMENT '合同金额(单位分)',
  `actual_contract_amt` bigint(20) NOT NULL DEFAULT '0' COMMENT '实收合同金额(单位分)',
  `balance_amt` bigint(20) NOT NULL DEFAULT '0' COMMENT '账本余额(单位分)',
  `freezing_amt` bigint(20) NOT NULL DEFAULT '0' COMMENT '冻结金额(单位分)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_acc_book_type` (`account_id`,`book_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='账本表';


CREATE TABLE `fc_account_book_flow` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `version` int(11) NOT NULL DEFAULT '0' COMMENT '版本号',
  `seller_id` bigint(20) NOT NULL COMMENT '卖家id',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '未完成0 已完成1',
  `flow_type` int(8) NOT NULL COMMENT '流水类型 如 缴费单 1000  违规单2000  赔偿单 3000',
  `flow_sub_type` int(8) NOT NULL COMMENT '流水子类型 如 追加保证金1001  补齐保证金1002  违规发货违规单2001 违规假货违规单2002  违规虚假宣传违规单2003',
  `out_type` varchar(64) NOT NULL COMMENT '外部业务渠道 如 fc_voucher',
  `out_id` varchar(64) NOT NULL COMMENT '外部业务id 如fc_voucher的voucherId',
  `book_type` tinyint(2) NOT NULL COMMENT '账本类型同fc_account_book表的book_type',
  `book_id` bigint(20) NOT NULL COMMENT '账本id',
  `amount` bigint(20) NOT NULL COMMENT '金额(单位分)',
  `gmt_statement` datetime COMMENT '账本余额增加或扣减的时间',
  `write_off_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否销帐 未销帐0 已销帐1',
  `write_off_type` varchar(64)  COMMENT '销帐来源类型如fc_voucher',
  `write_off_id` varchar(64)  COMMENT '销帐id (销帐绑定的 fc_voucher的主键(缴费单)id)',
  msg varchar(512) DEFAULT NULL COMMENT '流水说明',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_book_out` (`book_type`,`out_type`,`out_id`),
  KEY `idx_book_statement` (`book_id`,`gmt_statement`),
  KEY `idx_write_off_id` (`write_off_id`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='账本流水表';


CREATE TABLE `fc_voucher` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `version` int(11) NOT NULL DEFAULT '0' COMMENT '版本号',
  `is_deleted` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0未删除 1已删除',
  `seller_id` bigint(20) NOT NULL COMMENT '卖家id',
  `voucher_id` varchar(64) NOT NULL COMMENT '单据id 通过idgen生成',
  `voucher_type` int(8) NOT NULL COMMENT '单据类型,缴费单(缴钱缴积分)1000, 违规单(扣保证金扣积分)2000 赔偿单(扣保证金扣积分) 3000 清零单(清算保证金和积分)4000',
  `voucher_sub_type` int(8) NOT NULL COMMENT '单据子类型',
  `pay_flag` tinyint(3) NOT NULL DEFAULT '10' COMMENT '10 未处理 20 已处理 30 不需处理 ',
  `expect_amt` bigint(20) DEFAULT NULL COMMENT '应缴(扣)金额(单位分)',
  `actual_amt` bigint(20) DEFAULT NULL COMMENT '实缴(扣)金额(单位分)',
  `expect_point` bigint(20) DEFAULT NULL COMMENT '应缴(扣)积分',
  `actual_point` bigint(20) DEFAULT NULL COMMENT '实缴(扣)积分',
  `proc_inst_id` varchar(256) DEFAULT NULL COMMENT '流程引擎返回的流程id',
  `node_key` varchar(256) DEFAULT NULL COMMENT '流程节点',
  `node_cat_key` varchar(256) DEFAULT NULL COMMENT '流程noteCategory(group)',
  `role` varchar(256) DEFAULT NULL COMMENT '流程执行的角色',
  `proc_start_time` datetime DEFAULT NULL COMMENT '流程开始时间',
  `proc_end_time` datetime DEFAULT NULL COMMENT '流程完成时间',
  `obj_type` varchar(64) DEFAULT NULL COMMENT '业务类型 如trade ,sku',
  `obj_id` varchar(64) DEFAULT NULL COMMENT '	业务实体id',
  `create_remark` varchar(1024) DEFAULT NULL COMMENT '发起备注',
  `create_file` varchar(1024) DEFAULT NULL COMMENT '发起文件 格式JSON字符串 ',
  `evidence_remark` varchar(1024) DEFAULT NULL COMMENT '证据备注',
  `evidence_file` varchar(2048) DEFAULT NULL COMMENT '证据文件 格式JSON字符串',
  `ext_props` varchar(1024) DEFAULT NULL COMMENT '扩展字段 如缴费单银行流水 evidence_flow:(流水号多个隔开)',
  PRIMARY KEY (`id`),
  UNIQUE KEY uniq_voucher_id(`voucher_id`),
  KEY `idx_gmt_created` (`gmt_created`),
  KEY `idx_proc_start` (`proc_start_time`),
  KEY `idx_obj_id` (`obj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='单据表';


CREATE TABLE `fc_voucher_delivery` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `version` int(11) NOT NULL DEFAULT '0' COMMENT '版本号',
  `seller_id` bigint(20) NOT NULL COMMENT '卖家id',
  `voucher_id` varchar(64) DEFAULT NULL COMMENT '业务单据id',
  `rule_id` varchar(64) NOT NULL COMMENT '违规规则id',
  `amount` bigint(20) NOT NULL COMMENT '单据金额(单位分)(通过zeus任务计算的订单的违规金额)',
  `trade_id` varchar(64) NOT NULL COMMENT '订单id',
  `pay_mode` tinyint(2) NOT NULL COMMENT '支付方式 在线支付1或者货到付款2',
  `trade_mode` varchar(32) DEFAULT NULL COMMENT 'b2c 或者o2o ..',
  `statement_mode` tinyint(2) NOT NULL COMMENT '结算模式 1 佣金 2 结算价',
  `total_amt` bigint(20) NOT NULL COMMENT '商品总金额(现金+健康生活通)(单位分)',
  `settle_amt` bigint(20) NOT NULL COMMENT '商品结算总金额(结算价总和)(单位分)',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `create_time` datetime DEFAULT NULL COMMENT '下单时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `lg_time` datetime DEFAULT NULL COMMENT '物流揽件时间',
  `arrived_time` datetime DEFAULT NULL COMMENT '物流送达时间',
  `company_id` bigint(20) DEFAULT NULL COMMENT '物流公司公司id',
  `company_name` varchar(128) DEFAULT NULL COMMENT '物流公司名',
  `tracking_number` varchar(128) DEFAULT NULL COMMENT '运单号',
  `trace_supported` tinyint(2) DEFAULT NULL COMMENT 'NULL为没有物流单,是否有物流追踪信息 0 无 1 有',
  `u_prov` varchar(32)  NOT NULL COMMENT '省(买家收货)',
  `u_city` varchar(32)  NOT NULL COMMENT '市(买家收货)',
  `u_area` varchar(32)  NOT NULL COMMENT '区(买家收货)',
  `s_prov` varchar(32)  DEFAULT NULL COMMENT '省(卖家发货)',
  `s_city` varchar(32)  DEFAULT NULL COMMENT '市(卖家发货)',
  `s_area` varchar(32)  DEFAULT NULL COMMENT '区(卖家发货)',
  `ext_props` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`),
  UNIQUE KEY uniq_trade_id(`trade_id`),
  KEY `idx_voucher_id` (`voucher_id`),
  KEY `idx_gmt_created` (`gmt_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='违规单据违规发货扩展属性表';


CREATE TABLE `fc_voucher_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `seller_id` bigint(20) NOT NULL COMMENT '卖家id',
  `voucher_id` bigint(20) NOT NULL COMMENT '单据id',
  `opt_type` varchar(256) DEFAULT NULL COMMENT '操作类型',
  `operator` varchar(256) DEFAULT NULL COMMENT '操作人',
  `msg` varchar(128) DEFAULT NULL COMMENT '操作描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='单据操作记录表';


CREATE TABLE `fc_statement` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `version` int(11) NOT NULL DEFAULT '0' COMMENT '版本号',
  `seller_id` bigint(20) NOT NULL COMMENT '卖家id',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否完成 未完成0 已完成1',
  `out_type` varchar(64) NOT NULL COMMENT '外部业务类型 如商城财务系统账单表fc_voucher',
  `out_id` varchar(64) NOT NULL COMMENT '外部业务id',
  `subject` int(11) NOT NULL COMMENT '科目',
  `finance_id` varchar(128) DEFAULT NULL COMMENT '财务系统对应记录主键id',
  `first_time` datetime DEFAULT NULL COMMENT '应收时间',
  `second_time` datetime DEFAULT NULL COMMENT '应付时间',
  `platform_receivable` bigint(20) DEFAULT NULL COMMENT '平台应收',
  `platform_receivable_tax` bigint(20) DEFAULT NULL COMMENT '平台应收税费',
  `platform_payable` bigint(20) DEFAULT NULL COMMENT '平台应付',
  `platform_payable_tax` bigint(20) DEFAULT NULL COMMENT '平台应付税费',
  `platform_receipts` bigint(20) DEFAULT NULL COMMENT '平台实收',
  `platform_receipts_tax` bigint(20) DEFAULT NULL COMMENT '平台实收税费',
  `platform_paid` bigint(20) DEFAULT NULL COMMENT '平台实付',
  `platform_paid_tax` bigint(20) DEFAULT NULL COMMENT '平台实付税费',
  msg varchar(512) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_book_s_type` (`out_id`,`out_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='财务应收应付账单表';


CREATE TABLE `fc_violation_rule` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `version` int(11) NOT NULL DEFAULT '0' COMMENT '版本号',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '是否有效 0 无效 1 有效',
  `rule_type` tinyint(2) NOT NULL COMMENT '类型 ,发货延迟1 送达延迟 2',
  `is_deal` tinyint(2) NOT NULL DEFAULT '1' COMMENT '0 免责 1不免责',
  `level` int(11) NOT NULL DEFAULT '0' COMMENT '规则优先级 211~300 免责 111~200 短时间特殊处理 10~100通用兜底',
  `pay_mode` tinyint(2) NOT NULL COMMENT '支付模式 在线支付1 或货到付款2',
  `trade_mode` varchar(32) NOT NULL COMMENT '订单模式 如b2c 或者o2o	',
  `statement_mode` varchar(20) NOT NULL COMMENT '结算模式 1 佣金 2 结算价',
  `interval_day` int(11) NOT NULL COMMENT '计算的日期离当前多少天 8 = T+7 ,拉取订单数据过滤条件',
  `trade_time_start` datetime NOT NULL COMMENT '匹配属性,规则适用订单确认起始时间时间(在线支付支付时间 cod下单时间)',
  `trade_time_end` datetime NOT NULL COMMENT '匹配属性,规则适用订单确认结束时间时间(在线支付支付时间 cod下单时间)',
  `seller_ids` varchar(1024) DEFAULT NULL COMMENT '匹配属性,规则适用商户,多个seller,逗号隔开(不能超过50个)',
  `sku_type` varchar(64) DEFAULT NULL COMMENT '匹配属性,sku的type|subType 单个',
  `u_prov_code` varchar(10) DEFAULT NULL COMMENT '匹配属性,省编码(收货地址)',
  `u_city_code` varchar(10) DEFAULT NULL COMMENT '匹配属性,市编码(收货地址)',
  `u_area_code` varchar(10) DEFAULT NULL COMMENT '匹配属性,区编码(收货地址)',
  `u_prov` varchar(32) DEFAULT NULL COMMENT '匹配属性,省份(收货地址)',
  `u_city` varchar(32) DEFAULT NULL COMMENT '匹配属性,市(收货地址)',
  `u_area` varchar(32) DEFAULT NULL COMMENT '匹配属性,区(收货地址)',
  `s_prov_code` varchar(10) DEFAULT NULL COMMENT '匹配属性,省编号 (发货地址)',
  `s_city_code` varchar(10) DEFAULT NULL COMMENT '匹配属性,市编号 (发货地址)',
  `s_area_code` varchar(10) DEFAULT NULL COMMENT '匹配属性,区编号 (发货地址)',
  `s_prov` varchar(32) DEFAULT NULL COMMENT '匹配属性,省 (发货地址)',
  `s_city` varchar(32) DEFAULT NULL COMMENT '匹配属性,市 (发货地址)',
  `s_area` varchar(32) DEFAULT NULL COMMENT '匹配属性,区 (发货地址)',
  `latest_time` bigint(20) NOT NULL COMMENT '违规属性,物流最晚发货(即揽收时间)可使用分钟数 或最晚送达时间可使用分钟数 阀值 ',
  `min_money` bigint(20) DEFAULT NULL  COMMENT '计算属性,最小处罚金额(单位分)',
  `max_money` bigint(20) DEFAULT NULL  COMMENT '计算属性,最大处罚金额(单位分)',
  `punish_rate` bigint(20) DEFAULT NULL COMMENT '计算属性,处罚万分比率 如30% 那么值是 3000',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='违规规则表';


CREATE TABLE `fc_violation_rule_seller` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `gmt_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0 未删除 1 删除',
  `version` int(11) NOT NULL DEFAULT '0' COMMENT '版本号',
  `seller_id` bigint(20) NOT NULL COMMENT '卖家id',
  `name` varchar(100) DEFAULT NULL COMMENT '商家名',

  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_seller_id` (`seller_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='违规规则商户表';


