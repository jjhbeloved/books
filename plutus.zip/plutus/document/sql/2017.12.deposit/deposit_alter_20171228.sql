USE mcfinance;

alter table fc_voucher_log modify column msg varchar(2048) COMMENT '操作描述';