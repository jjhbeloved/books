package com.pajk.plutus.test.ut.biz.manager.voucher;

import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDAO;
import com.pajk.plutus.biz.model.query.account.VoucherPageQuery;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fuyongda on 2017/12/29.
 * Modified by fuyongda on 2017/12/29.
 */
public class PageQueryVoucherUT extends BaseVoucherManagerUT {

    @Test(description = "没有查到结果")
    public void test1() {
        VoucherPageQuery voucherPageQuery = new VoucherPageQuery();
        PageResultDTO<VoucherDO> pageResultDTO = voucherManager.pageQueryVoucher(voucherPageQuery, userParam);

        assertThat(pageResultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(pageResultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(pageResultDTO.getModel()).isEqualTo(Collections.emptyList());
        assertThat(pageResultDTO.getTotalCount()).isEqualTo(0);
    }

    @Test(description = "没有查到结果")
    public void test2() {
        int count = 2;
        Mockito.doReturn(count).when(voucherMapper).pageQueryCount(Matchers.any());

        Mockito.doReturn(null).when(voucherMapper).pageQuery(Matchers.any());

        VoucherPageQuery voucherPageQuery = new VoucherPageQuery();
        PageResultDTO<VoucherDO> pageResultDTO = voucherManager.pageQueryVoucher(voucherPageQuery, userParam);

        assertThat(pageResultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(pageResultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(pageResultDTO.getModel()).isEqualTo(Collections.emptyList());
        assertThat(pageResultDTO.getModel().size()).isEqualTo(0);
    }

    @Test(description = "成功")
    public void test3() {
        VoucherDAO voucherDAO = new VoucherDAO();

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        list.add(null);

        int count = 2;
        Mockito.doReturn(count).when(voucherMapper).pageQueryCount(Matchers.any());

        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());

        VoucherPageQuery voucherPageQuery = new VoucherPageQuery();
        PageResultDTO<VoucherDO> pageResultDTO = voucherManager.pageQueryVoucher(voucherPageQuery, userParam);

        assertThat(pageResultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(pageResultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(pageResultDTO.getTotalCount()).isEqualTo(count);
        assertThat(pageResultDTO.getModel().size()).isEqualTo(count);
    }

}
