package com.pajk.plutus.test.it.biz.manager.impl.accountmanager;

import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.test.it.BaseIT;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * Created by lizhijun on 2017/12/27.
 */
public class DoWriteOffIT extends BaseIT {

    @Autowired
    private AccountManager accountManager;

    @Test
    public void test1(){

        accountManager.doWriteOff(91);
    }
}
