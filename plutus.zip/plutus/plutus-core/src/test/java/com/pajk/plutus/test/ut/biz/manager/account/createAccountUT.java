package com.pajk.plutus.test.ut.biz.manager.account;

import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountDAO;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by  guguangming on 2018/01/03
 **/
public class createAccountUT extends BaseAccountManagerUT {

    @Test(description = "seller 不存在")
    public void test1() {
        KyCallResult<SellerDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(false);
        Mockito.doReturn(kyCallResult).when(sellerService).getSellerById(Matchers.anyLong());
        ResultDTO<VoidEntity> resultDTO = accountManager.createAccount(defaultSellerId);
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SELLER_NOT_EXISTS.getCode());
    }

    @Test(description = "幂等返回 查询当前seller  AccountDO 存在  并且全部类型账本都存在 ")
    public void test2() {
        mockSellerDO(buildSellerDO());

        Mockito.doReturn(buildAccountDAO()).when(accountMapper).queryBySeller(Matchers.anyLong());

        Mockito.doReturn(buildListAccountBookDAO()).when(accountBookMapper).queryBySeller(Matchers.anyLong());

        ResultDTO<VoidEntity> resultDTO = accountManager.createAccount(defaultSellerId);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
    }

    @Test(description = " 账户存在但是账本都不存在 ")
    public void test3() {
        mockSellerDO(buildSellerDO());

        Mockito.doReturn(buildAccountDAO()).when(accountMapper).queryBySeller(Matchers.anyLong());

        Mockito.doReturn(null).when(accountBookMapper).queryBySeller(Matchers.anyLong());

        Mockito.doReturn(1).when(accountBookMapper).create(Matchers.any(AccountBookDAO.class));


        ResultDTO<VoidEntity> resultDTO = accountManager.createAccount(defaultSellerId);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());

    }

    @Test(description = "账户账本都不存在 ")
    public void test4() {
        mockSellerDO(buildSellerDO());

        Mockito.doReturn(null).when(accountMapper).queryBySeller(Matchers.anyLong());

        Mockito.doReturn(null).when(accountBookMapper).queryBySeller(Matchers.anyLong());

        Mockito.doReturn(1).when(accountBookMapper).create(Matchers.any(AccountBookDAO.class));
        Mockito.doReturn(1).when(accountMapper).create(Matchers.any(AccountDAO.class));

        ResultDTO<VoidEntity> resultDTO = accountManager.createAccount(defaultSellerId);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());

    }

}
