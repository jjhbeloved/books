package com.pajk.plutus.test.it.biz.manager.impl.vouchermanager;

import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.permission.AuthResourceProperties;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.test.it.BaseIT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * Created by lizhijun on 2017/12/22.
 */
public class AuditPaymentIT extends BaseIT {
    @Autowired
    private VoucherManager voucherManager;

    @Test
    public void test1(){
        long sellerId = 20021820000L;
        String voucherId = "131";
        String nodeKey = "financeAuditPaymentUT";
        String transitionKey = "disAgree";
        String remark = "audit_payment_remark";
        UserParam userParam = new UserParam();

        userParam.setAppId(AuthResourceProperties.APPID);
        userParam.setDomainId(AuthResourceProperties.DOMAIN_ID);
        userParam.setUserId(20019550008L);
        ResultDTO<VoidEntity> resultDTO =  voucherManager.auditPayment(
                sellerId,voucherId,transitionKey,nodeKey,remark,userParam);
        System.out.println(resultDTO);
    }

    @Test
    public void test2(){
        long sellerId = 20021820000L;
        String voucherId = "82";
        String nodeKey = "financeAuditPaymentUT";
        String transitionKey = "agree";
        String remark = "audit_payment_remark";
        UserParam userParam = new UserParam();

//        userParam.setAppId(AuthResourceProperties.APPID);
//        userParam.setDomainId(AuthResourceProperties.DOMAIN_ID);
//        userParam.setUserId(20019550008L);
        userParam.setAppId(defaultAppId);
        userParam.setDomainId(defaultDomainId);
        userParam.setUserId(defaultUserId);
        ResultDTO<VoidEntity> resultDTO =  voucherManager.auditPayment(
                defaultSellerId,voucherId,transitionKey,nodeKey,remark,userParam);
        System.out.println(resultDTO);
    }

}
