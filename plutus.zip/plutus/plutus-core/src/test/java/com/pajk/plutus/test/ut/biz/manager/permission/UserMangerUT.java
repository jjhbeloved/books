package com.pajk.plutus.test.ut.biz.manager.permission;

import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.kylin.apigw.model.domain.UserInfoDTO;
import com.pajk.plutus.biz.manager.permission.UserManger;
import com.pajk.plutus.test.ut.BaseServiceUT;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by  guguangming on 2018/01/03
 **/
public class UserMangerUT extends BaseServiceUT {
    @InjectMocks
    protected UserManger userManger = new UserManger();




    @Test(description = "匹配到结果")
    public void testGetCurrentUserRole() {
        KyCallResult<String> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel("manager");

        Mockito.doReturn(kyCallResult).when(permissionService).getCurRole(Matchers.anyLong(), Matchers.anyLong());

        String userRole = userManger.getCurrentUserRole(defaultUserId, defaultAppId);
        assertThat(userRole).isNotNull();
        assertThat(userRole).isEqualTo("manager");
    }


 
}
