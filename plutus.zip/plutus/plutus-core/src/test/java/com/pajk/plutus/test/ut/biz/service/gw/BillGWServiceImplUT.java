package com.pajk.plutus.test.ut.biz.service.gw;

import com.google.common.collect.Lists;
import com.pajk.plutus.biz.common.util.ResultUtil;
import com.pajk.plutus.biz.manager.BillManager;
import com.pajk.plutus.biz.service.gw.BillGWServiceImpl;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.client.model.result.gw.VoidGwEntity;
import com.pajk.plutus.client.model.result.gw.bill.SettlementItemConfirmGW;
import com.pajk.plutus.test.ut.BaseGwServiceUT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import net.pocrd.dubboext.DubboExtProperty;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.testng.annotations.Test;

import java.util.LinkedList;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.doReturn;

/**
 * @author david
 * @since created by on 17/12/18 11:44
 */
public class BillGWServiceImplUT extends BaseGwServiceUT {

    @InjectMocks
    private BillGWServiceImpl billGWService;

    @Mock
    private BillManager billManager;

    private long sellerId = 700009L;

    private LinkedList<SettlementItemConfirmGW> createSettlementItemConfirmGW() {
        LinkedList<SettlementItemConfirmGW> linkedList = Lists.newLinkedList();
        SettlementItemConfirmGW billSettlementDO = new SettlementItemConfirmGW();
        billSettlementDO.id = 123L;
        billSettlementDO.actualBillAmt = 123L;
        linkedList.add(billSettlementDO);
        return linkedList;
    }

    private String createRemarkByCount(int count) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < count; i++) {
            stringBuilder.append("1");
        }
        return stringBuilder.toString();
    }

    @Test
    public void testConfirmSettlement() throws Exception {
        long billId = 1L;
        long appId = 1L;
        long userId = 1L;
        String role = "admin";
        String buttonKey = "agree";
        String confirmFileId = "x";
        String confirmFileName = "b";

        mockitoPermissionOk();

        DubboExtProperty.clearNotificaitons();
        LinkedList<SettlementItemConfirmGW> settlementItemConfirmGWS = createSettlementItemConfirmGW();
        VoidGwEntity voidGwEntity = billGWService.confirmSettlement(appId, userId, sellerId, billId,
                settlementItemConfirmGWS,
                buttonKey,
                confirmFileId, confirmFileName, createRemarkByCount(700)
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        mockitoCurrentUserRoleFail();
        voidGwEntity = billGWService.confirmSettlement(appId, userId, sellerId, billId,
                settlementItemConfirmGWS,
                buttonKey,
                confirmFileId, confirmFileName, createRemarkByCount(2)
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        mockitoCurrentUserRoleOK(role);
        voidGwEntity = billGWService.confirmSettlement(appId, userId, sellerId, billId,
                settlementItemConfirmGWS,
                buttonKey,
                confirmFileId, confirmFileName, createRemarkByCount(2)
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();


        mockitoUserInfoFail();
        voidGwEntity = billGWService.confirmSettlement(appId, userId, sellerId, billId,
                settlementItemConfirmGWS,
                buttonKey,
                confirmFileId, confirmFileName, createRemarkByCount(2)
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        mockitoUserInoOK(userId, "xb");
        ResultDTO<VoidEntity> resultDTO = ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);
        doReturn(resultDTO).when(billManager).confirmSettlement(anyLong(), any(), anyString(), any(), any());
        voidGwEntity = billGWService.confirmSettlement(appId, userId, sellerId, billId,
                settlementItemConfirmGWS,
                buttonKey,
                confirmFileId, confirmFileName, createRemarkByCount(2)
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        VoidEntity voidEntity = new VoidEntity();
        resultDTO = new ResultDTO<>(voidEntity);
        doReturn(resultDTO).when(billManager).confirmSettlement(anyLong(), any(), anyString(), any(), any());
        voidGwEntity = billGWService.confirmSettlement(appId, userId, sellerId, billId,
                settlementItemConfirmGWS,
                buttonKey,
                confirmFileId, confirmFileName, createRemarkByCount(2)
        );
        assert voidGwEntity != null;
        DubboExtProperty.clearNotificaitons();
    }

    @Test
    public void testConfirmInvoice() throws Exception {
        long billId = 1L;
        long appId = 1L;
        long userId = 1L;
        String role = "admin";
        String buttonKey = "agree";
        long invoiceAmt = 1L;
        long invoiceTaxAmt = 2L;
        String invoiceTrackingNumber = "xxx";
        String invoiceId = "123";

        mockitoPermissionOk();

        DubboExtProperty.clearNotificaitons();
        mockitoCurrentUserRoleOK(role);
        mockitoUserInoOK(userId, "xb");
        ResultDTO<VoidEntity> resultDTO = ResultUtil.returnResultDTO(ErrorCode.BILL_NOT_EXIST);
        doReturn(resultDTO).when(billManager).confirmInvoice(any(), any(), any(), anyBoolean());
        VoidGwEntity voidGwEntity = billGWService.confirmInvoice(appId, userId,
                sellerId, billId,
                invoiceAmt, invoiceTaxAmt, invoiceTrackingNumber, createRemarkByCount(0),
                buttonKey
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        voidGwEntity = billGWService.confirmInvoice(appId, userId,
                sellerId, billId,
                invoiceAmt, invoiceTaxAmt, invoiceTrackingNumber, createRemarkByCount(103),
                buttonKey
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        voidGwEntity = billGWService.confirmInvoice(appId, userId,
                sellerId, billId,
                invoiceAmt, invoiceTaxAmt, invoiceTrackingNumber, invoiceId,
                buttonKey
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        resultDTO = new ResultDTO<>(new VoidEntity());
        doReturn(resultDTO).when(billManager).confirmInvoice(any(), any(), any(), anyBoolean());
        voidGwEntity = billGWService.confirmInvoice(appId, userId,
                sellerId, billId,
                invoiceAmt, invoiceTaxAmt, invoiceTrackingNumber, invoiceId,
                buttonKey
        );
        assert voidGwEntity != null;
        DubboExtProperty.clearNotificaitons();


        mockitoCurrentUserRoleFail();
        voidGwEntity = billGWService.confirmInvoice(appId, userId,
                sellerId, billId,
                invoiceAmt, invoiceTaxAmt, invoiceTrackingNumber, invoiceId,
                buttonKey
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();
    }

    @Test
    public void testRecievieInvoice() throws Exception {
        long billId = 1L;
        long appId = 1L;
        long userId = 1L;
        String role = "admin";
        String buttonKey = "agree";

        mockitoPermissionOk();

        DubboExtProperty.clearNotificaitons();
        VoidGwEntity voidGwEntity = billGWService.receiveInvoice(appId, userId,
                sellerId, billId,
                buttonKey, createRemarkByCount(502)
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        mockitoCurrentUserRoleOK(role);
        mockitoUserInoOK(userId, "xb");
        ResultDTO<VoidEntity> resultDTO = ResultUtil.returnResultDTO(ErrorCode.BILL_ITEM_NOT_EXIST);
        doReturn(resultDTO).when(billManager).receiveInvoice(anyLong(), anyString(), any(), any());
        voidGwEntity = billGWService.receiveInvoice(appId, userId,
                sellerId, billId,
                buttonKey, createRemarkByCount(40)
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        resultDTO = new ResultDTO<>(new VoidEntity());
        doReturn(resultDTO).when(billManager).receiveInvoice(anyLong(), anyString(), any(), any());
        voidGwEntity = billGWService.receiveInvoice(appId, userId,
                sellerId, billId,
                buttonKey, createRemarkByCount(40)
        );
        assert voidGwEntity != null;
        DubboExtProperty.clearNotificaitons();

        mockitoCurrentUserRoleFail();
        voidGwEntity = billGWService.receiveInvoice(appId, userId,
                sellerId, billId,
                buttonKey, createRemarkByCount(40)
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();
    }

    @Test
    public void testConfirmPayment() throws Exception {
        long billId = 1L;
        long appId = 1L;
        long userId = 1L;
        String role = "admin";
        String buttonKey = "agree";
        String paymentFileId = "x";
        String paymentFileName = "x";

        mockitoPermissionOk();

        DubboExtProperty.clearNotificaitons();
        VoidGwEntity voidGwEntity = billGWService.confirmPayment(appId, userId,
                sellerId, billId,
                createRemarkByCount(102), buttonKey,
                paymentFileId, paymentFileName
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        voidGwEntity = billGWService.confirmPayment(appId, userId,
                sellerId, billId,
                createRemarkByCount(0), buttonKey,
                paymentFileId, paymentFileName
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        mockitoCurrentUserRoleOK(role);
        mockitoUserInoOK(userId, "xb");
        ResultDTO<VoidEntity> resultDTO = ResultUtil.returnResultDTO(ErrorCode.INVOICE_AMT_ERROR);
        doReturn(resultDTO).when(billManager).confirmPayment(any(), any(), any(), anyBoolean());
        voidGwEntity = billGWService.confirmPayment(appId, userId,
                sellerId, billId,
                createRemarkByCount(2), buttonKey,
                paymentFileId, paymentFileName
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        resultDTO = new ResultDTO<>(new VoidEntity());
        doReturn(resultDTO).when(billManager).confirmPayment(any(), any(), any(), anyBoolean());
        voidGwEntity = billGWService.confirmPayment(appId, userId,
                sellerId, billId,
                createRemarkByCount(2), buttonKey,
                paymentFileId, paymentFileName
        );
        assert voidGwEntity != null;
        DubboExtProperty.clearNotificaitons();

        mockitoCurrentUserRoleFail();
        voidGwEntity = billGWService.confirmPayment(appId, userId,
                sellerId, billId,
                createRemarkByCount(2), buttonKey,
                paymentFileId, paymentFileName
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();
    }

    @Test
    public void testConfirmReceivePayment() throws Exception {
        long billId = 1L;
        long appId = 1L;
        long userId = 1L;
        String role = "admin";
        String buttonKey = "agree";

        mockitoPermissionOk();

        DubboExtProperty.clearNotificaitons();
        VoidGwEntity voidGwEntity = billGWService.confirmReceivePayment(appId, userId,
                sellerId, billId,
                buttonKey, createRemarkByCount(700)
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        mockitoCurrentUserRoleOK(role);
        mockitoUserInoOK(userId, "xb");
        ResultDTO<VoidEntity> resultDTO = ResultUtil.returnResultDTO(ErrorCode.ERROR);
        doReturn(resultDTO).when(billManager).confirmReceivePayment(anyLong(), anyString(), any(), any());
        voidGwEntity = billGWService.confirmReceivePayment(appId, userId,
                sellerId, billId,
                buttonKey, createRemarkByCount(10)
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        resultDTO = ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        doReturn(resultDTO).when(billManager).confirmReceivePayment(anyLong(), anyString(), any(), any());
        voidGwEntity = billGWService.confirmReceivePayment(appId, userId,
                sellerId, billId,
                buttonKey, createRemarkByCount(10)
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();

        resultDTO = new ResultDTO<>(new VoidEntity());
        doReturn(resultDTO).when(billManager).confirmReceivePayment(anyLong(), anyString(), any(), any());
        voidGwEntity = billGWService.confirmReceivePayment(appId, userId,
                sellerId, billId,
                buttonKey, createRemarkByCount(10)
        );
        assert voidGwEntity != null;
        DubboExtProperty.clearNotificaitons();

        mockitoCurrentUserRoleFail();
        voidGwEntity = billGWService.confirmReceivePayment(appId, userId,
                sellerId, billId,
                buttonKey, createRemarkByCount(10)
        );
        assert voidGwEntity == null;
        DubboExtProperty.clearNotificaitons();
    }


}