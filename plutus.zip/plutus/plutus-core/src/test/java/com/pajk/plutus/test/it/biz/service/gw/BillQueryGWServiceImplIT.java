package com.pajk.plutus.test.it.biz.service.gw;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.pajk.plutus.client.api.gw.BillQueryGWService;
import com.pajk.plutus.client.model.result.gw.bill.ConfirmSettlementGW;
import com.pajk.plutus.client.model.result.gw.bill.PageSettlementGW;
import com.pajk.plutus.test.it.BaseIT;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * @author david
 * @since created by on 17/12/18 10:25
 */
public class BillQueryGWServiceImplIT extends BaseIT {

    @Autowired
    private BillQueryGWService billQueryGWService;

    @Test
    public void queryConfirmSettlement() {
        ConfirmSettlementGW confirmSettlementGW = billQueryGWService.queryConfirmSettlement(9222001L, 20024130304L, 3L,2083950007L, 246L);
        System.out.println(JSONObject.toJSONString(confirmSettlementGW));

    }

    @Test
    public void querySettlement() {
//        SettlementOrderGW settlementOrder = billQueryGWService.querySettlement(9222001L, 20024130208L, 2083950007L, 151L);
//        System.out.println(JSONObject.toJSONString(settlementOrder));
    }

    @Test
    public void pageQuerySettlement() {
        final PageSettlementGW pageSettlementGW = billQueryGWService.pageQuerySettlement(
                9222001L, 20024130304L, 9222000L, 2083950007L, "2017-10", "2017-12", 1, 10);
        System.out.println(JSON.toJSONString(pageSettlementGW));
    }
}