package com.pajk.plutus.test.ut.biz.service.web.depositcontroller;

import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.dao.repo.VoucherRepository;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.param.restapi.UpdateContractAmtParam;
import com.pajk.plutus.biz.service.web.DepositController;
import com.pajk.plutus.client.model.enums.account.BookStatus;
import com.pajk.plutus.client.model.enums.account.BookType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.testng.annotations.Test;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by lizhijun on 2018/1/4.
 */
public class UpdateContractAmtUT extends BaseWebServiceUT {
    @InjectMocks
    private DepositController depositController = new DepositController();

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @Mock
    private VoucherQueryRepository voucherQueryRepository;

    @Mock
    private VoucherRepository voucherRepository;

    @Mock
    private AccountQueryRepository accountQueryRepository;

    @Mock
    private ControlCache controlCache;

    private static final String voucherId = "100";
    private static final String nodeKey = "nodeKey";
    private static final String nodeCatKey = "nodeCatKey";
    private static final String transitionKey = "transitionKey";
    private static final String role = "role";
    private static final String path = "deposit/financeAuditPayment";


    @Test(description = "参数错误:sellerId不正确")
    public void test1(){
        UpdateContractAmtParam param = buildParam();
        param.setSellerId(1000001010L);
        ResultDTO<VoidEntity> resultDTO = depositController.updateContractAmt(param);
        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "参数错误:updateContractAmt 小于0")
    public void test2(){
        UpdateContractAmtParam param = buildParam();
        param.setUpdateContractAmt(-1L);
        ResultDTO<VoidEntity> resultDTO = depositController.updateContractAmt(param);
        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "参数错误:updateContractAmt 小于0 baseContractAmt 小于0")
    public void test3(){
        UpdateContractAmtParam param = buildParam();
        param.setUpdateContractAmt(-1L);
        param.setBaseContractAmt(-2L);
        ResultDTO<VoidEntity> resultDTO = depositController.updateContractAmt(param);
        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "参数错误:updateContractAmt 大于0")
    public void test4(){
        UpdateContractAmtParam param = buildParam();
        param.setBaseContractAmt(param.getUpdateContractAmt() + 1L);
        ResultDTO<VoidEntity> resultDTO = depositController.updateContractAmt(param);
        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "参数错误:remark超500")
    public void test5(){
        UpdateContractAmtParam param = buildParam();
        StringBuilder sb = new StringBuilder();
        for (int i=0; i<100; i++){
            sb.append("remark");
        }
        param.setRemark(sb.toString());
        ResultDTO<VoidEntity> resultDTO = depositController.updateContractAmt(param);
        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "账本冻结")
    public void test6(){
        mockitoPermissionOk();
        UpdateContractAmtParam param = buildParam();
        AccountBookDO bookDO = buildBook(defaultSellerId,1L);
        bookDO.setStatus(BookStatus.INVALID);
        bookDO.setBookType(BookType.DEPOSIT);

        Mockito.doReturn(Optional.of(bookDO)).when(accountQueryRepository).queryBookBySeller(defaultSellerId,bookDO.getBookType().getCode());
        ResultDTO<VoidEntity> resultDTO = depositController.updateContractAmt(param);
        assertThat(ErrorCode.BOOK_IS_IN_VALID.eq(resultDTO.getResultCode())).isTrue();
    }

    private UpdateContractAmtParam buildParam(){
        UpdateContractAmtParam  updateContractAmtParam = new UpdateContractAmtParam();
        updateContractAmtParam.setAccountBookId(1L);
        updateContractAmtParam.setBaseContractAmt(100L);
        updateContractAmtParam.setUpdateContractAmt(200L);
        updateContractAmtParam.setSellerId(defaultSellerId);
        updateContractAmtParam.setRemark("remark");
        return updateContractAmtParam;
    }
}
