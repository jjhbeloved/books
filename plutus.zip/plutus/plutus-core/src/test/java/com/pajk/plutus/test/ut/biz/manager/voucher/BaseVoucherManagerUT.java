package com.pajk.plutus.test.ut.biz.manager.voucher;

import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.common.idgen.IDPool;
import com.pajk.plutus.biz.dao.mapper.single.account.AccountBookFlowMapper;
import com.pajk.plutus.biz.dao.mapper.single.account.AccountBookMapper;
import com.pajk.plutus.biz.dao.mapper.single.account.AccountMapper;
import com.pajk.plutus.biz.dao.mapper.single.voucher.StatementMapper;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherDeliveryMapper;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherLogMapper;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherMapper;
import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.dao.repo.AccountRepository;
import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.dao.repo.VoucherRepository;
import com.pajk.plutus.biz.dao.repo.impl.AccountQueryRepositoryImpl;
import com.pajk.plutus.biz.dao.repo.impl.AccountRepositoryImpl;
import com.pajk.plutus.biz.dao.repo.impl.VoucherQueryRepositoryImpl;
import com.pajk.plutus.biz.dao.repo.impl.VoucherRepositoryImpl;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.test.ut.BaseServiceUT;
import com.pajk.taskcenter.client.model.dto.CreateProcInstResultDTO;
import com.pajk.taskcenter.client.model.dto.TaskInstDTO;
import com.pajk.taskcenter.client.model.result.BatchResult;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.any;

/**
 * Created by cuidongchao on 2017/12/22.
 */
public class BaseVoucherManagerUT extends BaseServiceUT {

    @InjectMocks
    protected VoucherManager voucherManager = new VoucherManagerImpl();

    @InjectMocks
    @Spy
    protected VoucherQueryRepository voucherQueryRepository = new VoucherQueryRepositoryImpl();

    @InjectMocks
    @Spy
    protected VoucherRepository voucherRepository = new VoucherRepositoryImpl();

    @InjectMocks
    @Spy
    protected AccountQueryRepository accountQueryRepository = new AccountQueryRepositoryImpl();

    @InjectMocks
    @Spy
    protected AccountRepository accountRepository = new AccountRepositoryImpl();

    @Mock
    protected IDPool voucherIDPool;

    @Mock
    protected ControlCache controlCache;

    @Mock
    protected VoucherMapper voucherMapper;

    @Mock
    protected VoucherDeliveryMapper voucherDeliveryMapper;

    @Mock
    protected AccountMapper accountMapper;

    @Mock
    protected AccountBookMapper accountBookMapper;

    @Mock
    protected AccountBookFlowMapper accountBookFlowMapper;

    @Mock
    protected StatementMapper statementMapper;

    @Mock
    protected VoucherLogMapper voucherLogMapper;

    protected long defaultSellerId = 12340909L;
    protected long expectAmt = 100L;
    protected String voucherId = "123456789";
    protected UserParam userParam = new UserParam(defaultAppId, defaultUserId, 0L);

    protected void mockSellerSuccess() {
        KyCallResult<SellerDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        SellerDO sellerDO = new SellerDO();
        sellerDO.setName("SELLER");
        sellerDO.setId(defaultSellerId);
        kyCallResult.setModel(sellerDO);
        Mockito.doReturn(kyCallResult)
                .when(sellerService)
                .getSellerById(any());
    }

    protected void mockVoucherIDGen() {
        Mockito.doReturn("123400")
                .when(voucherIDPool)
                .getNewId();
    }

    protected void mockFlowServiceCreateProcessOK() {
        BatchResult<CreateProcInstResultDTO> batchResultDTO = new BatchResult<>();
        batchResultDTO.setSuccess(true);
        CreateProcInstResultDTO createProcInstResultDTO = new CreateProcInstResultDTO();
        createProcInstResultDTO.setProcInstId(1234L);
        createProcInstResultDTO.setSuccess(true);
        TaskInstDTO taskInstDTO = new TaskInstDTO();
        taskInstDTO.setNodeKey("Hi");
        taskInstDTO.setNodeCatKey("Jack");
        taskInstDTO.setRole("admin");
        List<TaskInstDTO> taskInstDTOS = new ArrayList<>();
        taskInstDTOS.add(taskInstDTO);
        createProcInstResultDTO.setTaskInstDTOList(taskInstDTOS);

        batchResultDTO.getModel().add(createProcInstResultDTO);

        Mockito.doReturn(batchResultDTO)
                .when(flowService)
                .createProcess(any());
    }

    protected void mockFlowServiceCreateProcessFail() {
        BatchResult<CreateProcInstResultDTO> batchResultDTO = new BatchResult<>();
        batchResultDTO.setSuccess(false);

        Mockito.doReturn(batchResultDTO)
                .when(flowService)
                .createProcess(any());
    }

}
