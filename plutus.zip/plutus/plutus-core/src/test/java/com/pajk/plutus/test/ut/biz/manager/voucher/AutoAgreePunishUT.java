package com.pajk.plutus.test.ut.biz.manager.voucher;

import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDAO;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.taskcenter.client.model.dto.*;
import com.pajk.taskcenter.client.model.result.BatchResult;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fuyongda on 2018/1/3.
 * Modified by fuyongda on 2018/1/3.
 */
public class AutoAgreePunishUT extends BaseVoucherManagerUT {

    @Test(description = "违规单的条数为0")
    public void test1() {
        ResultDTO<VoidEntity> resultDTO = voucherManager.autoAgreePunish();

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
    }

    @Test(description = "成功")
    public void test2() {
        VoucherDAO voucherDAO1 = new VoucherDAO();
        voucherDAO1.setSellerId(defaultSellerId);

        VoucherDAO voucherDAO2 = new VoucherDAO();
        voucherDAO2.setSellerId(12345678L);

        VoucherDAO voucherDAO3 = new VoucherDAO();
        voucherDAO3.setSellerId(defaultSellerId);
        voucherDAO3.setExpectAmt(1L);
        voucherDAO3.setExpectPoint(1L);

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO1);
        list.add(voucherDAO2);
        list.add(voucherDAO3);
        list.add(voucherDAO3);
        list.add(voucherDAO3);
        mockData(list);

        AccountBookDAO accountBookDAO = new AccountBookDAO();

        List<AccountBookDAO> accountBookList = new LinkedList<>();
        accountBookList.add(accountBookDAO);
        Mockito.doReturn(accountBookList).when(accountBookMapper).queryBySeller(defaultSellerId);

        mockFlowGetNodeInfoList();

        mockFlowCompleteState();

        Mockito.doReturn("transitionKey").when(controlCache).getVoucherPunishSellerAgreeTransitionKey();

        Mockito.doReturn(1).when(voucherMapper).updateByOPT(Matchers.any());

        Mockito.doReturn(1).when(accountBookMapper).updateByOPT(Matchers.any());

        Mockito.when(accountBookMapper.create(Matchers.any()))
                .thenReturn(1).thenReturn(0).thenReturn(0).thenReturn(0);

        ResultDTO<VoidEntity> resultDTO = voucherManager.autoAgreePunish();

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
    }

    private void mockFlowCompleteState() {
        TaskInstDTO taskInstDTO = new TaskInstDTO();

        List<TaskInstDTO> list = new LinkedList<>();
        list.add(taskInstDTO);

        CompleteTaskResultDTO completeTaskResultDTO1 = new CompleteTaskResultDTO();
        completeTaskResultDTO1.setSuccess(true);
        completeTaskResultDTO1.setTaskInstDTOList(list);
        completeTaskResultDTO1.setEndFlag(true);

        CompleteTaskResultDTO completeTaskResultDTO2 = new CompleteTaskResultDTO();
        completeTaskResultDTO2.setSuccess(false);

        Mockito.when(flowService.completeState(Matchers.any())).thenReturn(completeTaskResultDTO1)
                .thenReturn(completeTaskResultDTO2).thenThrow(RuntimeException.class)
                .thenReturn(completeTaskResultDTO1);
    }

    private void mockFlowGetNodeInfoList() {
        TransitionDTO transitionDTO = new TransitionDTO();
        transitionDTO.setTransitionKey("transitionKey");

        List<TransitionDTO> transitionDTOS = new LinkedList<>();
        transitionDTOS.add(transitionDTO);

        NodeDTO nodeDTO = new NodeDTO();
        nodeDTO.setTransitionDTOList(transitionDTOS);

        GetNodeInfoResultDTO getNodeInfoResultDTO = new GetNodeInfoResultDTO();
        getNodeInfoResultDTO.setNodeDTO(nodeDTO);

        List<GetNodeInfoResultDTO> list = new LinkedList<>();
        list.add(getNodeInfoResultDTO);

        BatchResult<GetNodeInfoResultDTO> batchResult1 = new BatchResult<>();
        batchResult1.setSuccess(true);
        batchResult1.setModel(list);

        BatchResult<GetNodeInfoResultDTO> batchResult2 = new BatchResult<>();
        batchResult2.setSuccess(false);

        Mockito.when(flowService.getNodeInfoList(Matchers.any()))
                .thenReturn(batchResult1).thenReturn(batchResult2).thenReturn(batchResult1).thenReturn(batchResult1);
    }

    private void mockData(List<VoucherDAO> list) {
        Mockito.doReturn(list.size()).when(voucherMapper).pageQueryCount(Matchers.any());

        Mockito.when(voucherMapper.pageQuery(Matchers.any()))
                .thenReturn(list).thenReturn(Collections.emptyList()).thenReturn(list).thenReturn(list);
    }

}
