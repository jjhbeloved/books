package com.pajk.plutus.test.ut.biz.model.roma;

import com.pajk.plutus.biz.model.roma.RomaBookFlowInfo;
import com.pajk.plutus.test.ut.BaseServiceUT;
import com.pajk.roma.message.RomaDbMessage;
import org.testng.annotations.Test;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by lizhijun on 2018/1/3.
 */
public class RomaBookFlowInfoUT extends BaseServiceUT {


    @Test
    public void test(){
        RomaDbMessage.RomaDbData.FieldData value1 =
                RomaDbMessage.RomaDbData.FieldData.newBuilder().setFieldName("id").setNewValue("100")
                        .build();

        RomaDbMessage.RomaDbData.FieldData value2 =
                RomaDbMessage.RomaDbData.FieldData.newBuilder().setFieldName("seller_id").setNewValue("1000101")
                        .build();
        RomaDbMessage.RomaDbData.FieldData value3 =
                RomaDbMessage.RomaDbData.FieldData.newBuilder()
                        .setFieldName("status").setOldValue("0").setNewValue("1").build();


        RomaDbMessage.RomaDbData changeData =
                RomaDbMessage.RomaDbData.newBuilder().addFieldsValue(value1).addFieldsValue(value2)
                        .addFieldsValue(value3).build();


        RomaBookFlowInfo flowInfo = new RomaBookFlowInfo(changeData);
        assertThat(flowInfo.getStatus()).isNotNull();


    }
}
