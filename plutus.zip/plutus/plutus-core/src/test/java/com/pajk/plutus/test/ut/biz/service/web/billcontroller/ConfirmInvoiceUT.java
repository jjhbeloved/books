package com.pajk.plutus.test.ut.biz.service.web.billcontroller;

import com.pajk.plutus.biz.model.query.bill.InvoiceInfoDTO;
import com.pajk.plutus.biz.service.web.BillController;
import com.pajk.plutus.biz.service.web.BillQueryController;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import org.mockito.InjectMocks;
import org.testng.annotations.Test;

/**
 * Created by fanhuafeng on 18/1/4.
 * Modify by fanhuafeng on 18/1/4
 */
public class ConfirmInvoiceUT extends BaseWebServiceUT {

    @InjectMocks
    private BillController billController = new BillController();



    @Test
    public void test01(){
        InvoiceInfoDTO invoice = new InvoiceInfoDTO();
        invoice.setSellerId(defaultSellerId);
        invoice.setBillId(100000L);
        invoice.setInvoiceAmt(1000L);


        billController.confirmInvoice(invoice);


    }
}
