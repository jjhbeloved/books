package com.pajk.plutus.test.ut.biz.task;

import com.pajk.hawaii.client.JobExecutionContext;
import com.pajk.hawaii.client.JobListener;
import com.pajk.plutus.biz.common.util.ResultUtil;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.exceptions.DBException;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.task.VoucherDeliveryToVoucherListener;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseServiceUT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 17/12/28.
 * Modify by fanhuafeng on 17/12/28
 */
public class VoucherDeliveryToVoucherListenerUT extends BaseServiceUT {

    @InjectMocks
    private JobListener listener = new VoucherDeliveryToVoucherListener();

    @Mock
    private VoucherManager voucherManager;

    @Mock
    private ControlCache controlCache;


    @Test
    public void test01(){
        JobExecutionContext context = new JobExecutionContext();


        Mockito.doReturn(3).when(controlCache).getVoucherDeliveryAutoProcessInterval();



        ResultDTO<VoidEntity> resultDTO = ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);

        Mockito.doReturn(resultDTO).when(voucherManager).autoCreatePunish(Matchers.any(Date.class),Matchers.any(Date.class));

        listener.execute(context);

        assertThat(context.isSuccess()).isFalse();
    }

    @Test
    public void test02(){
        JobExecutionContext context = new JobExecutionContext();
        Mockito.doReturn(3).when(controlCache).getVoucherDeliveryAutoProcessInterval();

        Mockito.doThrow(new DBException(123, "fail")).when(voucherManager).autoCreatePunish(Matchers.any(Date.class),Matchers.any(Date.class));

        listener.execute(context);

        assertThat(context.isSuccess()).isFalse();
    }

    @Test
    public void testSuccess(){


        assertThat(VoucherDeliveryToVoucherListener.class.getName()).isEqualToIgnoringCase(listener.getName());

        Mockito.doReturn(3).when(controlCache).getVoucherDeliveryAutoProcessInterval();
        JobExecutionContext context = new JobExecutionContext();
        ResultDTO<VoidEntity> resultDTO = new ResultDTO<>();

        Mockito.doReturn(resultDTO).when(voucherManager).autoCreatePunish(Matchers.any(Date.class),Matchers.any(Date.class));

        listener.execute(context);

        assertThat(context.isSuccess()).isTrue();
    }
}
