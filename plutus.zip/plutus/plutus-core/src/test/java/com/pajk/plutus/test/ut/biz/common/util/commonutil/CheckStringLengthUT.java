package com.pajk.plutus.test.ut.biz.common.util.commonutil;

import com.pajk.plutus.biz.common.util.CommonUtil;
import org.testng.annotations.Test;

import static org.assertj.core.api.Java6Assertions.assertThat;

/**
 * Created by lizhijun on 2018/1/4.
 */
public class CheckStringLengthUT {
    @Test
    public void test(){
        assertThat( CommonUtil.checkStringLength("",10)).isFalse();
        assertThat( CommonUtil.checkStringLength("123",1)).isFalse();
        assertThat( CommonUtil.checkStringLength("123",5)).isTrue();
    }
}
