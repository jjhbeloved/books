package com.pajk.plutus.test.ut.biz.common.util.jsonutil;

import com.alibaba.fastjson.JSONObject;
import com.pajk.plutus.biz.common.util.JsonUtil;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 17/12/28.
 * Modify by fanhuafeng on 17/12/28
 */
public class JsonUtilUT {
    @Test
    public void testParse01(){
        Map<String, String> map = JsonUtil.parse("");
        assertThat(map.size()).isEqualTo(0);
    }


    @Test
    public void testParse02(){
        Map<String, String> map = JsonUtil.parse("zzzzz");
        assertThat(map.size()).isEqualTo(0);
    }

    @Test
    public void testParse03(){
        Map<String, String> map2 = new HashMap<>();
        map2.put("key1", "value2");

        Map<String, String> map = JsonUtil.parse(JsonUtil.obj2Str(map2));
        assertThat(map.size()).isEqualTo(1);
        assertThat(map.get("key1")).isEqualTo(map2.get("key1"));
    }



    @Test
    public void testParseJSONObject01(){
        JSONObject map = JsonUtil.parseJSONObject("");
        assertThat(map).isNull();
    }


    @Test
    public void testParseJSONObject02(){
        JSONObject map  = JsonUtil.parseJSONObject("zzzzz");
        assertThat(map).isNull();
    }

    @Test
    public void testParseJSONObject03(){
        Map<String, String> map2 = new HashMap<>();
        map2.put("key1", "value2");

        JSONObject map  = JsonUtil.parseJSONObject(JsonUtil.obj2Str(map2));
        assertThat(map.size()).isEqualTo(1);
        assertThat(map.get("key1")).isEqualTo(map2.get("key1"));
    }
}
