package com.pajk.plutus.test.ut.biz.service.web.depositcontroller;

import com.pajk.plutus.biz.common.idgen.IDPool;
import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.dao.repo.VoucherRepository;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.account.AccountBookFlowDO;
import com.pajk.plutus.biz.model.param.restapi.AddBalanceAmtParam;
import com.pajk.plutus.biz.service.web.DepositController;
import com.pajk.plutus.client.model.enums.account.BookFlowOutType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by lizhijun on 2018/1/4.
 */
public class AddBalanceAmtUT extends BaseWebServiceUT {
    @InjectMocks
    private DepositController depositController = new DepositController();

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @Mock
    private AccountQueryRepository accountQueryRepository;

    @Mock
    private VoucherRepository voucherRepository;

    @Mock
    private VoucherQueryRepository voucherQueryRepository;

    @Mock
    private IDPool voucherIDPool;

    @Mock
    private ControlCache controlCache;

    private static final long bookId = 1L;
    private static final long amount = 100L;


    @Test(description = "参数不对:sellerId错误")
    public void test1(){
        AddBalanceAmtParam param = buildParam();
        param.setSellerId(100001111L);
        ResultDTO<String> resultDTO =  depositController.addBalanceAmt(param);
        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "参数不对:remark操作500")
    public void test2(){
        AddBalanceAmtParam param = buildParam();
        StringBuilder sb = new StringBuilder();
        for (int i=0;i<100;i++){
            sb.append("remark");
        }
        param.setRemark(sb.toString());
        ResultDTO<String> resultDTO =  depositController.addBalanceAmt(param);
        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "参数不对:金额小于0")
    public void test3(){
        AddBalanceAmtParam param = buildParam();
        mockitoPermissionOk();
        param.setAmount(0L);
        ResultDTO<String> resultDTO =  depositController.addBalanceAmt(param);
        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "账本不存在")
    public void test4(){
        AddBalanceAmtParam param = buildParam();
        mockitoPermissionOk();
        Mockito.doReturn(Optional.empty()).when(accountQueryRepository).queryBookBySellerAndBookId(defaultSellerId,bookId);
        ResultDTO<String> resultDTO =  depositController.addBalanceAmt(param);
        assertThat(ErrorCode.BOOK_NOT_EXISTS.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "需要补缴的违规单不存在")
    public void test5(){
        AddBalanceAmtParam param = buildParam();
        mockitoPermissionOk();

        Mockito.doReturn(Optional.of(buildBook(defaultSellerId,bookId))).when(accountQueryRepository).queryBookBySellerAndBookId(defaultSellerId,bookId);
        Mockito.doReturn(60).when(controlCache).getAccountBookFlowWriteOffQueryDaySpan();

        Mockito.doReturn(0).when(accountQueryRepository).queryBookFlowCount(Matchers.any());
        ResultDTO<String> resultDTO =  depositController.addBalanceAmt(param);
        assertThat(ErrorCode.ADD_FAIL_CASE_AMOUNT_ZERO.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "需要补缴的违规单不存在")
    public void test6(){
        AddBalanceAmtParam param = buildParam();
        mockitoPermissionOk();
        Mockito.doReturn(Optional.of(buildBook(defaultSellerId,bookId))).when(accountQueryRepository).queryBookBySellerAndBookId(defaultSellerId,bookId);
        Mockito.doReturn(60).when(controlCache).getAccountBookFlowWriteOffQueryDaySpan();

        Mockito.doReturn(100).when(accountQueryRepository).queryBookFlowCount(Matchers.any());
        Mockito.doReturn(Optional.empty()).when(accountQueryRepository).pageQueryBookFlow(Matchers.any());
        ResultDTO<String> resultDTO =  depositController.addBalanceAmt(param);
        assertThat(ErrorCode.ADD_FAIL_CASE_AMOUNT_ZERO.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "创建失败")
    public void test7(){
        AddBalanceAmtParam param = buildParam();
        mockitoPermissionOk();
        Mockito.doReturn(Optional.of(buildBook(defaultSellerId,bookId))).when(accountQueryRepository).queryBookBySellerAndBookId(defaultSellerId,bookId);
        Mockito.doReturn(60).when(controlCache).getAccountBookFlowWriteOffQueryDaySpan();

        Mockito.doReturn(100).when(accountQueryRepository).queryBookFlowCount(Matchers.any());

        List<AccountBookFlowDO> flowDOs = new LinkedList<>();
        AccountBookFlowDO flowDO = buildBookFlow(defaultSellerId,bookId,1, BookFlowOutType.FC_VOUCHER,"1");
        flowDOs.add(flowDO);
        Mockito.doReturn(Optional.of(flowDOs)).when(accountQueryRepository).pageQueryBookFlow(Matchers.any());

        mockCreateProcess(false);
        ResultDTO<String> resultDTO =  depositController.addBalanceAmt(param);
        assertThat(ErrorCode.PROCESS_CREATE.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "创建流程成功,更新数据库失败")
    public void test8(){
        AddBalanceAmtParam param = buildParam();
        mockitoPermissionOk();
        Mockito.doReturn(Optional.of(buildBook(defaultSellerId,bookId))).when(accountQueryRepository).queryBookBySellerAndBookId(defaultSellerId,bookId);
        Mockito.doReturn(60).when(controlCache).getAccountBookFlowWriteOffQueryDaySpan();

        Mockito.doReturn(100).when(accountQueryRepository).queryBookFlowCount(Matchers.any());

        List<AccountBookFlowDO> flowDOs = new LinkedList<>();
        AccountBookFlowDO flowDO = buildBookFlow(defaultSellerId,bookId,1, BookFlowOutType.FC_VOUCHER,"1");
        flowDO.setAmount(amount -10);
        flowDOs.add(flowDO);
        Mockito.doReturn(Optional.of(flowDOs)).when(accountQueryRepository).pageQueryBookFlow(Matchers.any());

        mockCreateProcess(true);

        Mockito.doThrow(new RuntimeException()).when(voucherRepository).addBalanceAmt(
                Matchers.any(),Matchers.any(),Matchers.any(),Matchers.anyList(),Matchers.anyString(),Matchers.any());

        ResultDTO<String> resultDTO =  depositController.addBalanceAmt(param);
        assertThat(ErrorCode.STORE_DB_FAILED.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "创建流程成功")
    public void test9(){
        AddBalanceAmtParam param = buildParam();
        mockitoPermissionOk();
        Mockito.doReturn(Optional.of(buildBook(defaultSellerId,bookId))).when(accountQueryRepository).queryBookBySellerAndBookId(defaultSellerId,bookId);
        Mockito.doReturn(60).when(controlCache).getAccountBookFlowWriteOffQueryDaySpan();
        Mockito.doReturn(100).when(accountQueryRepository).queryBookFlowCount(Matchers.any());

        List<AccountBookFlowDO> flowDOs = new LinkedList<>();
        AccountBookFlowDO flowDO = buildBookFlow(defaultSellerId,bookId,1, BookFlowOutType.FC_VOUCHER,"1");
        flowDO.setAmount(amount);
        flowDOs.add(flowDO);
        Mockito.doReturn(Optional.of(flowDOs)).when(accountQueryRepository).pageQueryBookFlow(Matchers.any());
        mockCreateProcess(true);

        ResultDTO<String> resultDTO =  depositController.addBalanceAmt(param);
        assertThat(ErrorCode.SUCCESS.eq(resultDTO.getResultCode())).isTrue();
    }

    private AddBalanceAmtParam buildParam(){
        AddBalanceAmtParam param = new AddBalanceAmtParam();
        param.setSellerId(defaultSellerId);
        param.setAccountBookId(bookId);
        param.setAmount(amount);
        param.setRemark("remark");
        return param;
    }

}
