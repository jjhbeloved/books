package com.pajk.plutus.test.ut.biz.common.util.commonutil;

import com.pajk.plutus.biz.common.util.CommonUtil;
import com.pajk.plutus.test.ut.BaseServiceUT;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 17/12/28.
 * Modify by fanhuafeng on 17/12/28
 */
public class IsPhoneUT extends BaseServiceUT {
    @Test
    public void testPhone1() {
        String phone = "";
        boolean ret = CommonUtil.isPhone(phone);
        assertThat(ret).isFalse();
    }

    @Test
    public void testPhone2() {
        String phone = "1323333444o";
        boolean ret = CommonUtil.isPhone(phone);
        assertThat(ret).isFalse();
    }

    @Test
    public void testPhone3() {
        String phone = "1323333444";
        boolean ret = CommonUtil.isPhone(phone);
        assertThat(ret).isFalse();
    }

    @Test
    public void testPhone4() {
        String phone = "23233334444";
        boolean ret = CommonUtil.isPhone(phone);
        assertThat(ret).isFalse();
    }

    @Test
    public void testPhone5() {
        String phone = "15138756492";
        boolean ret = CommonUtil.isPhone(phone);
        assertThat(ret).isTrue();
    }

}
