package com.pajk.plutus.test.ut.biz.service.gw.depositquerygwservice;

import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherMapper;
import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.dao.repo.impl.VoucherQueryRepositoryImpl;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDAO;
import com.pajk.plutus.biz.service.gw.DepositQueryGWServiceImpl;
import com.pajk.plutus.client.api.gw.DepositQueryGWService;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.voucher.PageVoucherGW;
import com.pajk.plutus.test.ut.BaseGwServiceUT;
import org.apache.commons.lang3.math.NumberUtils;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by guguangming on 2017/12/28
 * Modified by fuyongda on 2017/12/29
 */
public class PageQuerySellerVoucherUT extends BaseGwServiceUT {

    @InjectMocks
    private DepositQueryGWService depositQueryGWService = new DepositQueryGWServiceImpl();

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @InjectMocks
    @Spy
    private VoucherQueryRepository voucherQueryRepository = new VoucherQueryRepositoryImpl();

    @Mock
    private VoucherMapper voucherMapper;

    @Mock
    private ControlCache controlCache;

    private String voucherId = "1221";
    private String nodeCatKey = "complaint";
    private int pageSize = 20;
    private int pageNo = 1;
    private String commitStart = "2017-12-10";
    private String commitEnd = "2017-12-28";
    private int voucherType = VoucherType.VIOLATION.getCode();
    private int voucherSubType = VoucherSubType.DELAY_DELIVERY_VIOLATION.getCode();
    private String role = "SELLER_OP";
    private AppResourceDO appResourceDO = new AppResourceDO();


    @Test(description = "voucherId错误")
    public void test0() {
        mockitoPermissionOk();

        PageVoucherGW pageVoucherGW = depositQueryGWService.pageQuerySellerVoucher(defaultAppId, defaultUserId,
                defaultSellerId, "ddsfdsfdsf", nodeCatKey, voucherType, voucherSubType,
                commitStart, commitEnd, pageNo, pageSize);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(pageVoucherGW).isNull();
    }

    @Test(description = "分页查询->超过最大数量")
    public void test1() {
        mockitoPermissionOk();

        PageVoucherGW pageVoucherGW = depositQueryGWService.pageQuerySellerVoucher(defaultAppId, defaultUserId,
                defaultSellerId, voucherId, nodeCatKey, voucherType, voucherSubType,
                commitStart, commitEnd, pageNo, 200000);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_QUERY_INTERVAL_OVER_THRESHOLD);
        assertThat(pageVoucherGW).isNull();
    }

    @Test(description = "分页查询 pageNo错误 返回->超过最大数量")
    public void test2() {
        mockitoPermissionOk();

        PageVoucherGW pageVoucherGW = depositQueryGWService.pageQuerySellerVoucher(defaultAppId, defaultUserId,
                defaultSellerId, voucherId, nodeCatKey, voucherType, voucherSubType,
                commitStart, commitEnd, -2, pageSize);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_QUERY_INTERVAL_OVER_THRESHOLD);
        assertThat(pageVoucherGW).isNull();
    }

    @Test(description = "voucherType 参数错误")
    public void test3() {
        mockitoPermissionOk();

        PageVoucherGW pageVoucherGW = depositQueryGWService.pageQuerySellerVoucher(defaultAppId, defaultUserId,
                defaultSellerId, voucherId, nodeCatKey, VoucherType.UNKNOWN.getCode(), voucherSubType,
                commitStart, commitEnd, pageNo, pageSize);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(pageVoucherGW).isNull();
    }

    @Test(description = "voucherSubType 参数错误")
    public void test4() {
        mockitoPermissionOk();

        PageVoucherGW pageVoucherGW = depositQueryGWService.pageQuerySellerVoucher(defaultAppId, defaultUserId,
                defaultSellerId, voucherId, nodeCatKey, voucherType, VoucherSubType.UNKNOWN.getCode(),
                commitStart, commitEnd, pageNo, pageSize);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(pageVoucherGW).isNull();
    }

    @Test(description = "commitEndDate > commitStartDate 参数错误")
    public void test5() {
        mockitoPermissionOk();

        PageVoucherGW pageVoucherGW = depositQueryGWService.pageQuerySellerVoucher(defaultAppId, defaultUserId,
                defaultSellerId, voucherId, nodeCatKey, voucherType, -1,
                "2017-12-28", "2017-12-21", pageNo, pageSize);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(pageVoucherGW).isNull();
    }

    @Test(description = "commitEndDate is null, commitStartDate is not null, voucherId is empty")
    public void test6() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockData();

        PageVoucherGW pageVoucherGW = depositQueryGWService.pageQuerySellerVoucher(defaultAppId, defaultUserId,
                defaultSellerId, null, null, voucherType, -1, commitStart, null, pageNo, pageSize);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(pageVoucherGW).isNotNull();
    }

    @Test(description = "commitEndDate is null, commitStartDate is null, voucherSubType == -1")
    public void test7() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockData();

        PageVoucherGW pageVoucherGW = depositQueryGWService.pageQuerySellerVoucher(defaultAppId, defaultUserId,
                defaultSellerId, voucherId, nodeCatKey, voucherType, -1,
                null, null, pageNo, pageSize);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(pageVoucherGW).isNotNull();
    }

    @Test(description = "commitEndDate is not null, commitStartDate is null, status is empty")
    public void test8() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockData();

        PageVoucherGW pageVoucherGW = depositQueryGWService.pageQuerySellerVoucher(defaultAppId, defaultUserId,
                defaultSellerId, voucherId, null, voucherType, voucherSubType,
                null, commitEnd, pageNo, pageSize);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(pageVoucherGW).isNotNull();
    }

    @Test(description = "status is all")
    public void test9() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockData();

        PageVoucherGW pageVoucherGW = depositQueryGWService.pageQuerySellerVoucher(defaultAppId, defaultUserId,
                defaultSellerId, voucherId, "all", voucherType, voucherSubType,
                commitStart, commitEnd, pageNo, pageSize);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(pageVoucherGW).isNotNull();
    }

    @Test(description = "appResource is null")
    public void test10() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(null);

        mockData();

        PageVoucherGW pageVoucherGW = depositQueryGWService.pageQuerySellerVoucher(defaultAppId, defaultUserId,
                defaultSellerId, voucherId, nodeCatKey, voucherType, voucherSubType,
                commitStart, commitEnd, pageNo, pageSize);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(pageVoucherGW).isNotNull();
    }

    @Test(description = "role匹配，显示操作按钮")
    public void test11() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        Mockito.doReturn(1).when(voucherMapper).pageQueryCount(Matchers.any());

        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setRole(role);

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());

        PageVoucherGW pageVoucherGW = depositQueryGWService.pageQuerySellerVoucher(defaultAppId, defaultUserId,
                defaultSellerId, voucherId, nodeCatKey, voucherType, voucherSubType,
                commitStart, commitEnd, pageNo, pageSize);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(pageVoucherGW).isNotNull();
        assertThat(pageVoucherGW.voucherInfos.size()).isEqualTo(1);
        assertThat(pageVoucherGW.voucherInfos.get(0)).isNotNull();
        assertThat(pageVoucherGW.voucherInfos.get(0).buttons).isNotNull();
        assertThat(pageVoucherGW.voucherInfos.get(0).buttons.size()).isEqualTo(1);
    }

    private void mockData() {
        Mockito.doReturn(1).when(voucherMapper).pageQueryCount(Matchers.any());

        VoucherDAO voucherDAO = new VoucherDAO();

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());
    }

}
