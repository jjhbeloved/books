package com.pajk.plutus.test.it.biz.manager.impl.vouchermanager;

import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.test.it.BaseIT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * Created by  guguangming on 2018/01/03
 **/
public class PageQueryVoucher extends BaseIT {
    @Autowired
    private VoucherManager voucherManager;

    @Test
    public void test1(){
//        ResultDTO<Long> resultDTO = voucherManager.queryMustAddAmt(20021820000L,2L);

//        System.out.println(resultDTO);
    }

}
