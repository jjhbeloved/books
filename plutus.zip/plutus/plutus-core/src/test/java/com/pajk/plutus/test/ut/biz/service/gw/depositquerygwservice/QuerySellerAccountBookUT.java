package com.pajk.plutus.test.ut.biz.service.gw.depositquerygwservice;

import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.dao.mapper.single.account.AccountBookMapper;
import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.dao.repo.impl.AccountQueryRepositoryImpl;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.manager.impl.AccountManagerImpl;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.service.gw.DepositQueryGWServiceImpl;
import com.pajk.plutus.client.api.gw.DepositQueryGWService;
import com.pajk.plutus.client.model.enums.account.BookType;
import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.account.AccountBookGW;
import com.pajk.plutus.test.ut.BaseGwServiceUT;
import org.apache.commons.lang3.math.NumberUtils;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by  guguangming on 2018/01/03
 **/
public class QuerySellerAccountBookUT extends BaseGwServiceUT {

    @InjectMocks
    private DepositQueryGWService depositQueryGWService = new DepositQueryGWServiceImpl();

    @InjectMocks
    @Spy
    private AccountManager accountManager = new AccountManagerImpl();

    @InjectMocks
    @Spy
    private AccountQueryRepository accountQueryRepository = new AccountQueryRepositoryImpl();


    @Mock
    private AccountBookMapper bookMapper;

    private long bookId = 111L;
    private String sellerName = "好药师";

    @Test(description = "账本不存在")
    public void test1() {
        mockitoPermissionOk();
        AccountBookGW bookFlowGW = depositQueryGWService.querySellerAccountBook(defaultAppId, defaultUserId, defaultSellerId);

        Mockito.doReturn(Optional.of(buildAccountBookDO())).when(accountQueryRepository).queryBookBySeller(Matchers.anyLong(), Matchers.anyInt());

        List<AccountBookDO> bookDOS = new ArrayList<>();
        bookDOS.add(buildAccountBookDO());
        Mockito.doReturn(Optional.of(bookDOS)).when(accountQueryRepository).queryBookBySeller(Matchers.anyLong());

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_BOOK_NOT_EXISTS);
        assertThat(bookFlowGW).isNull();
    }

    @Test(description = "账本存在")
    public void test2() {
        mockitoPermissionOk();

        Mockito.doReturn(Optional.of(buildAccountBookDO2())).when(accountQueryRepository).queryBookBySeller(Matchers.anyLong(), Matchers.anyInt());

        List<AccountBookDO> bookDOS = new ArrayList<>();
        bookDOS.add(buildAccountBookDO2());
        Mockito.doReturn(Optional.of(bookDOS)).when(accountQueryRepository).queryBookBySeller(Matchers.anyLong());

        KyCallResult<SellerDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(false);
        Mockito.doReturn(kyCallResult).when(sellerService).getSellerById(Matchers.anyLong());

        AccountBookGW bookFlowGW = depositQueryGWService.querySellerAccountBook(defaultAppId, defaultUserId, defaultSellerId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode._C_SUCCESS);
        assertThat(bookFlowGW).isNotNull();
        assertThat(bookFlowGW.sellerName).isNull();
    }

    @Test(description = "账本存在")
    public void test5() {
        mockitoPermissionOk();

        Mockito.doReturn(Optional.of(buildAccountBookDO2())).when(accountQueryRepository).queryBookBySeller(Matchers.anyLong(), Matchers.anyInt());

        List<AccountBookDO> bookDOS = new ArrayList<>();
        bookDOS.add(buildAccountBookDO2());
        Mockito.doReturn(Optional.of(bookDOS)).when(accountQueryRepository).queryBookBySeller(Matchers.anyLong());

        KyCallResult<SellerDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildSellerDO());

        Mockito.doReturn(kyCallResult).when(sellerService).getSellerById(Matchers.anyLong());

        AccountBookGW bookFlowGW = depositQueryGWService.querySellerAccountBook(defaultAppId, defaultUserId, defaultSellerId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode._C_SUCCESS);
        assertThat(bookFlowGW).isNotNull();
        assertThat(bookFlowGW.sellerName).isEqualTo(sellerName);
    }


    private AccountBookDO buildAccountBookDO() {
        AccountBookDO bookDO = new AccountBookDO();
        bookDO.setBookType(BookType.ANNUAL_FEE);
        bookDO.setId(bookId);
        bookDO.setBalanceAmt(111L);
        bookDO.setSellerId(defaultSellerId);
        return bookDO;
    }

    private AccountBookDO buildAccountBookDO2() {
        AccountBookDO bookDO = new AccountBookDO();
        bookDO.setBookType(BookType.DEPOSIT);
        bookDO.setId(bookId);
        bookDO.setBalanceAmt(111L);
        bookDO.setSellerId(defaultSellerId);
        return bookDO;
    }

    private SellerDO buildSellerDO() {
        SellerDO sellerDO = new SellerDO();
        sellerDO.setId(defaultSellerId);
        sellerDO.setName(sellerName);
        return sellerDO;
    }

}
