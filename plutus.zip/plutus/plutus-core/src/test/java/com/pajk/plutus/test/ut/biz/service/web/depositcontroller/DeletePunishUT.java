package com.pajk.plutus.test.ut.biz.service.web.depositcontroller;

import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.dao.repo.VoucherRepository;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.param.restapi.DealPunishParam;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.service.web.DepositController;
import com.pajk.plutus.client.model.enums.voucher.VoucherDeleteFlag;
import com.pajk.plutus.client.model.enums.voucher.VoucherStatus;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;


/**
 * Created by lizhijun on 2018/1/2.
 */
public class DeletePunishUT extends BaseWebServiceUT{
    @InjectMocks
    private DepositController depositController = new DepositController();

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @Mock
    private VoucherQueryRepository voucherQueryRepository;

    @Mock
    private VoucherRepository voucherRepository;

    @Test(description = "参数不正确")
    public void test1(){
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(9999999999L);
        dealPunishParam.setVoucherId("100000");
        ResultDTO<VoidEntity> resultDTO = depositController.deletePunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_PARAM_ERROR);
    }

    @Test(description = "单据不存在")
    public void test2(){
        long sellerId = 10000000101L;
        String voucherId = "100000";
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(sellerId);
        dealPunishParam.setVoucherId(voucherId);
        mockitoPermissionOk();
        Mockito.doReturn(Optional.empty()).when(voucherQueryRepository).queryVoucherById(sellerId,voucherId);

        ResultDTO<VoidEntity> resultDTO = depositController.deletePunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_VOUCHER_NOT_EXISTS);
    }

    @Test(description = "已经删除")
    public void test3(){
        long sellerId = 10000000101L;
        String voucherId = "100000";
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(sellerId);
        dealPunishParam.setVoucherId(voucherId);
        mockitoPermissionOk();
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(voucherId);
        voucherDO.setSellerId(sellerId);
        voucherDO.setIsDeleted(VoucherDeleteFlag.IS_DELETE.getCode());
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(sellerId,voucherId);

        ResultDTO<VoidEntity> resultDTO = depositController.deletePunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_SUCCESS);
    }
    @Test(description = "不可删除,状态不为创建状态, 且类型不为虚假宣传或者假货 ")
    public void test4(){
        long sellerId = 10000000101L;
        String voucherId = "100000";
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(sellerId);
        dealPunishParam.setVoucherId(voucherId);
        mockitoPermissionOk();
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(voucherId);
        voucherDO.setSellerId(sellerId);
        voucherDO.setNodeKey("nodeKey");
        voucherDO.setVoucherSubType(VoucherSubType.ADD_DEPOSIT);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(sellerId,voucherId);

        ResultDTO<VoidEntity> resultDTO = depositController.deletePunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_STATUS_NOT_MATCH);
    }

    @Test(description = "不可删除:状态不为创建状态,类型为虚假宣传 ")
    public void test5(){
        long sellerId = 10000000101L;
        String voucherId = "100000";
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(sellerId);
        dealPunishParam.setVoucherId(voucherId);
        mockitoPermissionOk();
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(voucherId);
        voucherDO.setSellerId(sellerId);
        voucherDO.setNodeKey("nodeKey");
        voucherDO.setVoucherSubType(VoucherSubType.FALSE_CONDUCT_VIOLATION);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(sellerId,voucherId);

        ResultDTO<VoidEntity> resultDTO = depositController.deletePunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_STATUS_NOT_MATCH);
    }

    @Test(description = "不可删除:状态不为创建状态,类型为假货 ")
    public void test6(){
        long sellerId = 10000000101L;
        String voucherId = "100000";
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(sellerId);
        dealPunishParam.setVoucherId(voucherId);
        mockitoPermissionOk();
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(voucherId);
        voucherDO.setSellerId(sellerId);
        voucherDO.setNodeKey("nodeKey");
        voucherDO.setVoucherSubType(VoucherSubType.FAKE_VIOLATION);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(sellerId,voucherId);

        ResultDTO<VoidEntity> resultDTO = depositController.deletePunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_STATUS_NOT_MATCH);
    }

    @Test(description = "不可删除:状态为创建状态,类型不为虚假宣传和假货 ")
    public void test7(){
        long sellerId = 10000000101L;
        String voucherId = "100000";
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(sellerId);
        dealPunishParam.setVoucherId(voucherId);
        mockitoPermissionOk();
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(voucherId);
        voucherDO.setSellerId(sellerId);
        voucherDO.setNodeKey(VoucherStatus.CREATED.getCode());
        voucherDO.setVoucherSubType(VoucherSubType.PAY_IN_BACK_DEPOSIT);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(sellerId,voucherId);

        ResultDTO<VoidEntity> resultDTO = depositController.deletePunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_STATUS_NOT_MATCH);
    }

    @Test(description = "不可删除:状态为创建状态,类型为虚假宣传,删除失败 ")
    public void test8(){
        long sellerId = 10000000101L;
        String voucherId = "100000";
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(sellerId);
        dealPunishParam.setVoucherId(voucherId);
        mockitoPermissionOk();
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(voucherId);
        voucherDO.setSellerId(sellerId);
        voucherDO.setNodeKey(VoucherStatus.CREATED.getCode());
        voucherDO.setVoucherSubType(VoucherSubType.FALSE_CONDUCT_VIOLATION);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(sellerId,voucherId);

        Mockito.doThrow(new RuntimeException()).when(voucherRepository).deletePunish(Matchers.any(),Matchers.any());
        ResultDTO<VoidEntity> resultDTO = depositController.deletePunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_STORE_DB_FAILED);
    }

    @Test(description = "不可删除:状态为创建状态,类型为虚假宣传,删除成功 ")
    public void test9(){
        long sellerId = 10000000101L;
        String voucherId = "100000";
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(sellerId);
        dealPunishParam.setVoucherId(voucherId);
        mockitoPermissionOk();
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(voucherId);
        voucherDO.setSellerId(sellerId);
        voucherDO.setNodeKey(VoucherStatus.CREATED.getCode());
        voucherDO.setVoucherSubType(VoucherSubType.FALSE_CONDUCT_VIOLATION);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(sellerId,voucherId);

        ResultDTO<VoidEntity> resultDTO = depositController.deletePunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_SUCCESS);
    }
}
