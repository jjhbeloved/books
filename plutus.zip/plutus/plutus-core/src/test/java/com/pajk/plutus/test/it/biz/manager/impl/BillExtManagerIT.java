package com.pajk.plutus.test.it.biz.manager.impl;

import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.kylin.api.service.PermissionService;
import com.pajk.plutus.biz.common.util.JsonUtil;
import com.pajk.plutus.biz.manager.BillExtManager;
import com.pajk.plutus.biz.model.query.bill.BillStatusDTO;
import com.pajk.plutus.biz.model.query.bill.SellerDTO;
import com.pajk.plutus.test.it.BaseIT;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.ArrayList;

import static org.assertj.core.api.Assertions.assertThat;

public class BillExtManagerIT extends BaseIT {

    @Autowired
    BillExtManager billExtManager;

    @Test
    public void testGetBillStatus() {
        BatchResultDTO<BillStatusDTO> all = billExtManager.getBillStatus();
        assertThat(all.isSuccess()).isTrue();
        assertThat(all.getModel()).isNotNull();
    }

    @Test
    public void testGetSellers() {
        BatchResultDTO<SellerDTO> sellers = billExtManager.getSellers();
        assertThat(sellers.isSuccess()).isTrue();
        assertThat(sellers.getModel()).isNotNull();
    }

    @Autowired
    private PermissionService permissionService;
    @Test
    public void x() {
        KyCallResult<String>  stringKyCallResult = permissionService.getCurRole(20024130208L, null);
        System.out.println(JsonUtil.obj2Str(stringKyCallResult.getModel()));
    }
}
