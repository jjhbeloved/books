package com.pajk.plutus.test.ut.biz.service.web;

import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.BillExtManager;
import com.pajk.plutus.biz.manager.BillManager;
import com.pajk.plutus.biz.manager.permission.UserManger;
import com.pajk.plutus.biz.manager.permission.UserUtil;
import com.pajk.plutus.biz.model.bill.*;
import com.pajk.plutus.biz.model.param.restapi.PageQuerySettlementParam;
import com.pajk.plutus.biz.model.param.restapi.SettlementParam;
import com.pajk.plutus.biz.model.process.TransitionDO;
import com.pajk.plutus.biz.model.query.bill.BillSettlementDTO;
import com.pajk.plutus.biz.service.web.BillQueryController;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseServiceUT;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.user.model.User;
import org.assertj.core.util.Lists;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import java.util.Date;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.when;

/**
 * Created by arjaylv on 2017/12/13.
 *
 * @author arjaylv
 */
public class BillQueryControllerUT extends BaseServiceUT {

    @InjectMocks
    private BillQueryController billQueryController;

    @Mock
    private BillManager billManager;

    @Mock
    private BillExtManager billExtManager;

    @Mock
    private UserManger userManger;

    @Mock
    private ControlCache controlCache;

//    @Test
//    public void testPageQuerySettlement() {
//        when(userManger.getCurrentUserRole()).thenReturn("CWCN_OP");
//        PageQuerySettlementParam pageQuerySettlementParam = new PageQuerySettlementParam();
//        PageResultDTO<BillSettlementDO> pageResult = new PageResultDTO<>();
//        when(billManager.pageQuerySettlementByCondition(anyString(), anyInt(), anyInt(), anyMap())).thenReturn(pageResult);
//        PageResultDTO<BillSettlementDTO> result = billQueryController.pageQuerySettlement(pageQuerySettlementParam);
//        assertThat(result.getModel()).isEmpty();
//    }

//    @Test
//    public void testPageQuerySettlementParamsNull() {
//        when(userManger.getCurrentUserRole()).thenReturn("CWCN_OP");
//        PageQuerySettlementParam pageQuerySettlementParam = new PageQuerySettlementParam();
//        PageResultDTO<BillSettlementDO> pageResult = new PageResultDTO<>();
//        pageQuerySettlementParam.setStartTime("2017-11");
//        pageQuerySettlementParam.setEndTime("2017-11");
//        pageQuerySettlementParam.setSellerId(null);
//        pageQuerySettlementParam.setNodeKey(null);
//        when(billManager.pageQuerySettlementByCondition(anyString(), anyInt(), anyInt(), anyMap())).thenReturn(pageResult);
//        PageResultDTO<BillSettlementDTO> result = billQueryController.pageQuerySettlement(pageQuerySettlementParam);
//        assertThat(result.getModel()).isEmpty();
//    }

//    @Test
//    public void testPageQuerySettlementParamsNull2() {
//        when(userManger.getCurrentUserRole()).thenReturn("CWCN_OP");
//        PageQuerySettlementParam pageQuerySettlementParam = new PageQuerySettlementParam();
//        PageResultDTO<BillSettlementDO> pageResult = new PageResultDTO<>();
//        pageQuerySettlementParam.setStartTime("2017-01");
//        pageQuerySettlementParam.setEndTime("2017-12");
//        pageQuerySettlementParam.setSellerId(null);
//        pageQuerySettlementParam.setNodeKey("test");
//        pageQuerySettlementParam.setNodeKey("all");
//        when(billManager.pageQuerySettlementByCondition(anyString(), anyInt(), anyInt(), anyMap())).thenReturn(pageResult);
//        PageResultDTO<BillSettlementDTO> result = billQueryController.pageQuerySettlement(pageQuerySettlementParam);
//        assertThat(result.getModel()).isEmpty();
//    }
//
//    @Test
//    public void testPageQuerySettlementResultOtherEmpty() {
//        when(userManger.getCurrentUserRole()).thenReturn("CWCN_OP");
//        when(controlCache.getBillSettlementQueryDaySpan()).thenReturn(367);
//        when(controlCache.getBillSettlementQueryDayInterval()).thenReturn(365);
//        PageQuerySettlementParam pageQuerySettlementParam = new PageQuerySettlementParam();
//        pageQuerySettlementParam.setStartTime("2018-01");
//        pageQuerySettlementParam.setEndTime("2018-12");
//        pageQuerySettlementParam.setSellerId(123L);
//        pageQuerySettlementParam.setNodeKey("test");
//        PageResultDTO<BillSettlementDO> pageResult = new PageResultDTO<>();
//        BillSettlementDO billSettlementDO = new BillSettlementDO();
//
//        billSettlementDO.setSettlementType(1);
//        billSettlementDO.setPayToType(1);
//
//        pageResult.setModel(Lists.newArrayList(billSettlementDO));
//        mockitoPermissionOk();
//        when(billManager.pageQuerySettlementByCondition(anyString(), anyInt(), anyInt(), anyMap())).thenReturn(pageResult);
//        PageResultDTO<BillSettlementDTO> result = billQueryController.pageQuerySettlement(pageQuerySettlementParam);
//        assertThat(result.getModel()).isNotEmpty();
//    }

//    @Test
//    public void testPageQuerySettlementResultException() {
//        when(userManger.getCurrentUserRole()).thenReturn("CWCN_OP");
//        when(controlCache.getBillSettlementQueryDaySpan()).thenReturn(367);
//        when(controlCache.getBillSettlementQueryDayInterval()).thenReturn(365);
//        PageQuerySettlementParam pageQuerySettlementParam = new PageQuerySettlementParam();
//        pageQuerySettlementParam.setStartTime("2017-01");
//        pageQuerySettlementParam.setEndTime("2017-12");
//        PageResultDTO<BillSettlementDO> pageResult = new PageResultDTO<>();
//        BillSettlementDO billSettlementDO = new BillSettlementDO();
//
//        billSettlementDO.setSettlementType(1);
//        billSettlementDO.setPayToType(1);
//
//        pageResult.setModel(Lists.newArrayList(billSettlementDO));
//
//        when(billManager.pageQuerySettlementByCondition(anyString(), anyInt(), anyInt(), anyMap())).thenThrow(new RuntimeException());
//        PageResultDTO<BillSettlementDTO> result = billQueryController.pageQuerySettlement(pageQuerySettlementParam);
//        assertThat(result.getModel()).isEmpty();
//    }

//
//    @Test
//    public void testPageQuerySettlementResultFalse() {
//        when(userManger.getCurrentUserRole()).thenReturn("CWCN_OP");
//        when(controlCache.getBillSettlementQueryDaySpan()).thenReturn(367);
//        when(controlCache.getBillSettlementQueryDayInterval()).thenReturn(365);
//        PageQuerySettlementParam pageQuerySettlementParam = new PageQuerySettlementParam();
//        pageQuerySettlementParam.setStartTime("2017-12");
//        pageQuerySettlementParam.setEndTime("2018-01");
//        PageResultDTO<BillSettlementDO> pageResult = new PageResultDTO<>();
//        BillSettlementDO billSettlementDO = new BillSettlementDO();
//
//        billSettlementDO.setSettlementType(1);
//        billSettlementDO.setPayToType(1);
//        mockitoPermissionOk();
//        pageResult.setModel(Lists.newArrayList(billSettlementDO));
//
//        pageResult.setResultCode(0);
//        when(billManager.pageQuerySettlementByCondition(anyString(), anyInt(), anyInt(), anyMap())).thenReturn(pageResult);
//        PageResultDTO<BillSettlementDTO> result = billQueryController.pageQuerySettlement(pageQuerySettlementParam);
//        assertThat(result.getResultCode()).isEqualTo(0);
//    }
//
//    @Test
//    public void testPageQuerySettlementResultResult() {
//        User user = new User(123L);
//        user.setName("test");
//        UserUtil.putUser(user);
//        mockitoPermissionOk();
//        when(userManger.getCurrentUserRole()).thenReturn("CWCN_OP");
//        when(controlCache.getBillSettlementQueryDaySpan()).thenReturn(367);
//        when(controlCache.getBillSettlementQueryDayInterval()).thenReturn(365);
//        PageQuerySettlementParam pageQuerySettlementParam = new PageQuerySettlementParam();
//        pageQuerySettlementParam.setStartTime("2018-01");
//        pageQuerySettlementParam.setEndTime("2018-12");
//        PageResultDTO<BillSettlementDO> pageResult = new PageResultDTO<>();
//        BillSettlementDO billSettlementDO = buildSettlement();
//        pageResult.setModel(Lists.newArrayList(billSettlementDO));
//        Mockito.doReturn(pageResult).when(billManager).pageQuerySettlementByCondition(anyString(), anyInt(), anyInt(), anyMap());
//
//        PageResultDTO<BillSettlementDTO> result = billQueryController.pageQuerySettlement(pageQuerySettlementParam);
//        assertThat(result.getModel()).isNotEmpty();
//    }

    @Test
    public void testQuerySettlement() {
        ResultDTO<BillSettlementDO> resultDTO = new ResultDTO<>();
        resultDTO.setModel(buildSettlement());

        Mockito.doReturn(resultDTO).when(billManager).querySettlement(anyLong());

        SettlementParam settlementParam = new SettlementParam();
        settlementParam.setBillId(123L);
        mockitoPermissionOk();
        ResultDTO<BillSettlementDTO> result = billQueryController.querySettlement(settlementParam);
        assertThat(result.getModel()).isNotNull();
    }

    @Test
    public void testQuerySettlementException() {
        ResultDTO<BillSettlementDO> resultDTO = new ResultDTO<>();
        resultDTO.setModel(buildSettlement());
        when(billManager.querySettlement(anyLong())).thenThrow(new RuntimeException());

        SettlementParam settlementParam = new SettlementParam();
        settlementParam.setBillId(123L);
        ResultDTO<BillSettlementDTO> result = billQueryController.querySettlement(settlementParam);
        assertThat(result.getModel()).isNull();
    }

    private BillSettlementDO buildSettlement() {
        BillSettlementDO billSettlementDO = new BillSettlementDO();

        billSettlementDO.setSettlementType(1);
        billSettlementDO.setPayToType(1);

        List<PaymentInfoDO> paymentInfoDOS = Lists.newArrayList();
        paymentInfoDOS.add(new PaymentInfoDO());
        billSettlementDO.setPaymentInfoDOS(paymentInfoDOS);

        billSettlementDO.setInvoiceInfoDO(new InvoiceInfoDO());
        billSettlementDO.setSellerAccountInfoDO(new SellerAccountInfoDO());
        billSettlementDO.setSellerInvoiceInfoDO(new SellerInvoiceInfoDO());
        billSettlementDO.setAccountInfoSnapshotDO(new AccountInfoSnapshotDO());
        billSettlementDO.setInvoiceInfoSnapshotDO(new InvoiceInfoSnapshotDO());

        ConfirmInfoDO confirmInfoDO = new ConfirmInfoDO();
        confirmInfoDO.setFileInfoDO(Lists.newArrayList(new FileInfoDO()));
        billSettlementDO.setConfirmInfoDO(confirmInfoDO);

        SettlementOperationDO settlementOperationDO = new SettlementOperationDO();
        settlementOperationDO.setOperationStartTime(new DateTime(new Date()).toDate());
        settlementOperationDO.setOperationEndTime(new DateTime(new Date()).plusDays(2).toDate());
        settlementOperationDO.setOperationVote("test");
        SettlementOperationDO settlementOperationDO2 = new SettlementOperationDO();
        settlementOperationDO2.setOperationStartTime(new DateTime(new Date()).toDate());
        settlementOperationDO2.setOperationEndTime(new DateTime(new Date()).plusDays(2).toDate());
        billSettlementDO.setSettlementOperationDOS(Lists.newArrayList(settlementOperationDO, settlementOperationDO2));

        BillSettlementItemDO billSettlementItemDO = new BillSettlementItemDO();
        billSettlementItemDO.setBillType(3);
        billSettlementItemDO.setId(1L);
        billSettlementDO.setBillSettlementItemDOS(Lists.newArrayList(billSettlementItemDO));

        CascadeButtonDO cascadeButtonDO = new CascadeButtonDO();
        cascadeButtonDO.setName("");
        cascadeButtonDO.setTransitions(Lists.newArrayList(new TransitionDO()));
        billSettlementDO.setCascadeButtonDOs(Lists.newArrayList(cascadeButtonDO));
        return billSettlementDO;
    }


    @Test
    public void queryConfirmSettlement() {

        SettlementParam param = new SettlementParam();
        param.setBillId(1L);
        String curRole = "BD";

        ResultDTO<BillSettlementDO> resultDO = new ResultDTO<>();
        BillSettlementDO settlementDO = buildSettlement();
        settlementDO.setRole(curRole);
        resultDO.setModel(settlementDO);

        Mockito.when(billManager.queryConfirmSettlement(anyLong())).thenReturn(resultDO);

        Mockito.when(userManger.getCurrentUserRole()).thenReturn(curRole);

        BatchResultDTO<ButtonDO> batchResultDTO = new BatchResultDTO<>();
        Mockito.when(billManager.getButtons(anyLong(), anyString())).thenReturn(batchResultDTO);

        UserUtil.putUser(new User(3333L));
        mockitoPermissionOk();
        ResultDTO<BillSettlementDTO> resultDTO = billQueryController.queryConfirmSettlement(param);
        Assert.assertNotNull(resultDTO);
        Assert.assertTrue(resultDTO.isSuccess());
        Assert.assertNotNull(resultDTO.getModel());


        resultDO.setResultCode(ErrorCode.BILL_NOT_EXIST.getCode());
        resultDTO = billQueryController.queryConfirmSettlement(param);
        Assert.assertFalse(resultDTO.isSuccess());

        resultDO.setResultCode(ErrorCode.SUCCESS.getCode());
        settlementDO.setRole(null);
        resultDTO = billQueryController.queryConfirmSettlement(param);
        Assert.assertTrue(resultDTO.isSuccess());
        Assert.assertNotNull(resultDTO.getModel());
        Assert.assertEquals(1, resultDTO.getModel().getActionButtons().size());

        settlementDO.setProcInstId(null);
        resultDTO = billQueryController.queryConfirmSettlement(param);
        Assert.assertTrue(resultDTO.isSuccess());
        Assert.assertNotNull(resultDTO.getModel());
        Assert.assertEquals(1, resultDTO.getModel().getActionButtons().size());
    }


}
