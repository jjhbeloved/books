package com.pajk.plutus.test.ut.biz.service.gw.depositquerygwservice;

import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.dao.repo.impl.AccountQueryRepositoryImpl;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.manager.impl.AccountManagerImpl;
import com.pajk.plutus.biz.model.account.AccountBookFlowDO;
import com.pajk.plutus.biz.model.query.account.BookFlowPageQuery;
import com.pajk.plutus.biz.service.gw.DepositQueryGWServiceImpl;
import com.pajk.plutus.client.api.gw.DepositQueryGWService;
import com.pajk.plutus.client.model.enums.account.BookFlowType;
import com.pajk.plutus.client.model.enums.account.BookFlowWriteOffOutType;
import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.account.PageAccountBookFlowGW;
import com.pajk.plutus.test.ut.BaseGwServiceUT;
import org.apache.commons.lang3.math.NumberUtils;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by  guguangming on 2018/01/03
 **/
public class PageQuerySellerBookFlowUT extends BaseGwServiceUT {
    @InjectMocks
    private DepositQueryGWService depositQueryGWService = new DepositQueryGWServiceImpl();

    @InjectMocks
    @Spy
    private AccountManager accountManager = new AccountManagerImpl();

    @InjectMocks
    @Spy
    private AccountQueryRepository accountQueryRepository = new AccountQueryRepositoryImpl();


    @Mock
    private ControlCache controlCache;

    private int flowType = 1000;
    private String startTime = "2018-01-04";
    private String endTime = "2018-01-04";
    private int pageSize = 20;
    private int pageNo = 1;

    private long amount = 100L;
    private String outerId = "12312";


    @Test(description = "分页查询->超过最大数量")
    public void test1() {
        mockitoPermissionOk();

        PageAccountBookFlowGW bookFlowGW = depositQueryGWService.pageQuerySellerBookFlow(defaultAppId, defaultUserId,
                defaultSellerId, flowType, startTime, endTime, pageNo, 200000);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(bookFlowGW).isNull();
    }

    @Test(description = "分页查询 pageNo错误 返回->超过最大数量")
    public void test2() {
        mockitoPermissionOk();
        PageAccountBookFlowGW bookFlowGW = depositQueryGWService.pageQuerySellerBookFlow(defaultAppId, defaultUserId,
                defaultSellerId, flowType, startTime, endTime, -2, 20);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(bookFlowGW).isNull();
    }


    @Test(description = "flowType错误 ")
    public void test3() {
        mockitoPermissionOk();
        PageAccountBookFlowGW bookFlowGW = depositQueryGWService.pageQuerySellerBookFlow(defaultAppId, defaultUserId,
                defaultSellerId, 33333, startTime, endTime, pageNo, pageSize);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(bookFlowGW).isNull();
    }

    @Test(description = "end.getTime() < start.getTime() ")
    public void test4() {
        mockitoPermissionOk();
        PageAccountBookFlowGW bookFlowGW = depositQueryGWService.pageQuerySellerBookFlow(defaultAppId, defaultUserId,
                defaultSellerId, flowType, "2018-01-04 16:28:41", "2018-01-01 16:28:53", pageNo, pageSize);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(bookFlowGW).isNull();
    }


    @Test(description = "查询成功如何处理 ")
    public void test6() {
        mockitoPermissionOk();

        Mockito.doReturn(20).when(controlCache).getAccountBookFlowDefaultQueryDaySpan();

        Mockito.doReturn(1).when(accountQueryRepository).queryBookFlowCount(Matchers.any(BookFlowPageQuery.class));

        List<AccountBookFlowDO> list = new ArrayList<>();

        AccountBookFlowDO flowDO = buildAccountBookFlowDO();
        list.add(flowDO);
        Mockito.doReturn(Optional.of(list)).when(accountQueryRepository).pageQueryBookFlow(Matchers.any(BookFlowPageQuery.class));


        PageAccountBookFlowGW bookFlowGW = depositQueryGWService.pageQuerySellerBookFlow(defaultAppId, defaultUserId,
                defaultSellerId, flowType, startTime, endTime, pageNo, pageSize);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode._C_SUCCESS);
        assertThat(bookFlowGW).isNotNull();
        assertThat(bookFlowGW.depositFlows.size()).isNotZero();
        assertThat(bookFlowGW.depositFlows.get(0).amount).isEqualTo(amount);
        assertThat(bookFlowGW.depositFlows.get(0).voucherId).isEqualTo(outerId);

    }

    @Test(description = "flowType为负数 ")
    public void test7() {
        mockitoPermissionOk();

        Mockito.doReturn(20).when(controlCache).getAccountBookFlowDefaultQueryDaySpan();

        Mockito.doReturn(1).when(accountQueryRepository).queryBookFlowCount(Matchers.any(BookFlowPageQuery.class));

        List<AccountBookFlowDO> list = new ArrayList<>();

        AccountBookFlowDO flowDO = buildAccountBookFlowDO();
        list.add(flowDO);
        Mockito.doReturn(Optional.of(list)).when(accountQueryRepository).pageQueryBookFlow(Matchers.any(BookFlowPageQuery.class));


        PageAccountBookFlowGW bookFlowGW = depositQueryGWService.pageQuerySellerBookFlow(defaultAppId, defaultUserId,
                defaultSellerId, -1, startTime, endTime, pageNo, pageSize);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode._C_SUCCESS);
        assertThat(bookFlowGW).isNotNull();
        assertThat(bookFlowGW.depositFlows.size()).isNotZero();
        assertThat(bookFlowGW.depositFlows.get(0).amount).isEqualTo(amount);
        assertThat(bookFlowGW.depositFlows.get(0).voucherId).isEqualTo(outerId);

    }

    @Test(description = "startTime 为空 ")
    public void test8() {
        mockitoPermissionOk();

        Mockito.doReturn(20).when(controlCache).getAccountBookFlowDefaultQueryDaySpan();

        Mockito.doReturn(1).when(accountQueryRepository).queryBookFlowCount(Matchers.any(BookFlowPageQuery.class));

        List<AccountBookFlowDO> list = new ArrayList<>();

        AccountBookFlowDO flowDO = buildAccountBookFlowDO();
        list.add(flowDO);
        Mockito.doReturn(Optional.of(list)).when(accountQueryRepository).pageQueryBookFlow(Matchers.any(BookFlowPageQuery.class));


        PageAccountBookFlowGW bookFlowGW = depositQueryGWService.pageQuerySellerBookFlow(defaultAppId, defaultUserId,
                defaultSellerId, -1, null, null, pageNo, pageSize);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode._C_SUCCESS);
        assertThat(bookFlowGW).isNotNull();
        assertThat(bookFlowGW.depositFlows.size()).isNotZero();
        assertThat(bookFlowGW.depositFlows.get(0).amount).isEqualTo(amount);
        assertThat(bookFlowGW.depositFlows.get(0).voucherId).isEqualTo(outerId);

    }


    private AccountBookFlowDO buildAccountBookFlowDO() {
        AccountBookFlowDO flowDO = new AccountBookFlowDO();
        flowDO.setWriteOffType(BookFlowWriteOffOutType.FC_VOUCHER);
        flowDO.setAmount(amount);
        flowDO.setFlowType(BookFlowType.PAYMENT);
        flowDO.setGmtStatement(new Date());
        flowDO.setOutId(outerId);
        return flowDO;
    }


}
