package com.pajk.plutus.test.ut.biz.service.web.depositcontroller;

import com.pajk.plutus.biz.common.idgen.IDPool;
import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.dao.repo.VoucherRepository;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.param.restapi.CreatePunishParam;
import com.pajk.plutus.biz.service.web.DepositController;
import com.pajk.plutus.client.model.enums.account.BookType;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by lizhijun on 2017/12/29.
 */
public class CreatePunishUT extends BaseWebServiceUT {
    @InjectMocks
    private DepositController depositController = new DepositController();

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @Mock
    private AccountQueryRepository accountQueryRepository;

    @Mock
    private VoucherRepository voucherRepository;

    @Mock
    private IDPool voucherIDPool;
    private static final String createFile = "";
    private static final String createRemark = "createRemark";
    private static final long sellerId = 12000000101L;
    private static final int voucherSubType = VoucherSubType.FALSE_CONDUCT_VIOLATION.getCode();
    private static final long expectAmt = 10000L;

    @Test(description = "商户id不合法")
    public void test1(){
        CreatePunishParam createPunishParam = buildCreatePunishParam(111111L,voucherSubType,expectAmt,createFile,createRemark);

        ResultDTO<VoidEntity> resultDTO =  depositController.createPunish(createPunishParam);

        assertThat(ErrorCode.C_PARAM_ERROR).isEqualTo(resultDTO.getResultCode());
    }

    @Test(description = "类型不合法")
    public void test2(){
        CreatePunishParam createPunishParam = buildCreatePunishParam(sellerId,10000,expectAmt,createFile,createRemark);

        ResultDTO<VoidEntity> resultDTO =  depositController.createPunish(createPunishParam);

        assertThat(ErrorCode.C_PARAM_ERROR).isEqualTo(resultDTO.getResultCode());
    }

    @Test(description = "预期金额小于等于0")
    public void test3(){
        CreatePunishParam createPunishParam = buildCreatePunishParam(sellerId,voucherSubType,0L,createFile,createRemark);

        ResultDTO<VoidEntity> resultDTO =  depositController.createPunish(createPunishParam);

        assertThat(ErrorCode.C_PARAM_ERROR).isEqualTo(resultDTO.getResultCode());
    }

    @Test(description = "备注长度超过500")
    public void test4(){
        StringBuilder sb = new StringBuilder();
        for (int i=0 ;i<100 ;i++){
            sb.append("remark");
        }
        CreatePunishParam createPunishParam = buildCreatePunishParam(sellerId,voucherSubType,expectAmt,createFile,sb.toString());

        ResultDTO<VoidEntity> resultDTO =  depositController.createPunish(createPunishParam);

        assertThat(ErrorCode.C_PARAM_ERROR).isEqualTo(resultDTO.getResultCode());
    }

    @Test(description = "文件格式不正确")
    public void test5(){
        StringBuilder sb = new StringBuilder();
        for (int i=0 ;i<100 ;i++){
            sb.append("remark");
        }
        String files="[{\"name\":123}]";
        CreatePunishParam createPunishParam = buildCreatePunishParam(sellerId,voucherSubType,expectAmt,files,sb.toString());

        ResultDTO<VoidEntity> resultDTO =  depositController.createPunish(createPunishParam);

        assertThat(ErrorCode.C_PARAM_ERROR).isEqualTo(resultDTO.getResultCode());
    }

    @Test(description = "创建成功")
    public void test6(){
        StringBuilder sb = new StringBuilder();
        for (int i=0 ;i<10 ;i++){
            sb.append("remark");
        }
        String files="[{\"fileKey\":123}]";
        CreatePunishParam createPunishParam = buildCreatePunishParam(sellerId,voucherSubType,expectAmt,files,sb.toString());
        mockitoPermissionOk();
        Mockito.doReturn(1).when(accountQueryRepository).queryBookCount(Matchers.any());
        AccountBookDO bookDO = new AccountBookDO();
        bookDO.setContractAmt(expectAmt + 10000L);
        Mockito.doReturn(Optional.of(bookDO)).when(accountQueryRepository).queryValidBookBySeller(sellerId,BookType.DEPOSIT.getCode());

        Mockito.doReturn("1000000").when(voucherIDPool).getNewId();

        ResultDTO<VoidEntity> resultDTO =  depositController.createPunish(createPunishParam);

        assertThat(ErrorCode.C_SUCCESS).isEqualTo(resultDTO.getResultCode());
    }

    @Test(description = "创建发生异常")
    public void test7(){
        StringBuilder sb = new StringBuilder();
        for (int i=0 ;i<10 ;i++){
            sb.append("remark");
        }
        String files="[{\"fileKey\":123}]";
        CreatePunishParam createPunishParam = buildCreatePunishParam(sellerId,voucherSubType,expectAmt,files,sb.toString());
        mockitoPermissionOk();
        Mockito.doReturn(1).when(accountQueryRepository).queryBookCount(Matchers.any());
        AccountBookDO bookDO = new AccountBookDO();
        bookDO.setContractAmt(expectAmt + 10000L);
        Mockito.doReturn(Optional.of(bookDO)).when(accountQueryRepository).queryValidBookBySeller(sellerId,BookType.DEPOSIT.getCode());

        Mockito.doReturn("1000000").when(voucherIDPool).getNewId();

        Mockito.doThrow(new RuntimeException()).when(voucherRepository).createPunish(Matchers.any(),Matchers.any());

        ResultDTO<VoidEntity> resultDTO =  depositController.createPunish(createPunishParam);

        assertThat(ErrorCode.C_STORE_DB_FAILED).isEqualTo(resultDTO.getResultCode());
    }

    private CreatePunishParam buildCreatePunishParam(long sellerId,Integer voucherSubType,
                                                     Long expectAmt, String createFile, String createRemark){
        CreatePunishParam createPunishParam = new CreatePunishParam();
        createPunishParam.setSellerId(sellerId);
        createPunishParam.setVoucherSubType(voucherSubType);
        createPunishParam.setExpectAmt(expectAmt);
        createPunishParam.setCreateFile(createFile);
        createPunishParam.setCreateRemark(createRemark);
        return createPunishParam;
    }


}
