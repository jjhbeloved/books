package com.pajk.plutus.test.ut.biz.service.web.billquerycontroller;

import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyBatchResult;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.common.util.TimeUtils;
import com.pajk.plutus.biz.dao.repo.BillSettlementQueryRepository;
import com.pajk.plutus.biz.dao.repo.SellerAccountInfoRepository;
import com.pajk.plutus.biz.dao.repo.SellerInvoiceInfoRepository;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.BillManager;
import com.pajk.plutus.biz.manager.impl.BillManagerImpl;
import com.pajk.plutus.biz.manager.permission.UserManger;
import com.pajk.plutus.biz.model.bill.BillSettlementDO;
import com.pajk.plutus.biz.model.bill.SellerAccountInfoDO;
import com.pajk.plutus.biz.model.bill.SellerInvoiceInfoDO;
import com.pajk.plutus.biz.model.param.restapi.PageQuerySettlementParam;
import com.pajk.plutus.biz.model.query.bill.BillSettlementDTO;
import com.pajk.plutus.biz.service.web.BillQueryController;
import com.pajk.plutus.client.model.enums.bill.SettlementType;
import com.pajk.plutus.client.model.enums.trade.PayToType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.taskcenter.client.model.dto.GetNodeInfoResultDTO;
import com.pajk.taskcenter.client.model.dto.NodeDTO;
import com.pajk.taskcenter.client.model.result.BatchResult;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 18/1/3.
 * Modify by fanhuafeng on 18/1/3
 */
public class PageQuerySettlementUT extends BaseWebServiceUT {

    // 商家收款-平安应付
    public final static String TYPE_SJSKPAYF = "BillSJSKPAYF";
    // 平台收款-平安应付
    public final static String TYPE_PTSKPAYF = "BillPTSKPAYF";
    // 商家收款-平安应收
    public final static String TYPE_SJSKPAYS = "BillSJSKPAYS";

    protected static final String SYSTEM = "plutus";
    protected static final String KY_SYSTEM = "taskcenter";
    protected static final String CHANNEL = "all";
    protected static final String PROC_DEF_SOURCE = "procDef";





    @InjectMocks
    private BillQueryController billQueryController = new BillQueryController();

    @InjectMocks
    @Spy
    private BillManager billManager = new BillManagerImpl();


    @InjectMocks
    @Spy
    private UserManger userManger = new UserManger();

    @Mock
    private BillSettlementQueryRepository billSettlementQueryRepository;

    @Mock
    private SellerInvoiceInfoRepository sellerInvoiceInfoRepository;

    @Mock
    private SellerAccountInfoRepository sellerAccountInfoRepository;

    @Mock
    private ControlCache controlCache;

    @Test(description = "时间超长")
    public void test01(){
        PageQuerySettlementParam param = new PageQuerySettlementParam();
        param.setStartTime("2016-11");
        param.setEndTime("2017-12");


        Mockito.doReturn(10).when(controlCache).getBillSettlementQueryDayInterval();

        PageResultDTO<BillSettlementDTO> result = billQueryController.pageQuerySettlement(param);
        assertThat(result.getResultCode()).isEqualTo(ErrorCode.C_QUERY_INTERVAL_OVER_THRESHOLD);

    }


    @Test
    public void test02(){

        Mockito.doReturn(930).when(controlCache).getBillSettlementQueryDaySpan();
        Mockito.doReturn(3650).when(controlCache).getBillSettlementQueryDayInterval();
        mockitoPermissionOk();



        PageQuerySettlementParam param = new PageQuerySettlementParam();
        param.setStartTime("2017-11");
        param.setEndTime("2017-12");

        KyCallResult<String> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(false);
        Mockito.doReturn(kyCallResult).when(permissionService).getCurRole(defaultUserId, null);


        PageResultDTO<BillSettlementDTO> result = billQueryController.pageQuerySettlement(param);
        assertThat(result.getResultCode()).isEqualTo(ErrorCode.C_EXCEPTION);

    }


    @Test(description = "总数为0")
    public void test03(){

        Mockito.doReturn(930).when(controlCache).getBillSettlementQueryDaySpan();
        Mockito.doReturn(3650).when(controlCache).getBillSettlementQueryDayInterval();
        mockitoPermissionOk();



        PageQuerySettlementParam param = new PageQuerySettlementParam();
        param.setStartTime("2017-11");
        param.setEndTime("2017-12");

        KyCallResult<String> kyCallResult = new KyCallResult<>();
        kyCallResult.setModel("SELLER_OP");
        Mockito.doReturn(kyCallResult).when(permissionService).getCurRole(defaultUserId, null);


        Mockito.doReturn(0).when(billSettlementQueryRepository).count(Matchers.anyMap());


        PageResultDTO<BillSettlementDTO> result = billQueryController.pageQuerySettlement(param);
        assertThat(result.isSuccess()).isTrue();
        assertThat(result.getPageNo()).isEqualTo(param.getPageNo());
        assertThat(result.getPageSize()).isEqualTo(param.getPageSize());
        assertThat(result.getTotalCount()).isEqualTo(0);

    }

    @Test(description = "总数为10 查询超过总数")
    public void test04(){

        Mockito.doReturn(930).when(controlCache).getBillSettlementQueryDaySpan();
        Mockito.doReturn(3650).when(controlCache).getBillSettlementQueryDayInterval();
        mockitoPermissionOk();



        PageQuerySettlementParam param = new PageQuerySettlementParam();
        param.setStartTime("2017-11");
        param.setEndTime("2017-12");

        KyCallResult<String> kyCallResult = new KyCallResult<>();
        kyCallResult.setModel("SELLER_OP");
        Mockito.doReturn(kyCallResult).when(permissionService).getCurRole(defaultUserId, null);


        Mockito.doReturn(10).when(billSettlementQueryRepository).count(Matchers.anyMap());
        Mockito.doReturn(new LinkedList()).when(billSettlementQueryRepository).pageList(Matchers.anyInt(), Matchers.anyInt(), Matchers.anyMap());


        PageResultDTO<BillSettlementDTO> result = billQueryController.pageQuerySettlement(param);
        assertThat(result.isSuccess()).isTrue();
        assertThat(result.getPageNo()).isEqualTo(param.getPageNo());
        assertThat(result.getPageSize()).isEqualTo(param.getPageSize());
        assertThat(result.getTotalCount()).isEqualTo(10);
        assertThat(result.getModel().size()).isEqualTo(0);

    }


    @Test(description = "总数为1 有1条记录, 流程没开始")
    public void test05(){

        Mockito.doReturn(930).when(controlCache).getBillSettlementQueryDaySpan();
        Mockito.doReturn(3650).when(controlCache).getBillSettlementQueryDayInterval();
        mockitoPermissionOk();

        PageQuerySettlementParam param = new PageQuerySettlementParam();
        param.setStartTime("2017-11");
        param.setEndTime("2017-12");

        KyCallResult<String> kyCallResult = new KyCallResult<>();
        kyCallResult.setModel("SELLER_OP");
        Mockito.doReturn(kyCallResult).when(permissionService).getCurRole(defaultUserId, null);


        Mockito.doReturn(1).when(billSettlementQueryRepository).count(Matchers.anyMap());

        List<BillSettlementDO> bills = new LinkedList();
        BillSettlementDO bill1 = buildBillSettlement();
        bills.add(bill1);


        KyBatchResult<SellerDO> sellerListResult = new KyBatchResult<>();
        List<SellerDO> sellers = new LinkedList<>();
        SellerDO sellerDO = new SellerDO();
        sellerDO.setId(defaultSellerId);
        sellers.add(sellerDO);
        sellerListResult.setModel(sellers);

        Mockito.doReturn(sellerListResult).when(sellerService).getSellersByIds(Matchers.anyList());



        KyBatchResult<AppResourceDO> k1 = new KyBatchResult<>();
        KyBatchResult<AppResourceDO> k2 = new KyBatchResult<>();
        KyBatchResult<AppResourceDO> k3 = new KyBatchResult<>();

        Mockito.doReturn(k1).when(appResourceService).getAppResource(KY_SYSTEM, CHANNEL, TYPE_SJSKPAYF, PROC_DEF_SOURCE);
        Mockito.doReturn(k2).when(appResourceService).getAppResource(KY_SYSTEM, CHANNEL, TYPE_PTSKPAYF, PROC_DEF_SOURCE);
        Mockito.doReturn(k3).when(appResourceService).getAppResource(KY_SYSTEM, CHANNEL, TYPE_SJSKPAYS, PROC_DEF_SOURCE);




        Mockito.doReturn(bills).when(billSettlementQueryRepository).pageList(Matchers.anyInt(), Matchers.anyInt(), Matchers.anyMap());
        Optional<SellerAccountInfoDO> optionalSellerAccountInfoDO = Optional.empty();
        Optional<SellerInvoiceInfoDO> optionalSellerInvoiceInfoDO = Optional.empty();
        Mockito.doReturn(optionalSellerAccountInfoDO).when(sellerAccountInfoRepository).queryBySellerId(Matchers.anyLong(), Matchers.anyInt());
        Mockito.doReturn(optionalSellerInvoiceInfoDO).when(sellerInvoiceInfoRepository).queryBySellerId(Matchers.anyLong(), Matchers.anyInt());

        PageResultDTO<BillSettlementDTO> result = billQueryController.pageQuerySettlement(param);
        assertThat(result.isSuccess()).isTrue();
        assertThat(result.getPageNo()).isEqualTo(param.getPageNo());
        assertThat(result.getPageSize()).isEqualTo(param.getPageSize());
        assertThat(result.getTotalCount()).isEqualTo(1);
        assertThat(result.getModel().size()).isEqualTo(1);

    }


    @Test(description = "总数为1 有1条记录, 流程开始")
    public void test056(){

        Mockito.doReturn(930).when(controlCache).getBillSettlementQueryDaySpan();
        Mockito.doReturn(3650).when(controlCache).getBillSettlementQueryDayInterval();
        mockitoPermissionOk();

        PageQuerySettlementParam param = new PageQuerySettlementParam();
        param.setStartTime("2017-11");
        param.setEndTime("2017-12");

        KyCallResult<String> kyCallResult = new KyCallResult<>();
        kyCallResult.setModel("SELLER_OP");
        Mockito.doReturn(kyCallResult).when(permissionService).getCurRole(defaultUserId, null);


        Mockito.doReturn(1).when(billSettlementQueryRepository).count(Matchers.anyMap());

        List<BillSettlementDO> bills = new LinkedList();
        BillSettlementDO bill1 = buildBillSettlement();
        bill1.setProcInstId(1234567L);
        bill1.setRole("SELLER_OP");


        bills.add(bill1);


        BatchResult<GetNodeInfoResultDTO> batchResult = new BatchResult<>();
        GetNodeInfoResultDTO getNodeInfoResultDTO = new GetNodeInfoResultDTO();
        List<GetNodeInfoResultDTO> getNodeInfoResultDTOs = new LinkedList<>();
        getNodeInfoResultDTOs.add(getNodeInfoResultDTO);
        NodeDTO nodeDTO = new NodeDTO();

        getNodeInfoResultDTO.setNodeDTO(nodeDTO);

        batchResult.setModel(getNodeInfoResultDTOs);
        Mockito.doReturn(batchResult).when(flowService).getNodeInfoList(Matchers.anyList());




        KyBatchResult<SellerDO> sellerListResult = new KyBatchResult<>();
        List<SellerDO> sellers = new LinkedList<>();
        SellerDO sellerDO = new SellerDO();
        sellerDO.setId(defaultSellerId);
        sellers.add(sellerDO);
        sellerListResult.setModel(sellers);

        Mockito.doReturn(sellerListResult).when(sellerService).getSellersByIds(Matchers.anyList());



        KyBatchResult<AppResourceDO> k1 = new KyBatchResult<>();
        KyBatchResult<AppResourceDO> k2 = new KyBatchResult<>();
        KyBatchResult<AppResourceDO> k3 = new KyBatchResult<>();

        Mockito.doReturn(k1).when(appResourceService).getAppResource(KY_SYSTEM, CHANNEL, TYPE_SJSKPAYF, PROC_DEF_SOURCE);
        Mockito.doReturn(k2).when(appResourceService).getAppResource(KY_SYSTEM, CHANNEL, TYPE_PTSKPAYF, PROC_DEF_SOURCE);
        Mockito.doReturn(k3).when(appResourceService).getAppResource(KY_SYSTEM, CHANNEL, TYPE_SJSKPAYS, PROC_DEF_SOURCE);




        Mockito.doReturn(bills).when(billSettlementQueryRepository).pageList(Matchers.anyInt(), Matchers.anyInt(), Matchers.anyMap());
        Optional<SellerAccountInfoDO> optionalSellerAccountInfoDO = Optional.empty();
        Optional<SellerInvoiceInfoDO> optionalSellerInvoiceInfoDO = Optional.empty();
        Mockito.doReturn(optionalSellerAccountInfoDO).when(sellerAccountInfoRepository).queryBySellerId(Matchers.anyLong(), Matchers.anyInt());
        Mockito.doReturn(optionalSellerInvoiceInfoDO).when(sellerInvoiceInfoRepository).queryBySellerId(Matchers.anyLong(), Matchers.anyInt());

        PageResultDTO<BillSettlementDTO> result = billQueryController.pageQuerySettlement(param);
        assertThat(result.isSuccess()).isTrue();
        assertThat(result.getPageNo()).isEqualTo(param.getPageNo());
        assertThat(result.getPageSize()).isEqualTo(param.getPageSize());
        assertThat(result.getTotalCount()).isEqualTo(1);
        assertThat(result.getModel().size()).isEqualTo(1);

    }



    private BillSettlementDO buildBillSettlement(){
        BillSettlementDO bill1 = new BillSettlementDO();
        bill1.setSellerId(defaultSellerId);
        bill1.setId(1234L);
        bill1.setSettlementType(SettlementType.PA_PAY.getCode());
        bill1.setPayToType(PayToType.PAY_TO_SELLER.getCode());
        bill1.setBillNo(1000100101L);
        bill1.setMonth(TimeUtils.parse("2017-11",TimeUtils.MONTH_FORMAT));
        bill1.setBillAmt(12345678L);
        bill1.setActualBillAmt(123456789L);


        return bill1;

    }
}
