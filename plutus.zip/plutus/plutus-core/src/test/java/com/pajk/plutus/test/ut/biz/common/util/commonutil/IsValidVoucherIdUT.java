package com.pajk.plutus.test.ut.biz.common.util.commonutil;

import com.pajk.plutus.biz.common.util.CommonUtil;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 17/12/28.
 * Modify by fanhuafeng on 17/12/28
 */
public class IsValidVoucherIdUT {


    @Test
    public void testSuccess(){
        String no = "1009877";
        boolean flag = CommonUtil.isValidVoucherId(no);
        assertThat(flag).isTrue();
    }


    @Test()
    public void test1(){
        String no = "  ";
        boolean flag = CommonUtil.isValidVoucherId(no);
        assertThat(flag).isFalse();
    }

    @Test()
    public void test2(){
        String no = ",a234234234";
        boolean flag = CommonUtil.isValidVoucherId(no);
        assertThat(flag).isFalse();
    }


    @Test()
    public void test3(){
        String no = "-100006";
        boolean flag = CommonUtil.isValidVoucherId(no);
        assertThat(flag).isFalse();
    }
    @Test()
    public void test4(){
        String no = "0";
        boolean flag = CommonUtil.isValidVoucherId(no);
        assertThat(flag).isFalse();
    }

}
