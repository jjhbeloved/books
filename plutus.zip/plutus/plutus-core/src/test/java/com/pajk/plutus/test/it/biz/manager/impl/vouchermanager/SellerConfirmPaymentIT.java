package com.pajk.plutus.test.it.biz.manager.impl.vouchermanager;

import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.permission.AuthResourceProperties;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.test.it.BaseIT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * Created by lizhijun on 2017/12/22.
 */
public class SellerConfirmPaymentIT extends BaseIT {
    @Autowired
    private VoucherManager voucherManager;

    @Test
    public void testSuccess(){
        long sellerId = 20021820000L;
        String voucherId = "131";
        String nodeKey = "sellerConfirm";
        String transitionKey = "confirm";
        String remark = "remark_remark841";
        String evidenceFlow = "evidenceFlow841";
        UserParam userParam = new UserParam();

        //userParam.setAppId(AuthResourceProperties.APPID);
        //userParam.setDomainId(AuthResourceProperties.DOMAIN_ID);
        //userParam.setUserId(20019550008L);

        userParam.setAppId(defaultAppId);
        userParam.setDomainId(defaultDomainId);
        userParam.setUserId(defaultUserId);

        ResultDTO<VoidEntity> resultDTO =  voucherManager.sellerConfirmPayment(
                sellerId,voucherId,transitionKey,nodeKey,remark,evidenceFlow,"",userParam);
        System.out.println(resultDTO);
    }
}
