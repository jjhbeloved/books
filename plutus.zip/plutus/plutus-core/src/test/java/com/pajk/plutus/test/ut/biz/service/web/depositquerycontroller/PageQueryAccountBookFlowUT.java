package com.pajk.plutus.test.ut.biz.service.web.depositquerycontroller;

import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.manager.impl.AccountManagerImpl;
import com.pajk.plutus.biz.model.account.AccountBookFlowDO;
import com.pajk.plutus.biz.model.param.restapi.PageQueryAccountBookFlowParam;
import com.pajk.plutus.biz.model.result.dto.account.AccountBookFlowDTO;
import com.pajk.plutus.biz.service.web.DepositQueryController;
import com.pajk.plutus.client.model.enums.account.BookFlowType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 17/12/28.
 * Modify by fanhuafeng on 17/12/28
 */
public class PageQueryAccountBookFlowUT extends BaseWebServiceUT {

    @InjectMocks
    private DepositQueryController depositQueryController = new DepositQueryController();

    @InjectMocks
    @Spy
    private AccountManager accountManager = new AccountManagerImpl();

    @Mock
    private AccountQueryRepository accountQueryRepository;

    @Mock
    private ControlCache controlCache;

    private static final long defaultAccountId = 1;
    private static final long defaultBookId = 2;


    @Test(description = "pageSize超出最大值, startDate is not null, endDate is not null")
    public void test1() {
        PageQueryAccountBookFlowParam param = buildQueryParam();
        param.setPageSize(100000000);

        PageResultDTO<AccountBookFlowDTO> result = depositQueryController.pageQueryAccountBookFlow(param);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.PAGE_SIZE_OUT_OF_MAX_VALUE.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.PAGE_SIZE_OUT_OF_MAX_VALUE.getDesc());
    }

    @Test(description = "startDate is null, endDate is null, flowType > 0")
    public void test2() {
        PageQueryAccountBookFlowParam param = buildQueryParam();
        param.setGmtStatementStart(null);
        param.setGmtStatementEnd(null);

        mockitoPermissionOk();

        Optional<List<AccountBookFlowDO>> optional = Optional.empty();
        Mockito.doReturn(optional).when(accountQueryRepository).pageQueryBookFlow(Matchers.any());

        PageResultDTO<AccountBookFlowDTO> result = depositQueryController.pageQueryAccountBookFlow(param);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
    }

    @Test(description = "startDate is not null, endDate is null, flowType < 0")
    public void test3() {
        PageQueryAccountBookFlowParam param = buildQueryParam();
        param.setGmtStatementEnd(null);
        param.setFlowType(-1);

        mockitoPermissionOk();

        Optional<List<AccountBookFlowDO>> optional = Optional.empty();
        Mockito.doReturn(optional).when(accountQueryRepository).pageQueryBookFlow(Matchers.any());

        PageResultDTO<AccountBookFlowDTO> result = depositQueryController.pageQueryAccountBookFlow(param);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
    }

    @Test(description = "startDate is null, endDate is not null")
    public void test4() {
        PageQueryAccountBookFlowParam param = buildQueryParam();
        param.setGmtStatementStart(null);

        mockitoPermissionOk();

        Optional<List<AccountBookFlowDO>> optional = Optional.empty();
        Mockito.doReturn(optional).when(accountQueryRepository).pageQueryBookFlow(Matchers.any());

        PageResultDTO<AccountBookFlowDTO> result = depositQueryController.pageQueryAccountBookFlow(param);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
    }

    @Test(description = "startDate < endDate")
    public void test5() {
        PageQueryAccountBookFlowParam param = buildQueryParam();
        param.setGmtStatementStart("2017-12-20 01:00:00");
        param.setGmtStatementEnd("2017-12-10 01:00:00");

        mockitoPermissionOk();

        Optional<List<AccountBookFlowDO>> optional = Optional.empty();
        Mockito.doReturn(optional).when(accountQueryRepository).pageQueryBookFlow(Matchers.any());

        PageResultDTO<AccountBookFlowDTO> result = depositQueryController.pageQueryAccountBookFlow(param);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.PARAM_ERROR.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.PARAM_ERROR.getDesc());
    }

    private PageQueryAccountBookFlowParam buildQueryParam() {
        PageQueryAccountBookFlowParam param = new PageQueryAccountBookFlowParam();
        param.setSellerId(defaultSellerId);
        param.setAccountBookId(defaultBookId);
        param.setFlowType(BookFlowType.VIOLATION.getCode());
        param.setGmtStatementEnd("2017-12-20 01:00:00");
        param.setGmtStatementStart("2017-12-10 01:00:00");
        param.setPageNo(1);
        param.setPageSize(50);
        return param;
    }

}
