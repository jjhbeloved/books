package com.pajk.plutus.test.ut.biz.service.web.depositcontroller;

import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.dao.repo.VoucherRepository;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.param.restapi.AuditPaymentParam;
import com.pajk.plutus.biz.service.web.DepositController;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.testng.annotations.Test;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by lizhijun on 2018/1/4.
 */
public class financeAuditPaymentUT extends BaseWebServiceUT {
    @InjectMocks
    private DepositController depositController = new DepositController();

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @Mock
    private VoucherQueryRepository voucherQueryRepository;

    @Mock
    private VoucherRepository voucherRepository;

    @Mock
    private ControlCache controlCache;

    private static final String voucherId = "100";
    private static final String nodeKey = "nodeKey";
    private static final String nodeCatKey = "nodeCatKey";
    private static final String transitionKey = "transitionKey";
    private static final String role = "role";
    private static final String path = "deposit/financeAuditPayment";

    @Test(description = "参数错误:商户id不对")
    public void test1(){
        AuditPaymentParam param = buildParam();
        param.setSellerId(1100001111L);
        ResultDTO<VoidEntity> resultDTO = depositController.financeAuditPayment(param);
        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "参数错误:商户id不对")
    public void test2(){
        AuditPaymentParam param = buildParam();
        param.setSellerId(1100001111L);
        param.setVoucherId("l2");
        ResultDTO<VoidEntity> resultDTO = depositController.financeAuditPayment(param);
        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "参数错误:单据id不对")
    public void test3(){
        AuditPaymentParam param = buildParam();
        param.setVoucherId("l1");
        ResultDTO<VoidEntity> resultDTO = depositController.financeAuditPayment(param);
        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "参数错误:remark太长")
    public void test4(){
        AuditPaymentParam param = buildParam();
        StringBuilder sb = new StringBuilder();
        for (int i=0; i<100; i++){
            sb.append("remark");
        }
        param.setRemark(sb.toString());
        ResultDTO<VoidEntity> resultDTO = depositController.financeAuditPayment(param);
        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "单据不存在")
    public void test5(){
        mockitoPermissionOk();
        AuditPaymentParam param = buildParam();
        Mockito.doReturn(Optional.empty()).when(voucherQueryRepository).queryVoucherById(param.getSellerId(),param.getVoucherId());

        ResultDTO<VoidEntity> resultDTO = depositController.financeAuditPayment(param);
        assertThat(ErrorCode.VOUCHER_NOT_EXISTS.eq(resultDTO.getResultCode())).isTrue();
    }


    private AuditPaymentParam buildParam(){
        AuditPaymentParam param = new AuditPaymentParam();
        param.setSellerId(defaultSellerId);
        param.setVoucherId(voucherId);
        param.setNodeKey(nodeKey);
        param.setTransitionKey(transitionKey);
        param.setRemark("remark");
        return param;
    }


}
