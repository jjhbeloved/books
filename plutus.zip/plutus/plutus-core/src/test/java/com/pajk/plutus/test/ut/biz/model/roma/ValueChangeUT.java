package com.pajk.plutus.test.ut.biz.model.roma;

import com.pajk.plutus.biz.model.roma.ValueChange;
import com.pajk.plutus.test.ut.BaseServiceUT;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;


/**
 * Created by fanhuafeng on 17/12/29.
 * Modify by fanhuafeng on 17/12/29
 */
public class ValueChangeUT extends BaseServiceUT {


    @Test
    public void test01(){

        ValueChange valueChange = new ValueChange();
        valueChange.setOldValue("123");
        valueChange.setNewValue("456");
        assertThat(valueChange.isChanged()).isTrue();
        valueChange.getNewValue();
        valueChange.getOldValue();

        valueChange.toString();



    }


    @Test
    public void test02(){

        ValueChange valueChange2 = new ValueChange();
        valueChange2.setOldValue("1");
        valueChange2.setNewValue("1");
        assertThat(valueChange2.isChanged()).isFalse();
        valueChange2.toString();


    }

    @Test
    public void test03(){

        ValueChange valueChange = new ValueChange();
        valueChange.setOldValue("");
        valueChange.setNewValue("456");

        valueChange.toString();

    }

    @Test
    public void test04(){

        ValueChange valueChange = new ValueChange();
        valueChange.setOldValue("1");
        valueChange.setNewValue("");

        valueChange.toString();

    }

    @Test
    public void test05(){

        ValueChange valueChange = new ValueChange();
        valueChange.setOldValue("");
        valueChange.setNewValue("");

        valueChange.toString();

    }
}