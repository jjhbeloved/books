package com.pajk.plutus.test.ut.biz.common.util.commonutil;

import com.pajk.plutus.biz.common.util.CommonUtil;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by lizhijun on 2018/1/9.
 */
public class FenToYuanUT {
    @Test
    public void test01(){
        long amount = 103L;
        String i = CommonUtil.fenToYuan(amount);
        assertThat(i).isEqualTo("1.03");

        long amount2 = 20L;
        String i2 = CommonUtil.fenToYuan(amount2);
        System.out.println(i2);

        assertThat(i2).isEqualTo("0.20");

    }
}
