package com.pajk.plutus.test.ut.biz.service.web.depositquerycontroller;

import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherDeliveryMapper;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherMapper;
import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.param.restapi.QueryVoucherParam;
import com.pajk.plutus.biz.model.result.dto.voucher.VoucherDTO;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.model.voucher.VoucherDeliveryDO;
import com.pajk.plutus.biz.service.web.DepositQueryController;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.taskcenter.client.model.dto.GetNodeInfoResultDTO;
import com.pajk.taskcenter.client.model.dto.NodeDTO;
import com.pajk.taskcenter.client.model.dto.TaskInstDTO;
import com.pajk.taskcenter.client.model.dto.TransitionDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.apache.commons.lang3.math.NumberUtils;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.*;

import static com.pajk.plutus.biz.model.enums.VoucherExtPropsKey.EVIDENCE_FLOW;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.doReturn;

/**
 * Created by  guguangming on 2017/12/29
 **/
public class QueryVoucherOptUT extends BaseWebServiceUT {

    @InjectMocks
    private DepositQueryController depositQueryController = new DepositQueryController();

    @Mock
    protected VoucherMapper voucherMapper;

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @Mock
    protected VoucherQueryRepository voucherQueryRepository;

    @Mock
    protected VoucherDeliveryMapper voucherDeliveryMapper;

    private String fileToken = "12321321";

    private String key3 = "审核中";
    private String nodeKey = "sellerConfirm";
    private String role = "SELLER_OP";
    private String evidenceFlow = "91122222";
    private String procInstId = "22198321";
    private String transitionKey = nodeKey;
    private String transitionName = key3;
    private String sellerName = "好药师";

    private QueryVoucherParam buildQueryVoucherParam() {
        QueryVoucherParam param = new QueryVoucherParam();
        param.setSellerId(defaultSellerId);
        param.setVoucherId(defaultVoucherId);
        return param;
    }

    @Test(description = "查询失败->voucher 不存在")
    public void test_001() {
        mockitoPermissionOk();
        Mockito.doReturn(Optional.empty()).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.VOUCHER_NOT_EXISTS.getCode());
    }

    @Test(description = "查询失败->VOUCHER_DELIVERY_NOT_EXISTS ")
    public void test_002() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.empty()).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.VOUCHER_DELIVERY_NOT_EXISTS.getCode());
    }

    @Test(description = "非PAYMENT  nodeKeyName 查询失败 ")
    public void test_003() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);
        //mock 角色名称
        mockitoCurrentUserRoleOK(role);
        //mock fileToken
        mockFileToken("12");
        //mock fileGwDomain
        mockFilegwDomain("fileGwDomain");
        //mock seller 商户信息
        mockSeller(buildSellerDO(), true);
        //mock 文案中心数据
        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(false);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
        List<AppResourceDO> doList = new LinkedList<>();

        doList.add(buildAppResourceDO());
        //mock 批量查询文案中心
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        //mock 流程记录
        mockGetFinishedActInstList(taskInstDTOS, true);
        //mock 流程记录节点信息
        mockNodeInfoList(buildListGetNodeInfo(), true);


        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        VoucherDTO voucher = result.getModel();
        assertThat(voucher).isNotNull();
        assertThat(voucher.getNodeKeyName()).isNull();
        assertThat(voucher.getAuditFlows().size()).isNotZero();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);
    }

    @Test(description = "非PAYMENT 构造附件TFS地址和文件名称 buildFileUrl分支覆盖 fileName / fileKey 为空 ")
    public void test_004() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        voucherDO.setCreateFile("[{\"fileKey\":\"T1iNxTBTxT1RCvBVdK.jpg\"}]");
        voucherDO.setEvidenceFile("[{\"fileName\":\"timg.jpg\"}]");

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);
        mockitoCurrentUserRoleOK(role);
        mockFileToken("12");
        mockFilegwDomain("filegwDomain");
        mockSeller(buildSellerDO(), true);
        mockAppResourceDO(buildAppResourceDO());

        List<AppResourceDO> doList = new LinkedList<>();

        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);
        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        mockNodeInfoList(buildListGetNodeInfo(), true);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        VoucherDTO voucher = result.getModel();
        assertThat(voucher.getNodeKeyName()).isNotNull();
        assertThat(voucher.getAuditFlows().size()).isNotZero();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);
        //验证
        assertThat(voucher.getCreateFiles().get(0).getFileKey()).isNull();
        assertThat(voucher.getCreateFiles().get(0).getFileName()).isNull();
        assertThat(voucher.getEvidenceFiles().get(0).getFileName()).isNotNull();
        assertThat(voucher.getEvidenceFiles().get(0).getFileKey()).isNull();

    }

    @Test(description = "非PAYMENT fileTokenService.requestFileToken  查询失败  即fileToken 为空 ")
    public void test_005() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);
        mockitoCurrentUserRoleOK(role);
        // fileTokenService.requestFileToken 查询失败  即为空格
        mockFileToken("");
        mockFilegwDomain("filegwDomain");
        mockSeller(buildSellerDO(), true);

        mockAppResourceDO(buildAppResourceDO());

        List<AppResourceDO> doList = new LinkedList<>();
        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);
        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        mockNodeInfoList(buildListGetNodeInfo(), true);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());


        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        VoucherDTO voucher = result.getModel();

        assertThat(voucher.getNodeKeyName()).isNotNull();
        assertThat(voucher.getAuditFlows().size()).isNotZero();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);
        //验证
        assertThat(voucher.getCreateFiles().get(0).getFileKey()).isNull();
        assertThat(voucher.getCreateFiles().get(0).getFileName()).isNotNull();
        assertThat(voucher.getEvidenceFiles().get(0).getFileName()).isNotNull();
        assertThat(voucher.getEvidenceFiles().get(0).getFileKey()).isNull();

    }

    @Test(description = "非PAYMENT 流程记录查询成功，批量读取文案中心失败  -> " +
            "appResourceService.getAppResource(system, channel, type, source);则审批记录role、nodeKeyDesc为空 ")
    public void test_006() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);
        mockitoCurrentUserRoleOK(role);
        mockFileToken("12");
        mockFilegwDomain("filegwDomain");
        mockSeller(buildSellerDO(), true);

        mockAppResourceDO(buildAppResourceDO());
        // 处理为失败
        mockBatchAppResourceDO(null, false);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        mockNodeInfoList(buildListGetNodeInfo(), true);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());


        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        VoucherDTO voucher = result.getModel();
        assertThat(voucher.getNodeKeyName()).isNotNull();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);
        assertThat(voucher.getCreateFiles().get(0).getFileKey()).isNotNull();
        assertThat(voucher.getCreateFiles().get(0).getFileKey()).isNotNull();
        assertThat(voucher.getEvidenceFiles().get(0).getFileName()).isNotNull();
        assertThat(voucher.getEvidenceFiles().get(0).getFileKey()).isNotNull();

        // 验证
        assertThat(voucher.getAuditFlows().size()).isNotZero();
        assertThat(voucher.getAuditFlows().get(0).getRole()).isNull();
        assertThat(voucher.getAuditFlows().get(0).getNodeKeyDesc()).isNull();

    }

    @Test(description = "非PAYMENT 类型 操作按钮查询 查询角色失败 apiName 为空")
    public void test_007() {

        baseQueryMock();

        KyCallResult<String> resultKy = new KyCallResult<>();
        resultKy.setSuccess(false);
        resultKy.setModel(role);
        doReturn(resultKy).when(permissionService).getCurRole(anyLong(), anyLong());

        mockNodeInfoList(buildListGetNodeInfo(), true);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        VoucherDTO voucher = result.getModel();
        assertThat(voucher.getNodeKeyName()).isEqualTo(key3);
        assertThat(voucher.getApiName()).isNull();
        assertThat(voucher.getAuditFlows().size()).isNotZero();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);

    }


    @Test(description = "非PAYMENT 类型 操作按钮查询 查询角色成功 角色为空")
    public void test_008() {

        baseQueryMock();

        mockitoCurrentUserRoleOK("");

        mockNodeInfoList(buildListGetNodeInfo(), true);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        VoucherDTO voucher = result.getModel();
        assertThat(voucher.getNodeKeyName()).isEqualTo(key3);
        assertThat(voucher.getApiName()).isNull();
        assertThat(voucher.getAuditFlows().size()).isNotZero();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);

    }

    @Test(description = "非PAYMENT 类型 操作按钮查询 查询角色成功 角色不匹配")
    public void test_009() {

        baseQueryMock();

        mockitoCurrentUserRoleOK("111111");

        mockNodeInfoList(buildListGetNodeInfo(), true);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        VoucherDTO voucher = result.getModel();
        assertThat(voucher.getApiName()).isNull();
        assertThat(voucher.getAuditFlows().size()).isNotZero();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);

    }

    @Test(description = "非PAYMENT 类型 操作按钮查询 查询角色成功 分支NodeDto为空 ")
    public void test_010() {

        baseQueryMock();

        mockitoCurrentUserRoleOK(role);
        //NodeDto为空
        List<GetNodeInfoResultDTO> resultDTOS = new LinkedList<>();
        mockNodeInfoList(resultDTOS, true);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        VoucherDTO voucher = result.getModel();
        assertThat(voucher.getNodeKeyName()).isEqualTo(key3);
        assertThat(voucher.getApiName()).isNull();
        assertThat(voucher.getAuditFlows().size()).isNotZero();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);

    }

    @Test(description = "非PAYMENT 类型 操作按钮查询 查询角色成功 flowService.getNodeInfoList 查询 失败")
    public void test_011() {

        baseQueryMock();

        mockitoCurrentUserRoleOK(role);
        //NodeDto为空
        List<GetNodeInfoResultDTO> resultDTOS = new LinkedList<>();
        mockNodeInfoList(resultDTOS, false);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        VoucherDTO voucher = result.getModel();

        assertThat(voucher.getNodeKeyName()).isEqualTo(key3);
        assertThat(voucher.getApiName()).isNull();
        assertThat(voucher.getAuditFlows().size()).isNotZero();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);

    }

    @Test(description = "非PAYMENT 类型 操作按钮查询 查询成功数据验证")
    public void test_012() {

        baseQueryMock();

        mockitoCurrentUserRoleOK(role);
        //NodeDto为空
        List<GetNodeInfoResultDTO> resultDTOS = new LinkedList<>();
        mockNodeInfoList(buildListGetNodeInfo(), true);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());


        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        VoucherDTO voucher = result.getModel();

        assertThat(voucher.getFlowButtons().get(0).getTransitionKey()).isEqualTo(transitionKey);
        assertThat(voucher.getFlowButtons().get(0).getTransitionName()).isEqualTo(transitionName);

        assertThat(voucher.getNodeKeyName()).isEqualTo(key3);
        assertThat(voucher.getAuditFlows().size()).isNotZero();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);

    }


    @Test(description = "非PAYMENT 类型 流程记录查询失败 ")
    public void test_013() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        mockitoCurrentUserRoleOK(role);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("12");
        mockFilegwDomain("filegwDomain");
        mockSeller(buildSellerDO(), true);

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
        List<AppResourceDO> doList = new LinkedList<>();

        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, false);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, false);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        VoucherDTO voucher = result.getModel();

        assertThat(voucher.getNodeKeyName()).isEqualTo(key3);
        assertThat(voucher.getAuditFlows()).isNull();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);

    }


    @Test(description = "PAYMENT 类型 查询成功银行流水为空")
    public void test_014() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherType(VoucherType.PAYMENT);
        voucherDO.setVoucherSubType(VoucherSubType.ADD_DEPOSIT);
        //流水为空
        voucherDO.setExtProps(new HashMap<>());
        mockitoCurrentUserRoleOK(role);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("12");
        mockFilegwDomain("filegwDomain");
        mockSeller(buildSellerDO(), true);

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());

        List<AppResourceDO> doList = new LinkedList<>();
        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());
        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        VoucherDTO voucher = result.getModel();

        assertThat(voucher.getNodeKeyName()).isEqualTo(key3);
        assertThat(voucher.getAuditFlows().size()).isNotZero();
        assertThat(voucher.getPaymentProp().getEvidenceFlow()).isNull();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);

    }

    @Test(description = "PAYMENT 类型 审批记录查询失败 ")
    public void test_015() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherType(VoucherType.PAYMENT);
        voucherDO.setVoucherSubType(VoucherSubType.PAY_IN_BACK_DEPOSIT);
        mockitoCurrentUserRoleOK(role);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("12");
        mockFilegwDomain("filegwDomain");
        mockSeller(buildSellerDO(), true);

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());

        List<AppResourceDO> doList = new LinkedList<>();
        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, false);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucherOpt(buildQueryVoucherParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        VoucherDTO voucher = result.getModel();

        assertThat(voucher.getNodeKeyName()).isEqualTo(key3);
        assertThat(voucher.getAuditFlows()).isNull();
        assertThat(voucher.getPaymentProp().getEvidenceFlow()).isEqualTo(evidenceFlow);
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);

    }


    private void baseQueryMock() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("13");
        mockFilegwDomain("filegwDomain");
        mockSeller(buildSellerDO(), true);

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
        List<AppResourceDO> doList = new LinkedList<>();

        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);
    }

    //PAYMENT 判断  查询流程记录失败 流程记录ApprovalVote 失败  解析文件失败
    private VoucherDO buildVoucherDO() {
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(defaultVoucherId);
        voucherDO.setIsDeleted(0);
        voucherDO.setExpectAmt(100L);
        voucherDO.setSellerId(defaultSellerId);
        voucherDO.setActualAmt(100L);
        voucherDO.setGmtCreated(new Date());
        voucherDO.setRole(role);
        voucherDO.setOutId("0");
        voucherDO.setVoucherType(VoucherType.VIOLATION);
        voucherDO.setNodeKey(nodeKey);
        voucherDO.setProcInstId(procInstId);
        voucherDO.setVoucherSubType(VoucherSubType.FAKE_VIOLATION);

        voucherDO.setCreateFile("[{\"fileKey\":\"T1iNxTBTxT1RCvBVdK.jpg\",\"fileName\":\"timg.jpg\"}]");
        voucherDO.setEvidenceFile("[{\"fileKey\":\"T1iNxTBTxT1RCvBVdK.jpg\",\"fileName\":\"timg.jpg\"}]");
        Map<String, String> ext = new HashMap<>();
        ext.put(EVIDENCE_FLOW.getCode(), evidenceFlow);
        voucherDO.setExtProps(ext);
        return voucherDO;
    }

    private VoucherDeliveryDO buildVoucherDeliveryDO() {
        VoucherDeliveryDO deliveryDO = new VoucherDeliveryDO();
        deliveryDO.setAmount(1);
        deliveryDO.setCompanyId(10001L);
        deliveryDO.setCompanyName("顺丰快递");
        deliveryDO.setCreateTime(new Date());
        deliveryDO.setAmount(1L);
        deliveryDO.setDeliveryTime(new Date());
        deliveryDO.setTrackingNumber("97661270004");
        deliveryDO.setLgTime(new Date());
        return deliveryDO;
    }

    private AppResourceDO buildAppResourceDO() {
        AppResourceDO aDo = new AppResourceDO();
        aDo.key3 = key3;
        aDo.keyName = nodeKey;
        aDo.val = "{ \"sellerConfirm\": \"提示语句\" } ";
        aDo.val2 = role;
        aDo.val3 = "审核成功";
        return aDo;
    }

    private TaskInstDTO buildTaskInstDTO() {
        TaskInstDTO instDTO = new TaskInstDTO();
        instDTO.setNodeKey("sellerAgree");
        instDTO.setApprovalId("111");
        instDTO.setApprovalVote("1111");
        instDTO.setStartTime(new Date());
        return instDTO;
    }

    private List<GetNodeInfoResultDTO> buildListGetNodeInfo() {
        List<GetNodeInfoResultDTO> resultDTOS = new LinkedList<>();
        GetNodeInfoResultDTO dto = new GetNodeInfoResultDTO();
        dto.setNodeKey(nodeKey);
        dto.setSuccess(true);
        dto.setProcInstId(NumberUtils.toLong(procInstId));

        NodeDTO nodeDTO = new NodeDTO();
        nodeDTO.setPath("");
        List<TransitionDTO> transitionDTOList = new LinkedList<>();
        TransitionDTO transitionDTO = new TransitionDTO();
        transitionDTO.setTransitionKey(transitionKey);
        transitionDTO.setTransitionName(transitionName);
        transitionDTOList.add(transitionDTO);
        nodeDTO.setTransitionDTOList(transitionDTOList);

        dto.setNodeDTO(nodeDTO);
        resultDTOS.add(dto);
        return resultDTOS;
    }

    private SellerDO buildSellerDO() {
        SellerDO sellerDO = new SellerDO();
        sellerDO.setName(sellerName);
        sellerDO.setId(defaultSellerId);
        return sellerDO;
    }

}
