package com.pajk.plutus.test.ut.biz.mq.consumer.seller;

import com.pajk.kylin.helpcenter.api.model.message.SellerAddMsg;
import com.pajk.plutus.biz.common.util.ResultUtil;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.model.result.dto.process.TransitionDTO;
import com.pajk.plutus.biz.mq.consumer.seller.KylinAddSellerConsumer;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseServiceUT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 17/12/28.
 * Modify by fanhuafeng on 17/12/28
 */
public class KylinAddSellerConsumerUT extends BaseServiceUT {


    @Mock
    private AccountManager accountManager;


    @InjectMocks
    public KylinAddSellerConsumer consumer ;


    @Test(description = "msg is null")
    public void test0(){

        boolean flag = consumer.doConsumeMessage(null, 1);
        assertThat(flag).isTrue();
    }



    @Test(description = "instanceof 不一致")
    public void test01(){

        boolean flag = consumer.doConsumeMessage(new TransitionDTO(), 1);
        assertThat(flag).isTrue();
    }


    @Test(description = "reconsumeTimes >= limit ")
    public void test02(){

        boolean flag = consumer.doConsumeMessage(new TransitionDTO(), consumer.DEFAULT_RECONSUME_TIMES+ 1);
        assertThat(flag).isTrue();
    }

    @Test(description = "创建账户信息失败")
    public void test03(){
        SellerAddMsg sellerAddMsg = new SellerAddMsg();
        sellerAddMsg.setSellerId(10000000L);

        ResultDTO<VoidEntity> result = ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);

        Mockito.doReturn(result).when(accountManager).createAccount(sellerAddMsg.getSellerId());


        boolean flag = consumer.doConsumeMessage(sellerAddMsg,  1);
        assertThat(flag).isFalse();
    }




    @Test
    public void testSuccess(){
        SellerAddMsg sellerAddMsg = new SellerAddMsg();
        sellerAddMsg.setSellerId(10000000L);

        ResultDTO<VoidEntity> result = new ResultDTO<>();

        Mockito.doReturn(result).when(accountManager).createAccount(sellerAddMsg.getSellerId());


        boolean flag = consumer.doConsumeMessage(sellerAddMsg,  1);
        assertThat(flag).isTrue();
    }



}
