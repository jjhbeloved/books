package com.pajk.plutus.test.ut;

import com.pajk.plutus.biz.manager.permission.UserUtil;
import com.pajk.user.model.User;
import org.testng.annotations.BeforeMethod;

/**
 * Created by fanhuafeng on 17/12/28.
 * Modify by fanhuafeng on 17/12/28
 */
public abstract class BaseWebServiceUT extends BaseServiceUT {

    @BeforeMethod
    public void setUp() throws Exception {
        super.setUp();
        User user = new User(defaultUserId);
        user.setName("test");
        UserUtil.putUser(user);
    }

}
