package com.pajk.plutus.test.ut.biz.manager.voucher;

import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountDAO;
import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDAO;
import com.pajk.plutus.client.model.enums.account.BookStatus;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import java.util.ArrayList;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.*;

/**
 * Created by cuidongchao on 2017/12/29.
 */
public class UpdateContractAmtUT extends BaseVoucherManagerUT {


    private long accountBookId = 1234L;
    private long baseContractAmt = 1000L;
    private long updateContractAmt = 2000L;
    private String remark = "remark";

    @Test(description = "status of AccountBook is invalid")
    public void test001() {

        AccountBookDAO bookDAO = new AccountBookDAO();
        bookDAO.setStatus(BookStatus.INVALID.getCode());
        Mockito.doReturn(bookDAO)
                .when(accountBookMapper)
                .queryBySellerAndType(anyLong(), anyInt());


        ResultDTO<VoidEntity> ret = voucherManager.updateContractAmt(defaultSellerId, accountBookId,
                baseContractAmt, updateContractAmt, remark, null);

        assertThat(ErrorCode.BOOK_IS_IN_VALID.eq(ret.getResultCode())).isTrue();
    }

    @Test(description = "AccountBook does not exists and fail to create process")
    public void test002() {

        mockSellerSuccess();
        mockVoucherIDGen();
        mockFlowServiceCreateProcessFail();

        AccountBookDAO bookDAO = new AccountBookDAO();
        bookDAO.setStatus(BookStatus.VALID.getCode());

        Mockito.doReturn(null)
                .doReturn(bookDAO)
                .when(accountBookMapper)
                .queryBySellerAndType(anyLong(), anyInt());

        AccountDAO accountDAO = new AccountDAO();
        accountDAO.setSellerId(defaultSellerId);
        Mockito.doReturn(accountDAO)
                .when(accountMapper)
                .queryBySeller(anyLong());

        Mockito.doReturn(new ArrayList<>())
                .when(accountBookMapper)
                .queryBySeller(anyLong());

        Mockito.doReturn(1)
                .when(accountBookMapper)
                .create(any(AccountBookDAO.class));

        Mockito.doNothing()
                .when(voucherMapper)
                .create(any(VoucherDAO.class));


        ResultDTO<VoidEntity> ret = voucherManager.updateContractAmt(defaultSellerId, accountBookId,
                baseContractAmt, updateContractAmt, remark, null);

        assertThat(ret.isSuccess()).isFalse();
    }

    @Test(description = "DB exception")
    public void test003() {

        mockSellerSuccess();
        mockVoucherIDGen();
        mockFlowServiceCreateProcessOK();

        AccountBookDAO bookDAO = new AccountBookDAO();
        bookDAO.setStatus(BookStatus.VALID.getCode());
        Mockito.doReturn(bookDAO)
                .when(accountBookMapper)
                .queryBySellerAndType(anyLong(), anyInt());

        Mockito.doNothing()
                .when(voucherMapper)
                .create(any(VoucherDAO.class));

        Mockito.doReturn(0)
                .when(accountBookMapper)
                .updateByOPT(any());


        ResultDTO<VoidEntity> ret = voucherManager.updateContractAmt(defaultSellerId, accountBookId,
                baseContractAmt, updateContractAmt, remark, null);

        assertThat(ret.isSuccess()).isFalse();
    }

    @Test(description = "success")
    public void test004() {

        mockSellerSuccess();
        mockVoucherIDGen();
        mockFlowServiceCreateProcessOK();

        AccountBookDAO bookDAO = new AccountBookDAO();
        bookDAO.setStatus(BookStatus.VALID.getCode());
        Mockito.doReturn(bookDAO)
                .when(accountBookMapper)
                .queryBySellerAndType(anyLong(), anyInt());

        Mockito.doNothing()
                .when(voucherMapper)
                .create(any(VoucherDAO.class));

        Mockito.doReturn(1)
                .when(accountBookMapper)
                .updateByOPT(any());

        Mockito.doNothing()
                .when(accountBookFlowMapper)
                .create(any());

        Mockito.doNothing()
                .when(statementMapper)
                .create(any());

        Mockito.doNothing()
                .when(voucherLogMapper)
                .create(any());


        ResultDTO<VoidEntity> ret = voucherManager.updateContractAmt(defaultSellerId, accountBookId,
                baseContractAmt, updateContractAmt, remark, null);

        assertThat(ret.isSuccess()).isTrue();
    }

}
