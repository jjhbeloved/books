package com.pajk.plutus.test.it.biz.task;

import com.pajk.hawaii.client.JobExecutionContext;
import com.pajk.plutus.biz.task.AddBalanceAmtListener;
import com.pajk.plutus.test.it.BaseIT;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * Created by fuyongda on 2017/12/24.
 * Modified by fuyongda on 2017/12/24.
 */
public class AddBalanceAmtListenerIT extends BaseIT {

    @Autowired
    private AddBalanceAmtListener addBalanceAmtListener;

    @Test
    public void test() {
        JobExecutionContext context = new JobExecutionContext();
        addBalanceAmtListener.execute(context);
    }

}
