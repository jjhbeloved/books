package com.pajk.plutus.test.it.biz.dao.repo.impl;

import com.alibaba.fastjson.JSONObject;
import com.pajk.plutus.biz.dao.repo.BillSettlementQueryRepository;
import com.pajk.plutus.biz.model.bill.BillSettlementDO;
import com.pajk.plutus.test.it.BaseIT;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.Optional;

/**
 * @author david
 * @since created by on 17/12/17 22:52
 */
public class BillSettlementQueryRepositoryImplT extends BaseIT {

    @Autowired
    private BillSettlementQueryRepository billSettlementQueryRepository;

    @Test
    public void testQuerySettlementByBillId() throws Exception {
        Optional<BillSettlementDO> optional = billSettlementQueryRepository.querySettlementByBillId(1L);
        optional.ifPresent(billSettlementDO -> System.out.println(JSONObject.toJSONString(billSettlementDO)));
    }

    @Test
    public void testQuerySettlementByBillId1() throws Exception {
    }

    @Test
    public void testQuerySettlementDetailByBillId() throws Exception {
    }

    @Test
    public void testQuerySettlementDetailByBillId1() throws Exception {
    }

    @Test
    public void testQuerySettlementItemByBillId() throws Exception {
    }

    @Test
    public void testPageQuerySettlement() throws Exception {
    }

}