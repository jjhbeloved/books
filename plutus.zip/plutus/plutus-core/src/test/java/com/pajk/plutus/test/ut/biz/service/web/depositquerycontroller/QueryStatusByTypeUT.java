package com.pajk.plutus.test.ut.biz.service.web.depositquerycontroller;

import com.pajk.plutus.biz.service.web.DepositQueryController;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import org.mockito.InjectMocks;
import org.testng.annotations.Test;

/**
 * Created by lizhijun on 2018/1/4.
 */
public class QueryStatusByTypeUT extends BaseWebServiceUT{

    @InjectMocks
    private DepositQueryController depositQueryController = new DepositQueryController();

    @Test
    public void test1(){

    }
}
