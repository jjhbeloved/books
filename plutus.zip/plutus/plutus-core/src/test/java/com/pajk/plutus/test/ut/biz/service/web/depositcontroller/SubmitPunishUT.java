package com.pajk.plutus.test.ut.biz.service.web.depositcontroller;

import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.dao.repo.VoucherRepository;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.param.restapi.DealPunishParam;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.service.web.DepositController;
import com.pajk.plutus.client.model.enums.voucher.VoucherStatus;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.taskcenter.client.model.dto.CreateProcInstResultDTO;
import com.pajk.taskcenter.client.model.dto.TaskInstDTO;
import com.pajk.taskcenter.client.model.result.BatchResult;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by lizhijun on 2018/1/2.
 */
public class SubmitPunishUT extends BaseWebServiceUT {

    @InjectMocks
    private DepositController depositController = new DepositController();

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @Mock
    private VoucherQueryRepository voucherQueryRepository;

    @Mock
    private VoucherRepository voucherRepository;

    @Test(description = "参数不正确")
    public void test1(){
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(9999999999L);
        dealPunishParam.setVoucherId("100000");
        ResultDTO<VoidEntity> resultDTO = depositController.submitPunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_PARAM_ERROR);
    }

    @Test(description = "单据不存在")
    public void test2(){
        long sellerId = 10000000101L;
        String voucherId = "100000";
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(sellerId);
        dealPunishParam.setVoucherId(voucherId);
        mockitoPermissionOk();
        Mockito.doReturn(Optional.empty()).when(voucherQueryRepository).queryVoucherById(sellerId,voucherId);

        ResultDTO<VoidEntity> resultDTO = depositController.submitPunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_VOUCHER_NOT_EXISTS);
    }

    @Test(description = "状态不匹配:非创建状态,procInstId不为空")
    public void test3(){
        long sellerId = 10000000101L;
        String voucherId = "100000";
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(sellerId);
        dealPunishParam.setVoucherId(voucherId);
        mockitoPermissionOk();
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(voucherId);
        voucherDO.setSellerId(sellerId);
        voucherDO.setNodeKey("nodeKey");
        voucherDO.setProcInstId("procInstId");

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(sellerId,voucherId);

        ResultDTO<VoidEntity> resultDTO = depositController.submitPunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_STATUS_NOT_MATCH);
    }

    @Test(description = "状态不匹配:非创建状态,procInstId为空")
    public void test4(){
        long sellerId = 10000000101L;
        String voucherId = "100001";
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(sellerId);
        dealPunishParam.setVoucherId(voucherId);
        mockitoPermissionOk();
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(voucherId);
        voucherDO.setSellerId(sellerId);
        voucherDO.setNodeKey("nodeKey");

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(sellerId,voucherId);

        ResultDTO<VoidEntity> resultDTO = depositController.submitPunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_STATUS_NOT_MATCH);
    }

    @Test(description = "状态不匹配:创建状态,procInstId不为空")
    public void test5(){
        long sellerId = 10000000101L;
        String voucherId = "100001";
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(sellerId);
        dealPunishParam.setVoucherId(voucherId);
        mockitoPermissionOk();
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(voucherId);
        voucherDO.setSellerId(sellerId);
        voucherDO.setNodeKey(VoucherStatus.CREATED.getCode());
        voucherDO.setProcInstId("procInstId");

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(sellerId,voucherId);

        ResultDTO<VoidEntity> resultDTO = depositController.submitPunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_STATUS_NOT_MATCH);
    }

    @Test(description = "状态不匹配:创建状态,procInstId为空")
    public void test6(){
        long sellerId = 10000000101L;
        String voucherId = "100001";
        DealPunishParam dealPunishParam = new DealPunishParam();
        dealPunishParam.setSellerId(sellerId);
        dealPunishParam.setVoucherId(voucherId);
        mockitoPermissionOk();
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(voucherId);
        voucherDO.setSellerId(sellerId);
        voucherDO.setNodeKey(VoucherStatus.CREATED.getCode());

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(sellerId,voucherId);
        BatchResult<CreateProcInstResultDTO> batchResult = new BatchResult<>();
        CreateProcInstResultDTO createProcInstResultDTO = new CreateProcInstResultDTO();
        List<TaskInstDTO> taskInstDTOs = new LinkedList<>();
        createProcInstResultDTO.setTaskInstDTOList(taskInstDTOs);
        createProcInstResultDTO.getTaskInstDTOList().add(new TaskInstDTO());
        List<CreateProcInstResultDTO> list = new LinkedList<>();
        list.add(createProcInstResultDTO);
        batchResult.setModel(list);
        Mockito.doReturn(batchResult).when(flowService).createProcess(Matchers.any());

        ResultDTO<VoidEntity> resultDTO = depositController.submitPunish(dealPunishParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.C_SUCCESS);
    }
}
