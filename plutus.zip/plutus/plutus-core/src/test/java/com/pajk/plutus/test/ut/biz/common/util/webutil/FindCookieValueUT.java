package com.pajk.plutus.test.ut.biz.common.util.webutil;

import com.pajk.plutus.biz.util.WebUtil;
import com.pajk.plutus.test.ut.BaseServiceUT;
import org.springframework.mock.web.MockHttpServletRequest;
import org.testng.annotations.Test;

import javax.servlet.http.Cookie;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by lizhijun on 2018/1/4.
 */
public class FindCookieValueUT extends BaseServiceUT {

    @Test
    public void test(){
        MockHttpServletRequest request1 = new MockHttpServletRequest();
        Cookie[] cookie = new Cookie[3];
        Cookie cookie1 = new Cookie("cookieName1","cookieName1");
        Cookie cookie2 = new Cookie("cookieName2","cookieName2");
        Cookie cookie3 = new Cookie("cookieName3","cookieName3");
        cookie[0] = cookie1;
        cookie[1] = cookie2;
        cookie[2] = cookie3;

        request1.setCookies(cookie);

        assertThat(WebUtil.findCookieValue(request1,"cookie4")).isNull();
        assertThat(WebUtil.findCookieValue(request1,"cookieName1")).isNotNull();

        MockHttpServletRequest request2 = null;
        assertThat(WebUtil.findCookieValue(request2,"cookie4")).isNull();

        MockHttpServletRequest request3 = new MockHttpServletRequest();
        assertThat(WebUtil.findCookieValue(request3,"cookie4")).isNull();

        MockHttpServletRequest request4 = new MockHttpServletRequest();
        Cookie[] cookieArray2 = new Cookie[0];
        request4.setCookies(cookieArray2);
        assertThat(WebUtil.findCookieValue(request4,"cookie4")).isNull();






    }
}