package com.pajk.plutus.test.ut.biz.common.util.commonutil;

import com.pajk.plutus.biz.common.util.CommonUtil;
import com.pajk.plutus.client.model.result.ErrorCode;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 17/12/28.
 * Modify by fanhuafeng on 17/12/28
 */
public class CheckPageUT {

    private static final int MAX_PAGE_SIZE = 100;
    private static final int MAX_SIZE = 10000;

    @Test
    public void test1(){
        int pageNo = 0;
        int pageSize = 10;

        ErrorCode flag = CommonUtil.checkPage(pageNo,pageSize,MAX_PAGE_SIZE,MAX_SIZE);
        assertThat(flag).isEqualTo(ErrorCode.PARAM_ERROR);
    }

    @Test
    public void test2(){
        int pageNo = 0;
        int pageSize = 0;

        ErrorCode flag = CommonUtil.checkPage(pageNo,pageSize,MAX_PAGE_SIZE,MAX_SIZE);
        assertThat(flag).isEqualTo(ErrorCode.PARAM_ERROR);
    }

    @Test
    public void test3(){
        int pageNo = 1;
        int pageSize = 0;

        ErrorCode flag = CommonUtil.checkPage(pageNo,pageSize,MAX_PAGE_SIZE,MAX_SIZE);
        assertThat(flag).isEqualTo(ErrorCode.PARAM_ERROR);
    }



    @Test
    public void test5(){
        int pageNo = 1;
        int pageSize = 1000;

        ErrorCode flag = CommonUtil.checkPage(pageNo,pageSize,MAX_PAGE_SIZE,MAX_SIZE);
        assertThat(flag).isEqualTo(ErrorCode.PAGE_SIZE_OUT_OF_MAX_VALUE);
    }



    @Test
    public void test7(){
        int pageNo = 1000;
        int pageSize = 100;

        ErrorCode flag = CommonUtil.checkPage(pageNo,pageSize,MAX_PAGE_SIZE,MAX_SIZE);
        assertThat(flag).isEqualTo(ErrorCode.PAGE_SIZE_OUT_OF_MAX_VALUE);
    }

    @Test
    public void test8(){
        int pageNo = 10;
        int pageSize = 100;

        ErrorCode flag = CommonUtil.checkPage(pageNo,pageSize,MAX_PAGE_SIZE,MAX_SIZE);
        assertThat(flag).isEqualTo(ErrorCode.SUCCESS);
    }


}
