package com.pajk.plutus.test.ut.biz.service.web.depositquerycontroller;

import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.plutus.biz.dao.mapper.single.account.AccountBookMapper;
import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.dao.repo.impl.AccountQueryRepositoryImpl;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.manager.impl.AccountManagerImpl;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.biz.model.param.restapi.BookAndSellerParam;
import com.pajk.plutus.biz.model.result.dto.account.AccountBookDTO;
import com.pajk.plutus.biz.service.web.DepositQueryController;
import com.pajk.plutus.client.model.enums.account.BookType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.testng.annotations.Test;

import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fuyongda on 2018/1/5.
 * Modified by fuyongda on 2018/1/5.
 */
public class QueryAccountBookUT extends BaseWebServiceUT {

    @InjectMocks
    private DepositQueryController depositQueryController = new DepositQueryController();

    @InjectMocks
    @Spy
    private AccountManager accountManager = new AccountManagerImpl();

    @InjectMocks
    @Spy
    private AccountQueryRepository accountQueryRepository = new AccountQueryRepositoryImpl();

    @Mock
    private AccountBookMapper bookMapper;

    @Test(description = "账本不存在")
    public void test1() {
        mockitoPermissionOk();

        ResultDTO<AccountBookDTO> resultDTO = depositQueryController.queryAccountBook(this.buildBookAndSellerParam());

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.BOOK_NOT_EXISTS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.BOOK_NOT_EXISTS.getDesc());
    }

    @Test(description = "成功")
    public void test2() {
        AccountBookDAO accountBookDAO = new AccountBookDAO();
        accountBookDAO.setBookType(BookType.DEPOSIT.getCode());
        accountBookDAO.setSellerId(defaultSellerId);

        List<AccountBookDAO> list = new LinkedList<>();
        list.add(accountBookDAO);

        mockSellerDO(new SellerDO());

        mockitoPermissionOk();

        Mockito.doReturn(list).when(bookMapper).queryBySeller(defaultSellerId);

        ResultDTO<AccountBookDTO> resultDTO = depositQueryController.queryAccountBook(this.buildBookAndSellerParam());

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(resultDTO.getModel()).isNotNull();
        assertThat(resultDTO.getModel().getSellerId()).isEqualTo(defaultSellerId);
    }

    private BookAndSellerParam buildBookAndSellerParam() {
        BookAndSellerParam bookAndSellerParam = new BookAndSellerParam();
        bookAndSellerParam.setSellerId(defaultSellerId);
        bookAndSellerParam.setAccountBookId(1234567L);
        return bookAndSellerParam;
    }

}
