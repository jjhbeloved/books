package com.pajk.plutus.test.ut.biz.common.util.commonutil;

import com.pajk.plutus.biz.common.util.CommonUtil;
import com.pajk.plutus.biz.common.util.TimeUtils;
import com.pajk.plutus.client.model.result.ErrorCode;
 import org.testng.annotations.Test;

import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 17/12/28.
 * Modify by fanhuafeng on 17/12/28
 */
public class CheckQueryTimeUT {


    private static final int DAY_SPAN = 92;

    private static final int DAY_INTERVAL = 31;


    @Test
    public void test01(){
        Date start = null;
        Date end = null;


        ErrorCode errorCode = CommonUtil.checkQueryTime(start, end, DAY_SPAN, DAY_INTERVAL);
        assertThat(errorCode).isEqualTo(ErrorCode.PARAM_ERROR);

    }

    @Test
    public void test02(){
        Date start = new Date();
        Date end = null;


        ErrorCode errorCode = CommonUtil.checkQueryTime(start, end, DAY_SPAN, DAY_INTERVAL);
        assertThat(errorCode).isEqualTo(ErrorCode.PARAM_ERROR);

    }

    @Test
    public void test03(){
        Date start = null;
        Date end = new Date();


        ErrorCode errorCode = CommonUtil.checkQueryTime(start, end, DAY_SPAN, DAY_INTERVAL);
        assertThat(errorCode).isEqualTo(ErrorCode.PARAM_ERROR);

    }

    @Test
    public void test04(){
        Date start = TimeUtils.parse("2017-08-20 01:01:01");
        Date end = TimeUtils.parse("2017-11-10 01:01:01");

        ErrorCode errorCode = CommonUtil.checkQueryTime(start, end, DAY_SPAN, DAY_INTERVAL);
        assertThat(errorCode).isEqualTo(ErrorCode.QUERY_INTERVAL_OVER_THRESHOLD);

    }


    @Test
    public void test05(){
        Date start = TimeUtils.parse("2016-11-10 01:01:01");
        Date end = TimeUtils.parse("2016-11-20 01:01:01");

        ErrorCode errorCode = CommonUtil.checkQueryTime(start, end, DAY_SPAN, DAY_INTERVAL);
        assertThat(errorCode).isEqualTo(ErrorCode.QUERY_TOO_OLD);

    }


    @Test
    public void testSuccess(){
        Date start = TimeUtils.parse("2017-12-10 01:01:01");
        Date end = TimeUtils.parse("2017-12-20 01:01:01");

        ErrorCode errorCode = CommonUtil.checkQueryTime(start, end, DAY_SPAN, DAY_INTERVAL);
        assertThat(errorCode).isEqualTo(ErrorCode.SUCCESS);

    }
}
