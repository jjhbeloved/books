package com.pajk.plutus.test.it.biz.service.web;

import com.pajk.plutus.biz.model.param.restapi.PageQuerySettlementParam;
import com.pajk.plutus.biz.model.query.bill.BillSettlementDTO;
import com.pajk.plutus.biz.service.web.BillQueryController;
import com.pajk.plutus.test.it.BaseControllerIT;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * Created by lizhijun on 2018/1/2.
 */
public class BillQueryControllerIT extends BaseControllerIT {

    @Autowired
    private BillQueryController billQueryController;

    @Test
    public void testPageQuery(){
        String startTime = "2017-11";
        String endTime = "2018-02";


        PageQuerySettlementParam pageQuerySettlementParam = new PageQuerySettlementParam();
        pageQuerySettlementParam.setStartTime(startTime);
        pageQuerySettlementParam.setEndTime(endTime);
        pageQuerySettlementParam.setPageNo(1);
        pageQuerySettlementParam.setPageSize(10);

        PageResultDTO<BillSettlementDTO>   result = billQueryController.pageQuerySettlement(pageQuerySettlementParam);

        System.out.println(result);
    }

}
