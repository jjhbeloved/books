package com.pajk.plutus.test.ut.biz.model.enums;

import com.pajk.plutus.biz.model.enums.OptTypeEnum;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 18/1/4.
 * Modify by fanhuafeng on 18/1/4
 */
public class OptTypeEnumUT {


    @Test
    public void test01(){
        OptTypeEnum item = OptTypeEnum.AUDIT_PAYMENT;
        item.getDesc();
    }


    @Test
    public void test02(){
        OptTypeEnum item0 = null;
        OptTypeEnum item1 = OptTypeEnum.AUDIT_PAYMENT;
        OptTypeEnum item2 = OptTypeEnum.ADD_BALANCE_AMT;

        assertThat(OptTypeEnum.ADD_BALANCE_AMT.isEquals(item0)).isFalse();
        assertThat(OptTypeEnum.ADD_BALANCE_AMT.isEquals(item1)).isFalse();
        assertThat(OptTypeEnum.ADD_BALANCE_AMT.isEquals(item2)).isTrue();

    }
}
