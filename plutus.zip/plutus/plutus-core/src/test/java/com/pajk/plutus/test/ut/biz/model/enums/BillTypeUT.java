package com.pajk.plutus.test.ut.biz.model.enums;

import com.pajk.plutus.client.model.enums.bill.BillType;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by  guguangming on 2018/01/03
 **/
public class BillTypeUT {
    @Test
    public void test() {
        BillType key = BillType.PA_NO;
        key.getDesc();
        assertThat(key.getCode()).isEqualTo(0);
        assertThat(key.getDesc()).isEqualTo("未知合计");
        boolean f1 = key.isEquals(0);
        boolean f2 = key.isEquals(BillType.PA_NO);
        assertThat(f1).isTrue();
        assertThat(f2).isTrue();
        assertThat(BillType.valueOf(0)).isEqualTo(key);

    }

}
