package com.pajk.plutus.test.ut.biz.service.web.billquerycontroller;

import com.pajk.plutus.biz.service.web.BillQueryController;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import org.mockito.InjectMocks;

/**
 * Created by fanhuafeng on 18/1/3.
 * Modify by fanhuafeng on 18/1/3
 */
public class QueryConfirmSettlementUT extends BaseWebServiceUT {



    @InjectMocks
    private BillQueryController billQueryController = new BillQueryController();
}
