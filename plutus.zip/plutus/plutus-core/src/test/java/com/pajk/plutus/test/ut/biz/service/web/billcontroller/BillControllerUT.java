package com.pajk.plutus.test.ut.biz.service.web.billcontroller;

import com.pajk.plutus.biz.manager.BillManager;
import com.pajk.plutus.biz.manager.permission.UserManger;
import com.pajk.plutus.biz.manager.permission.UserUtil;
import com.pajk.plutus.biz.model.query.bill.InvoiceInfoDTO;
import com.pajk.plutus.biz.model.query.bill.PaymentInfoDTO;
import com.pajk.plutus.biz.model.query.bill.RemarkDTO;
import com.pajk.plutus.biz.service.web.BillController;
import com.pajk.plutus.biz.service.web.BillQueryController;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseServiceUT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import com.pajk.user.model.User;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.mockito.Matchers.*;

/**
 * @author sunjin
 * @since created by on 17/12/22 18:42
 */
public class BillControllerUT extends BaseServiceUT {

    @InjectMocks
    private BillQueryController billQueryController;

    @InjectMocks
    private BillController billController;

    @Mock
    private BillManager billManager;
    @Mock
    private UserManger userManger;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        User user = new User(1L);
        user.setName("unit test user");
        UserUtil.putUser(user);
    }

    @After
    public void tearDown() {
    }


    @Test
    public void confirmSettlement() {
        RemarkDTO remarkDTO = new RemarkDTO();
        remarkDTO.setBillId(1L);
        remarkDTO.setRemark("");
        remarkDTO.setButtonKey("confirm");
        mockitoPermissionOk();
        ResultDTO<VoidEntity> resultDTO = billController.confirmSettlement(remarkDTO);
        Assert.assertFalse(resultDTO.isSuccess());
        Assert.assertEquals(resultDTO.getResultCode(), ErrorCode.EXCEPTION.getCode());

        Mockito.when(userManger.getCurrentUserRole()).thenReturn("role");
        User user = new User(1L);
        user.setName(null);
        UserUtil.putUser(user);
        resultDTO = billController.confirmSettlement(remarkDTO);
        Assert.assertFalse(resultDTO.isSuccess());
        Assert.assertEquals(resultDTO.getResultCode(), ErrorCode.EXCEPTION.getCode());

        user = new User(1L);
        user.setName("unit test user");
        UserUtil.putUser(user);

        ResultDTO<VoidEntity> result = new ResultDTO<>();
        Mockito.when(billManager.confirmOnlyRemark(anyLong(), anyString(), anyObject(), anyObject())).thenReturn(result);

        resultDTO = billController.confirmSettlement(remarkDTO);
        Assert.assertTrue(resultDTO.isSuccess());
    }

    @Test
    public void testConfirmInvoice() {
        InvoiceInfoDTO invoiceInfoDTO = new InvoiceInfoDTO();
        invoiceInfoDTO.setInvoiceTrackingNumber("2222");
        invoiceInfoDTO.setInvoiceId("123456");
        invoiceInfoDTO.setInvoiceTaxAmt(10086L);
        invoiceInfoDTO.setInvoiceAmt(10086L);
        invoiceInfoDTO.setBillId(147L);
        invoiceInfoDTO.setButtonKey("confirm");
        ResultDTO<VoidEntity> result = new ResultDTO<VoidEntity>();
        Mockito.when(billManager.confirmInvoice(anyObject(), anyObject(), anyObject(), anyBoolean())).thenReturn(result);
        Mockito.when(userManger.getCurrentUserRole()).thenReturn("role");
        mockitoPermissionOk();
        ResultDTO<VoidEntity> resultDTO = billController.confirmInvoice(invoiceInfoDTO);
        Assert.assertTrue(resultDTO.isSuccess());
    }

    @Test
    public void testReceiveInvoice() {
        RemarkDTO remarkDTO = new RemarkDTO();
        remarkDTO.setBillId(1L);
        remarkDTO.setRemark("");
        remarkDTO.setButtonKey("confirm");
        Mockito.when(userManger.getCurrentUserRole()).thenReturn("role");
        ResultDTO<VoidEntity> result = new ResultDTO<>();
        Mockito.when(billManager.receiveInvoice(anyLong(), anyString(), anyObject(), anyObject())).thenReturn(result);
        mockitoPermissionOk();
        ResultDTO<VoidEntity> resultDTO = billController.receiveInvoice(remarkDTO);
        Assert.assertTrue(resultDTO.isSuccess());

    }

    @Test
    public void confirmPayment() {
        PaymentInfoDTO paymentInfoDTO = new PaymentInfoDTO();
        paymentInfoDTO.setPaymentNo("sssss");
        paymentInfoDTO.setPaymentFileId("fileDID");
        ResultDTO<VoidEntity> result = new ResultDTO<>();
        Mockito.when(billManager.confirmPayment(anyObject(), anyObject(), anyObject(), anyBoolean())).thenReturn(result);
        Mockito.when(userManger.getCurrentUserRole()).thenReturn("role");
        mockitoPermissionOk();
        ResultDTO<VoidEntity> resultDTO = billController.confirmPayment(paymentInfoDTO);
        Assert.assertTrue(resultDTO.isSuccess());
    }

    @Test
    public void confirmReceivePayment() {
        RemarkDTO remarkDTO = new RemarkDTO();
        remarkDTO.setBillId(1L);
        remarkDTO.setRemark("");
        remarkDTO.setButtonKey("confirm");
        Mockito.when(userManger.getCurrentUserRole()).thenReturn("role");
        ResultDTO<VoidEntity> result = new ResultDTO<>();
        Mockito.when(billManager.confirmReceivePayment(anyLong(), anyString(), anyObject(), anyObject())).thenReturn(result);
        mockitoPermissionOk();
        ResultDTO<VoidEntity> resultDTO = billController.confirmReceivePayment(remarkDTO);
        Assert.assertTrue(resultDTO.isSuccess());
    }

}