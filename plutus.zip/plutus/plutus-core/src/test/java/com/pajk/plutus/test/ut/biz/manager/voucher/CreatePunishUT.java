package com.pajk.plutus.test.ut.biz.manager.voucher;

import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.exceptions.DBException;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountDAO;
import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDAO;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.client.model.enums.account.BookStatus;
import com.pajk.plutus.client.model.enums.account.BookType;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.*;

/**
 * Created by cuidongchao on 2017/12/22.
 */
public class CreatePunishUT extends BaseVoucherManagerUT {


    @Test(description = "查询到账本为空，创建账本，商户不存在")
    public void test001() {

        Mockito.doReturn(0)
                .when(accountBookMapper).pageQueryCount(any());
        KyCallResult<SellerDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(false);
        Mockito.doReturn(kyCallResult)
                .when(sellerService)
                .getSellerById(any());

        ResultDTO<VoidEntity> ret = voucherManager.createPunish(defaultSellerId, VoucherSubType.FAKE_VIOLATION,
                expectAmt, null, null, new UserParam());

        assertThat(ret.isSuccess()).isFalse();
    }

    @Test(description = "查询到账本为空，创建账本，账户不存在，创建失败")
    public void test002() {

        Mockito.doReturn(0)
                .when(accountBookMapper).pageQueryCount(any());

        mockSellerSuccess();

        Mockito.doReturn(null)
                .when(accountMapper)
                .queryBySeller(anyLong());
        Mockito.doThrow(new DBException(123, "FAIL"))
                .when(accountMapper)
                .create(any(AccountDAO.class));

        ResultDTO<VoidEntity> ret = voucherManager.createPunish(defaultSellerId, VoucherSubType.FAKE_VIOLATION,
                expectAmt, null, null, new UserParam());

        assertThat(ret.isSuccess()).isFalse();
    }

    @Test(description = "查询到账本为空，创建账本，账本不存在，创建失败")
    public void test003() {

        Mockito.doReturn(0)
                .when(accountBookMapper).pageQueryCount(any());

        mockSellerSuccess();

        AccountDAO accountDAO = new AccountDAO();
        accountDAO.setSellerId(defaultSellerId);
        Mockito.doReturn(accountDAO)
                .when(accountMapper)
                .queryBySeller(anyLong());

        Mockito.doReturn(new ArrayList<>())
                .when(accountBookMapper)
                .queryBySeller(anyLong());

        Mockito.doThrow(new DBException(123, "FAIL"))
                .when(accountBookMapper)
                .create(any(AccountBookDAO.class));

        ResultDTO<VoidEntity> ret = voucherManager.createPunish(defaultSellerId, VoucherSubType.FAKE_VIOLATION,
                expectAmt, null, null, new UserParam());

        assertThat(ret.isSuccess()).isFalse();
    }

    @Test(description = "查询到账本为空，创建账本，账本不存在，创建成功")
    public void test004() {

        Mockito.doReturn(0)
                .when(accountBookMapper).pageQueryCount(any());

        mockSellerSuccess();

        AccountDAO accountDAO = new AccountDAO();
        accountDAO.setSellerId(defaultSellerId);
        Mockito.doReturn(accountDAO)
                .when(accountMapper)
                .queryBySeller(anyLong());

        Mockito.doReturn(new ArrayList<>())
                .when(accountBookMapper)
                .queryBySeller(anyLong());

        Mockito.doReturn(1)
                .when(accountBookMapper)
                .create(any(AccountBookDAO.class));

        Mockito.doNothing()
                .when(voucherMapper)
                .create(any(VoucherDAO.class));

        ResultDTO<VoidEntity> ret = voucherManager.createPunish(defaultSellerId, VoucherSubType.FAKE_VIOLATION,
                expectAmt, null, null, new UserParam());

        assertThat(ret.isSuccess()).isTrue();
    }

    @Test(description = "查询到账本为空，创建账本，账本存在一部分，创建成功")
    public void test005() {

        Mockito.doReturn(0)
                .when(accountBookMapper).pageQueryCount(any());

        mockSellerSuccess();

        AccountDAO accountDAO = new AccountDAO();
        accountDAO.setSellerId(defaultSellerId);
        Mockito.doReturn(accountDAO)
                .when(accountMapper)
                .queryBySeller(anyLong());

        List<AccountBookDAO> bookDAOS = new ArrayList<>();
        AccountBookDAO accountBookDAO1 = new AccountBookDAO();
        accountBookDAO1.setBookType(BookType.ANNUAL_FEE.getCode());
        bookDAOS.add(accountBookDAO1);
        Mockito.doReturn(bookDAOS)
                .when(accountBookMapper)
                .queryBySeller(anyLong());

        Mockito.doReturn(1)
                .when(accountBookMapper)
                .create(any(AccountBookDAO.class));

        Mockito.doNothing()
                .when(voucherMapper)
                .create(any(VoucherDAO.class));

        ResultDTO<VoidEntity> ret = voucherManager.createPunish(defaultSellerId, VoucherSubType.FAKE_VIOLATION,
                expectAmt, null, null, new UserParam());

        assertThat(ret.isSuccess()).isTrue();
    }

    @Test(description = "查询到账本为空，创建账本，账本存在一部分，创建成功")
    public void test006() {

        Mockito.doReturn(0)
                .when(accountBookMapper).pageQueryCount(any());

        mockSellerSuccess();

        AccountDAO accountDAO = new AccountDAO();
        accountDAO.setSellerId(defaultSellerId);
        Mockito.doReturn(accountDAO)
                .when(accountMapper)
                .queryBySeller(anyLong());

        List<AccountBookDAO> bookDAOS = new ArrayList<>();
        AccountBookDAO accountBookDAO1 = new AccountBookDAO();
        accountBookDAO1.setBookType(BookType.GIFT.getCode());
        bookDAOS.add(accountBookDAO1);
        Mockito.doReturn(bookDAOS)
                .when(accountBookMapper)
                .queryBySeller(anyLong());

        Mockito.doReturn(1)
                .when(accountBookMapper)
                .create(any(AccountBookDAO.class));

        Mockito.doNothing()
                .when(voucherMapper)
                .create(any(VoucherDAO.class));

        ResultDTO<VoidEntity> ret = voucherManager.createPunish(defaultSellerId, VoucherSubType.FAKE_VIOLATION,
                expectAmt, null, null, new UserParam());

        assertThat(ret.isSuccess()).isTrue();
    }

    @Test(description = "查询到账本为空，创建账本，账本存在一部分，创建成功")
    public void test007() {

        Mockito.doReturn(0)
                .when(accountBookMapper).pageQueryCount(any());

        mockSellerSuccess();

        AccountDAO accountDAO = new AccountDAO();
        accountDAO.setSellerId(defaultSellerId);
        Mockito.doReturn(accountDAO)
                .when(accountMapper)
                .queryBySeller(anyLong());

        List<AccountBookDAO> bookDAOS = new ArrayList<>();
        AccountBookDAO accountBookDAO1 = new AccountBookDAO();
        accountBookDAO1.setBookType(BookType.INTEGRATION.getCode());
        bookDAOS.add(accountBookDAO1);
        Mockito.doReturn(bookDAOS)
                .when(accountBookMapper)
                .queryBySeller(anyLong());

        Mockito.doReturn(1)
                .when(accountBookMapper)
                .create(any(AccountBookDAO.class));

        Mockito.doNothing()
                .when(voucherMapper)
                .create(any(VoucherDAO.class));

        ResultDTO<VoidEntity> ret = voucherManager.createPunish(defaultSellerId, VoucherSubType.FAKE_VIOLATION,
                expectAmt, null, null, new UserParam());

        assertThat(ret.isSuccess()).isTrue();
    }

    @Test(description = "查询到账本为空，创建账本，账本存在一部分，创建成功")
    public void test008() {

        Mockito.doReturn(0)
                .when(accountBookMapper).pageQueryCount(any());

        mockSellerSuccess();

        AccountDAO accountDAO = new AccountDAO();
        accountDAO.setSellerId(defaultSellerId);
        Mockito.doReturn(accountDAO)
                .when(accountMapper)
                .queryBySeller(anyLong());

        List<AccountBookDAO> bookDAOS = new ArrayList<>();
        AccountBookDAO accountBookDAO1 = new AccountBookDAO();
        accountBookDAO1.setBookType(BookType.DEPOSIT.getCode());
        bookDAOS.add(accountBookDAO1);
        Mockito.doReturn(bookDAOS)
                .when(accountBookMapper)
                .queryBySeller(anyLong());

        Mockito.doReturn(1)
                .when(accountBookMapper)
                .create(any(AccountBookDAO.class));

        Mockito.doNothing()
                .when(voucherMapper)
                .create(any(VoucherDAO.class));

        ResultDTO<VoidEntity> ret = voucherManager.createPunish(defaultSellerId, VoucherSubType.FAKE_VIOLATION,
                expectAmt, null, null, new UserParam());

        assertThat(ret.isSuccess()).isTrue();
    }

    @Test(description = "查询到账本不空，但是已冻结")
    public void test009() {

        Mockito.doReturn(1)
                .when(accountBookMapper).pageQueryCount(any());

        Mockito.doReturn(null)
                .when(accountBookMapper)
                .queryValidBookBySeller(anyLong(), anyInt());

        ResultDTO<VoidEntity> ret = voucherManager.createPunish(defaultSellerId, VoucherSubType.FAKE_VIOLATION,
                expectAmt, null, null, new UserParam());

        assertThat(ret.isSuccess()).isTrue();
    }

    @Test(description = "查询到账本不空, 创建成功")
    public void test010() {
        Mockito.doReturn(1)
                .when(accountBookMapper).pageQueryCount(any());

        AccountBookDAO accountBookDAO = new AccountBookDAO();
        accountBookDAO.setStatus(BookStatus.VALID.getCode());
        accountBookDAO.setContractAmt(100L);
        Mockito.doReturn(accountBookDAO)
                .when(accountBookMapper)
                .queryValidBookBySeller(anyLong(), anyInt());

        Mockito.doNothing()
                .when(voucherMapper)
                .create(any(VoucherDAO.class));

        ResultDTO<VoidEntity> ret = voucherManager.createPunish(defaultSellerId, VoucherSubType.FAKE_VIOLATION,
                expectAmt, null, null, new UserParam());

        assertThat(ret.isSuccess()).isTrue();
    }

    @Test(description = "查询到账本不空，创建失败")
    public void test011() {
        Mockito.doReturn(1)
                .when(accountBookMapper).pageQueryCount(any());

        AccountBookDAO accountBookDAO = new AccountBookDAO();
        accountBookDAO.setStatus(BookStatus.VALID.getCode());
        accountBookDAO.setContractAmt(100L);
        Mockito.doReturn(accountBookDAO)
                .when(accountBookMapper)
                .queryValidBookBySeller(anyLong(), anyInt());

        Mockito.doThrow(new DBException(123, "FAIL"))
                .when(voucherMapper)
                .create(any(VoucherDAO.class));

        ResultDTO<VoidEntity> ret = voucherManager.createPunish(defaultSellerId, VoucherSubType.FAKE_VIOLATION,
                expectAmt, null, null, new UserParam());

        assertThat(ret.getResultCode()).isEqualTo(123);
    }

    @Test(description = "查询到账本不空, 合同金额为0，创建失败")
    public void test012() {
        Mockito.doReturn(1)
                .when(accountBookMapper).pageQueryCount(any());

        AccountBookDAO accountBookDAO = new AccountBookDAO();
        accountBookDAO.setStatus(BookStatus.VALID.getCode());
        accountBookDAO.setContractAmt(0);
        Mockito.doReturn(accountBookDAO)
                .when(accountBookMapper)
                .queryValidBookBySeller(anyLong(), anyInt());

        Mockito.doNothing()
                .when(voucherMapper)
                .create(any(VoucherDAO.class));

        ResultDTO<VoidEntity> ret = voucherManager.createPunish(defaultSellerId, VoucherSubType.FAKE_VIOLATION,
                expectAmt, null, null, new UserParam());

        assertThat(ErrorCode.ADD_FAIL_EXPECT_GT_CONTRACT.eq(ret.getResultCode())).isTrue();
    }



}
