package com.pajk.plutus.test.ut.biz.service.gw.deposigwservice;

import com.pajk.plutus.biz.dao.repo.VoucherRepository;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.service.gw.DepositGWServiceImpl;
import com.pajk.plutus.client.api.gw.DepositGWService;
import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.VoidGwEntity;
import com.pajk.plutus.test.ut.BaseGwServiceUT;
import org.apache.commons.lang3.math.NumberUtils;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by lizhijun on 2017/12/28.
 */
public class SellerConfirmPaymentUT extends BaseGwServiceUT{
    @InjectMocks
    private DepositGWService depositGWService = new DepositGWServiceImpl();

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @Mock
    private VoucherRepository voucherRepository;

    @Test(description = "备注太长")
    public void test_01(){
        String voucherId = "10000190";
        String transitionKey = "transitionKey";
        String nodeKey = "nodeKey";
        StringBuilder sb = new StringBuilder();
        for (int i = 0 ;i< 100 ;i++){
            sb.append("remark");
        }
        mockitoPermissionOk();
        String evidenceFile="";
        String evidenceFlow="evidenceFlow";
        VoidGwEntity voidGwEntity =depositGWService.sellerConfirmPayment(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,sb.toString(),evidenceFlow,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "")
    public void test_02(){

    }

}
