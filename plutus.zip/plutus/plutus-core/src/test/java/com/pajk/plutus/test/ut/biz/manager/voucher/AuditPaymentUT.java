package com.pajk.plutus.test.ut.biz.manager.voucher;

import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookFlowDAO;
import com.pajk.plutus.biz.model.mapper.single.voucher.StatementDAO;
import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDAO;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.taskcenter.client.model.dto.*;
import com.pajk.taskcenter.client.model.result.BatchResult;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fuyongda on 2018/1/3.
 * Modified by fuyongda on 2018/1/3.
 */
public class AuditPaymentUT extends BaseVoucherManagerUT {

    private String transitionKey = "transitionKey";
    private String nodeKey = "nodeKey";
    private String remark = "remark";
    private String role = "role";
    private String path = "path";

    @Test(description = "缴费单不存在")
    public void test1() {
        ResultDTO<VoidEntity> resultDTO =
                voucherManager.auditPayment(defaultSellerId, voucherId, transitionKey, nodeKey, remark, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.VOUCHER_NOT_EXISTS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.VOUCHER_NOT_EXISTS.getDesc());
    }

    @Test(description = "审批前置检查失败")
    public void test2() {
        mockData(VoucherSubType.PAY_IN_BACK_DEPOSIT);

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        ResultDTO<VoidEntity> resultDTO =
                voucherManager.auditPayment(defaultSellerId, voucherId, transitionKey, nodeKey, remark, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.EXCEPTION.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.EXCEPTION.getDesc());
    }

    @Test(description = "审批任务失败")
    public void test3() {
        mockData(VoucherSubType.PAY_IN_BACK_DEPOSIT);

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        mockFlowCompleteTask(false, false);

        userParam.setPath(path);
        ResultDTO<VoidEntity> resultDTO =
                voucherManager.auditPayment(defaultSellerId, voucherId, transitionKey, nodeKey, remark, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.PROCESS_COMPLETE.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.PROCESS_COMPLETE.getDesc());
    }

    @Test(description = "审批任务成功, 不是最后一步, 更新voucher成功")
    public void test4() {
        mockData(VoucherSubType.PAY_IN_BACK_DEPOSIT);

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        mockFlowCompleteTask(true, false);

        Mockito.doReturn(1).when(voucherMapper).updateByOPT(Matchers.any());

        userParam.setPath(path);
        ResultDTO<VoidEntity> resultDTO =
                voucherManager.auditPayment(defaultSellerId, voucherId, transitionKey, nodeKey, remark, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
    }

    @Test(description = "审批任务成功, 不是最后一步, 更新voucher失败")
    public void test5() {
        mockData(VoucherSubType.PAY_IN_BACK_DEPOSIT);

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        mockFlowCompleteTask(true, false);

        userParam.setPath(path);
        ResultDTO<VoidEntity> resultDTO =
                voucherManager.auditPayment(defaultSellerId, voucherId, transitionKey, nodeKey, remark, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.STORE_DB_FAILED.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(" financeAuditPayment fail.");
    }

    @Test(description = "审批任务成功, 是最后一步, VoucherSubType.ADD_DEPOSIT, 查询不到bookFlow")
    public void test6() {
        mockData(VoucherSubType.ADD_DEPOSIT);

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        mockFlowCompleteTask(true, true);

        userParam.setPath(path);
        ResultDTO<VoidEntity> resultDTO =
                voucherManager.auditPayment(defaultSellerId, voucherId, transitionKey, nodeKey, remark, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.FAILURE.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.FAILURE.getDesc());
    }

    @Test(description = "审批任务成功, 是最后一步, VoucherSubType.PAY_IN_BACK_DEPOSIT, 查询财务应收应付记录失败")
    public void test7() {
        mockData(VoucherSubType.PAY_IN_BACK_DEPOSIT);

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        mockFlowCompleteTask(true, true);

        mockAccountBookFlow();

        userParam.setPath(path);
        ResultDTO<VoidEntity> resultDTO =
                voucherManager.auditPayment(defaultSellerId, voucherId, transitionKey, nodeKey, remark, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.FAILURE.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.FAILURE.getDesc());
    }

    @Test(description = "审批任务成功, 是最后一步, 更新voucher失败")
    public void test8() {
        mockData(VoucherSubType.PAY_IN_BACK_DEPOSIT);

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        mockFlowCompleteTask(true, true);

        mockAccountBookFlow();

        mockStatement();

        userParam.setPath(path);
        ResultDTO<VoidEntity> resultDTO =
                voucherManager.auditPayment(defaultSellerId, voucherId, transitionKey, nodeKey, remark, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.STORE_DB_FAILED.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(" auditPayment voucher fail.");
    }

    @Test(description = "审批任务成功, 是最后一步, 更新accountBook失败, VoucherSubType.ADD_DEPOSIT")
    public void test9() {
        mockData(VoucherSubType.ADD_DEPOSIT);

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        mockFlowCompleteTask(true, true);

        mockAccountBookFlow();

        mockStatement();

        Mockito.doReturn(1).when(voucherMapper).updateByOPT(Matchers.any());

        userParam.setPath(path);
        ResultDTO<VoidEntity> resultDTO =
                voucherManager.auditPayment(defaultSellerId, voucherId, transitionKey, nodeKey, remark, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.STORE_DB_FAILED.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(" auditPayment book fail.");
    }

    @Test(description = "审批任务成功, 是最后一步, 更新accountBookFlow失败, VoucherSubType.PAY_IN_BACK_DEPOSIT")
    public void test10() {
        mockData(VoucherSubType.PAY_IN_BACK_DEPOSIT);

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        mockFlowCompleteTask(true, true);

        mockAccountBookFlow();

        mockStatement();

        Mockito.doReturn(1).when(voucherMapper).updateByOPT(Matchers.any());

        Mockito.doReturn(1).when(accountBookMapper).updateByOPT(Matchers.any());

        userParam.setPath(path);
        ResultDTO<VoidEntity> resultDTO =
                voucherManager.auditPayment(defaultSellerId, voucherId, transitionKey, nodeKey, remark, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.STORE_DB_FAILED.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(" auditPayment bookFlow fail.");
    }

    @Test(description = "审批任务成功, 是最后一步, 更新Statement失败, VoucherSubType.PAY_IN_BACK_DEPOSIT")
    public void test11() {
        mockData(VoucherSubType.PAY_IN_BACK_DEPOSIT);

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        mockFlowCompleteTask(true, true);

        mockAccountBookFlow();

        mockStatement();

        Mockito.doReturn(1).when(voucherMapper).updateByOPT(Matchers.any());

        Mockito.doReturn(1).when(accountBookMapper).updateByOPT(Matchers.any());

        Mockito.doReturn(1).when(accountBookFlowMapper).updateByOPT(Matchers.any());

        userParam.setPath(path);
        ResultDTO<VoidEntity> resultDTO =
                voucherManager.auditPayment(defaultSellerId, voucherId, transitionKey, nodeKey, remark, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.STORE_DB_FAILED.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(" auditPayment statement fail.");
    }

    @Test(description = "审批任务成功, 是最后一步, 成功")
    public void test12() {
        mockData(VoucherSubType.FAKE_VIOLATION);

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        mockFlowCompleteTask(true, true);

        mockAccountBookFlow();

        mockStatement();

        Mockito.doReturn(1).when(voucherMapper).updateByOPT(Matchers.any());

        Mockito.doReturn(1).when(accountBookMapper).updateByOPT(Matchers.any());

        Mockito.doReturn(1).when(accountBookFlowMapper).updateByOPT(Matchers.any());

        Mockito.doReturn(1).when(statementMapper).updateByOPT(Matchers.any());

        userParam.setPath(path);
        ResultDTO<VoidEntity> resultDTO =
                voucherManager.auditPayment(defaultSellerId, voucherId, transitionKey, nodeKey, remark, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
    }

    private void mockAccountBookFlow() {
        AccountBookFlowDAO accountBookFlowDAO = new AccountBookFlowDAO();
        Mockito.doReturn(accountBookFlowDAO).when(accountBookFlowMapper)
                .queryByOutId(Matchers.anyLong(), Matchers.anyString(), Matchers.anyString());
    }

    private void mockStatement() {
        StatementDAO statementDAO = new StatementDAO();
        Mockito.doReturn(statementDAO).when(statementMapper).queryByOutId(Matchers.anyString(), Matchers.anyString());
    }

    private void mockFlowCompleteTask(boolean success, boolean endFlag) {
        TaskInstDTO taskInstDTO = new TaskInstDTO();

        List<TaskInstDTO> taskInstDTOList = new LinkedList<>();
        taskInstDTOList.add(taskInstDTO);

        CompleteTaskResultDTO completeTaskResultDTO = new CompleteTaskResultDTO();
        completeTaskResultDTO.setEndFlag(endFlag);
        completeTaskResultDTO.setTaskInstDTOList(taskInstDTOList);

        List<CompleteTaskResultDTO> list = new LinkedList<>();
        list.add(completeTaskResultDTO);

        BatchResult<CompleteTaskResultDTO> batchResultDTO = new BatchResult<>();
        batchResultDTO.setSuccess(success);
        batchResultDTO.setModel(list);

        Mockito.doReturn(batchResultDTO).when(flowService).completeTask(Matchers.any());
    }

    private void mockData(VoucherSubType voucherSubType) {
        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setRole(role);
        voucherDAO.setNodeKey(nodeKey);
        voucherDAO.setVoucherSubType(voucherSubType.getCode());
        Mockito.doReturn(voucherDAO).when(voucherMapper).queryBySellerAndId(defaultSellerId, voucherId);

        AccountBookDAO accountBookDAO = new AccountBookDAO();

        List<AccountBookDAO> list = new LinkedList<>();
        list.add(accountBookDAO);
        Mockito.doReturn(list).when(accountBookMapper).queryBySeller(defaultSellerId);
    }

    private void mockFlowGetNodeInfoList() {
        TransitionDTO transitionDTO = new TransitionDTO();
        transitionDTO.setTransitionKey(transitionKey);

        List<TransitionDTO> transitionDTOS = new LinkedList<>();
        transitionDTOS.add(transitionDTO);

        NodeDTO nodeDTO = new NodeDTO();
        nodeDTO.setPath(path);
        nodeDTO.setTransitionDTOList(transitionDTOS);

        GetNodeInfoResultDTO getNodeInfoResultDTO = new GetNodeInfoResultDTO();
        getNodeInfoResultDTO.setNodeDTO(nodeDTO);

        List<GetNodeInfoResultDTO> list = new LinkedList<>();
        list.add(getNodeInfoResultDTO);

        BatchResult<GetNodeInfoResultDTO> batchResult1 = new BatchResult<>();
        batchResult1.setSuccess(true);
        batchResult1.setModel(list);

        Mockito.when(flowService.getNodeInfoList(Matchers.any())).thenReturn(batchResult1);
    }

}
