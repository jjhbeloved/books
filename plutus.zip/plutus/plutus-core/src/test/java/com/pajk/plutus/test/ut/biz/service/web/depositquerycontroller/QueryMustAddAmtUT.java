package com.pajk.plutus.test.ut.biz.service.web.depositquerycontroller;

import com.pajk.plutus.biz.dao.mapper.single.account.AccountBookFlowMapper;
import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.dao.repo.impl.AccountQueryRepositoryImpl;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.manager.impl.AccountManagerImpl;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookFlowDAO;
import com.pajk.plutus.biz.model.param.restapi.BookAndSellerParam;
import com.pajk.plutus.biz.service.web.DepositQueryController;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fuyongda on 2018/1/8.
 * Modified by fuyongda on 2018/1/8.
 */
public class QueryMustAddAmtUT extends BaseWebServiceUT {

    @InjectMocks
    private DepositQueryController depositQueryController = new DepositQueryController();

    @InjectMocks
    @Spy
    private AccountManager accountManager = new AccountManagerImpl();

    @InjectMocks
    @Spy
    private AccountQueryRepository accountQueryRepository = new AccountQueryRepositoryImpl();

    @Mock
    private AccountBookFlowMapper bookFlowMapper;

    @Mock
    private ControlCache controlCache;

    @Test
    public void test1() {
        Mockito.doReturn(1000).when(bookFlowMapper).pageQueryCount(Matchers.any());

        AccountBookFlowDAO accountBookFlowDAO = new AccountBookFlowDAO();
        accountBookFlowDAO.setAmount(5678);

        List<AccountBookFlowDAO> list = new LinkedList<>();
        list.add(accountBookFlowDAO);
        Mockito.doReturn(list).when(bookFlowMapper).pageQuery(Matchers.any());

        mockitoPermissionOk();

        BookAndSellerParam bookAndSellerParam = new BookAndSellerParam();
        bookAndSellerParam.setSellerId(defaultSellerId);
        bookAndSellerParam.setAccountBookId(1234L);

        ResultDTO<Long> resultDTO = depositQueryController.queryMustAddAmt(bookAndSellerParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(resultDTO.getModel()).isNotNull();
        assertThat(resultDTO.getModel()).isEqualTo(5678L);
    }

}
