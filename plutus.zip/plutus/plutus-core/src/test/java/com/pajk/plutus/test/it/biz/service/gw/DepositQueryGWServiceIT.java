package com.pajk.plutus.test.it.biz.service.gw;

import com.pajk.plutus.biz.common.util.JsonUtil;
import com.pajk.plutus.client.api.gw.DepositQueryGWService;
import com.pajk.plutus.client.model.result.gw.process.BatchNodeCatKeyGW;
import com.pajk.plutus.client.model.result.gw.voucher.PageVoucherGW;
import com.pajk.plutus.client.model.result.gw.voucher.VoucherGW;
import com.pajk.plutus.test.it.BaseIT;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fuyongda on 2017/12/20.
 * Modified by fuyongda on 2017/12/20.
 */
public class DepositQueryGWServiceIT extends BaseIT {

    @Autowired
    private DepositQueryGWService depositQueryGWService;

    @Test
    public void testQuerySellerVoucher() {
        String voucherId = "88";
        VoucherGW voucherGW = depositQueryGWService
                .querySellerVoucher(9222000L, 9222001L, 20019550008L, 12026100507L, voucherId);

        System.out.println(JsonUtil.obj2Str(voucherGW));
        assertThat(voucherGW).isNotNull();
    }

    @Test
    public void testQuerySellerOptVoucher() {
        String voucherId = "88";
        VoucherGW voucherGW = depositQueryGWService
                .querySellerOptVoucher(9222000L, 9222001L, 20019550008L, 12026100507L, voucherId);

        System.out.println(JsonUtil.obj2Str(voucherGW));
        assertThat(voucherGW).isNotNull();
    }

    @Test
    public void testQueryStatusByType() {
        BatchNodeCatKeyGW batchNodeCatKeyGW1 =
                depositQueryGWService.queryStatusByType(defaultAppId, defaultUserId, defaultSellerId, 1000);
        BatchNodeCatKeyGW batchNodeCatKeyGW2 =
                depositQueryGWService.queryStatusByType(defaultAppId, defaultUserId, defaultSellerId, 2000);

        System.out.println(JsonUtil.obj2Str(batchNodeCatKeyGW1));
        System.out.println(JsonUtil.obj2Str(batchNodeCatKeyGW2));
        assertThat(batchNodeCatKeyGW1).isNotNull();
        assertThat(batchNodeCatKeyGW2).isNotNull();
    }

    @Test
    public void testPageQuery(){
        PageVoucherGW pageVoucherGW = depositQueryGWService.pageQuerySellerVoucher(defaultAppId,defaultUserId,12026100507L,null,null,2000,-1,null,null,1,10);

        System.out.println(pageVoucherGW);
    }

}
