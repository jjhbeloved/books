package com.pajk.plutus.test.ut.biz.service.web.depositquerycontroller;

import com.pajk.plutus.biz.model.param.restapi.QueryVoucherSubTypeParam;
import com.pajk.plutus.biz.model.result.dto.voucher.VoucherSubTypeDTO;
import com.pajk.plutus.biz.service.web.DepositQueryController;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import org.mockito.InjectMocks;
import org.testng.annotations.Test;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by lizhijun on 2018/1/4.
 */
public class QueryVoucherSubTypeUT extends BaseWebServiceUT {
    @InjectMocks
    private DepositQueryController depositQueryController = new DepositQueryController();


    @Test(description = "参数错误")
    public void test1(){
        QueryVoucherSubTypeParam param = buildParam();
        param.setVoucherType(1);
        BatchResultDTO<VoucherSubTypeDTO> batchResultDTO = depositQueryController.queryVoucherSubType(param);
        assertThat(ErrorCode.PARAM_ERROR.eq(batchResultDTO.getResultCode())).isTrue();


    }

    @Test(description = "查询成功")
    public void test2(){
        QueryVoucherSubTypeParam param = buildParam();
        mockitoPermissionOk();
        BatchResultDTO<VoucherSubTypeDTO> batchResultDTO = depositQueryController.queryVoucherSubType(param);
        assertThat(ErrorCode.SUCCESS.eq(batchResultDTO.getResultCode())).isTrue();
    }

    private QueryVoucherSubTypeParam buildParam(){
        QueryVoucherSubTypeParam param = new QueryVoucherSubTypeParam();
        param.setVoucherType(VoucherType.VIOLATION.getCode());
        param.setIsCanHandleCreate(false);
        return param;
    }

}
