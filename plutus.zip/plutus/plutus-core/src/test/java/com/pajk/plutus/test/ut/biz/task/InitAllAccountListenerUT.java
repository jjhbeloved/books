package com.pajk.plutus.test.ut.biz.task;

import com.pajk.hawaii.client.JobExecutionContext;
import com.pajk.hawaii.client.JobListener;
import com.pajk.plutus.biz.common.util.ResultUtil;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.task.AutoAgreePunishListener;
import com.pajk.plutus.biz.task.InitAllAccountListener;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseServiceUT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 17/12/28.
 * Modify by fanhuafeng on 17/12/28
 */
public class InitAllAccountListenerUT extends BaseServiceUT {

    @InjectMocks
    private JobListener listener = new InitAllAccountListener();

    @Mock
    private AccountManager manager;



    @Test
    public void test01(){
        JobExecutionContext context = new JobExecutionContext();
        ResultDTO<VoidEntity> resultDTO = ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);

        Mockito.doReturn(resultDTO).when(manager).createAccountByAllSellers();

        listener.execute(context);

        assertThat(context.isSuccess()).isFalse();
    }

    @Test
    public void test02(){
        JobExecutionContext context = new JobExecutionContext();


        Mockito.doThrow(new RuntimeException()).when(manager).createAccountByAllSellers();

        listener.execute(context);

        assertThat(context.isSuccess()).isFalse();
    }

    @Test
    public void testSuccess(){


        assertThat(InitAllAccountListener.class.getName()).isEqualToIgnoringCase(listener.getName());


        JobExecutionContext context = new JobExecutionContext();
        ResultDTO<VoidEntity> resultDTO = new ResultDTO<>();

        Mockito.doReturn(resultDTO).when(manager).createAccountByAllSellers();

        listener.execute(context);

        assertThat(context.isSuccess()).isTrue();
    }
}
