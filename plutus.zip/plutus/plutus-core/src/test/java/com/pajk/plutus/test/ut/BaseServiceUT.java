package com.pajk.plutus.test.ut;

import com.pajk.filegw.api.FileTokenService;
import com.pajk.filegw.api.TfsGroup;
import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyBatchResult;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.kylin.api.service.AppResourceService;
import com.pajk.kylin.api.service.PermissionService;
import com.pajk.kylin.api.service.SellerService;
import com.pajk.kylin.api.service.UserSellerService;
import com.pajk.kylin.apigw.model.domain.UserInfoDTO;
import com.pajk.plutus.biz.diamond.ConstantCache;
import com.pajk.plutus.biz.manager.permission.AuthResourceProperties;
import com.pajk.plutus.biz.manager.permission.UserUtil;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.account.AccountBookFlowDO;
import com.pajk.plutus.client.model.enums.account.BookFlowOutType;
import com.pajk.plutus.client.model.enums.seller.SellerServiceType;
import com.pajk.taskcenter.client.model.dto.*;
import com.pajk.taskcenter.client.model.query.BizObjQuery;
import com.pajk.taskcenter.client.model.query.ProcessInstQuery;
import com.pajk.taskcenter.client.model.result.BatchResult;
import com.pajk.taskcenter.client.service.FlowService;
import com.pajk.user.model.User;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeMethod;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.matches;
import static org.mockito.Mockito.doReturn;

/**
 * Created by fanhuafeng on 17/2/22.
 * Modify by fanhuafeng on 17/2/22
 */
public abstract class BaseServiceUT {

    @Mock
    protected PermissionService permissionService;

    @Mock
    protected UserSellerService userSellerService;

    @Mock
    protected AppResourceService appResourceService;

    @Mock
    protected FileTokenService fileTokenService;

    @Mock
    private ConstantCache constantCache;

    @Mock
    protected FlowService flowService;

    @Mock
    protected SellerService sellerService;


    @BeforeMethod
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
        User user = new User(defaultUserId);
        user.setName("test");
        UserUtil.putUser(user);
    }

    public long defaultSellerUserId = 3143140909L;
    public long defaultSellerId = 13428700506L;
    public String defaultTradeId = "1921300908";
    public long defaultAppId = AuthResourceProperties.APPID;
    public long defaultUserId = 1234354678L;
    public long defaultDomainId = AuthResourceProperties.DOMAIN_ID;
    public String defaultVoucherId = "1002";
    public Date now = new Date();

    protected void mockitoPermissionOk() {
        KyCallResult<Boolean> result = new KyCallResult<>();
        result.setModel(true);
        doReturn(result).when(permissionService).hasPermission(Matchers.any());
    }

    protected void mockitoPermissionFail() {
        KyCallResult<Boolean> result = new KyCallResult<>();
        result.setModel(false);
        doReturn(result).when(permissionService).hasPermission(Matchers.any());
    }

    /**
     * 模拟获取角色成功
     *
     * @param role 返回的角色
     */
    protected void mockitoCurrentUserRoleOK(String role) {
        KyCallResult<String> result = new KyCallResult<>();
        result.setSuccess(true);
        result.setModel(role);
        doReturn(result).when(permissionService).getCurRole(anyLong(), anyLong());
    }

    /**
     * 模拟获取角色失败
     */
    protected void mockitoCurrentUserRoleFail() {
        KyCallResult<String> result = new KyCallResult<>();
        result.setSuccess(true);
        result.setModel("");
        doReturn(result).when(permissionService).getCurRole(anyLong(), anyLong());
    }

    /**
     * 模拟获取用户成功
     *
     * @param userId   用户ID
     * @param userName 用户名
     */
    protected void mockitoUserInoOK(long userId, String userName) {
        UserInfoDTO userInfoDTO = new UserInfoDTO();
        userInfoDTO.userId = userId;
        userInfoDTO.loginName = userName;
        KyCallResult<UserInfoDTO> result = new KyCallResult<>();
        result.setSuccess(true);
        result.setModel(userInfoDTO);
        doReturn(result).when(userSellerService).getUserInfo(anyLong());
    }

    /**
     * 模拟获取用户失败
     */
    protected void mockitoUserInfoFail() {
        KyCallResult<UserInfoDTO> result = new KyCallResult<>();
        result.setSuccess(false);
        doReturn(result).when(userSellerService).getUserInfo(anyLong());
    }

    protected void mockAppResourceDO(AppResourceDO appResourceDO) {
        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setModel(appResourceDO);
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(),
                Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
    }

    protected void mockSellerDO(SellerDO sellerDO) {
        sellerDO.setServiceType(SellerServiceType.B2C.getCode());

        KyCallResult<SellerDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setModel(sellerDO);
        Mockito.doReturn(kyCallResult).when(sellerService).getSellerById(Matchers.anyLong());
    }

    /**
     * mock 节点信息
     */
    protected void mockNodeInfoList(List<GetNodeInfoResultDTO> resultDTO,boolean success){
        BatchResult<GetNodeInfoResultDTO> batchResult = new BatchResult<>();
        batchResult.setSuccess(success);
        batchResult.setModel(resultDTO);
        Mockito.doReturn(batchResult).when(flowService).getNodeInfoList(Matchers.anyListOf(ProcessInstQuery.class));
    }
    /**
     * getAppResource四个参数批量获取
     */
    protected void mockBatchAppResourceDO(List<AppResourceDO> list, boolean success) {
        KyBatchResult<AppResourceDO> kyCallResult = new KyBatchResult<>();
        kyCallResult.setModel(list);
        kyCallResult.setSuccess(success);
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(),
                Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
    }

    /**
     * 获取fileToken
     */
    protected void mockFileToken(String  fileToken) {
        Mockito.doReturn(fileToken).when(fileTokenService).requestFileToken(Matchers.anyLong(),
                Matchers.anyLong(),Matchers.any(TfsGroup.class),Matchers.anyString(),Matchers.anyLong());
    }

    protected void mockFilegwDomain(String  filegwDomain) {
        Mockito.doReturn(filegwDomain).when(constantCache).getFilegwDomainInner();
        Mockito.doReturn(filegwDomain).when(constantCache).getFilegwDomainOuter();
    }

    /**
     * 查看流程记录
     */
    protected void mockGetFinishedActInstList(List<TaskInstDTO> taskInstDTOS,boolean success) {
        BatchResult<TaskInstDTO> instDTOBatchResult = new BatchResult<>();
        instDTOBatchResult.setModel(taskInstDTOS);
        instDTOBatchResult.setSuccess(success);
        Mockito.doReturn(instDTOBatchResult).when(flowService).getFinishedActInstList(Matchers.any(BizObjQuery.class));
    }

    protected void mockRole(String role,boolean isQueryFail){
        KyCallResult<String> kyCallResult = new KyCallResult<>();
        if(isQueryFail){
            kyCallResult.setSuccess(false);
        }else{
            kyCallResult.setModel(role);
        }

        Mockito.doReturn(kyCallResult).when(permissionService).getCurRole(defaultUserId,defaultAppId);
    }

    /**
     *mock seller
     */
    protected void mockSeller(SellerDO sellerDO,boolean success){
        KyCallResult<SellerDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(success);
        kyCallResult.setModel(sellerDO);
        Mockito.doReturn(kyCallResult).when(sellerService).getSellerById(Matchers.anyLong());
    }

    protected void mockNodeList(String nodeKey, boolean isException, boolean isEmpty,boolean isQueryFail,boolean nodeIsEmpty,
                                String path,String transitionKey,String transitionName){

        if(isException){
            Mockito.doThrow(new RuntimeException()).when(flowService).getNodeInfoList(Matchers.any());
            return;
        }

        BatchResult<GetNodeInfoResultDTO> batchResult = new BatchResult<>();
        if(isEmpty){
            List<GetNodeInfoResultDTO> getNodeInfoResultDTOs = new LinkedList<>();
            batchResult.setModel(getNodeInfoResultDTOs);
            Mockito.doReturn(batchResult).when(flowService).getNodeInfoList(Matchers.any());
            return;
        }

        if(isQueryFail){
            batchResult.setSuccess(false);
            Mockito.doReturn(batchResult).when(flowService).getNodeInfoList(Matchers.any());
            return;
        }

        List<GetNodeInfoResultDTO> getNodeInfoResultDTOs = new LinkedList<>();
        GetNodeInfoResultDTO getNodeInfoResultDTO = buildGetNodeInfoResultDTO(nodeKey,path,transitionKey,transitionName,nodeIsEmpty);
        getNodeInfoResultDTOs.add(getNodeInfoResultDTO);
        batchResult.setModel(getNodeInfoResultDTOs);
        Mockito.doReturn(batchResult).when(flowService).getNodeInfoList(Matchers.any());

    }

    protected GetNodeInfoResultDTO buildGetNodeInfoResultDTO(String nodeKey,String path,String transitonKey,String transitionName,boolean nodeIsEmpty){
        GetNodeInfoResultDTO resultDTO = new GetNodeInfoResultDTO();
        resultDTO.setNodeKey(nodeKey);
        resultDTO.setNodeDTO(buildNodeDTO(path,transitonKey,transitionName,nodeIsEmpty));
        return resultDTO;
    }

    protected NodeDTO buildNodeDTO(String path, String transitonKey, String transitionName, boolean nodeIsEmpty){
        NodeDTO nodeDTO = new NodeDTO();
        nodeDTO.setPath(path);
        List<TransitionDTO> transitionDTOs = new LinkedList<>();
        if (!nodeIsEmpty){
            transitionDTOs.add(buildTransitionDTO(transitonKey,transitionName));
        }
        nodeDTO.setTransitionDTOList(transitionDTOs);
        return nodeDTO;
    }

    protected TransitionDTO buildTransitionDTO(String transitonKey,String transitionName){
        TransitionDTO transitionDTO = new TransitionDTO();
        transitionDTO.setTransitionName(transitionName);
        transitionDTO.setTransitionKey(transitonKey);
        return transitionDTO;
    }

    protected void mockCompeteTask(boolean batchFail ,boolean batchException, boolean requestFail, boolean doNodeEnter,
                                           boolean nodeEnterFail, boolean nodeEnterException , boolean isEnd){

        if(batchException){
            Mockito.doThrow(new RuntimeException()).when(flowService).completeTask(Matchers.any());
            return;
        }

        BatchResult<CompleteTaskResultDTO> batchResultDTO = new BatchResult<>();
        if(batchFail){
            batchResultDTO.setSuccess(false);
            Mockito.doReturn(batchResultDTO).when(flowService).completeTask(Matchers.any());
            return;
        }
        List<CompleteTaskResultDTO> list = new LinkedList<>();
        CompleteTaskResultDTO taskResultDTO = new CompleteTaskResultDTO();
        list.add(taskResultDTO);
        batchResultDTO.setModel(list);
        if(requestFail){
            taskResultDTO.setSuccess(false);

            if(doNodeEnter){
                taskResultDTO.setErrorCode(com.pajk.taskcenter.client.model.result.ErrorCode.NODE_EXECUTED_ERROR.getCode());
                Mockito.doReturn(batchResultDTO).when(flowService).completeTask(Matchers.any());
                if(nodeEnterException){
                    Mockito.doThrow(new RuntimeException()).when(flowService).nodeEnter(Matchers.any(), Matchers.anyBoolean());
                    return;
                }
                CompleteTaskResultDTO result = new CompleteTaskResultDTO();
                if(nodeEnterFail){
                    result.setSuccess(false);
                    Mockito.doReturn(result).when(flowService).nodeEnter(Matchers.any(), Matchers.anyBoolean());
                    return;
                }
                TaskInstDTO taskInstDTO = buildTaskInstDTO("nodeKey2","nodeCateKey2","role2");
                List<TaskInstDTO> taskInstDTOs = new LinkedList<>();
                taskInstDTOs.add(taskInstDTO);
                result.setTaskInstDTOList(taskInstDTOs);
                Mockito.doReturn(result).when(flowService).nodeEnter(Matchers.any(), Matchers.anyBoolean());
                return;
            }
            taskResultDTO.setErrorCode(com.pajk.taskcenter.client.model.result.ErrorCode.NO_ROLENODE_ERROR.getCode());
            Mockito.doReturn(batchResultDTO).when(flowService).completeTask(Matchers.any());

            return;

        }

        TaskInstDTO taskInstDTO = buildTaskInstDTO("nodeKey2","nodeCateKey2","role2");
        List<TaskInstDTO> taskInstDTOs = new LinkedList<>();
        taskInstDTOs.add(taskInstDTO);

        taskResultDTO.setTaskInstDTOList(taskInstDTOs);
        taskResultDTO.setEndFlag(isEnd);

        Mockito.doReturn(batchResultDTO).when(flowService).completeTask(Matchers.any());


    }

    protected void mockCreateProcess(boolean success){
        BatchResult<CreateProcInstResultDTO> batchResult = new BatchResult<>();
        if(!success){
            batchResult.setSuccess(success);
        }else{
            CreateProcInstResultDTO createProcInstResultDTO = new CreateProcInstResultDTO();
            createProcInstResultDTO.setProcInstId(1L);
            List<TaskInstDTO> taskInstDTOs = new LinkedList<>();
            createProcInstResultDTO.setTaskInstDTOList(taskInstDTOs);
            createProcInstResultDTO.getTaskInstDTOList().add(new TaskInstDTO());
            List<CreateProcInstResultDTO> list = new LinkedList<>();
            list.add(createProcInstResultDTO);
            batchResult.setModel(list);
        }

        Mockito.doReturn(batchResult).when(flowService).createProcess(Matchers.any());
    }

    protected AccountBookDO buildBook(long sellerId, long id){
        AccountBookDO accountBookDO = new AccountBookDO();
        accountBookDO.setSellerId(sellerId);
        accountBookDO.setId(id);
        return accountBookDO;
    }

    protected AccountBookFlowDO buildBookFlow(long sellerId, long bookId, long id, BookFlowOutType outType, String outId){
        AccountBookFlowDO bookFlowDO = new AccountBookFlowDO();
        bookFlowDO.setBookId(bookId);
        bookFlowDO.setSellerId(sellerId);
        bookFlowDO.setId(id);
        bookFlowDO.setAmount(-100);
        bookFlowDO.setOutType(outType);
        bookFlowDO.setOutId(outId);
        return bookFlowDO;
    }
    private TaskInstDTO buildTaskInstDTO(String nodeKey, String nodeCatKey, String role){
        TaskInstDTO taskInstDTO = new TaskInstDTO();
        taskInstDTO.setNodeKey(nodeKey);
        taskInstDTO.setNodeCatKey(nodeCatKey);
        taskInstDTO.setRole(role);
        return taskInstDTO;
    }




}
