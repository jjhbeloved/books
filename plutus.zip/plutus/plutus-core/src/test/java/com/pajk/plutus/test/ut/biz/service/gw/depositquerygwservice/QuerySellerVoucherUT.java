package com.pajk.plutus.test.ut.biz.service.gw.depositquerygwservice;

import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherDeliveryMapper;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherMapper;
import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.model.voucher.VoucherDeliveryDO;
import com.pajk.plutus.biz.service.gw.DepositQueryGWServiceImpl;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.voucher.VoucherGW;
import com.pajk.plutus.test.ut.BaseGwServiceUT;
import com.pajk.taskcenter.client.model.dto.TaskInstDTO;
import org.apache.commons.lang3.math.NumberUtils;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.*;

import static com.pajk.plutus.biz.model.enums.VoucherExtPropsKey.EVIDENCE_FLOW;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by  guguangming on 2017/12/29
 **/
public class QuerySellerVoucherUT extends BaseGwServiceUT {
    @InjectMocks
    private DepositQueryGWServiceImpl depositQueryGWService = new DepositQueryGWServiceImpl();

    @Mock
    protected VoucherMapper voucherMapper;

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @Mock
    protected VoucherQueryRepository voucherQueryRepository;

    @Mock
    protected VoucherDeliveryMapper voucherDeliveryMapper;

    private String fileToken = "12321321";

    private String key3 = "审核中";
    private String nodeKey = "SELLER_OP";
    private String role = "sellerConfirm";
    private String evidenceFlow = "91122222";



    @Test(description = "查询失败->voucher 参数错误")
    public void test0() {
        mockitoPermissionOk();
        Mockito.doReturn(Optional.empty()).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        VoucherGW voucher = depositQueryGWService.querySellerVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, "ewrew");

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(voucher).isNull();
    }

    @Test(description = "查询失败->voucher 不存在")
    public void test1() {
        mockitoPermissionOk();
        Mockito.doReturn(Optional.empty()).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        VoucherGW voucher = depositQueryGWService.querySellerVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_VOUCHER_NOT_EXISTS);
        assertThat(voucher).isNull();
    }

    @Test(description = "查询失败->VOUCHER_DELIVERY_NOT_EXISTS ")
    public void test2() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.empty()).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        VoucherGW voucher = depositQueryGWService.querySellerVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_VOUCHER_DELIVERY_NOT_EXISTS);
        assertThat(voucher).isNull();
    }

    @Test(description = "非PAYMENT  nodeKeyName 查询失败 ")
    public void test3() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(false);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
        List<AppResourceDO> doList = new LinkedList<>();

        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        VoucherGW voucher = depositQueryGWService.querySellerVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isNull();
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }

    @Test(description = "非PAYMENT 类型 ->nodeKeyNam & 流程记录查询成功")
    public void test4() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
        List<AppResourceDO> doList = new LinkedList<>();

        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        VoucherGW voucher = depositQueryGWService.querySellerVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }

    @Test(description = "非PAYMENT 类型 流程记录查询失败 ")
    public void test5() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
        List<AppResourceDO> doList = new LinkedList<>();

        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, false);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, false);

        VoucherGW voucher = depositQueryGWService.querySellerVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        assertThat(voucher.auditFlows).isNull();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }


    @Test(description = "PAYMENT 类型 查询成功银行流水为空")
    public void test6() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherType(VoucherType.PAYMENT);
        voucherDO.setVoucherSubType(VoucherSubType.ADD_DEPOSIT);
        //流水为空
        voucherDO.setExtProps(new HashMap<>());
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());

        List<AppResourceDO> doList = new LinkedList<>();
        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        VoucherGW voucher = depositQueryGWService.querySellerVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.paymentProp.evidenceFlow).isNull();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }

    @Test(description = "PAYMENT 类型 审批记录查询失败 ")
    public void test7() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherType(VoucherType.PAYMENT);
        voucherDO.setVoucherSubType(VoucherSubType.PAY_IN_BACK_DEPOSIT);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());

        List<AppResourceDO> doList = new LinkedList<>();
        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, false);

        VoucherGW voucher = depositQueryGWService.querySellerVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        //为空
        assertThat(voucher.auditFlows).isNull();
        assertThat(voucher.paymentProp.evidenceFlow).isEqualTo(evidenceFlow);
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }

    @Test(description = "PAYMENT 查询成功 ")
    public void test8() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherType(VoucherType.PAYMENT);
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());

        List<AppResourceDO> doList = new LinkedList<>();
        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        VoucherGW voucher = depositQueryGWService.querySellerVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.nodeKey).isEqualTo(nodeKey);
        assertThat(voucher.paymentProp.evidenceFlow).isEqualTo(evidenceFlow);
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }

    private VoucherDO buildVoucherDO() {
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(defaultVoucherId);
        voucherDO.setIsDeleted(0);
        voucherDO.setExpectAmt(100L);
        voucherDO.setSellerId(defaultSellerId);
        voucherDO.setActualAmt(100L);
        voucherDO.setGmtCreated(new Date());
        voucherDO.setRole(role);
        voucherDO.setVoucherType(VoucherType.VIOLATION);
        voucherDO.setNodeKey(nodeKey);
        voucherDO.setVoucherSubType(VoucherSubType.FAKE_VIOLATION);
        voucherDO.setCreateRemark("12321");
        voucherDO.setCreateFile("[{\"fileKey\":\"T1iNxTBTxT1RCvBVdK.jpg\",\"fileName\":\"timg.jpg\"}]");
        voucherDO.setEvidenceFile("[{\"fileKey\":\"T1iNxTBTxT1RCvBVdK.jpg\",\"fileName\":\"timg.jpg\"}]");
        Map<String, String> ext = new HashMap<>();
        ext.put(EVIDENCE_FLOW.getCode(), evidenceFlow);
        voucherDO.setExtProps(ext);
        return voucherDO;
    }

    private VoucherDeliveryDO buildVoucherDeliveryDO() {
        VoucherDeliveryDO deliveryDO = new VoucherDeliveryDO();
        deliveryDO.setAmount(1);
        deliveryDO.setCompanyId(10001L);
        deliveryDO.setCompanyName("顺丰快递");
        deliveryDO.setCreateTime(new Date());
        deliveryDO.setAmount(1L);
        deliveryDO.setDeliveryTime(new Date());
        deliveryDO.setTrackingNumber("97661270004");
        deliveryDO.setId(1L);
        return deliveryDO;
    }

    private AppResourceDO buildAppResourceDO() {
        AppResourceDO aDo = new AppResourceDO();
        aDo.key3 = key3;
        aDo.keyName = nodeKey;
        aDo.val2 = role;
        aDo.val3 = "审核成功";
        return aDo;
    }

    private TaskInstDTO buildTaskInstDTO() {
        TaskInstDTO instDTO = new TaskInstDTO();
        instDTO.setNodeKey("sellerAgree");
        instDTO.setApprovalId("111");
        instDTO.setApprovalVote("1111");
        instDTO.setNodeKey(nodeKey);
        return instDTO;
    }

}
