package com.pajk.plutus.test.it.biz.manager.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.pajk.plutus.biz.common.util.JsonUtil;
import com.pajk.plutus.biz.manager.BillManager;
import com.pajk.plutus.biz.model.bill.BillSettlementDO;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.biz.model.query.bill.*;
import com.pajk.plutus.client.model.enums.bill.BillType;
import com.pajk.plutus.client.model.enums.bill.SettlementType;
import com.pajk.plutus.client.model.enums.trade.PayToType;
import com.pajk.plutus.test.it.BaseIT;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.testng.annotations.Test;

import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author david
 * @since created by on 17/12/18 10:28
 */
public class BillManagerImplIT extends BaseIT {

    @Autowired
    private BillManager billManager;

    private long sellerId = 2083950007;


    private String flag = "_x_^_y_x";

    private String nowStr = "2017-12-18 20:25:40";

    private DateFormat format = new SimpleDateFormat("yyyy-MM-dd");

    private int months = 18;

    private String buttonKey = "agree";

    private Map<Long, List<Long>> ids = Maps.newHashMap();

    @Test
    public void validatePTSK_PAYF() {
        try {
            int sType = SettlementType.PA_PAY.getCode();
            int pType = PayToType.PAY_TO_PLATFORM.getCode();
            createData(sType, pType);
            long userId = 3306;
            ids.forEach((id, billItemIds) -> {
                try {
                    confirmSettlement(id, userId, billItemIds, "agree", "SELLER_OP");
                    confirmOnlyRemark(id, userId, "agree", "BD");
                    confirmOnlyRemark(id, userId, "agree", "CWSH_OP");
                    confirmInvoice(id, userId, "confirm", "SELLER_OP");
                    receiveInvoice(id, userId, "confirm", "CWPJ_OP");
                    confirmPayment(id, userId, "confirm", "CWCN_OP");
                    confirmReceivePayment(id, userId, "supplierReceipted", "SELLER_OP");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            deleteData();
        }
    }

    @Test
    public void validateSJSK_PAYF() {
        try {
            int sType = SettlementType.PA_PAY.getCode();
            int pType = PayToType.PAY_TO_SELLER.getCode();
            createData(sType, pType);
            long userId = 3306;
            ids.forEach((id, billItemIds) -> {
                try {
                    confirmSettlement(id, userId, billItemIds, "agree", "SELLER_OP");
                    confirmOnlyRemark(id, userId, "agree", "BD");
                    confirmOnlyRemark(id, userId, "agree", "CWSH_OP");
                    confirmInvoice(id, userId, "confirm", "SELLER_OP");
                    receiveInvoice(id, userId, "confirm", "CWPJ_OP");
                    confirmPayment(id, userId, "confirm", "CWCN_OP");
                    confirmReceivePayment(id, userId, "sellerReceipted", "SELLER_OP");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            deleteData();
        }
    }

    @Test
    public void validateSJSK_PAYS() {
        try {
            int sType = SettlementType.PA_RECEIPT.getCode();
            int pType = PayToType.PAY_TO_SELLER.getCode();
            createData(sType, pType);
            long userId = 3306;
            ids.forEach((id, billItemIds) -> {
                try {
                    confirmSettlement(id, userId, billItemIds, "agree", "SELLER_OP");
                    confirmOnlyRemark(id, userId, "agree", "BD");
                    confirmOnlyRemark(id, userId, "agree", "CWSH_OP");
                    confirmInvoice(id, userId, "confirm", "CWPJ_OP");
                    receiveInvoice(id, userId, "confirm", "SELLER_OP");
                    confirmPayment(id, userId, "confirm", "SELLER_OP");
                    confirmReceivePayment(id, userId, "PAReceipted", "CWCN_OP");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            deleteData();
        }
    }

    private long t_bill_id = 149L;

    //    @Test
    public void testConfirmSettlement() {
        long billId = t_bill_id;
        long userId = 3306;
        List<Long> billItemIds = Lists.newArrayList();
        billItemIds.add(9892578762717L);
        billItemIds.add(9892579854092L);
        confirmSettlement(billId, userId, billItemIds, buttonKey, "SELLER_OP");
    }

    //        @Test
    public void testConfirmOnlyRemark() {
        long billId = t_bill_id;
        long userId = 3306;
        confirmOnlyRemark(billId, userId, buttonKey, "CWSH_OP");
    }

    //        @Test
    public void testReceiveInvoice() {
        long billId = t_bill_id;
        long userId = 3306;
        receiveInvoice(billId, userId, "confirm", "SELLER_OP");
    }

    //        @Test
    public void testConfirmPayment() throws Exception {
        long billId = t_bill_id;
        long userId = 3306;
        confirmPayment(billId, userId, "confirm", "SELLER_OP");
    }

    //        @Test
    public void testConfirmInvoice() {
        long billId = t_bill_id;
        long userId = 3306;
        confirmInvoice(billId, userId, "confirm", "CWPJ_OP");
    }

    //        @Test
    public void testConfirmReceivePayment() {
        long billId = t_bill_id;
        long userId = 3306;
        confirmReceivePayment(billId, userId, "supplierReceipted", "SELLER_OP");
    }

    //    @Test
    public void testQuerySettlement() throws Exception {
        long billId = t_bill_id;
        ResultDTO<BillSettlementDO> resultDTO = billManager.querySettlement(billId, sellerId);
        System.out.println(JsonUtil.obj2Str(resultDTO));
    }

    //    @Test
    public void testGetButtons() throws Exception {
//        BatchResultDTO<ButtonDO> resultDTO = billManager.getButtons(109130L, "BDAudit");
//        System.out.println(JsonUtil.obj2Str(resultDTO));
    }

    //    @Test
    public void testQueryConfirmSettlement() throws Exception {
        long billId = 246;
        long sellerId = 2083950007;
        ResultDTO<BillSettlementDO> resultDTO = billManager.queryConfirmSettlement(billId, sellerId);
        System.out.println(JSONObject.toJSONString(resultDTO.getModel()));

    }

    @Test
    public void pageQuerySettlement() {
        final PageResultDTO<BillSettlementDO> billSettlementDOPageResultDTO = billManager.pageQuerySettlement(
                2083950007L, "SELLER_OP", "2017-01", "2017-12", 1, 10);
        System.out.println(JSON.toJSONString(billSettlementDOPageResultDTO));
    }

//
//    @Test
//    public void testPageQuerySettlementByCondition() throws Exception {
//        Map<String, Object> params = Maps.newHashMap();
//        params.put("startTime", "2017-01");
//        params.put("endTime", "2017-12");
//        PageResultDTO<BillSettlementDO> page = billManager.pageQuerySettlementByCondition("", 1, 20, params);
//
//        System.out.println(page.getTotalCount());
//    }

    private void confirmSettlement(long billId, long userId, List<Long> billItemIds, String buttonKey, String role) {
        String userName = "xb";
        String remark = "confirmSettlement";
        BillLogDTO billLogDTO = new BillLogDTO();
        billLogDTO.setRemark(remark);
        billLogDTO.setOperatorId(String.valueOf(userId));
        billLogDTO.setOperatorName(userName);
        billLogDTO.setSellerId(sellerId);
        billLogDTO.setRole(role);

        BillSettlementDTO billSettlementDTO = new BillSettlementDTO();
        billSettlementDTO.setConfirmFileUrl("xZbxds");
        billSettlementDTO.setConfirmRemark(remark);
        billSettlementDTO.setConfirmFileName("hawaii");

        List<BillSettlementItemDTO> billSettlementItemDTOS = billItemIds.stream()
                .map(billItemId -> {
                    BillSettlementItemDTO billSettlementItemDTO = new BillSettlementItemDTO();
                    billSettlementItemDTO.setId(billItemId);
                    billSettlementItemDTO.setActualBillAmt(400L);
                    return billSettlementItemDTO;
                }).collect(Collectors.toList());
        billSettlementDTO.setSettlementItems(billSettlementItemDTOS);

        UserParam userParam = new UserParam();
        userParam.setAppId(defaultAppId);
        userParam.setDomainId(defaultDomainId);
        userParam.setUserId(defaultUserId);

        ResultDTO<VoidEntity> resultDTO = billManager.confirmSettlement(billId, billSettlementDTO, buttonKey, billLogDTO, userParam);
        System.out.println(JSONObject.toJSONString(resultDTO));
    }

    private void confirmOnlyRemark(long billId, long userId, String buttonKey, String role) {
        String userName = "xb";
        String remark = "confirmOnlyRemark";
        BillLogDTO billLogDTO = new BillLogDTO();
        billLogDTO.setRemark(remark);
        billLogDTO.setOperatorId(String.valueOf(userId));
        billLogDTO.setOperatorName(userName);
        billLogDTO.setSellerId(sellerId);
        billLogDTO.setRole(role);

        UserParam userParam = new UserParam();
        userParam.setAppId(defaultAppId);
        userParam.setDomainId(defaultDomainId);
        userParam.setUserId(defaultUserId);

        ResultDTO<VoidEntity> resultDTO = billManager.confirmOnlyRemark(billId, buttonKey, billLogDTO, userParam);
        System.out.println(JSONObject.toJSONString(resultDTO));
    }

    public void confirmInvoice(long billId, long userId, String buttonKey, String role) {
        String userName = "xb";
        String remark = "confirmInvoice";
        BillLogDTO billLogDTO = new BillLogDTO();
        billLogDTO.setRemark(remark);
        billLogDTO.setOperatorId(String.valueOf(userId));
        billLogDTO.setOperatorName(userName);
        billLogDTO.setSellerId(sellerId);
        billLogDTO.setRole(role);

        InvoiceInfoDTO invoiceInfoDTO = new InvoiceInfoDTO();
        invoiceInfoDTO.setBillId(billId);
        invoiceInfoDTO.setInvoiceId("xxxx-0001");
        invoiceInfoDTO.setInvoiceAmt(600L);
        invoiceInfoDTO.setInvoiceTaxAmt(200L);
        invoiceInfoDTO.setInvoiceTrackingNumber("---pajk----");
        invoiceInfoDTO.setButtonKey(buttonKey);

        UserParam userParam = new UserParam();
        userParam.setAppId(defaultAppId);
        userParam.setDomainId(defaultDomainId);
        userParam.setUserId(defaultUserId);

        ResultDTO<VoidEntity> resultDTO = billManager.confirmInvoice(invoiceInfoDTO, billLogDTO, userParam, true);
        System.out.println(JSONObject.toJSONString(resultDTO));
    }

    private void receiveInvoice(long billId, long userId, String buttonKey, String role) {
        String userName = "xb";
        String remark = "receiveInvoice";
        BillLogDTO billLogDTO = new BillLogDTO();
        billLogDTO.setRemark(remark);
        billLogDTO.setOperatorId(String.valueOf(userId));
        billLogDTO.setOperatorName(userName);
        billLogDTO.setSellerId(sellerId);
        billLogDTO.setRole(role);

        UserParam userParam = new UserParam();
        userParam.setAppId(defaultAppId);
        userParam.setDomainId(defaultDomainId);
        userParam.setUserId(defaultUserId);

        ResultDTO<VoidEntity> resultDTO = billManager.receiveInvoice(billId, buttonKey, billLogDTO, userParam);
        System.out.println(JSONObject.toJSONString(resultDTO));
    }

    private void confirmPayment(long billId, long userId, String buttonKey, String role) {
        String userName = "xb";
        String remark = "confirmPayment";
        BillLogDTO billLogDTO = new BillLogDTO();
        billLogDTO.setRemark(remark);
        billLogDTO.setOperatorId(String.valueOf(userId));
        billLogDTO.setOperatorName(userName);
        billLogDTO.setSellerId(sellerId);
        billLogDTO.setRole(role);

        PaymentInfoDTO paymentInfoDTO = new PaymentInfoDTO();
        paymentInfoDTO.setBillId(billId);
        paymentInfoDTO.setButtonKey(buttonKey);
        paymentInfoDTO.setPaymentNo("ISO-9001");
        paymentInfoDTO.setPaymentFileName("iXnpls");
        paymentInfoDTO.setPaymentFileId("goods");

        UserParam userParam = new UserParam();
        userParam.setAppId(defaultAppId);
        userParam.setDomainId(defaultDomainId);
        userParam.setUserId(defaultUserId);

        ResultDTO<VoidEntity> resultDTO = billManager.confirmPayment(paymentInfoDTO, billLogDTO, userParam, false);
        System.out.println(JSONObject.toJSONString(resultDTO));
    }

    private void confirmReceivePayment(long billId, long userId, String buttonKey, String role) {
        String userName = "xb";
        String remark = "confirmReceivePayment";
        BillLogDTO billLogDTO = new BillLogDTO();
        billLogDTO.setRemark(remark);
        billLogDTO.setOperatorId(String.valueOf(userId));
        billLogDTO.setOperatorName(userName);
        billLogDTO.setSellerId(sellerId);
        billLogDTO.setRole(role);

        UserParam userParam = new UserParam();
        userParam.setAppId(defaultAppId);
        userParam.setDomainId(defaultDomainId);
        userParam.setUserId(defaultUserId);

        ResultDTO<VoidEntity> resultDTO = billManager.confirmReceivePayment(billId, buttonKey, billLogDTO, userParam);
        System.out.println(JSONObject.toJSONString(resultDTO));
    }

    private void createSellerInvoice(Connection connection) throws Exception {
        String sql = "INSERT INTO seller_invoice_info (gmt_created, version, seller_id, status, invoice_title, taxpayer_number) " +
                "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, nowStr);
            pstmt.setInt(2, 0);
            pstmt.setLong(3, sellerId);
            pstmt.setInt(4, 0);
            pstmt.setString(5, "平安健康互联网");
            pstmt.setString(6, "pajk-internet-up");
            pstmt.execute();
        }
    }

    private void createSellerAccount(Connection connection) throws Exception {
        String sql = "INSERT INTO seller_account_info (gmt_created, version, seller_id, status, account_type, `purchaser_account`, purchaser_account_name, purchaser_bank_name) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, nowStr);
            pstmt.setInt(2, 0);
            pstmt.setLong(3, sellerId);
            pstmt.setInt(4, 0);
            pstmt.setInt(5, 1);
            pstmt.setString(6, "pajkhlw");
            pstmt.setString(7, "平安健康互联网");
            pstmt.setString(8, "中国建设银行");
            pstmt.execute();
        }
    }

    private void createSettlementData(Connection connection, int sType, int pType) throws Exception {
        String sql = "INSERT INTO bill_settlement (gmt_created, version, seller_id, month, pay_to_type, settlement_type, bill_amt, actual_bill_amt, ext_props) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Date now = new Date();
        try (PreparedStatement pstmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            for (int i = months; i <= months; i++) {
                pstmt.setString(1, nowStr);
                pstmt.setInt(2, 0);
                pstmt.setLong(3, sellerId);
                pstmt.setString(4, format.format(DateUtils.addMonths(now, -i)));
                pstmt.setInt(5, pType);
                pstmt.setInt(6, sType);
                pstmt.setLong(7, 10000L);
                pstmt.setLong(8, 10000L);
                pstmt.setString(9, flag);
                pstmt.addBatch();
            }
            pstmt.executeBatch();
            ResultSet resultSet = pstmt.getGeneratedKeys();
            while (resultSet.next()) {
                ids.put(resultSet.getLong(1), Lists.newLinkedList());
            }
            createSettlementItemData(connection);
        }
    }

    private void createSettlementItemData(Connection connection) throws Exception {
        String sql = "INSERT INTO bill_settlement_item (gmt_created, version, seller_id, bill_id, bill_type, bill_amt, actual_bill_amt) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            List<Integer> exceptions = Lists.newLinkedList();
            ids.forEach((id, lists) -> {
                for (int j = 0; j < 2; j++) {
                    try {
                        pstmt.setString(1, nowStr);
                        pstmt.setInt(2, 0);
                        pstmt.setLong(3, sellerId);
                        pstmt.setLong(4, id);
                        pstmt.setInt(5, BillType.ITEM_COST.getCode());
                        pstmt.setLong(6, 500L);
                        pstmt.setLong(7, 500L);
                        pstmt.addBatch();
                    } catch (SQLException e) {
                        e.printStackTrace();
                        exceptions.add(0);
                    }
                }
                try {
                    pstmt.executeBatch();
                    ResultSet resultSet = pstmt.getGeneratedKeys();
                    while (resultSet.next()) {
                        lists.add(resultSet.getLong(1));
                    }
                } catch (SQLException e) {
                    exceptions.add(0);
                }
            });
            if (!exceptions.isEmpty()) {
                throw new SQLException("o");
            }
        }
    }

    private void createData(int sType, int pType) {
        invoke(new Call() {
            @Override
            public void invoke(ResultSet result) {

            }

            @Override
            public void invoke(Connection connection) throws Exception {
//                createSellerInvoice(connection);
//                createSellerAccount(connection);
                createSettlementData(connection, sType, pType);
            }
        });
    }

    private void delete(Connection connection, String sql) {
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            if (!CollectionUtils.isEmpty(ids)) {
                ids.forEach((id, lists) -> {
                    try {
                        pstmt.setLong(1, id);
                        pstmt.addBatch();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                });
                pstmt.executeBatch();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void deleteData() {
        invoke(new Call() {
            @Override
            public void invoke(ResultSet result) {

            }

            @Override
            public void invoke(Connection connection) {
                String sql = "delete from bill_settlement where id=?";
                delete(connection, sql);
                sql = "delete from bill_settlement_item where bill_id=?";
                delete(connection, sql);
                sql = "delete from seller_account_info where seller_id=?";
//                delete(connection, sql);
                sql = "delete from seller_invoice_info where seller_id=?";
//                delete(connection, sql);
                sql = "delete from bill_log where bill_id=?";
                delete(connection, sql);
            }
        });
    }
}