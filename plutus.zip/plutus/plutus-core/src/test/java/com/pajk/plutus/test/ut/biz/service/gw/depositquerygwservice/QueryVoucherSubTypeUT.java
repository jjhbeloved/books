package com.pajk.plutus.test.ut.biz.service.gw.depositquerygwservice;

import com.pajk.plutus.biz.service.gw.DepositQueryGWServiceImpl;
import com.pajk.plutus.client.api.gw.DepositQueryGWService;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.voucher.BatchVoucherSubTypeGW;
import com.pajk.plutus.test.ut.BaseGwServiceUT;
import org.apache.commons.lang3.math.NumberUtils;
import org.mockito.InjectMocks;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by  guguangming on 2018/01/03
 **/
public class QueryVoucherSubTypeUT extends BaseGwServiceUT {
    @InjectMocks
    private DepositQueryGWService depositQueryGWService = new DepositQueryGWServiceImpl();

    @Test(description = "为unknown")
    public void test1() {
        mockitoPermissionOk();
        BatchVoucherSubTypeGW subType = depositQueryGWService.queryVoucherSubType(defaultAppId, defaultUserId, defaultSellerId, 7878,
                false);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(subType).isNull();
    }


    @Test(description = "查询成功")
    public void test2() {
        mockitoPermissionOk();
        BatchVoucherSubTypeGW subType = depositQueryGWService.queryVoucherSubType(defaultAppId, defaultUserId, defaultSellerId, VoucherType.PAYMENT.getCode(),
                true);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode._C_SUCCESS);
        assertThat(subType).isNotNull();
        assertThat(subType.voucherSubTypes.size()).isNotZero();

    }
}
