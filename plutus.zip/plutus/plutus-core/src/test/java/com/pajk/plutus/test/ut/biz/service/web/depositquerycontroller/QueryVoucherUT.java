package com.pajk.plutus.test.ut.biz.service.web.depositquerycontroller;

import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherDeliveryMapper;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherMapper;
import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.param.restapi.QueryVoucherParam;
import com.pajk.plutus.biz.model.result.dto.voucher.VoucherDTO;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.model.voucher.VoucherDeliveryDO;
import com.pajk.plutus.biz.service.web.DepositQueryController;
import com.pajk.plutus.client.model.enums.trade.PayMode;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.taskcenter.client.model.dto.TaskInstDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.*;

import static com.pajk.plutus.biz.model.enums.VoucherExtPropsKey.EVIDENCE_FLOW;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by  guguangming on 2017/12/29
 **/
public class QueryVoucherUT extends BaseWebServiceUT {

    @InjectMocks
    private DepositQueryController depositQueryController = new DepositQueryController();

    @Mock
    protected VoucherMapper voucherMapper;

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @Mock
    protected VoucherQueryRepository voucherQueryRepository;

    @Mock
    protected VoucherDeliveryMapper voucherDeliveryMapper;

    private String fileToken = "12321321";

    private String key3 = "审核中";
    private String nodeKey = "SELLER_OP";
    private String role = "sellerConfirm";
    private String evidenceFlow = "91122222";
    private String sellerName = "好药师";

    private QueryVoucherParam buildQueryParam() {
        mockitoPermissionOk();
        QueryVoucherParam queryParam = new QueryVoucherParam();
        queryParam.setSellerId(defaultSellerId);
        queryParam.setVoucherId(defaultVoucherId);
        return queryParam;
    }

    @Test(description = "单据不存在")
    public void test01() {
        mockitoPermissionOk();
        Mockito.doReturn(Optional.empty()).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucher(buildQueryParam());
        assertThat(result.getResultCode()).isEqualTo(ErrorCode.VOUCHER_NOT_EXISTS.getCode());
    }

    @Test(description = "延迟发货类型 违规单据违规发货扩展属性不存在")
    public void test02() {
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.empty()).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucher(buildQueryParam());
        assertThat(result.getResultCode()).isEqualTo(ErrorCode.VOUCHER_DELIVERY_NOT_EXISTS.getCode());
    }


    @Test(description = "延迟发货类型 查询NodeKeyName失败 & querySeller失败")
    public void test03() {
        mockitoPermissionOk();

        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);
        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(false);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
        List<AppResourceDO> doList = new LinkedList<>();

        mockSeller(buildSellerDO(),false);


        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucher(buildQueryParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        VoucherDTO voucher =  result.getModel();
        assertThat(voucher).isNotNull();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);
        assertThat(voucher.getNodeKeyName()).isNull();
        assertThat(voucher.getSellerName()).isNull();
        assertThat(voucher.getAuditFlows().size()).isNotZero();

    }

    @Test(description = "延迟发货类型&PayMode.PAY_ONLINE  查询审批记录失败 ")
    public void test04() {
        mockitoPermissionOk();

        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);
        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
        List<AppResourceDO> doList = new LinkedList<>();

        mockSeller(buildSellerDO(),true);


        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, false);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucher(buildQueryParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());

        VoucherDTO voucher =  result.getModel();
        assertThat(voucher).isNotNull();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);
        assertThat(voucher.getNodeKeyName()).isEqualTo(key3);
        assertThat(voucher.getSellerName()).isEqualTo(sellerName);
        assertThat(voucher.getAuditFlows()).isNull();
    }

    @Test(description = "延迟发货类型 PayMode.CASH_ON_DELIVERY ")
    public void test05() {
        mockitoPermissionOk();

        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        VoucherDeliveryDO deliveryDO = buildVoucherDeliveryDO();
        deliveryDO.setPayMode(PayMode.CASH_ON_DELIVERY.getCode());
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);
        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
        List<AppResourceDO> doList = new LinkedList<>();

        mockSeller(buildSellerDO(),true);


        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucher(buildQueryParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());

        VoucherDTO voucher =  result.getModel();
        assertThat(voucher).isNotNull();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);
        assertThat(voucher.getNodeKeyName()).isEqualTo(key3);
        assertThat(voucher.getSellerName()).isEqualTo(sellerName);

    }

    @Test(description = "PAYMENT类型 数据完成验证 ")
    public void test06() {
        mockitoPermissionOk();

        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherType(VoucherType.PAYMENT);
        voucherDO.setVoucherSubType(VoucherSubType.ADD_DEPOSIT);
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
        List<AppResourceDO> doList = new LinkedList<>();

        mockSeller(buildSellerDO(),true);


        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        ResultDTO<VoucherDTO> result = depositQueryController.queryVoucher(buildQueryParam());

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());

        VoucherDTO voucher =  result.getModel();
        assertThat(voucher).isNotNull();
        assertThat(voucher.getVoucherId()).isEqualTo(defaultVoucherId);
        assertThat(voucher.getNodeKeyName()).isEqualTo(key3);
        assertThat(voucher.getSellerName()).isEqualTo(sellerName);

    }

    private VoucherDO buildVoucherDO() {
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(defaultVoucherId);
        voucherDO.setIsDeleted(0);
        voucherDO.setExpectAmt(100L);
        voucherDO.setSellerId(defaultSellerId);
        voucherDO.setActualAmt(100L);
        voucherDO.setGmtCreated(new Date());
        voucherDO.setRole(role);
        voucherDO.setIsDeleted(0);
        voucherDO.setVoucherType(VoucherType.VIOLATION);
        voucherDO.setNodeKey(nodeKey);
        voucherDO.setVoucherSubType(VoucherSubType.FAKE_VIOLATION);
        voucherDO.setCreateRemark("12321");
        voucherDO.setCreateFile("[{\"fileKey\":\"T1iNxTBTxT1RCvBVdK.jpg\",\"fileName\":\"timg.jpg\"}]");
        voucherDO.setEvidenceFile("[{\"fileKey\":\"T1iNxTBTxT1RCvBVdK.jpg\",\"fileName\":\"timg.jpg\"}]");
        Map<String, String> ext = new HashMap<>();
        ext.put(EVIDENCE_FLOW.getCode(), evidenceFlow);
        voucherDO.setExtProps(ext);
        return voucherDO;
    }

    private VoucherDeliveryDO buildVoucherDeliveryDO() {
        VoucherDeliveryDO deliveryDO = new VoucherDeliveryDO();
        deliveryDO.setAmount(1);
        deliveryDO.setCompanyId(10001L);
        deliveryDO.setCompanyName("顺丰快递");
        deliveryDO.setCreateTime(new Date());
        deliveryDO.setAmount(2L);
        deliveryDO.setDeliveryTime(new Date());
        deliveryDO.setTrackingNumber("97661270004");
        deliveryDO.setPayMode(PayMode.PAY_ONLINE.getCode());
        deliveryDO.setPayTime(new Date());
        deliveryDO.setCreateTime(new Date());
        deliveryDO.setId(1L);
        return deliveryDO;
    }

    private AppResourceDO buildAppResourceDO() {
        AppResourceDO aDo = new AppResourceDO();
        aDo.key3 = key3;
        aDo.keyName = nodeKey;
        aDo.val2 = role;
        aDo.val3 = "审核成功";
        return aDo;
    }

    private TaskInstDTO buildTaskInstDTO() {
        TaskInstDTO instDTO = new TaskInstDTO();
        instDTO.setNodeKey("sellerAgree");
        instDTO.setApprovalId("111");
        instDTO.setApprovalVote("1111");
        instDTO.setNodeKey(nodeKey);
        instDTO.setStartTime(new Date());
        return instDTO;
    }

    private SellerDO buildSellerDO() {
        SellerDO sellerDO = new SellerDO();
        sellerDO.setName(sellerName);
        sellerDO.setId(defaultSellerId);
        return sellerDO;
    }

}
