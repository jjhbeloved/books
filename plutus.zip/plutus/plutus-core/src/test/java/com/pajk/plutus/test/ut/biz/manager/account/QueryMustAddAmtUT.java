package com.pajk.plutus.test.ut.biz.manager.account;

import com.pajk.plutus.biz.model.mapper.single.account.AccountBookFlowDAO;
import com.pajk.plutus.biz.model.query.account.BookFlowPageQuery;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by  guguangming on 2018/01/03
 **/
public class QueryMustAddAmtUT extends BaseAccountManagerUT {
    @Test(description = "没有查到结果--->查询pageQueryCount 为0")
    public void test1() {
        Mockito.doReturn(0).when(accountBookFlowMapper).pageQueryCount(Matchers.any(BookFlowPageQuery.class));
        ResultDTO<Long> resultDTO = accountManager.queryMustAddAmt(defaultSellerId, defaultBookId);
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getModel().doubleValue()).isZero();
    }

    @Test(description = "没有查到结果--->pageQuery 为0")
    public void test2() {
        Mockito.doReturn(2).when(accountBookFlowMapper).pageQueryCount(Matchers.any(BookFlowPageQuery.class));
        Mockito.doReturn(null).when(accountBookFlowMapper).pageQuery(Matchers.any(BookFlowPageQuery.class));

        ResultDTO<Long> resultDTO = accountManager.queryMustAddAmt(defaultSellerId, defaultBookId);
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getModel().doubleValue()).isZero();
    }

    @Test(description = "没有查到结果--->accountBookFlowMapper.pageQuery 查询成功但数据为0")
    public void test3() {
        Mockito.doReturn(1).when(accountBookFlowMapper).pageQueryCount(Matchers.any(BookFlowPageQuery.class));

        List<AccountBookFlowDAO> list = new LinkedList<>();
        AccountBookFlowDAO flowDAO = buildAccountBookFlowDAO();
        flowDAO.setAmount(0L);
        list.add(flowDAO);
        Mockito.doReturn(list).when(accountBookFlowMapper).pageQuery(Matchers.any(BookFlowPageQuery.class));

        ResultDTO<Long> resultDTO = accountManager.queryMustAddAmt(defaultSellerId, defaultBookId);
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getModel().doubleValue()).isZero();
    }

    @Test(description = "没有查到结果--->查询成功并进行结果校验")
    public void test4() {
        Mockito.doReturn(1).when(accountBookFlowMapper).pageQueryCount(Matchers.any(BookFlowPageQuery.class));

        List<AccountBookFlowDAO> list = new LinkedList<>();
        list.add(buildAccountBookFlowDAO());
        Mockito.doReturn(list).when(accountBookFlowMapper).pageQuery(Matchers.any(BookFlowPageQuery.class));

        ResultDTO<Long> resultDTO = accountManager.queryMustAddAmt(defaultSellerId, defaultBookId);
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getModel().doubleValue()).isEqualTo(amount);
    }


}