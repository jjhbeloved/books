package com.pajk.plutus.test.ut.biz.manager.account;

/**
 * Created by  guguangming on 2018/01/03
 **/
public class PageQueryBookFlowUT extends BaseAccountManagerUT {
}
