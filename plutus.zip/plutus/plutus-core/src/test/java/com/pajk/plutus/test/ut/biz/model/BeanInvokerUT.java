package com.pajk.plutus.test.ut.biz.model;

import com.pajk.plutus.biz.model.bill.FileInfoDO;
import com.pajk.plutus.biz.model.bill.PaymentInfoDO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookFlowUpdateOPT;
import com.pajk.plutus.biz.model.param.restapi.*;
import com.pajk.plutus.biz.model.process.TaskDO;
import com.pajk.plutus.biz.model.query.bill.*;
import com.pajk.plutus.biz.model.result.dto.account.AccountBookDTO;
import com.pajk.plutus.biz.model.result.dto.account.AccountBookFlowDTO;
import com.pajk.plutus.biz.model.result.dto.account.BookButtonDTO;
import com.pajk.plutus.biz.model.result.dto.voucher.PaymentPropDTO;
import com.pajk.plutus.biz.model.result.dto.voucher.VoucherSubTypeDTO;
import com.pajk.plutus.biz.model.result.dto.voucher.VoucherSummaryDTO;
import com.pajk.plutus.biz.model.roma.PromiseWrapper;
import com.pajk.plutus.biz.model.roma.RomaBookFlowInfo;
import com.pajk.plutus.biz.model.roma.ValueChange;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.test.ut.BaseServiceUT;
import org.testng.annotations.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * 大规模bean覆盖率杀伤性武器
 */
public class BeanInvokerUT extends BaseServiceUT {

    @Test
    public void pagePOTest() throws Exception {
        Class[] classes = new Class[]{VoucherDO.class, AccountDTO.class, AccountSnapshotDTO.class,
                BillLogDTO.class, BillSettlementDTO.class, BillSettlementItemDTO.class, BillStatusDTO.class,
                ButtonDTO.class, ConfirmInfoDTO.class, FileInfoDTO.class, InvoiceDTO.class, InvoiceInfoDTO.class,
                InvoiceSnapshotDTO.class, PaymentInfoDTO.class, RemarkDTO.class, SellerDTO.class,
                SettlementOperationDTO.class, AccountBookDTO.class, AccountBookFlowDTO.class,
                AccountBookFlowUpdateOPT.class, AddBalanceAmtParam.class, AuditPaymentParam.class,
                AuditPunishParam.class, BookButtonDTO.class, ButtonDTO.class, CreatePunishParam.class,
                DealPunishParam.class, FileInfoDTO.class, FileInfoDO.class,
                com.pajk.plutus.biz.model.file.FileInfoDO.class, PageQueryAccountBookFlowParam.class,
                PageQueryAccountBookParam.class, PageQueryVoucherParam.class, PaymentPropDTO.class,
                PaymentInfoDO.class, PromiseWrapper.class, QueryVoucherSubTypeParam.class,
                RomaBookFlowInfo.class, ValueChange.class, TaskDO.class, UpdateContractAmtParam.class,
                VoucherSubTypeDTO.class, VoucherSummaryDTO.class
        };

        for (Class<?> clazz : classes) {
            beanCover(clazz, clazz.getConstructor().newInstance());
        }
    }

    private void beanCover(Class<?> clazz, Object obj) {
        Method[] methods = clazz.getMethods();
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            Class Type = field.getType();
            String name = field.getName();
            String one = name.substring(0, 1);
            String other = name.substring(1, name.length());
            name = one.toUpperCase() + other;
            String setMethod = "set" + name;
            String getMethod = "get" + name;
            try {
                clazz.getMethod(setMethod, Type).invoke(obj, getObj(Type));
                clazz.getMethod(getMethod).invoke(obj);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        for (Method method : methods) {
            System.out.println(method);
        }
    }

    private Object getObj(Class clazz) {
        if (clazz.getName().equals("java.lang.Long") || clazz.getName().equals("long")) {
            return 1L;
        }
        if (clazz.getName().equals("java.lang.String")) {
            return "test";
        }
        if (clazz.getName().equals("java.lang.Integer") || clazz.getName().equals("int")) {
            return 1;
        }
        if (clazz.getName().equals("java.util.Date")) {
            return new Date();
        }
        if (clazz.getName().equals("java.time.LocalDateTime")) {
            return LocalDateTime.now();
        }
        return 1L;
    }

}
