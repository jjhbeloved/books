package com.pajk.plutus.test.it;

import com.ninja_squad.dbsetup.DbSetup;
import com.ninja_squad.dbsetup.operation.Operation;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;

import java.sql.*;

import static com.ninja_squad.dbsetup.Operations.sql;

/**
 * Created by fanhuafeng on 17/2/22.
 * Modify by fanhuafeng on 17/2/22
 */
@SpringBootTest(classes = com.pajk.plutus.ApplicationMain.class)
public class BaseIT extends AbstractTestNGSpringContextTests {

    protected long defaultDomainId = 9222000L;
    protected long defaultAppId = 9222001L;
    protected long defaultUserId = 20018930308L;
    protected long defaultSellerId = 12026100507L;

    protected void doSql(String sql) {
        Operation operation = sql(sql);
        new DbSetup(Database.MCFINANCE, operation).launch();
    }

    /**
     * 打开连接批量调用SQL
     *
     * @param call 回调函数
     */
    protected void invoke(Call call) {
        try (Connection connection = Database.MCFINANCE.getConnection()
        ) {
            connection.setAutoCommit(false);
            call.invoke(connection);
            connection.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 回调函数可以获取主键ID
     *
     * @param sql  SQL语句
     * @param call 回调函数
     */
    protected void insert(String sql, Call call) {
        try (Connection connection = Database.MCFINANCE.getConnection();
             PreparedStatement pstmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)
        ) {
            connection.setAutoCommit(false);
            pstmt.executeUpdate();
            ResultSet resultSet = pstmt.getGeneratedKeys();
            call.invoke(resultSet);
            connection.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void query(String sql, Call call) throws SQLException {
        try (Connection connection = Database.MCFINANCE.getConnection(); Statement stmt = connection.createStatement()) {
            ResultSet resultSet = stmt.executeQuery(sql);
            call.invoke(resultSet);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected interface Call {
        void invoke(ResultSet result);

        void invoke(Connection connection) throws Exception;
    }

}
