package com.pajk.plutus.test.ut.biz.common.util.timeutil;

import com.pajk.plutus.biz.common.util.TimeUtils;
import org.testng.annotations.Test;

import java.lang.reflect.Constructor;
import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by cuidongchao on 2017/12/28.
 */
public class TimeUtilsUT {

    @Test(description = "addMonth")
    public void test001() {
        Date date = TimeUtils.parse("2017-12-28 12:34:20");
        Date date1 = TimeUtils.addMonth(date, -1);
        assertThat(date1.getMonth()).isEqualTo(10);

        date1 = TimeUtils.addMonth(date, 1);
        assertThat(date1.getMonth()).isEqualTo(0);
    }


    @Test(description = "addDay")
    public void test002() {
        Date date = TimeUtils.parse("2017-12-28 12:34:20");
        Date date1 = TimeUtils.addDate(date, -1);
        assertThat(date1.getDate()).isEqualTo(27);

        date1 = TimeUtils.addDate(date, 1);
        assertThat(date1.getDate()).isEqualTo(29);
    }


    @Test(description = "getBeginOfDate")
    public void test003() {
        Date date = TimeUtils.parse("2017-12-28 12:34:20");
        Date date1 = TimeUtils.getBeginOfDate(date);
        assertThat(date1.getHours()).isEqualTo(0);
        assertThat(date1.getMinutes()).isEqualTo(0);
        assertThat(date1.getSeconds()).isEqualTo(0);
    }

    @Test(description = "getEndOfDate")
    public void test004() {
        Date date = TimeUtils.parse("2017-12-28 12:34:20");
        Date date1 = TimeUtils.getEndOfDate(date);
        assertThat(date1.getHours()).isEqualTo(23);
        assertThat(date1.getMinutes()).isEqualTo(59);
        assertThat(date1.getSeconds()).isEqualTo(59);
    }

    @Test(description = "getTimeMillis")
    public void test005() {
        Date date = TimeUtils.parse("2017-12-28 12:34:20");
        Long m = TimeUtils.getTimeMillis(date);
        assertThat(m).isEqualTo(1514435660000L);
    }

    @Test(description = "getTimeMillis")
    public void test007() {
        Long m = TimeUtils.getTimeMillis(null, 0);
        assertThat(m).isEqualTo(0);
    }

    @Test(description = "getTimeSeconds")
    public void test008() {
        Date date = TimeUtils.parse("2017-12-28 12:34:20");
        Long m = TimeUtils.getTimeSeconds(date);
        assertThat(m).isEqualTo(1514435660L);
        m = TimeUtils.getTimeSeconds(null, 0);
        assertThat(m).isEqualTo(0);
    }

    @Test(description = "getTimeSeconds")
    public void test009() {
        Date date = TimeUtils.parse("2017-12-28 12:34:20");
        assertThat(date).isNotNull();
        date = TimeUtils.parse("2017-12-28 12:34:20", null);
        assertThat(date).isNull();
        date = TimeUtils.parse(null, null);
        assertThat(date).isNull();
        date = TimeUtils.parse("2017-12-28 12:34:20", "test");
        assertThat(date).isNull();
    }


    @Test(description = "")
    public void test010() {
        String s = "2017-12-28 12:34:20";
        Date date = TimeUtils.parse(s);
        assertThat(date).isNotNull();

        String tar = TimeUtils.format(date);
        assertThat(tar).isEqualTo(s);

        tar = TimeUtils.format(date, "test");
        assertThat(tar).isNull();

        tar = TimeUtils.format(date, null);
        assertThat(tar).isNull();

        tar = TimeUtils.format(null, "test");
        assertThat(tar).isNull();

    }

    @Test(description = "反射构造方法")
    public void test011() {

        try {
            Class clazz = TimeUtils.class;
            Constructor cons = clazz.getDeclaredConstructor(null);
            cons.setAccessible(true);

            cons.newInstance(null);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }




}
