package com.pajk.plutus.test.ut.biz.manager.voucher;

import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.common.util.TimeUtils;
import com.pajk.plutus.biz.exceptions.DBException;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountDAO;
import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDeliveryDAO;
import com.pajk.plutus.biz.model.query.voucher.VoucherDeliveryPageQuery;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.*;

/**
 * Created by cuidongchao on 2017/12/24.
 */
public class AutoCreatePunishUT extends BaseVoucherManagerUT {

    private Date end = new Date();
    private Date start = TimeUtils.addDate(end, -1);

    @Test(description = "数量为0")
    public void test001() {

        Mockito.doReturn(0)
                .when(voucherDeliveryMapper)
                .pageQueryCount(any(VoucherDeliveryPageQuery.class));

        ResultDTO<VoidEntity> ret = voucherManager.autoCreatePunish(start, end);

        assertThat(ret.isSuccess()).isTrue();
    }


    @Test(description = "数量为不为0，已经处理过的数据")
    public void test002() {

        Mockito.doReturn(1)
                .when(voucherDeliveryMapper)
                .pageQueryCount(any(VoucherDeliveryPageQuery.class));

        List<VoucherDeliveryDAO> deliveryDAOS = new ArrayList<>();
        VoucherDeliveryDAO dao = new VoucherDeliveryDAO();
        dao.setSellerId(defaultSellerId);
        dao.setVoucherId("12340909");
        deliveryDAOS.add(dao);

        Mockito.doReturn(deliveryDAOS)
                .doReturn(new ArrayList<>())
                .when(voucherDeliveryMapper)
                .pageQuery(any());


        ResultDTO<VoidEntity> ret = voucherManager.autoCreatePunish(start, end);

        assertThat(ret.isSuccess()).isTrue();
    }

    @Test(description = "账本不存在，创建账户、账本时，查询商家失败")
    public void test003() {

        Mockito.doReturn(1)
                .when(voucherDeliveryMapper)
                .pageQueryCount(any(VoucherDeliveryPageQuery.class));

        List<VoucherDeliveryDAO> deliveryDAOS = new ArrayList<>();
        VoucherDeliveryDAO dao = new VoucherDeliveryDAO();
        dao.setSellerId(defaultSellerId);
        deliveryDAOS.add(dao);

        Mockito.doReturn(deliveryDAOS)
                .doReturn(new ArrayList<>())
                .when(voucherDeliveryMapper)
                .pageQuery(any());

        Mockito.doReturn(0)
                .when(accountBookMapper).pageQueryCount(any());
        KyCallResult<SellerDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(false);
        Mockito.doReturn(kyCallResult)
                .when(sellerService)
                .getSellerById(any());


        ResultDTO<VoidEntity> ret = voucherManager.autoCreatePunish(start, end);

        assertThat(ret.isSuccess()).isTrue();
    }

    @Test(description = "数量为不为0，未处理过的数据，账户不存在")
    public void test004() {

        Mockito.doReturn(1)
                .when(voucherDeliveryMapper)
                .pageQueryCount(any(VoucherDeliveryPageQuery.class));

        List<VoucherDeliveryDAO> deliveryDAOS = new ArrayList<>();
        VoucherDeliveryDAO dao = new VoucherDeliveryDAO();
        dao.setSellerId(defaultSellerId);
        deliveryDAOS.add(dao);

        Mockito.doReturn(deliveryDAOS)
                .doReturn(new ArrayList<>())
                .when(voucherDeliveryMapper)
                .pageQuery(any());

        Mockito.doReturn(0)
                .when(accountBookMapper).pageQueryCount(any());

        mockSellerSuccess();

        Mockito.doReturn(null)
                .when(accountMapper)
                .queryBySeller(anyLong());
        Mockito.doReturn(1)
                .when(accountMapper)
                .create(any(AccountDAO.class));
        Mockito.doReturn(1)
                .when(accountBookMapper)
                .create(any(AccountBookDAO.class));

        mockVoucherIDGen();
        // mock create process
        mockFlowServiceCreateProcessOK();

        Mockito.doNothing()
                .when(voucherMapper)
                .create(any());
        Mockito.doReturn(1)
                .when(voucherDeliveryMapper)
                .updateByOPT(any());

        ResultDTO<VoidEntity> ret = voucherManager.autoCreatePunish(start, end);

        assertThat(ret.isSuccess()).isTrue();
    }

    @Test(description = "数量为不为0，未处理过的数据，账户不存在，数据库操作异常")
    public void test005() {

        Mockito.doReturn(1)
                .when(voucherDeliveryMapper)
                .pageQueryCount(any(VoucherDeliveryPageQuery.class));

        List<VoucherDeliveryDAO> deliveryDAOS = new ArrayList<>();
        VoucherDeliveryDAO dao = new VoucherDeliveryDAO();
        dao.setSellerId(defaultSellerId);
        deliveryDAOS.add(dao);

        Mockito.doReturn(deliveryDAOS)
                .doReturn(new ArrayList<>())
                .when(voucherDeliveryMapper)
                .pageQuery(any());

        Mockito.doReturn(0)
                .when(accountBookMapper).pageQueryCount(any());

        mockSellerSuccess();

        Mockito.doReturn(null)
                .when(accountMapper)
                .queryBySeller(anyLong());
        Mockito.doReturn(1)
                .when(accountMapper)
                .create(any(AccountDAO.class));
        Mockito.doReturn(1)
                .when(accountBookMapper)
                .create(any(AccountBookDAO.class));

        mockVoucherIDGen();
        // mock create process
        mockFlowServiceCreateProcessOK();

        Mockito.doThrow(new DBException(42, "FAIL"))
                .when(voucherMapper)
                .create(any());
        Mockito.doReturn(1)
                .when(voucherDeliveryMapper)
                .updateByOPT(any());

        ResultDTO<VoidEntity> ret = voucherManager.autoCreatePunish(start, end);

        assertThat(ret.isSuccess()).isTrue();
    }

    @Test(description = "账本存在，已冻结")
    public void test006() {

        Mockito.doReturn(1)
                .when(voucherDeliveryMapper)
                .pageQueryCount(any(VoucherDeliveryPageQuery.class));

        List<VoucherDeliveryDAO> deliveryDAOS = new ArrayList<>();
        VoucherDeliveryDAO dao = new VoucherDeliveryDAO();
        dao.setSellerId(defaultSellerId);
        deliveryDAOS.add(dao);

        Mockito.doReturn(deliveryDAOS)
                .doReturn(new ArrayList<>())
                .when(voucherDeliveryMapper)
                .pageQuery(any());

        Mockito.doReturn(1)
                .when(accountBookMapper).pageQueryCount(any());

        Mockito.doReturn(null)
                .when(accountBookMapper)
                .queryValidBookBySeller(anyLong(), anyInt());

        ResultDTO<VoidEntity> ret = voucherManager.autoCreatePunish(start, end);

        assertThat(ret.isSuccess()).isTrue();
    }

    @Test(description = "账本存在，创建流程失败")
    public void test007() {

        Mockito.doReturn(1)
                .when(voucherDeliveryMapper)
                .pageQueryCount(any(VoucherDeliveryPageQuery.class));

        List<VoucherDeliveryDAO> deliveryDAOS = new ArrayList<>();
        VoucherDeliveryDAO dao = new VoucherDeliveryDAO();
        dao.setSellerId(defaultSellerId);
        deliveryDAOS.add(dao);

        Mockito.doReturn(deliveryDAOS)
                .doReturn(new ArrayList<>())
                .when(voucherDeliveryMapper)
                .pageQuery(any());

        Mockito.doReturn(1)
                .when(accountBookMapper).pageQueryCount(any());

        Mockito.doReturn(new AccountBookDAO())
                .when(accountBookMapper)
                .queryValidBookBySeller(anyLong(), anyInt());

        mockFlowServiceCreateProcessFail();


        ResultDTO<VoidEntity> ret = voucherManager.autoCreatePunish(start, end);

        assertThat(ret.isSuccess()).isTrue();
    }

    @Test(description = "账本存在，创建流程成功")
    public void test008() {

        Mockito.doReturn(1)
                .when(voucherDeliveryMapper)
                .pageQueryCount(any(VoucherDeliveryPageQuery.class));

        List<VoucherDeliveryDAO> deliveryDAOS = new ArrayList<>();
        VoucherDeliveryDAO dao = new VoucherDeliveryDAO();
        dao.setSellerId(defaultSellerId);
        deliveryDAOS.add(dao);

        Mockito.doReturn(deliveryDAOS)
                .doReturn(new ArrayList<>())
                .when(voucherDeliveryMapper)
                .pageQuery(any());

        Mockito.doReturn(1)
                .when(accountBookMapper).pageQueryCount(any());

        Mockito.doReturn(new AccountBookDAO())
                .when(accountBookMapper)
                .queryValidBookBySeller(anyLong(), anyInt());

        mockFlowServiceCreateProcessOK();

        Mockito.doNothing()
                .when(voucherMapper)
                .create(any());
        Mockito.doReturn(1)
                .when(voucherDeliveryMapper)
                .updateByOPT(any());


        ResultDTO<VoidEntity> ret = voucherManager.autoCreatePunish(start, end);

        assertThat(ret.isSuccess()).isTrue();
    }


}
