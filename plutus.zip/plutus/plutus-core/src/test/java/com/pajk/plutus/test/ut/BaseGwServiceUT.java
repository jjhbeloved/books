package com.pajk.plutus.test.ut;

import net.pocrd.dubboext.DubboExtProperty;
import org.testng.annotations.BeforeMethod;

/**
 * Created by fanhuafeng on 16/12/12.
 * Modify by fanhuafeng on 16/12/12
 * api 网关单元测试的一个抽象测试类
 */
public abstract class BaseGwServiceUT extends BaseServiceUT {

    /**
     * 由于api网关的特殊性 同一个 UT下面 所有单元测试必须要使用  @Test(dependsOnMethods = "xxxx") 这种方式,
     * 也就是 下一个测试用例必须依赖上一个测试用例, 否则无法很好的读取api网关的错误码;
     *
     * @return 错误码
     */
    protected String getDubboErrorCode() {
        String str = DubboExtProperty.getErrorCode();
        DubboExtProperty.clearNotificaitons();
        return str;
    }

    @BeforeMethod
    public void setUp() throws Exception {
        super.setUp();
        DubboExtProperty.clearNotificaitons();
    }

}
