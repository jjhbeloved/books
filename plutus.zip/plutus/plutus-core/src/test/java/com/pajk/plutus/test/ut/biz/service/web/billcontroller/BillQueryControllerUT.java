package com.pajk.plutus.test.ut.biz.service.web.billcontroller;

import com.pajk.plutus.biz.manager.BillManager;
import com.pajk.plutus.biz.manager.permission.UserManger;
import com.pajk.plutus.biz.manager.permission.UserUtil;
import com.pajk.plutus.biz.model.bill.*;
import com.pajk.plutus.biz.model.param.restapi.SettlementParam;
import com.pajk.plutus.biz.model.query.bill.BillSettlementDTO;
import com.pajk.plutus.biz.service.web.BillQueryController;
import com.pajk.plutus.client.model.enums.bill.BillType;
import com.pajk.plutus.client.model.enums.bill.SettlementType;
import com.pajk.plutus.client.model.enums.trade.PayToType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseServiceUT;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.user.model.User;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;

/**
 * Created by sunjin on 2017/12/26.
 */
public class BillQueryControllerUT extends BaseServiceUT {

    @InjectMocks
    private BillQueryController billQueryController;

    @Mock
    private BillManager billManager;

    @Mock
    private UserManger userManger;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        User user = new User(1L);
        user.setName("unit test user");
        UserUtil.putUser(user);
    }

    @After
    public void tearDown() throws Exception {
    }


    @Test
    public void queryConfirmSettlement() {
        SettlementParam param = new SettlementParam();
        param.setBillId(1L);
        String curRole = "BD";

        ResultDTO<BillSettlementDO> resultDO = new ResultDTO<>();
        BillSettlementDO settlementDO = getBillSettlementDO();
        settlementDO.setRole(curRole);
        resultDO.setModel(settlementDO);

        Mockito.when(billManager.queryConfirmSettlement(anyLong())).thenReturn(resultDO);

        Mockito.when(userManger.getCurrentUserRole()).thenReturn(curRole);

        BatchResultDTO<ButtonDO> batchResultDTO = new BatchResultDTO<>();
        Mockito.when(billManager.getButtons(anyLong(), anyString())).thenReturn(batchResultDTO);

        mockitoPermissionOk();

        ResultDTO<BillSettlementDTO> resultDTO = billQueryController.queryConfirmSettlement(param);
        Assert.assertNotNull(resultDTO);
        Assert.assertTrue(resultDTO.isSuccess());
        Assert.assertNotNull(resultDTO.getModel());


        resultDO.setResultCode(ErrorCode.BILL_NOT_EXIST.getCode());
        resultDTO = billQueryController.queryConfirmSettlement(param);
        Assert.assertFalse(resultDTO.isSuccess());

        resultDO.setResultCode(ErrorCode.SUCCESS.getCode());
        settlementDO.setRole(null);
        resultDTO = billQueryController.queryConfirmSettlement(param);
        Assert.assertTrue(resultDTO.isSuccess());
        Assert.assertNotNull(resultDTO.getModel());
        Assert.assertEquals(0, resultDTO.getModel().getActionButtons().size());

        settlementDO.setProcInstId(null);
        resultDTO = billQueryController.queryConfirmSettlement(param);
        Assert.assertTrue(resultDTO.isSuccess());
        Assert.assertNotNull(resultDTO.getModel());
        Assert.assertEquals(0, resultDTO.getModel().getActionButtons().size());
    }

    private BillSettlementDO getBillSettlementDO() {
        BillSettlementDO billSettlementDO = new BillSettlementDO();
        billSettlementDO.setProcInstId(1L);
        billSettlementDO.setId(1L);
        billSettlementDO.setSellerId(1L);
        billSettlementDO.setSellerName("SELLER NAME");
        billSettlementDO.setMonth(new Date());
        billSettlementDO.setNodeKeyName("node key");
        billSettlementDO.setSettlementType(SettlementType.PA_PAY.getCode());

        billSettlementDO.setPayToType(PayToType.PAY_TO_SELLER.getCode());
        billSettlementDO.setBillAmt(1000L);
        billSettlementDO.setActualBillAmt(800L);

        // 支付信息
        List<PaymentInfoDO> paymentInfoDOS = new ArrayList<>();
        PaymentInfoDO paymentInfoDO = new PaymentInfoDO();
        paymentInfoDO.setPaymentNo("123213123");
        paymentInfoDO.setPaymentFileName("file name");
        paymentInfoDO.setPaymentFileId("12321312adas");
        paymentInfoDOS.add(paymentInfoDO);
        billSettlementDO.setPaymentInfoDOS(paymentInfoDOS);

        // 发票信息
        InvoiceInfoDO invoiceInfoDO = new InvoiceInfoDO();
        invoiceInfoDO.setInvoiceTax(200L);
        invoiceInfoDO.setInvoiceId("12312321");
        invoiceInfoDO.setInvoiceAmt(800L);
        invoiceInfoDO.setInvoiceId("12312312");
        invoiceInfoDO.setTrackingNumber("sdfghjkloiuyt");
        billSettlementDO.setInvoiceInfoDO(invoiceInfoDO);

        // 确认信息
        ConfirmInfoDO confirmInfoDO = new ConfirmInfoDO();
        confirmInfoDO.setRemark("remark");
        List<FileInfoDO> fileInfo = new ArrayList<>();
        confirmInfoDO.setFileInfoDO(fileInfo);
        FileInfoDO fileInfoDO = new FileInfoDO();
        fileInfoDO.setConfirmFileId("1123213");
        fileInfoDO.setConfirmFileName("file name");
        fileInfo.add(fileInfoDO);
        billSettlementDO.setConfirmInfoDO(confirmInfoDO);

        // 发票快照信息
        List<BillSettlementItemDO> settlementItemDOs = new ArrayList<>();
        BillSettlementItemDO billSettlementItemDO = new BillSettlementItemDO();
        settlementItemDOs.add(billSettlementItemDO);
        billSettlementItemDO.setBillId(1L);
        billSettlementItemDO.setBillAmt(800L);
        billSettlementItemDO.setActualBillAmt(700L);
        billSettlementItemDO.setSellerId(2L);
        billSettlementItemDO.setBillType(BillType.ITEM_COMMISSION_AMT.getCode());

        // 单据明细
        billSettlementDO.setBillSettlementItemDOS(settlementItemDOs);

        return billSettlementDO;
    }


}
