package com.pajk.plutus.test.it;

import com.pajk.plutus.biz.manager.permission.UserUtil;
import com.pajk.user.model.User;
import org.testng.annotations.BeforeMethod;

/**
 * Created by fuyongda on 2017/12/26.
 * Modified by fuyongda on 2017/12/26.
 */
public class BaseControllerIT extends BaseIT {

    @BeforeMethod
    public void setUp() throws Exception {
        User user = new User(defaultUserId);
        UserUtil.putUser(user);
    }

}
