package com.pajk.plutus.test.ut.biz.manager.account;

import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.biz.model.query.account.BookPageQuery;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by  guguangming on 2018/01/03
 **/
public class PageQueryBookUT extends BaseAccountManagerUT {
    @Test(description = "没有查到结果")
    public void test1() {
        BookPageQuery bookPageQuery = new BookPageQuery();
        PageResultDTO<AccountBookDO> pageResultDTO = accountManager.pageQueryBook(bookPageQuery);
        assertThat(pageResultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(pageResultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(pageResultDTO.getModel()).isEqualTo(Collections.emptyList());
        assertThat(pageResultDTO.getTotalCount()).isEqualTo(0);
    }

    @Test(description = "没有查到结果")
    public void test2() {
        Mockito.doReturn(1).when(accountBookMapper).pageQueryCount(Matchers.any(BookPageQuery.class));
        Mockito.doReturn(null).when(accountBookMapper).pageQuery(Matchers.any(BookPageQuery.class));

        BookPageQuery bookPageQuery = new BookPageQuery();
        PageResultDTO<AccountBookDO> pageResultDTO = accountManager.pageQueryBook(bookPageQuery);
        assertThat(pageResultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(pageResultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(pageResultDTO.getModel()).isEqualTo(Collections.emptyList());
    }

    @Test(description = "查出结果并验证")
    public void test3() {
        Mockito.doReturn(1).when(accountBookMapper).pageQueryCount(Matchers.any(BookPageQuery.class));
        AccountBookDAO bookDAO = buildAccountBookDAO();
        List<AccountBookDAO> list = new LinkedList<>();
        list.add(bookDAO);
        Mockito.doReturn(list).when(accountBookMapper).pageQuery(Matchers.any(BookPageQuery.class));

        BookPageQuery bookPageQuery = new BookPageQuery();
        PageResultDTO<AccountBookDO> pageResultDTO = accountManager.pageQueryBook(bookPageQuery);
        assertThat(pageResultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(pageResultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(pageResultDTO.getModel().size()).isNotZero();
        AccountBookDO bookDO = pageResultDTO.getModel().get(0);
        assertThat(bookDO.getAccountId()).isEqualTo(bookDAO.getAccountId());
        assertThat(bookDO.getBalanceAmt()).isEqualTo(bookDAO.getBalanceAmt());
        assertThat(bookDO.getActualContractAmt()).isEqualTo(bookDAO.getActualContractAmt());
    }

}
