package com.pajk.plutus.test.it.biz.manager.impl.vouchermanager;

import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.test.it.BaseIT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * Created by lizhijun on 2017/12/25.
 */
public class QueryMustAmtIT extends BaseIT {
    @Autowired
    private AccountManager accountManager;

    @Test
    public void test1(){
        ResultDTO<Long> resultDTO = accountManager.queryMustAddAmt(20021820000L,2L);

        System.out.println(resultDTO);
    }

}
