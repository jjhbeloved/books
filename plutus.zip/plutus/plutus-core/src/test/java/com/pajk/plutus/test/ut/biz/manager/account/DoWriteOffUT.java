package com.pajk.plutus.test.ut.biz.manager.account;

import com.pajk.plutus.biz.model.mapper.single.account.AccountBookFlowDAO;
import com.pajk.plutus.client.model.enums.account.BookFlowSubType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by  guguangming on 2018/01/03
 **/
public class DoWriteOffUT extends BaseAccountManagerUT {
    @Test(description = "账本流水不存在")
    public void test1() {
        Mockito.doReturn(null).when(accountBookFlowMapper).queryById(Matchers.anyLong());
        ResultDTO<VoidEntity> resultDTO = accountManager.doWriteOff(defaultBookFlowId);
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.WRITE_OFF_FLOW_NOT_EXISTS.getCode());
    }

    @Test(description = "FlowSubType状态不匹配 返回成功")
    public void test2() {
        AccountBookFlowDAO accountBookFlowDAO = buildAccountBookFlowDAO();
        accountBookFlowDAO.setFlowSubType(BookFlowSubType.ADD_DEPOSIT.getCode());
        Mockito.doReturn(accountBookFlowDAO).when(accountBookFlowMapper).queryById(Matchers.anyLong());
        ResultDTO<VoidEntity> resultDTO = accountManager.doWriteOff(defaultBookFlowId);
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
    }

    @Test(description = "queryBookFlowCountByWriteOffId 查询数量为0")
    public void test3() {
        Mockito.doReturn(buildAccountBookFlowDAO()).when(accountBookFlowMapper).queryById(Matchers.anyLong());
        Mockito.doReturn(0).when(accountBookFlowMapper).queryCountByWriteOffId(Matchers.anyInt(),
                Matchers.anyString(), Matchers.anyString());

        ResultDTO<VoidEntity> resultDTO = accountManager.doWriteOff(defaultBookFlowId);
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.WRITE_OFF_FLOW_NOT_EXISTS.getCode());
    }

    @Test(description = "accountBookFlowMapper.updateWriteOffToFinish  失败")
    public void test4() {
        Mockito.doReturn(buildAccountBookFlowDAO()).when(accountBookFlowMapper).queryById(Matchers.anyLong());

        Mockito.doReturn(1).when(accountBookFlowMapper).queryCountByWriteOffId(Matchers.anyInt(),
                Matchers.anyString(), Matchers.anyString());


        List<Long> listIds = Arrays.asList(100L);
        Mockito.doReturn(listIds).when(accountBookFlowMapper).pageQueryIdsByWriteOffId(Matchers.anyInt(),
                Matchers.anyString(), Matchers.anyString(), Matchers.anyInt(), Matchers.anyInt());

        Mockito.doReturn(0).when(accountBookFlowMapper).updateWriteOffToFinish(Matchers.anyLong(),
                Matchers.anyInt());

        ResultDTO<VoidEntity> resultDTO = accountManager.doWriteOff(defaultBookFlowId);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.STORE_DB_FAILED.getCode());
    }


    @Test(description = "accountBookFlowMapper.batchUpdateWriteOffToFinish  数量不屁屁额")
    public void test5() {
        Mockito.doReturn(buildAccountBookFlowDAO()).when(accountBookFlowMapper).queryById(Matchers.anyLong());

        Mockito.doReturn(1).when(accountBookFlowMapper).queryCountByWriteOffId(Matchers.anyInt(),
                Matchers.anyString(), Matchers.anyString());


        List<Long> listIds = Arrays.asList(100L);
        Mockito.doReturn(listIds).when(accountBookFlowMapper).pageQueryIdsByWriteOffId(Matchers.anyInt(),
                Matchers.anyString(), Matchers.anyString(), Matchers.anyInt(), Matchers.anyInt());

        Mockito.doReturn(1).when(accountBookFlowMapper).updateWriteOffToFinish(Matchers.anyLong(),
                Matchers.anyInt());

        Mockito.doReturn(5).when(accountBookFlowMapper).batchUpdateWriteOffToFinish(Matchers.anyListOf(Long.class));

        ResultDTO<VoidEntity> resultDTO = accountManager.doWriteOff(defaultBookFlowId);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.STORE_DB_FAILED.getCode());
    }

    @Test(description = "success")
    public void test6() {
        Mockito.doReturn(buildAccountBookFlowDAO()).when(accountBookFlowMapper).queryById(Matchers.anyLong());

        Mockito.doReturn(1).when(accountBookFlowMapper).queryCountByWriteOffId(Matchers.anyInt(),
                Matchers.anyString(), Matchers.anyString());


        List<Long> listIds = Arrays.asList(100L);
        Mockito.doReturn(listIds).when(accountBookFlowMapper).pageQueryIdsByWriteOffId(Matchers.anyInt(),
                Matchers.anyString(), Matchers.anyString(), Matchers.anyInt(), Matchers.anyInt());

        Mockito.doReturn(1).when(accountBookFlowMapper).updateWriteOffToFinish(Matchers.anyLong(),
                Matchers.anyInt());

        Mockito.doReturn(1).when(accountBookFlowMapper).batchUpdateWriteOffToFinish(Matchers.anyListOf(Long.class));

        ResultDTO<VoidEntity> resultDTO = accountManager.doWriteOff(defaultBookFlowId);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
    }


}
