package com.pajk.plutus.test.it;

import com.ninja_squad.dbsetup.destination.Destination;
import com.ninja_squad.dbsetup.destination.DriverManagerDestination;

/**
 * Created by fuyongda on 2017/12/11.
 * Modified by fuyongda on 2017/12/11.
 */
public class Database {

    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // mcfinance
    public static final String MCFINANCE_URL = "jdbc:mysql://devdb-m1.db.pajkdc.com/mcfinance";
    public static final String MCFINANCE_USER = "mcfinance";
    public static final String MCFINANCE_PASSWORD = "mcfinance";

    public static final Destination MCFINANCE =
            new DriverManagerDestination(MCFINANCE_URL, MCFINANCE_USER, MCFINANCE_PASSWORD);

}
