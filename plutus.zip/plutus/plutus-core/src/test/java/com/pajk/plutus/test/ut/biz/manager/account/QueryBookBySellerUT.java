package com.pajk.plutus.test.ut.biz.manager.account;

import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.client.model.enums.account.BookType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by  guguangming on 2018/01/03
 **/
public class QueryBookBySellerUT extends BaseAccountManagerUT {
    @Test(description = "没有查到结果")
    public void test1() {
        Mockito.doReturn(null).when(accountBookMapper).queryBySeller(Matchers.anyLong());
        ResultDTO<AccountBookDO> resultDTO = accountManager.queryBookBySeller(defaultSellerId, BookType.DEPOSIT);
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.BOOK_NOT_EXISTS.getCode());
    }

    @Test(description = "没有查到结果--->bookype 没有匹配到")
    public void test2() {
        List<AccountBookDAO> list = new LinkedList<>();
        AccountBookDAO bookDAO = buildAccountBookDAO();
        bookDAO.setBookType(BookType.ANNUAL_FEE.getCode());
        list.add(bookDAO);
        Mockito.doReturn(list).when(accountBookMapper).queryBySeller(Matchers.anyLong());
        ResultDTO<AccountBookDO> resultDTO = accountManager.queryBookBySeller(defaultSellerId, BookType.DEPOSIT);
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.BOOK_NOT_EXISTS.getCode());
    }


    @Test(description = "查询到结果")
    public void test3() {
        List<AccountBookDAO> list = new LinkedList<>();
        AccountBookDAO bookDAO = buildAccountBookDAO();
        list.add(bookDAO);
        Mockito.doReturn(list).when(accountBookMapper).queryBySeller(Matchers.anyLong());
        ResultDTO<AccountBookDO> resultDTO = accountManager.queryBookBySeller(defaultSellerId, BookType.DEPOSIT);
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());

        AccountBookDO bookDO = resultDTO.getModel();
        assertThat(bookDO.getAccountId()).isEqualTo(bookDAO.getAccountId());
        assertThat(bookDO.getBalanceAmt()).isEqualTo(bookDAO.getBalanceAmt());
        assertThat(bookDO.getActualContractAmt()).isEqualTo(bookDAO.getActualContractAmt());
    }


}
