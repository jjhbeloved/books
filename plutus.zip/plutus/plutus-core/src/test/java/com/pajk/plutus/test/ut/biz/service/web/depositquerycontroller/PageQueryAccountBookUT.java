package com.pajk.plutus.test.ut.biz.service.web.depositquerycontroller;

import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.manager.impl.AccountManagerImpl;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.param.restapi.PageQueryAccountBookParam;
import com.pajk.plutus.biz.model.query.account.BookPageQuery;
import com.pajk.plutus.biz.model.result.dto.account.AccountBookDTO;
import com.pajk.plutus.biz.service.web.DepositQueryController;
import com.pajk.plutus.client.model.enums.account.BookStatus;
import com.pajk.plutus.client.model.enums.account.BookType;
import com.pajk.plutus.client.model.enums.seller.SellerServiceType;
import com.pajk.plutus.client.model.enums.seller.SellerStatus;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 17/12/28.
 * Modify by fanhuafeng on 17/12/28
 */
public class PageQueryAccountBookUT extends BaseWebServiceUT {

    @InjectMocks
    private DepositQueryController depositQueryController = new DepositQueryController();

    @InjectMocks
    @Spy
    private AccountManager accountManager = new AccountManagerImpl();

    @Mock
    private AccountQueryRepository accountQueryRepository;


    private static final long defaultAccountId = 1;
    private static final long defaultBookId = 2;


    private PageQueryAccountBookParam buildQueryParam(){
        PageQueryAccountBookParam bookParam = new PageQueryAccountBookParam();
        bookParam.setStatus(BookStatus.VALID.getCode());
        bookParam.setBalanceAmtStart(10000L);
        bookParam.setBalanceAmtEnd(200000L);

        return bookParam;
    }


    @Test(description = "check page fail")
    public void test01(){
        PageQueryAccountBookParam bookParam =  buildQueryParam();
        bookParam.setPageNo(100);
        bookParam.setPageSize(1000);

        PageResultDTO<AccountBookDTO>  result = depositQueryController.pageQueryAccountBook(bookParam);
        assertThat(result.getResultCode()).isEqualTo(ErrorCode.PAGE_SIZE_OUT_OF_MAX_VALUE.getCode());

    }

    @Test(description = "getBalanceAmtStart 不合法")
    public void test02(){
        PageQueryAccountBookParam bookParam =  buildQueryParam();
        bookParam.setBalanceAmtStart(-100L);


        PageResultDTO<AccountBookDTO>  result = depositQueryController.pageQueryAccountBook(bookParam);
        assertThat(result.getResultCode()).isEqualTo(ErrorCode.PARAM_ERROR.getCode());

    }

    @Test(description = "getBalanceAmtEnd 不合法")
    public void test03(){
        PageQueryAccountBookParam bookParam =  buildQueryParam();
        bookParam.setBalanceAmtEnd(-100L);


        PageResultDTO<AccountBookDTO>  result = depositQueryController.pageQueryAccountBook(bookParam);
        assertThat(result.getResultCode()).isEqualTo(ErrorCode.PARAM_ERROR.getCode());

    }

    @Test(description = "bookStatus 不合法")
    public void test04(){
        PageQueryAccountBookParam bookParam =  buildQueryParam();
        bookParam.setStatus(BookStatus.UNKNOWN.getCode());


        PageResultDTO<AccountBookDTO>  result = depositQueryController.pageQueryAccountBook(bookParam);
        assertThat(result.getResultCode()).isEqualTo(ErrorCode.PARAM_ERROR.getCode());

    }


    @Test(description = "查询数量为0")
    public void test05(){
        PageQueryAccountBookParam bookParam =  buildQueryParam();
        bookParam.setStatus(BookStatus.VALID.getCode());
        mockitoPermissionOk();

        Mockito.doReturn(0).when(accountQueryRepository).queryBookCount(Matchers.any(BookPageQuery.class));

        PageResultDTO<AccountBookDTO>  result = depositQueryController.pageQueryAccountBook(bookParam);
        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getTotalCount()).isZero();
        assertThat(result.getModel().size()).isZero();

    }

    @Test(description = "查询数量为11, 分页无数据")
    public void test06(){
        PageQueryAccountBookParam bookParam =  buildQueryParam();
        bookParam.setStatus(BookStatus.VALID.getCode());
        mockitoPermissionOk();

        Mockito.doReturn(11).when(accountQueryRepository).queryBookCount(Matchers.any(BookPageQuery.class));

        Optional<List<AccountBookDO>> optional = Optional.empty();
        Mockito.doReturn(optional).when(accountQueryRepository).pageQueryBook(Matchers.any(BookPageQuery.class));


        PageResultDTO<AccountBookDTO>  result = depositQueryController.pageQueryAccountBook(bookParam);
        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getTotalCount()).isEqualTo(11);
        assertThat(result.getModel().size()).isZero();

    }


    @Test(description = "查询数量为11, 分页无数据")
    public void test06_1(){
        PageQueryAccountBookParam bookParam =  buildQueryParam();
        bookParam.setStatus(BookStatus.VALID.getCode());
        bookParam.setBalanceAmtEnd(null);
        bookParam.setBalanceAmtStart(null);
        bookParam.setStatus(-1);
        mockitoPermissionOk();

        Mockito.doReturn(11).when(accountQueryRepository).queryBookCount(Matchers.any(BookPageQuery.class));

        Optional<List<AccountBookDO>> optional = Optional.empty();
        Mockito.doReturn(optional).when(accountQueryRepository).pageQueryBook(Matchers.any(BookPageQuery.class));


        PageResultDTO<AccountBookDTO>  result = depositQueryController.pageQueryAccountBook(bookParam);
        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getTotalCount()).isEqualTo(11);
        assertThat(result.getModel().size()).isZero();

    }


    @Test(description = "查询数量为11, 有1条数据, seller查询不到")
    public void test07(){
        PageQueryAccountBookParam bookParam =  buildQueryParam();
        bookParam.setStatus(BookStatus.VALID.getCode());
        mockitoPermissionOk();

        Mockito.doReturn(11).when(accountQueryRepository).queryBookCount(Matchers.any(BookPageQuery.class));
        List<AccountBookDO> books = new LinkedList<>();
        AccountBookDO book = new AccountBookDO();
        book.setSellerId(defaultSellerId);
        book.setStatus(BookStatus.VALID);
        book.setBookType(BookType.ANNUAL_FEE);
        book.setGmtModified(new Date());
        book.setGmtModified(new Date());
        book.setActualContractAmt(1000L);
        book.setBalanceAmt(20000L);
        book.setFreezingAmt(1000L);
        book.setAccountId(defaultAccountId);
        book.setId(defaultBookId);
        books.add(book);
        Optional<List<AccountBookDO>> optional = Optional.ofNullable(books);
        Mockito.doReturn(optional).when(accountQueryRepository).pageQueryBook(Matchers.any(BookPageQuery.class));
        KyCallResult<SellerDO> resultSeller = new KyCallResult<>();
        resultSeller.setSuccess(false);

        Mockito.doReturn(resultSeller).when(sellerService).getSellerById(defaultSellerId);


        PageResultDTO<AccountBookDTO>  result = depositQueryController.pageQueryAccountBook(bookParam);
        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getTotalCount()).isEqualTo(11);
        assertThat(result.getModel().size()).isEqualTo(1);
        AccountBookDTO bookResult = result.getModel().get(0);

        assertThat(bookResult.getSellerId()).isEqualTo(defaultSellerId);
        assertThat(bookResult.getBookStatusCode()).isEqualTo(BookStatus.VALID.getCode());
        assertThat(bookResult.getBalanceAmt()).isEqualTo(book.getBalanceAmt());
        assertThat(bookResult.getContractAmt()).isEqualTo(book.getContractAmt());
        assertThat(bookResult.getAccountBookId()).isEqualTo(defaultBookId);
        assertThat(bookResult.getSellerName()).isEqualTo(null);
        assertThat(bookResult.getSellerType()).isEqualTo(null);

    }


    @Test(description = "查询数量为11, 有1条数据, 有seller信息")
    public void test08(){
        PageQueryAccountBookParam bookParam =  buildQueryParam();
        bookParam.setStatus(BookStatus.VALID.getCode());
        mockitoPermissionOk();

        Mockito.doReturn(11).when(accountQueryRepository).queryBookCount(Matchers.any(BookPageQuery.class));
        List<AccountBookDO> books = new LinkedList<>();
        AccountBookDO book = new AccountBookDO();
        book.setSellerId(defaultSellerId);
        book.setStatus(BookStatus.VALID);
        book.setBookType(BookType.ANNUAL_FEE);
        book.setGmtModified(new Date());
        book.setGmtModified(new Date());
        book.setActualContractAmt(1000L);
        book.setBalanceAmt(20000L);
        book.setFreezingAmt(1000L);
        book.setAccountId(defaultAccountId);
        book.setId(defaultBookId);
        books.add(book);
        Optional<List<AccountBookDO>> optional = Optional.ofNullable(books);
        Mockito.doReturn(optional).when(accountQueryRepository).pageQueryBook(Matchers.any(BookPageQuery.class));
        KyCallResult<SellerDO> resultSeller = new KyCallResult<>();
        resultSeller.setSuccess(true);
        SellerDO seller = new SellerDO();
        seller.setName("test");
        seller.setStatus(SellerStatus.NORMAL.getCode());
        seller.setServiceType(SellerServiceType.B2C.getCode());
        resultSeller.setModel(seller);

        Mockito.doReturn(resultSeller).when(sellerService).getSellerById(defaultSellerId);


        PageResultDTO<AccountBookDTO>  result = depositQueryController.pageQueryAccountBook(bookParam);
        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getTotalCount()).isEqualTo(11);
        assertThat(result.getModel().size()).isEqualTo(1);
        AccountBookDTO bookResult = result.getModel().get(0);

        assertThat(bookResult.getSellerId()).isEqualTo(defaultSellerId);
        assertThat(bookResult.getBookStatusCode()).isEqualTo(BookStatus.VALID.getCode());
        assertThat(bookResult.getBalanceAmt()).isEqualTo(book.getBalanceAmt());
        assertThat(bookResult.getContractAmt()).isEqualTo(book.getContractAmt());
        assertThat(bookResult.getAccountBookId()).isEqualTo(defaultBookId);
        assertThat(bookResult.getSellerName()).isEqualTo("test");
        assertThat(bookResult.getSellerType()).isEqualTo(SellerServiceType.B2C.getDesc());
        assertThat(bookResult.getSellerStatus()).isEqualTo(SellerStatus.NORMAL.getDesc());

    }
}
