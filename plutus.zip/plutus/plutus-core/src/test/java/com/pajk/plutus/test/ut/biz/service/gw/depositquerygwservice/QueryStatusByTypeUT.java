package com.pajk.plutus.test.ut.biz.service.gw.depositquerygwservice;

import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.service.gw.DepositQueryGWServiceImpl;
import com.pajk.plutus.client.api.gw.DepositQueryGWService;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.process.BatchNodeCatKeyGW;
import com.pajk.plutus.test.ut.BaseGwServiceUT;
import org.apache.commons.lang3.math.NumberUtils;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by  guguangming on 2018/01/04
 **/
public class QueryStatusByTypeUT extends BaseGwServiceUT {
    @InjectMocks
    private DepositQueryGWService depositQueryGWService = new DepositQueryGWServiceImpl();
    private String key3 = "审核中";
    private String nodeKey = "sellerConfirm";
    private String role = "SELLER_OP";

    @Test(description = "为unknown")
    public void test1() {
        mockitoPermissionOk();
        BatchNodeCatKeyGW nodeCatKey = depositQueryGWService.queryStatusByType(defaultAppId, defaultUserId, defaultSellerId, 7878);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(nodeCatKey).isNull();
    }


    @Test(description = "appResource为null  返回EXCEPTION")
    public void test2() {
        mockitoPermissionOk();

//        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
//        kyCallResult.setModel(appResourceDO);
        Mockito.doReturn(null).when(appResourceService).getAppResource(Matchers.anyString(),
                Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString());

        BatchNodeCatKeyGW nodeCatKey = depositQueryGWService.queryStatusByType(defaultAppId, defaultUserId, defaultSellerId, VoucherType.PAYMENT.getCode());
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_EXCEPTION);
        assertThat(nodeCatKey).isNull();
    }


    @Test(description = "val1为null  返回EXCEPTION")
    public void test3() {
        mockitoPermissionOk();

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        AppResourceDO appResourceDO = buildAppResourceDO();
        appResourceDO.val1 = "";
        kyCallResult.setModel(appResourceDO);
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(),
                Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString());

        BatchNodeCatKeyGW nodeCatKey = depositQueryGWService.queryStatusByType(defaultAppId, defaultUserId, defaultSellerId, VoucherType.PAYMENT.getCode());
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_EXCEPTION);
        assertThat(nodeCatKey).isNull();
    }

    @Test(description = "val1为null  返回EXCEPTION")
    public void test4() {
        mockitoPermissionOk();

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        AppResourceDO appResourceDO = buildAppResourceDO();
        kyCallResult.setModel(appResourceDO);
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(),
                Matchers.anyString(), Matchers.anyString(), Matchers.anyString(), Matchers.anyString());

        BatchNodeCatKeyGW nodeCatKey = depositQueryGWService.queryStatusByType(defaultAppId, defaultUserId, defaultSellerId, VoucherType.PAYMENT.getCode());
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode._C_SUCCESS);
        assertThat(nodeCatKey.nodeKeys.size()).isNotZero();
        // 其他数据验证
    }


    private AppResourceDO buildAppResourceDO() {
        AppResourceDO aDo = new AppResourceDO();
        aDo.key3 = key3;
        aDo.keyName = nodeKey;
        aDo.val = "{ \"sellerConfirm\": \"提示语句\" } ";
        aDo.val2 = role;
        aDo.val1 = "status1:value1;status2:value12";

        aDo.val3 = "审核成功";
        return aDo;
    }
}
