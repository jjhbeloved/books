package com.pajk.plutus.test.it.biz.manager.impl.accountmanager;

import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.result.KyBatchResult;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.kylin.api.service.AppResourceService;
import com.pajk.plutus.biz.common.util.TimeUtils;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.model.account.AccountBookFlowDO;
import com.pajk.plutus.biz.model.query.account.BookFlowPageQuery;
import com.pajk.plutus.test.it.BaseIT;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 17/12/19.
 * Modify by fanhuafeng on 17/12/19
 */
public class PageQueryBookFlowIT extends BaseIT {


    @Autowired
    private AccountManager accountManager;


    @Autowired
    protected AppResourceService appResourceService;

    @Test
    public void testSuccess(){

        BookFlowPageQuery query = new BookFlowPageQuery();
        query.setSellerId(12026100507L);
        query.setBookId(1L);
        Date start = TimeUtils.parse("2017-11-10 01:01:01");
        Date end = TimeUtils.parse("2017-12-20 01:01:01");
        query.setStatementStart(start);
        query.setStatementEnd(end);
        query.setPageNo(1);
        query.setPageSize(10);

        PageResultDTO<AccountBookFlowDO> result = accountManager.pageQueryBookFlow(query);
        assertThat(result.isSuccess()).isTrue();
        assertThat(result.getTotalCount()).isEqualTo(0);
        assertThat(result.getModel()).isNotNull();


    }


    @Test
    public void test(){
        KyBatchResult<AppResourceDO> kyBatchResult = appResourceService.getAppResource(
                "taskcenter", "all", "DepositViolationCommon", "procDef");

        KyCallResult<AppResourceDO> kyCallResult = appResourceService.getAppResource(
                "taskcenter", "all", "DepositViolationCommon", "procDef", "sellerDeal");

        assertThat(kyCallResult.isSuccess()).isTrue();
    }

}
