package com.pajk.plutus.test.ut.biz.service.gw.depositquerygwservice;

import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherDeliveryMapper;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherMapper;
import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.model.voucher.VoucherDeliveryDO;
import com.pajk.plutus.biz.service.gw.DepositQueryGWServiceImpl;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.voucher.PageVoucherGW;
import com.pajk.plutus.client.model.result.gw.voucher.VoucherGW;
import com.pajk.plutus.test.ut.BaseGwServiceUT;
import com.pajk.taskcenter.client.model.dto.GetNodeInfoResultDTO;
import com.pajk.taskcenter.client.model.dto.NodeDTO;
import com.pajk.taskcenter.client.model.dto.TaskInstDTO;
import com.pajk.taskcenter.client.model.dto.TransitionDTO;
import org.apache.commons.lang3.math.NumberUtils;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.*;

import static com.pajk.plutus.biz.model.enums.VoucherExtPropsKey.EVIDENCE_FLOW;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.doReturn;

/**
 * Created by  guguangming on 2017/12/29
 **/
public class QuerySellerOptVoucherUT extends BaseGwServiceUT {
    @InjectMocks
    private DepositQueryGWServiceImpl depositQueryGWService = new DepositQueryGWServiceImpl();

    @Mock
    protected VoucherMapper voucherMapper;

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @Mock
    protected VoucherQueryRepository voucherQueryRepository;

    @Mock
    protected VoucherDeliveryMapper voucherDeliveryMapper;

    private String fileToken = "12321321";

    private String key3 = "审核中";
    private String nodeKey = "sellerConfirm";
    private String role = "SELLER_OP";
    private String evidenceFlow = "91122222";
    private String procInstId = "22198321";
    private String transitionKey = nodeKey;
    private String transitionName = key3;


    @Test(description = "voucherId错误")
    public void test00() {
        mockitoPermissionOk();

        Mockito.doReturn(Optional.empty()).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, "23423423asfd");

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(voucher).isNull();
    }

    @Test(description = "查询失败->voucher 不存在")
    public void test_001() {
        mockitoPermissionOk();
        Mockito.doReturn(Optional.empty()).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_VOUCHER_NOT_EXISTS);
        assertThat(voucher).isNull();
    }

    @Test(description = "查询失败->VOUCHER_DELIVERY_NOT_EXISTS ")
    public void test_002() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.empty()).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);
        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_VOUCHER_DELIVERY_NOT_EXISTS);
        assertThat(voucher).isNull();
    }

    @Test(description = "非PAYMENT  nodeKeyName 查询失败 ")
    public void test_003() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);
        mockitoCurrentUserRoleOK(role);
        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(false);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
        List<AppResourceDO> doList = new LinkedList<>();

        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isNull();
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);
    }

    @Test(description = "非PAYMENT 构造附件TFS地址和文件名称 buildFileUrl分支覆盖 fileName / fileKey 为空 ")
    public void test_004() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        voucherDO.setCreateFile("[{\"fileKey\":\"T1iNxTBTxT1RCvBVdK.jpg\"}]");
        voucherDO.setEvidenceFile("[{\"fileName\":\"timg.jpg\"}]");

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);
        mockitoCurrentUserRoleOK(role);
        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        mockAppResourceDO(buildAppResourceDO());

        List<AppResourceDO> doList = new LinkedList<>();

        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);
        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        mockNodeInfoList(buildListGetNodeInfo(), true);

        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isNotNull();
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);
        //验证
        assertThat(voucher.createFiles.get(0).fileKey).isNull();
        assertThat(voucher.createFiles.get(0).fileName).isNull();
        assertThat(voucher.evidenceFiles.get(0).fileName).isNotNull();
        assertThat(voucher.evidenceFiles.get(0).fileKey).isNull();

    }

    @Test(description = "非PAYMENT fileTokenService.requestFileToken  查询失败  即fileToken 为空 ")
    public void test_005() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);
        mockitoCurrentUserRoleOK(role);
        // fileTokenService.requestFileToken 查询失败  即为空格
        mockFileToken("");
        mockFilegwDomain("filegwDomain");

        mockAppResourceDO(buildAppResourceDO());

        List<AppResourceDO> doList = new LinkedList<>();
        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);
        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        mockNodeInfoList(buildListGetNodeInfo(), true);

        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isNotNull();
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);
        //验证
        assertThat(voucher.createFiles.get(0).fileKey).isNull();
        assertThat(voucher.createFiles.get(0).fileName).isNotNull();
        assertThat(voucher.evidenceFiles.get(0).fileName).isNotNull();
        assertThat(voucher.evidenceFiles.get(0).fileKey).isNull();

    }

    @Test(description = "非PAYMENT 流程记录查询成功，批量读取文案中心失败  -> " +
            "appResourceService.getAppResource(system, channel, type, source);则审批记录role、nodeKeyDesc为空 ")
    public void test_006() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);
        mockitoCurrentUserRoleOK(role);
        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        mockAppResourceDO(buildAppResourceDO());
        // 处理为失败
        mockBatchAppResourceDO(null, false);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        mockNodeInfoList(buildListGetNodeInfo(), true);

        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isNotNull();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);
        assertThat(voucher.createFiles.get(0).fileKey).isNotNull();
        assertThat(voucher.createFiles.get(0).fileName).isNotNull();
        assertThat(voucher.evidenceFiles.get(0).fileName).isNotNull();
        assertThat(voucher.evidenceFiles.get(0).fileKey).isNotNull();

        // 验证
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.auditFlows.get(0).role).isNull();
        assertThat(voucher.auditFlows.get(0).nodeKeyDesc).isNull();

    }

    @Test(description = "非PAYMENT 类型 操作按钮查询 查询角色失败 apiName 为空")
    public void test_007() {

        baseQueryMock();

        KyCallResult<String> result = new KyCallResult<>();
        result.setSuccess(false);
        result.setModel(role);
        doReturn(result).when(permissionService).getCurRole(anyLong(), anyLong());

        mockNodeInfoList(buildListGetNodeInfo(), true);
        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        assertThat(voucher.apiName).isNull();
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }


    @Test(description = "非PAYMENT 类型 操作按钮查询 查询角色成功 角色为空")
    public void test_008() {

        baseQueryMock();

        mockitoCurrentUserRoleOK("");

        mockNodeInfoList(buildListGetNodeInfo(), true);
        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        assertThat(voucher.apiName).isNull();
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }

    @Test(description = "非PAYMENT 类型 操作按钮查询 查询角色成功 角色不匹配")
    public void test_009() {

        baseQueryMock();

        mockitoCurrentUserRoleOK("111111");

        mockNodeInfoList(buildListGetNodeInfo(), true);
        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        assertThat(voucher.apiName).isNull();
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }

    @Test(description = "非PAYMENT 类型 操作按钮查询 查询角色成功 分支NodeDto为空 ")
    public void test_010() {

        baseQueryMock();

        mockitoCurrentUserRoleOK(role);
        //NodeDto为空
        List<GetNodeInfoResultDTO> resultDTOS = new LinkedList<>();
        mockNodeInfoList(resultDTOS, true);
        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        assertThat(voucher.apiName).isNull();
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }

    @Test(description = "非PAYMENT 类型 操作按钮查询 查询角色成功 flowService.getNodeInfoList 查询 失败")
    public void test_011() {

        baseQueryMock();

        mockitoCurrentUserRoleOK(role);
        //NodeDto为空
        List<GetNodeInfoResultDTO> resultDTOS = new LinkedList<>();
        mockNodeInfoList(resultDTOS, false);
        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        assertThat(voucher.apiName).isNull();
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }

    @Test(description = "非PAYMENT 类型 操作按钮查询 查询成功数据验证")
    public void test_012() {

        baseQueryMock();

        mockitoCurrentUserRoleOK(role);
        //NodeDto为空
        List<GetNodeInfoResultDTO> resultDTOS = new LinkedList<>();
        mockNodeInfoList(buildListGetNodeInfo(), true);
        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);


        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.flowButtons.get(0).transitionKey).isEqualTo(transitionKey);
        assertThat(voucher.flowButtons.get(0).transitionName).isEqualTo(transitionName);

        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }


    @Test(description = "非PAYMENT 类型 流程记录查询失败 ")
    public void test_013() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        mockitoCurrentUserRoleOK(role);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
        List<AppResourceDO> doList = new LinkedList<>();

        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, false);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, false);

        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        assertThat(voucher.auditFlows).isNull();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }


    @Test(description = "PAYMENT 类型 查询成功银行流水为空")
    public void test_014() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherType(VoucherType.PAYMENT);
        voucherDO.setVoucherSubType(VoucherSubType.ADD_DEPOSIT);
        //流水为空
        voucherDO.setExtProps(new HashMap<>());
        mockitoCurrentUserRoleOK(role);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());

        List<AppResourceDO> doList = new LinkedList<>();
        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.paymentProp.evidenceFlow).isNull();
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }

    @Test(description = "PAYMENT 类型 审批记录查询失败 ")
    public void test_015() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherType(VoucherType.PAYMENT);
        voucherDO.setVoucherSubType(VoucherSubType.PAY_IN_BACK_DEPOSIT);
        mockitoCurrentUserRoleOK(role);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());

        List<AppResourceDO> doList = new LinkedList<>();
        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, false);

        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        //为空
        assertThat(voucher.auditFlows).isNull();
        assertThat(voucher.paymentProp.evidenceFlow).isEqualTo(evidenceFlow);
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }

    @Test(description = "PAYMENT 查询成功 ")
    public void test13() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherType(VoucherType.PAYMENT);
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);
        mockitoCurrentUserRoleOK(role);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());

        List<AppResourceDO> doList = new LinkedList<>();
        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);

        VoucherGW voucher = depositQueryGWService.querySellerOptVoucher(defaultDomainId, defaultAppId, defaultUserId,
                defaultSellerId, defaultVoucherId);

        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(0);
        assertThat(voucher.nodeCatKeyName).isEqualTo(key3);
        assertThat(voucher.auditFlows.size()).isNotZero();
        assertThat(voucher.nodeKey).isEqualTo(nodeKey);
        assertThat(voucher.paymentProp.evidenceFlow).isEqualTo(evidenceFlow);
        assertThat(voucher.voucherId).isEqualTo(defaultVoucherId);

    }


    private void baseQueryMock() {
        mockitoPermissionOk();
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId, defaultVoucherId);
        Mockito.doReturn(Optional.of(buildVoucherDeliveryDO())).when(voucherQueryRepository).queryVoucherDeliveryByVoucherId(defaultVoucherId);

        mockFileToken("12");
        mockFilegwDomain("filegwDomain");

        KyCallResult<AppResourceDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(true);
        kyCallResult.setModel(buildAppResourceDO());
        Mockito.doReturn(kyCallResult).when(appResourceService).getAppResource(Matchers.anyString(), Matchers.anyString()
                , Matchers.anyString(), Matchers.anyString(), Matchers.anyString());
        List<AppResourceDO> doList = new LinkedList<>();

        doList.add(buildAppResourceDO());
        mockBatchAppResourceDO(doList, true);

        List<TaskInstDTO> taskInstDTOS = new LinkedList<>();
        taskInstDTOS.add(buildTaskInstDTO());
        mockGetFinishedActInstList(taskInstDTOS, true);
    }

    //PAYMENT 判断  查询流程记录失败 流程记录ApprovalVote 失败  解析文件失败
    private VoucherDO buildVoucherDO() {
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(defaultVoucherId);
        voucherDO.setIsDeleted(0);
        voucherDO.setExpectAmt(100L);
        voucherDO.setSellerId(defaultSellerId);
        voucherDO.setActualAmt(100L);
        voucherDO.setGmtCreated(new Date());
        voucherDO.setRole(role);
        voucherDO.setVoucherType(VoucherType.VIOLATION);
        voucherDO.setNodeKey(nodeKey);
        voucherDO.setProcInstId(procInstId);
        voucherDO.setVoucherSubType(VoucherSubType.FAKE_VIOLATION);

        voucherDO.setCreateFile("[{\"fileKey\":\"T1iNxTBTxT1RCvBVdK.jpg\",\"fileName\":\"timg.jpg\"}]");
        voucherDO.setEvidenceFile("[{\"fileKey\":\"T1iNxTBTxT1RCvBVdK.jpg\",\"fileName\":\"timg.jpg\"}]");
        Map<String, String> ext = new HashMap<>();
        ext.put(EVIDENCE_FLOW.getCode(), evidenceFlow);
        voucherDO.setExtProps(ext);
        return voucherDO;
    }

    private VoucherDeliveryDO buildVoucherDeliveryDO() {
        VoucherDeliveryDO deliveryDO = new VoucherDeliveryDO();
        deliveryDO.setAmount(1);
        deliveryDO.setCompanyId(10001L);
        deliveryDO.setCompanyName("顺丰快递");
        deliveryDO.setCreateTime(new Date());
        deliveryDO.setAmount(1L);
        deliveryDO.setDeliveryTime(new Date());
        deliveryDO.setTrackingNumber("97661270004");
        return deliveryDO;
    }

    private AppResourceDO buildAppResourceDO() {
        AppResourceDO aDo = new AppResourceDO();
        aDo.key3 = key3;
        aDo.keyName = nodeKey;
        aDo.val = "{ \"sellerConfirm\": \"提示语句\" } ";
        aDo.val2 = role;
        aDo.val3 = "审核成功";
        return aDo;
    }

    private TaskInstDTO buildTaskInstDTO() {
        TaskInstDTO instDTO = new TaskInstDTO();
        instDTO.setNodeKey("sellerAgree");
        instDTO.setApprovalId("111");
        instDTO.setApprovalVote("1111");
        return instDTO;
    }

    private List<GetNodeInfoResultDTO> buildListGetNodeInfo() {
        List<GetNodeInfoResultDTO> resultDTOS = new LinkedList<>();
        GetNodeInfoResultDTO dto = new GetNodeInfoResultDTO();
        dto.setNodeKey(nodeKey);
        dto.setSuccess(true);
        dto.setProcInstId(NumberUtils.toLong(procInstId));

        NodeDTO nodeDTO = new NodeDTO();
        nodeDTO.setPath("");

        List<TransitionDTO> transitionDTOList = new LinkedList<>();
        TransitionDTO transitionDTO = new TransitionDTO();
        transitionDTO.setTransitionKey(transitionKey);
        transitionDTO.setTransitionName(transitionName);
        transitionDTOList.add(transitionDTO);
        nodeDTO.setTransitionDTOList(transitionDTOList);

        dto.setNodeDTO(nodeDTO);
        resultDTOS.add(dto);
        return resultDTOS;
    }
}
