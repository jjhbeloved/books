package com.pajk.plutus.test.ut.biz.common.util.commonutil;

import com.pajk.plutus.biz.common.util.CommonUtil;
import org.testng.annotations.Test;

import java.lang.reflect.Constructor;

/**
 * Created by lizhijun on 2018/1/4.
 */
public class PrivateUT {
    @Test
    public void test(){
        try {
            Class clazz = CommonUtil.class;
            Constructor cons = clazz.getDeclaredConstructor(null);
            cons.setAccessible(true);

            cons.newInstance(null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
