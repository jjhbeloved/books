package com.pajk.plutus.test.ut.biz.service.web.depositcontroller;

import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.dao.repo.VoucherRepository;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.param.restapi.AuditPunishParam;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.service.web.DepositController;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.testng.annotations.Test;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by lizhijun on 2018/1/4.
 */
public class AuditPunishUT extends BaseWebServiceUT {
    @InjectMocks
    private DepositController depositController = new DepositController();

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @Mock
    private AccountQueryRepository accountQueryRepository;

    @Mock
    private VoucherRepository voucherRepository;

    @Mock
    private VoucherQueryRepository voucherQueryRepository;

    @Mock
    private ControlCache controlCache;

    private static final String voucherId = "100";
    private static final long sellerId = 1000000101L;
    private static final String nodeKey = "nodeKey";
    private static final String nodeCatKey = "nodeCatKey";
    private static final String transitionKey = "transitionKey";
    private static final String role = "role";
    private static final String path = "deposit/auditPunish";

    @Test(description = "参数不正确:sellerId不对")
    public void test1(){
        AuditPunishParam param = buildParam();
        param.setSellerId(100001010L);
        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);

        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "参数不正确:sellerId不对")
    public void test2(){
        AuditPunishParam param = buildParam();
        param.setSellerId(100001010L);
        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);

        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "参数不正确:sellerId不对,单据id不对")
    public void test3(){
        AuditPunishParam param = buildParam();
        param.setSellerId(100001010L);
        param.setVoucherId("k1");
        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);

        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "参数不正确:sellerId对,单据id不对")
    public void test4(){
        AuditPunishParam param = buildParam();
        param.setVoucherId("k1");
        param.setRemark("");
        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);

        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "参数不正确:remark长度太长")
    public void test5(){
        AuditPunishParam param = buildParam();
        StringBuilder sb = new StringBuilder();
        for (int i=0;i<100;i++){
            sb.append("remark");
        }
        param.setRemark(sb.toString());
        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);

        assertThat(ErrorCode.PARAM_ERROR.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "单据不存在")
    public void test6(){
        AuditPunishParam param = buildParam();
        mockitoPermissionOk();
        Mockito.doReturn(Optional.empty()).when(voucherQueryRepository).queryVoucherById(param.getSellerId(),param.getVoucherId());
        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);


        assertThat(ErrorCode.VOUCHER_NOT_EXISTS.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "状态不匹配")
    public void test7(){

        AuditPunishParam param = buildParam();
        mockitoPermissionOk();
        mockRole(role,false);
        mockNodeList(nodeKey,false,false,false,false,path,transitionKey,transitionKey);
        VoucherDO voucherDO = buildVoucher();
        voucherDO.setNodeKey(nodeKey+"A");
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(param.getSellerId(),param.getVoucherId());
        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);

        assertThat(ErrorCode.STATUS_NOT_MATCH.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "没有权限:角色不对")
    public void test9(){
        AuditPunishParam param = buildParam();
        mockRole(role+"A",false);
        mockitoPermissionOk();
        Mockito.doReturn(Optional.of(buildVoucher())).when(voucherQueryRepository).queryVoucherById(param.getSellerId(),param.getVoucherId());
        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);

        assertThat(ErrorCode.NO_PERMISSION_TO_OPT.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "账本不存在")
    public void test10(){
        AuditPunishParam param = buildParam();
        mockRole(role,false);
        mockitoPermissionOk();
        mockNodeList(nodeKey,false,false,false,false,path,transitionKey,transitionKey);
        Mockito.doReturn(Optional.of(buildVoucher())).when(voucherQueryRepository).queryVoucherById(param.getSellerId(),param.getVoucherId());
        Mockito.doReturn(Optional.empty()).when(accountQueryRepository).queryBookBySeller(param.getSellerId());
        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);

        assertThat(ErrorCode.BOOK_NOT_EXISTS.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "审核异常")
    public void test11(){
        AuditPunishParam param = buildParam();
        mockRole(role,false);
        mockitoPermissionOk();
        mockNodeList(nodeKey,false,false,false,false,path,transitionKey,transitionKey);
        mockCompeteTask(false,true,false,false,false,false,false);
        Mockito.doReturn(Optional.of(buildVoucher())).when(voucherQueryRepository).queryVoucherById(param.getSellerId(),param.getVoucherId());
        mockAccountBook();

        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);

        assertThat(ErrorCode.EXCEPTION.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "审核成功:二级同意")
    public void test12(){
        AuditPunishParam param = buildParam();
        mockRole(role,false);
        mockitoPermissionOk();
        mockNodeList(nodeKey,false,false,false,false,path,transitionKey,transitionKey);
        mockCompeteTask(false,false,false,false,false,false,true);
        Mockito.doReturn(Optional.of(buildVoucher())).when(voucherQueryRepository).queryVoucherById(param.getSellerId(),param.getVoucherId());
        mockAccountBook();
        Mockito.doReturn(transitionKey).when(controlCache).getVoucherPunishSecondAuditPassTransitionKey();


        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);

        assertThat(ErrorCode.SUCCESS.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "审核成功:一级拒绝")
    public void test13(){
        AuditPunishParam param = buildParam();
        mockRole(role,false);
        mockitoPermissionOk();
        mockNodeList(nodeKey,false,false,false,false,path,transitionKey,transitionKey);
        mockCompeteTask(false,false,false,false,false,false,true);
        VoucherDO voucherDO = buildVoucher();
        voucherDO.setExpectAmt(100L);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(param.getSellerId(),param.getVoucherId());
        mockAccountBook();
        Mockito.doReturn(transitionKey+"A").when(controlCache).getVoucherPunishSecondAuditPassTransitionKey();
        Mockito.doReturn(transitionKey).when(controlCache).getVoucherPunishFirstAuditRefuseTransitionKey();
        Mockito.doReturn(transitionKey+"B").when(controlCache).getVoucherPunishSecondAuditRefuseTransitionKey();



        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);

        assertThat(ErrorCode.SUCCESS.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "审核成功:二级拒绝")
    public void test14(){
        AuditPunishParam param = buildParam();
        mockRole(role,false);
        mockitoPermissionOk();
        mockNodeList(nodeKey,false,false,false,false,path,transitionKey,transitionKey);
        mockCompeteTask(false,false,false,false,false,false,true);
        VoucherDO voucherDO = buildVoucher();
        voucherDO.setExpectAmt(100L);
        voucherDO.setExpectPoint(200L);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(param.getSellerId(),param.getVoucherId());
        mockAccountBook();
        Mockito.doReturn(transitionKey+"A").when(controlCache).getVoucherPunishSecondAuditPassTransitionKey();
        Mockito.doReturn(transitionKey+"B").when(controlCache).getVoucherPunishFirstAuditRefuseTransitionKey();
        Mockito.doReturn(transitionKey).when(controlCache).getVoucherPunishSecondAuditRefuseTransitionKey();

        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);

        assertThat(ErrorCode.SUCCESS.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "审核成功:一级同意")
    public void test15(){
        AuditPunishParam param = buildParam();
        mockRole(role,false);
        mockitoPermissionOk();
        mockNodeList(nodeKey,false,false,false,false,path,transitionKey,transitionKey);
        mockCompeteTask(false,false,false,false,false,false,true);
        VoucherDO voucherDO = buildVoucher();

        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(param.getSellerId(),param.getVoucherId());
        mockAccountBook();
        Mockito.doReturn(transitionKey+"D").when(controlCache).getVoucherPunishFirstAuditBackTransitionKey();

        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);

        assertThat(ErrorCode.SUCCESS.eq(resultDTO.getResultCode())).isTrue();
    }

    @Test(description = "审核成功:驳回")
    public void test16(){
        AuditPunishParam param = buildParam();
        mockRole(role,false);
        mockitoPermissionOk();
        mockNodeList(nodeKey,false,false,false,false,path,transitionKey,transitionKey);
        mockCompeteTask(false,false,false,false,false,false,false);
        VoucherDO voucherDO = buildVoucher();
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(param.getSellerId(),param.getVoucherId());
        mockAccountBook();
        Mockito.doReturn(transitionKey).when(controlCache).getVoucherPunishFirstAuditBackTransitionKey();

        ResultDTO<VoidEntity> resultDTO = depositController.auditPunish(param);

        assertThat(ErrorCode.SUCCESS.eq(resultDTO.getResultCode())).isTrue();
    }

    private AuditPunishParam buildParam(){
        AuditPunishParam param = new AuditPunishParam();
        param.setSellerId(sellerId);
        param.setVoucherId(voucherId);
        param.setNodeKey(nodeKey);
        param.setTransitionKey(transitionKey);
        param.setRemark("remark");
        return param;
    }

    private VoucherDO buildVoucher(){
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setVoucherId(voucherId);
        voucherDO.setNodeKey(nodeKey);
        voucherDO.setNodeCatKey(nodeCatKey);
        voucherDO.setRole(role);
        voucherDO.setSellerId(sellerId);
        voucherDO.setVoucherType(VoucherType.VIOLATION);
        voucherDO.setVoucherSubType(VoucherSubType.FALSE_CONDUCT_VIOLATION);
        return voucherDO;
    }

    private void mockAccountBook(){
        List<AccountBookDO> accountBookDOs = new LinkedList<>();

        AccountBookDO accountBookDO = new AccountBookDO();
        accountBookDO.setSellerId(sellerId);
        accountBookDO.setId(1);
        accountBookDOs.add(accountBookDO);
        Mockito.doReturn(Optional.of(accountBookDOs)).when(accountQueryRepository).queryBookBySeller(sellerId);
    }







}
