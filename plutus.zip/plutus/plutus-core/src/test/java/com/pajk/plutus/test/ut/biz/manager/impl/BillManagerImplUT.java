package com.pajk.plutus.test.ut.biz.manager.impl;

import com.google.common.collect.Lists;
import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.dao.mapper.single.bill.*;
import com.pajk.plutus.biz.dao.mapper.single.voucher.StatementMapper;
import com.pajk.plutus.biz.dao.repo.BillRepository;
import com.pajk.plutus.biz.dao.repo.BillSettlementQueryRepository;
import com.pajk.plutus.biz.dao.repo.SellerAccountInfoRepository;
import com.pajk.plutus.biz.dao.repo.SellerInvoiceInfoRepository;
import com.pajk.plutus.biz.dao.repo.impl.BillRepositoryImpl;
import com.pajk.plutus.biz.dao.repo.impl.BillSettlementQueryRepositoryImpl;
import com.pajk.plutus.biz.dao.repo.impl.SellerAccountInfoRepositoryImpl;
import com.pajk.plutus.biz.dao.repo.impl.SellerInvoiceInfoRepositoryImpl;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.impl.BillManagerImpl;
import com.pajk.plutus.biz.model.bill.BillSettlementDO;
import com.pajk.plutus.biz.model.bill.ButtonDO;
import com.pajk.plutus.biz.model.mapper.single.bill.*;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.biz.model.query.bill.*;
import com.pajk.plutus.client.model.enums.bill.SettlementType;
import com.pajk.plutus.client.model.enums.trade.PayToType;
import com.pajk.plutus.test.ut.BaseServiceUT;
import com.pajk.taskcenter.client.model.dto.*;
import com.pajk.taskcenter.client.model.result.BatchResult;
import com.pajk.taskcenter.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.util.CollectionUtils;
import org.testng.annotations.Test;

import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyMap;
import static org.mockito.Mockito.*;

/**
 * @author david
 * @since created by on 17/12/14 18:57
 */
public class BillManagerImplUT extends BaseServiceUT {

    @InjectMocks
    private BillManagerImpl billManager = new BillManagerImpl();

    @Spy
    @InjectMocks
    private BillSettlementQueryRepository billSettlementQueryRepository = new BillSettlementQueryRepositoryImpl();

    @Spy
    @InjectMocks
    private BillRepository billRepository = new BillRepositoryImpl();

    @Spy
    @InjectMocks
    private SellerInvoiceInfoRepository sellerInvoiceInfoRepository = new SellerInvoiceInfoRepositoryImpl();

    @Spy
    @InjectMocks
    private SellerAccountInfoRepository sellerAccountInfoRepository = new SellerAccountInfoRepositoryImpl();

    @Mock
    private BillSettlementMapper billSettlementMapper;

    @Mock
    private BillSettlementItemMapper billSettlementItemMapper;

    @Mock
    private InvoiceInfoSnapshotMapper invoiceInfoSnapshotMapper;

    @Mock
    private AccountInfoSnapshotMapper accountInfoSnapshotMapper;

    @Mock
    private SellerAccountInfoMapper sellerAccountInfoMapper;

    @Mock
    private SellerInvoiceInfoMapper sellerInvoiceInfoMapper;

    @Mock
    private BillLogMapper billLogMapper;

    @Mock
    private StatementMapper statementMapper;

    protected long defaultSellerId = 12340909L;
    protected UserParam userParam = new UserParam(defaultAppId, defaultUserId, 0L);

    private void mockitoQuerySellerNameOk() {
        KyCallResult<SellerDO> kyCallResult = new KyCallResult<>();
        SellerDO sellerDO = new SellerDO();
        sellerDO.setName("x");
        kyCallResult.setModel(sellerDO);
        doReturn(kyCallResult).when(sellerService).getSellerById(anyLong());
    }

    private void mockitoQuerySellerNameFail() {
        KyCallResult<SellerDO> kyCallResult = new KyCallResult<>(ErrorCode.NO_PARAM_ERROR.getCode(), ErrorCode.NO_PARAM_ERROR.getMsg());
        doReturn(kyCallResult).when(sellerService).getSellerById(anyLong());
    }

    private void mockitoGetNodeInfoOk(String key) {
        BatchResult<GetNodeInfoResultDTO> batchResult = new BatchResult<>();

        GetNodeInfoResultDTO getNodeInfoResultDTO = new GetNodeInfoResultDTO();
        NodeDTO nodeDTO = new NodeDTO();
        List<TransitionDTO> transitionDTOS = Lists.newLinkedList();
        TransitionDTO transitionDTO = new TransitionDTO();
        transitionDTO.setTransitionName("ok");
        transitionDTO.setTransitionKey(key);
        transitionDTOS.add(transitionDTO);
        nodeDTO.setTransitionDTOList(transitionDTOS);
        getNodeInfoResultDTO.setNodeDTO(nodeDTO);
        batchResult.setModel(Lists.newArrayList(getNodeInfoResultDTO));
        doReturn(batchResult).when(flowService).getNodeInfoList(any());
    }

    private void mockitoGetNodeInfoFailA() {
        BatchResult<GetNodeInfoResultDTO> batchResult = new BatchResult<>(ErrorCode.NO_PARAM_ERROR.getCode(), ErrorCode.NO_PARAM_ERROR.getMsg());
        doReturn(batchResult).when(flowService).getNodeInfoList(any());
    }

    private void mockitoGetNodeInfoFailB() {
        doThrow(new RuntimeException("x")).when(flowService).getNodeInfoList(any());
    }

    private void mockitoGetNodeInfoFailC() {
        BatchResult<GetNodeInfoResultDTO> batchResult = new BatchResult<>();

        GetNodeInfoResultDTO getNodeInfoResultDTO = new GetNodeInfoResultDTO();
        NodeDTO nodeDTO = new NodeDTO();
        List<TransitionDTO> transitionDTOS = Collections.emptyList();
        nodeDTO.setTransitionDTOList(transitionDTOS);
        getNodeInfoResultDTO.setNodeDTO(nodeDTO);
        batchResult.setModel(Lists.newArrayList(getNodeInfoResultDTO));
        doReturn(batchResult).when(flowService).getNodeInfoList(any());
    }

    private void mockitoCompleteTaskOk() {
        BatchResult<CompleteTaskResultDTO> batchResultDTO = new BatchResult<>();
        CompleteTaskResultDTO taskResultDTO = new CompleteTaskResultDTO();
        List<TaskInstDTO> taskInstDTOS = Lists.newLinkedList();
        TaskInstDTO taskInstDTO = new TaskInstDTO();
        taskInstDTOS.add(taskInstDTO);
        taskResultDTO.setProcInstId(123L);
        taskResultDTO.setTaskInstDTOList(taskInstDTOS);
        List<CompleteTaskResultDTO> taskResultDTOS = Lists.newLinkedList();
        taskResultDTOS.add(taskResultDTO);
        batchResultDTO.setModel(taskResultDTOS);
        doReturn(batchResultDTO).when(flowService).completeTask(any());
    }

    private void mockitoCompleteTaskFailA() {
        BatchResult<CompleteTaskResultDTO> batchResultDTO = new BatchResult<>(ErrorCode.NO_PARAM_ERROR.getCode(), ErrorCode.NO_PARAM_ERROR.getMsg());
        doReturn(batchResultDTO).when(flowService).completeTask(any());
    }

    private void mockitoCompleteTaskFailB() {
        doThrow(new RuntimeException("x")).when(flowService).completeTask(any());
    }

    private void mockitoCompleteTaskC() {
        BatchResult<CompleteTaskResultDTO> batchResultDTO = new BatchResult<>();
        CompleteTaskResultDTO taskResultDTO = new CompleteTaskResultDTO();
        List<TaskInstDTO> taskInstDTOS = Lists.newLinkedList();
        TaskInstDTO taskInstDTO = new TaskInstDTO();
        taskInstDTOS.add(taskInstDTO);
        taskResultDTO.setSuccess(false);
        taskResultDTO.setErrorCode(ErrorCode.NODE_EXECUTED_ERROR.getCode());
        taskResultDTO.setErrorMsg(ErrorCode.NODE_EXECUTED_ERROR.getMsg());
        taskResultDTO.setTaskInstDTOList(taskInstDTOS);
        batchResultDTO.setModel(Lists.newArrayList(taskResultDTO));
        doReturn(batchResultDTO).when(flowService).completeTask(any());
    }

    private void mockitoNodeEnterOk(boolean endFlag) {
        CompleteTaskResultDTO taskResultDTO = new CompleteTaskResultDTO();
        List<TaskInstDTO> taskInstDTOS = Lists.newLinkedList();
        TaskInstDTO taskInstDTO = new TaskInstDTO();
        taskInstDTOS.add(taskInstDTO);
        taskResultDTO.setProcInstId(123L);
        taskResultDTO.setEndFlag(endFlag);
        taskResultDTO.setTaskInstDTOList(taskInstDTOS);
        doReturn(taskResultDTO).when(flowService).nodeEnter(any(), anyBoolean());
    }

    private void mockitoNodeEnterFailA() {
        CompleteTaskResultDTO completeTaskResultDTO = new CompleteTaskResultDTO();
        completeTaskResultDTO.setSuccess(false);
        completeTaskResultDTO.setErrorCode(ErrorCode.NO_PARAM_ERROR.getCode());
        completeTaskResultDTO.setErrorMsg(ErrorCode.NO_PARAM_ERROR.getMsg());
        doReturn(completeTaskResultDTO).when(flowService).nodeEnter(any(), anyBoolean());
    }

    private void mockitoNodeEnterFailB() {
        doThrow(new RuntimeException("x")).when(flowService).nodeEnter(any(), anyBoolean());
    }

    private void mockitoCreateOk() {
        BatchResult<CreateProcInstResultDTO> batchResultDTO = new BatchResult<>();
        List<TaskInstDTO> taskInstDTOS = Lists.newLinkedList();
        TaskInstDTO taskInstDTO = new TaskInstDTO();
        taskInstDTOS.add(taskInstDTO);
        CreateProcInstResultDTO createProcInstResultDTO = new CreateProcInstResultDTO();
        createProcInstResultDTO.setTaskInstDTOList(taskInstDTOS);
        batchResultDTO.setModel(Lists.newArrayList(createProcInstResultDTO));
        doReturn(batchResultDTO).when(flowService).createProcess(any());
    }

    private void mockitoCreateA() {
        BatchResult<CreateProcInstResultDTO> batchResultDTO = new BatchResult<>(ErrorCode.NO_PARAM_ERROR.getCode(), ErrorCode.NO_PARAM_ERROR.getMsg());
        doReturn(batchResultDTO).when(flowService).createProcess(any());
    }

    private void mockitoCreateB() {
        doThrow(new RuntimeException("x")).when(flowService).createProcess(any());
    }

    private void mockitoCreateC(boolean endFlag) {
        BatchResult<CreateProcInstResultDTO> batchResultDTO = new BatchResult<>();
        List<TaskInstDTO> taskInstDTOS = Lists.newLinkedList();
        TaskInstDTO taskInstDTO = new TaskInstDTO();
        taskInstDTOS.add(taskInstDTO);
        CreateProcInstResultDTO createProcInstResultDTO = new CreateProcInstResultDTO();
        createProcInstResultDTO.setSuccess(true);
        createProcInstResultDTO.setEndFlag(endFlag);
        createProcInstResultDTO.setErrorCode(ErrorCode.NODE_EXECUTED_ERROR.getCode());
        createProcInstResultDTO.setErrorMsg(ErrorCode.NODE_EXECUTED_ERROR.getMsg());
        createProcInstResultDTO.setTaskInstDTOList(taskInstDTOS);
        batchResultDTO.setModel(Lists.newArrayList(createProcInstResultDTO));
        doReturn(batchResultDTO).when(flowService).createProcess(any());
    }

    @Test
    public void getButtons() {
        BatchResultDTO<ButtonDO> resultDTO = billManager.getDefaultButtons();
        assertThat(resultDTO.isSuccess()).isTrue();
        assertThat(resultDTO.getModel().get(0).getName()).isEqualTo("确认");

        mockitoGetNodeInfoFailA();
        resultDTO = billManager.getButtons(123L, null);
        assertThat(resultDTO.getModel()).isEmpty();


        mockitoGetNodeInfoFailB();
        resultDTO = billManager.getButtons(123L, null);
        assertThat(resultDTO.getModel()).isEmpty();

        mockitoGetNodeInfoOk("agree");
        resultDTO = billManager.getButtons(123L, null);
        assertThat(resultDTO.getModel()).isNotEmpty();
    }

    private BillSettlementDAO createBillSettlementDAO(Long procInstId, String role, long actAmt) {
        BillSettlementDAO billSettlementDAO = new BillSettlementDAO();
        billSettlementDAO.setId(123L);
        billSettlementDAO.setSellerId(123L);
        billSettlementDAO.setRole(role);
        billSettlementDAO.setPayToType(PayToType.PAY_TO_PLATFORM.getCode());
        billSettlementDAO.setSettlementType(SettlementType.PA_PAY.getCode());
        billSettlementDAO.setActualBillAmt(actAmt);
        billSettlementDAO.setInvoiceInfo("{\"invoiceAmt\":2000,\"invoiceId\":\"333333333333333\",\"invoiceTax\":300,\"trackingNumber\":\"444444444444444\"}");

        billSettlementDAO.setProcInstId(procInstId);
        return billSettlementDAO;
    }

    private BillSettlementDAO createBillSettlementDAO(Long procInstId, String role, long actAmt, PayToType payToType, SettlementType settlementType) {
        BillSettlementDAO billSettlementDAO = new BillSettlementDAO();
        billSettlementDAO.setId(123L);
        billSettlementDAO.setSellerId(123L);
        billSettlementDAO.setRole(role);
        billSettlementDAO.setPayToType(payToType.getCode());
        billSettlementDAO.setSettlementType(settlementType.getCode());
        billSettlementDAO.setActualBillAmt(actAmt);
        billSettlementDAO.setInvoiceInfo("{\"invoiceAmt\":2000,\"invoiceId\":\"333333333333333\",\"invoiceTax\":300,\"trackingNumber\":\"444444444444444\"}");

        billSettlementDAO.setProcInstId(procInstId);
        return billSettlementDAO;
    }

    private BillSettlementItemDAO createBillSettlementItemDAO(long billItemId, long billAmt) {
        BillSettlementItemDAO billSettlementItemDAO = new BillSettlementItemDAO();
        billSettlementItemDAO.setId(billItemId);
        billSettlementItemDAO.setActualBillAmt(billAmt);
        return billSettlementItemDAO;
    }

    private InvoiceInfoSnapshotDAO createInvoiceInfoSnapshotDAO() {
        InvoiceInfoSnapshotDAO invoiceInfoSnapshotDAO = new InvoiceInfoSnapshotDAO();
        return invoiceInfoSnapshotDAO;
    }

    private AccountInfoSnapshotDAO createAccountInfoSnapshotDAO() {
        AccountInfoSnapshotDAO accountInfoSnapshotDAO = new AccountInfoSnapshotDAO();
        return accountInfoSnapshotDAO;
    }

    private void mockitoBillSettlementItem(BillSettlementItemDAO billSettlementItemDAO) {
        doReturn(Lists.newArrayList(billSettlementItemDAO)).when(billSettlementItemMapper).queryByBillId(anyLong());
    }

    private void mockitoInvoiceInfoSnapshot(InvoiceInfoSnapshotDAO invoiceInfoSnapshotDAO) {
        doReturn(Lists.newArrayList(invoiceInfoSnapshotDAO)).when(invoiceInfoSnapshotMapper).queryByBillId(anyLong());
    }

    private void mockitoAccountInfoSnapshot(AccountInfoSnapshotDAO accountInfoSnapshotDAO) {
        doReturn(Lists.newArrayList(accountInfoSnapshotDAO)).when(accountInfoSnapshotMapper).queryByBillId(anyLong());
    }

    @Test
    public void queryConfirmSettlement() {
        long billId = 333L;
        long sellerId = 777L;
        doReturn(null).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        ResultDTO<BillSettlementDO> resultDTO = billManager.queryConfirmSettlement(billId);
        assertThat(resultDTO.isSuccess()).isFalse();
        resultDTO = billManager.queryConfirmSettlement(billId, sellerId);
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(null, "admin", 123L)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        mockitoBillSettlementItem(createBillSettlementItemDAO(1L, 1L));
        mockitoQuerySellerNameOk();
        resultDTO = billManager.queryConfirmSettlement(billId);
        assertThat(resultDTO.isSuccess()).isTrue();
        resultDTO = billManager.queryConfirmSettlement(billId, sellerId);
        assertThat(resultDTO.isSuccess()).isTrue();
    }

    @Test
    public void querySettlement() {
        long billId = 333L;
        long sellerId = 777L;
        doReturn(null).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        ResultDTO<BillSettlementDO> resultDTO = billManager.querySettlement(billId);
        assertThat(resultDTO.isSuccess()).isFalse();
        resultDTO = billManager.querySettlement(billId, sellerId);
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(null, "admin", 123L)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        mockitoBillSettlementItem(createBillSettlementItemDAO(1L, 1L));
        mockitoInvoiceInfoSnapshot(createInvoiceInfoSnapshotDAO());
        mockitoAccountInfoSnapshot(createAccountInfoSnapshotDAO());
        mockitoQuerySellerNameOk();
        resultDTO = billManager.querySettlement(billId);
        assertThat(resultDTO.isSuccess()).isTrue();
        resultDTO = billManager.querySettlement(billId, sellerId);
        assertThat(resultDTO.isSuccess()).isTrue();

        mockitoQuerySellerNameFail();
        resultDTO = billManager.querySettlement(billId);
        assertThat(resultDTO.isSuccess()).isTrue();
        resultDTO = billManager.querySettlement(billId, sellerId);
        assertThat(resultDTO.isSuccess()).isTrue();
    }

    private BillLogDTO createBillLogDTO(String role) {
        BillLogDTO billLogDTO = new BillLogDTO();
        billLogDTO.setOperatorId("123");
        billLogDTO.setOperatorName("xb");
        billLogDTO.setSellerId(123L);
        billLogDTO.setRole(role);
        billLogDTO.setRemark("remark");
        return billLogDTO;
    }

    private void validateRoleFail(long billId, String buttonKey, BillLogDTO billLogDTO) {
        mockitoGetNodeInfoFailA();
        ResultDTO<VoidEntity> resultDTO = billManager.confirmOnlyRemark(billId, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isFalse();

        mockitoGetNodeInfoFailB();
        resultDTO = billManager.confirmOnlyRemark(billId, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isFalse();

        mockitoGetNodeInfoFailC();
        resultDTO = billManager.confirmOnlyRemark(billId, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isFalse();

        mockitoGetNodeInfoOk("b");
        resultDTO = billManager.confirmOnlyRemark(billId, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isFalse();
    }

    private void validateComplete(Supplier<ResultDTO<VoidEntity>> supplier) {
        mockitoCompleteTaskFailA();
        ResultDTO<VoidEntity> resultDTO = supplier.get();
        assertThat(resultDTO.isSuccess()).isFalse();

        mockitoCompleteTaskFailB();
        resultDTO = supplier.get();
        assertThat(resultDTO.isSuccess()).isFalse();

        mockitoCompleteTaskC();
        mockitoNodeEnterFailA();
        resultDTO = supplier.get();
        assertThat(resultDTO.isSuccess()).isFalse();

        mockitoNodeEnterFailB();
        resultDTO = supplier.get();
        assertThat(resultDTO.isSuccess()).isFalse();

        mockitoNodeEnterOk(true);
        resultDTO = supplier.get();
        assertThat(resultDTO.isSuccess()).isTrue();

        mockitoNodeEnterOk(false);
        resultDTO = supplier.get();
        assertThat(resultDTO.isSuccess()).isTrue();

    }

    private void validateCreate(long billId, BillSettlementDTO billSettlementDTO, String buttonKey, BillLogDTO billLogDTO) {
        mockitoCreateB();
        ResultDTO<VoidEntity> resultDTO = billManager.confirmSettlement(billId, billSettlementDTO, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isFalse();

        mockitoCreateA();
        resultDTO = billManager.confirmSettlement(billId, billSettlementDTO, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isFalse();

        mockitoCreateC(true);
        resultDTO = billManager.confirmSettlement(billId, billSettlementDTO, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isTrue();
    }

    private void mockitoQuerySellerAccountInfoOk() {
        List<SellerAccountInfoDAO> sellerAccountInfoDAOS = Lists.newArrayList();
        SellerAccountInfoDAO sellerAccountInfoDAO = new SellerAccountInfoDAO();
        sellerAccountInfoDAO.setId(123L);
        sellerAccountInfoDAO.setSellerId(321L);
        sellerAccountInfoDAOS.add(sellerAccountInfoDAO);
        doReturn(sellerAccountInfoDAOS).when(sellerAccountInfoMapper).queryBySellerId(anyLong(), anyInt());
    }

    private void mockitoQuerySellerAccountInfoFail() {
        doReturn(Collections.emptyList()).when(sellerAccountInfoMapper).queryBySellerId(anyLong(), anyInt());
    }

    private void mockitoQuerySellerInvoiceInfoOk() {
        List<SellerInvoiceInfoDAO> sellerInvoiceInfoDAOS = Lists.newArrayList();
        SellerInvoiceInfoDAO sellerInvoiceInfoDAO = new SellerInvoiceInfoDAO();
        sellerInvoiceInfoDAO.setId(123L);
        sellerInvoiceInfoDAO.setSellerId(321L);
        sellerInvoiceInfoDAOS.add(sellerInvoiceInfoDAO);
        doReturn(sellerInvoiceInfoDAOS).when(sellerInvoiceInfoMapper).queryBySellerId(anyLong(), anyInt());
    }

    private void mockitoQuerySellerInvoiceInfoFail() {
        doReturn(Collections.emptyList()).when(sellerInvoiceInfoMapper).queryBySellerId(anyLong(), anyInt());
    }

    @Test
    public void confirmPayment() {
        long billId = 333L;
        String buttonKey = "agree";
        String role = "admin";
        long procInstId = 321L;
        BillLogDTO billLogDTO = createBillLogDTO(role);
        PaymentInfoDTO paymentInfoDTO = new PaymentInfoDTO();
        paymentInfoDTO.setBillId(billId);
        paymentInfoDTO.setButtonKey(buttonKey);
        paymentInfoDTO.setPaymentFileId("xxx");
        paymentInfoDTO.setPaymentFileName("xxx");
        paymentInfoDTO.setPaymentNo("xxx");
        mockRole(billLogDTO.getRole(), false);
        doReturn(null).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        ResultDTO<VoidEntity> resultDTO = billManager.confirmPayment(paymentInfoDTO, billLogDTO, userParam, true);
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(null, "xb", 123L)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        mockitoBillSettlementItem(createBillSettlementItemDAO(1L, 1L));
        resultDTO = billManager.confirmPayment(paymentInfoDTO, billLogDTO, userParam, false);
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(null, role, 123L)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        resultDTO = billManager.confirmPayment(paymentInfoDTO, billLogDTO, userParam, true);
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(procInstId, role, 123L)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        mockitoQuerySellerAccountInfoOk();
        mockitoGetNodeInfoOk(buttonKey);
        doReturn(1).when(billSettlementMapper).updateConfirm(any());
        doReturn(1).when(billLogMapper).insert(any());
        mockitoCompleteTaskOk();
        mockitoPermissionOk();
        mockitoCurrentUserRoleOK(role);
        resultDTO = billManager.confirmPayment(paymentInfoDTO, billLogDTO, userParam, true);
        assertThat(resultDTO.isSuccess()).isTrue();

        mockitoQuerySellerAccountInfoFail();
        assertThat(resultDTO.isSuccess()).isTrue();
    }

    @Test
    public void confirmInvoice() {
        long billId = 333L;
        String buttonKey = "agree";
        String role = "admin";
        long procInstId = 321L;
        BillLogDTO billLogDTO = createBillLogDTO(role);
        InvoiceInfoDTO invoiceInfoDTO = new InvoiceInfoDTO();
        invoiceInfoDTO.setBillId(billId);
        invoiceInfoDTO.setButtonKey(buttonKey);
        invoiceInfoDTO.setInvoiceId("xxx");
        invoiceInfoDTO.setInvoiceAmt(10L);
        invoiceInfoDTO.setInvoiceTaxAmt(1L);
        invoiceInfoDTO.setInvoiceTrackingNumber("XB");

        doReturn(null).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        ResultDTO<VoidEntity> resultDTO = billManager.confirmInvoice(invoiceInfoDTO, billLogDTO, userParam, false);
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(null, "xb", 123L)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        mockitoBillSettlementItem(createBillSettlementItemDAO(1L, 1L));
        resultDTO = billManager.confirmInvoice(invoiceInfoDTO, billLogDTO, userParam, false);
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(null, role, 123L)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        resultDTO = billManager.confirmInvoice(invoiceInfoDTO, billLogDTO, userParam, true);
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(procInstId, role, 123L)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        resultDTO = billManager.confirmInvoice(invoiceInfoDTO, billLogDTO, userParam, true);
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(procInstId, role, invoiceInfoDTO.getInvoiceAmt() + invoiceInfoDTO.getInvoiceTaxAmt()))
                .when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        mockitoQuerySellerInvoiceInfoOk();
        mockitoGetNodeInfoOk(buttonKey);
        doReturn(1).when(billSettlementMapper).updateConfirm(any());
        doReturn(1).when(billLogMapper).insert(any());
        mockitoCompleteTaskOk();
        mockitoPermissionOk();
        mockRole(role, false);
        mockitoCurrentUserRoleOK(role);
        resultDTO = billManager.confirmInvoice(invoiceInfoDTO, billLogDTO, userParam, true);
        assertThat(resultDTO.isSuccess()).isTrue();

        mockitoQuerySellerInvoiceInfoFail();
        assertThat(resultDTO.isSuccess()).isTrue();
    }

    @Test
    public void confirmSettlement() {
        long billId = 333L;
        String buttonKey = "agree";
        String role = "admin";
        long procInstId = 321L;
        long billItemId = 321L;
        long billAmt = 321L;
        BillLogDTO billLogDTO = createBillLogDTO(role);
        BillSettlementDTO billSettlementDTO = new BillSettlementDTO();
        BillSettlementItemDTO billSettlementItemDTO = new BillSettlementItemDTO();
        billSettlementItemDTO.setId(billItemId);
        billSettlementItemDTO.setBillAmt(billAmt);
        billSettlementItemDTO.setActualBillAmt(billAmt);
        billSettlementDTO.setSettlementItems(Lists.newArrayList(billSettlementItemDTO));

        doReturn(null).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        ResultDTO<VoidEntity> resultDTO = billManager.confirmSettlement(billId, billSettlementDTO, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(null, "xb", 123L)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        mockitoBillSettlementItem(createBillSettlementItemDAO(billItemId, billAmt));
        resultDTO = billManager.confirmSettlement(billId, billSettlementDTO, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(null, role, 123L)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        mockitoBillSettlementItem(createBillSettlementItemDAO(3L, billAmt));
        resultDTO = billManager.confirmSettlement(billId, billSettlementDTO, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isFalse();

        mockitoBillSettlementItem(createBillSettlementItemDAO(billItemId, billAmt));
        resultDTO = billManager.confirmSettlement(billId, billSettlementDTO, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(null, role, billAmt)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        validateCreate(billId, billSettlementDTO, buttonKey, billLogDTO);

        mockitoCreateOk();
        resultDTO = billManager.confirmSettlement(billId, billSettlementDTO, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isTrue();
    }

    private void onlyRemark(long billId, String buttonKey, BillLogDTO billLogDTO, Supplier<ResultDTO<VoidEntity>> supplier) {
        long procInstId = 321L;

        doReturn(null).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        ResultDTO<VoidEntity> resultDTO = supplier.get();
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(null, "xb", 123L)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        mockitoBillSettlementItem(createBillSettlementItemDAO(1L, 1L));
        resultDTO = supplier.get();
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(null, billLogDTO.getRole(), 123L)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        resultDTO = supplier.get();
        assertThat(resultDTO.isSuccess()).isFalse();

        doReturn(createBillSettlementDAO(procInstId, billLogDTO.getRole(), 123L)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        validateRoleFail(billId, buttonKey, billLogDTO);

        mockitoGetNodeInfoOk(buttonKey);
        resultDTO = supplier.get();
        assertThat(resultDTO.isSuccess()).isFalse();
    }

    @Test
    public void confirmOnlyRemark() {
        long billId = 333L;
        String buttonKey = "agree";
        BillLogDTO billLogDTO = createBillLogDTO("admin");
        mockRole(billLogDTO.getRole(), false);
        mockitoPermissionOk();
        mockitoCurrentUserRoleOK("admin");
        onlyRemark(billId, buttonKey, billLogDTO, () -> billManager.confirmOnlyRemark(billId, buttonKey, billLogDTO, userParam));

        doReturn(1).when(billSettlementMapper).updateConfirm(any());
        doReturn(1).when(billLogMapper).insert(any());
        validateComplete(() -> billManager.confirmOnlyRemark(billId, buttonKey, billLogDTO, userParam));
        mockitoCompleteTaskOk();
        ResultDTO<VoidEntity> resultDTO = billManager.confirmOnlyRemark(billId, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isTrue();
    }

    @Test
    public void receiveInvoice() {
        long billId = 333L;
        String buttonKey = "confirm";
        BillLogDTO billLogDTO = createBillLogDTO("admin");

        mockitoPermissionOk();
        mockRole(billLogDTO.getRole(), false);
        mockitoCurrentUserRoleOK("admin");

        onlyRemark(billId, buttonKey, billLogDTO, () -> billManager.receiveInvoice(billId, buttonKey, billLogDTO, userParam));

        mockitoQuerySellerInvoiceInfoOk();
        doReturn(1).when(billSettlementMapper).updateConfirm(any());
        doReturn(1).when(billLogMapper).insert(any());
        doReturn(1).when(invoiceInfoSnapshotMapper).insert(any());
        validateComplete(() -> billManager.receiveInvoice(billId, buttonKey, billLogDTO, userParam));

        mockitoCompleteTaskOk();
        doReturn(createBillSettlementDAO(112344L, billLogDTO.getRole(), 123L, PayToType.PAY_TO_PLATFORM, SettlementType.PA_RECEIPT)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        ResultDTO<VoidEntity> resultDTO = billManager.receiveInvoice(billId, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isTrue();

        mockitoCompleteTaskOk();
        doReturn(createBillSettlementDAO(112344L, billLogDTO.getRole(), 123L, PayToType.PAY_TO_SELLER, SettlementType.PA_RECEIPT)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        resultDTO = billManager.receiveInvoice(billId, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isTrue();

        mockitoCompleteTaskOk();
        doReturn(createBillSettlementDAO(112344L, billLogDTO.getRole(), 123L, PayToType.PAY_TO_SELLER, SettlementType.PA_PAY)).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        resultDTO = billManager.receiveInvoice(billId, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isTrue();

        mockitoQuerySellerInvoiceInfoFail();
        assertThat(resultDTO.isSuccess()).isTrue();
    }

    @Test
    public void confirmReceivePayment() {
        long billId = 333L;
        String buttonKey = "agree";
        BillLogDTO billLogDTO = createBillLogDTO("admin");
        billLogDTO.setSellerId(null);
        doReturn(null).when(billSettlementMapper).queryByIdAndSellerId(anyLong(), anyLong());
        mockitoPermissionOk();
        mockRole(billLogDTO.getRole(), false);
        mockitoCurrentUserRoleOK("admin");
        ResultDTO<VoidEntity> resultDTO = billManager.confirmReceivePayment(billId, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isFalse();

        billLogDTO.setSellerId(createBillLogDTO("admin").getSellerId());
        onlyRemark(billId, buttonKey, billLogDTO, () -> billManager.confirmReceivePayment(billId, buttonKey, billLogDTO, userParam));

        mockitoQuerySellerAccountInfoOk();
        doReturn(1).when(billSettlementMapper).updateConfirm(any());
        doReturn(1).when(billLogMapper).insert(any());
        doReturn(1).when(invoiceInfoSnapshotMapper).insert(any());
        validateComplete(() -> billManager.confirmReceivePayment(billId, buttonKey, billLogDTO, userParam));

        mockitoCompleteTaskOk();
        resultDTO = billManager.confirmReceivePayment(billId, buttonKey, billLogDTO, userParam);
        assertThat(resultDTO.isSuccess()).isTrue();

        mockitoQuerySellerAccountInfoFail();
        assertThat(resultDTO.isSuccess()).isTrue();
    }

    @Mock
    private ControlCache controlCache;

    @Test
    public void pageQuerySettlement() {
        final long userId = 10000L;
        final long sellerId = 100L;
        final long appId = 1L;
        String startTime = "2017-01";
        String endTime = "2017-12";
        when(controlCache.getBillSettlementQueryDaySpan()).thenReturn(367);
        when(controlCache.getBillSettlementQueryDayInterval()).thenReturn(365);
        final long billSettlementId = 10L;

        when(billSettlementMapper.count(anyMap())).thenReturn(0);
        PageResultDTO<BillSettlementDO> billSettlementDOPageResultDTO = billManager.pageQuerySettlement(
                sellerId, "SELLER_OP", startTime, endTime, 1, 10);
        assertThat(CollectionUtils.isEmpty(billSettlementDOPageResultDTO.getModel())).isTrue();
    }
}