package com.pajk.plutus.test.ut.biz.manager.account;

import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyBatchResult;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountDAO;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by  guguangming on 2018/01/03
 **/
public class CreateAccountByAllSellersUT extends BaseAccountManagerUT {

    @Test(description = "seller 查询失败")
    public void test1() {
        KyBatchResult<SellerDO> kyCallResult = new KyBatchResult<>();
        kyCallResult.setSuccess(false);
        Mockito.doReturn(kyCallResult).when(sellerService).getAllSellers();
        ResultDTO<VoidEntity> resultDTO = accountManager.createAccountByAllSellers();
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SELLER_NOT_EXISTS.getCode());
    }


    @Test(description = "seller 查询成功但是执行失败")
    public void test2() {
        KyBatchResult<SellerDO> batchResult = new KyBatchResult<>();
        batchResult.setSuccess(true);
        List<SellerDO> list = new ArrayList<>();
        list.add(buildSellerDO());
        batchResult.setModel(list);
        Mockito.doReturn(batchResult).when(sellerService).getAllSellers();

        KyCallResult<SellerDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(false);
        Mockito.doReturn(kyCallResult).when(sellerService).getSellerById(Matchers.anyLong());

        ResultDTO<VoidEntity> resultDTO = accountManager.createAccountByAllSellers();
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());

    }

    @Test(description = "全部执行成功")
    public void test3() {
        KyBatchResult<SellerDO> batchResult = new KyBatchResult<>();
        batchResult.setSuccess(true);
        List<SellerDO> list = new ArrayList<>();
        list.add(buildSellerDO());
        batchResult.setModel(list);
        Mockito.doReturn(batchResult).when(sellerService).getAllSellers();

        mockSellerDO(buildSellerDO());

        Mockito.doReturn(null).when(accountMapper).queryBySeller(Matchers.anyLong());

        Mockito.doReturn(null).when(accountBookMapper).queryBySeller(Matchers.anyLong());

        Mockito.doReturn(1).when(accountBookMapper).create(Matchers.any(AccountBookDAO.class));
        Mockito.doReturn(1).when(accountMapper).create(Matchers.any(AccountDAO.class));

        ResultDTO<VoidEntity> resultDTO = accountManager.createAccountByAllSellers();
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());

    }
}
