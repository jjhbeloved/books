package com.pajk.plutus.test.it.biz.manager.impl.vouchermanager;

import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.test.it.BaseIT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * Created by lizhijun on 2017/12/25.
 */
public class AddBalanceAmtIT extends BaseIT {
    @Autowired
    private VoucherManager voucherManager;

    @Test
    public void test1(){
        UserParam userParam = new UserParam(defaultAppId,defaultUserId);
        ResultDTO<String> resultDTO = voucherManager.addBalanceAmt(defaultSellerId,1L,10000L,"remark_test",userParam);

        System.out.println(resultDTO);
    }
}
