package com.pajk.plutus.test.ut.biz.service.web.billquerycontroller;

import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyBatchResult;
import com.pajk.plutus.biz.manager.BillExtManager;
import com.pajk.plutus.biz.manager.impl.BillExtManagerImpl;
import com.pajk.plutus.biz.model.query.bill.SellerDTO;
import com.pajk.plutus.biz.service.web.BillQueryController;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.testng.annotations.Test;

import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 18/1/2.
 * Modify by fanhuafeng on 18/1/2
 */
public class BatchQuerySellerUT extends BaseWebServiceUT {

    @InjectMocks
    private BillQueryController billQueryController = new BillQueryController();


    @InjectMocks
    @Spy
    private BillExtManager billExtManager = new BillExtManagerImpl();

    @Test
    public void test01(){

        mockitoPermissionOk();
        KyBatchResult<SellerDO> sellerDOKyBatchResult = new KyBatchResult<>();
        sellerDOKyBatchResult.setSuccess(false);
        Mockito.doReturn(sellerDOKyBatchResult).when(sellerService).getAllSellers();
        BatchResultDTO<SellerDTO> result = billQueryController.batchQuerySeller();
        assertThat(result.isSuccess()).isTrue();
        assertThat(result.getModel()).hasSize(0);




    }


    @Test
    public void test02(){

        mockitoPermissionOk();
        KyBatchResult<SellerDO> sellerDOKyBatchResult = new KyBatchResult<>();
        Mockito.doReturn(sellerDOKyBatchResult).when(sellerService).getAllSellers();

        SellerDO seller = new SellerDO();
        List<SellerDO> list = new LinkedList<>();
        list.add(seller);
        sellerDOKyBatchResult.setModel(list);

        BatchResultDTO<SellerDTO> result = billQueryController.batchQuerySeller();
        assertThat(result.isSuccess()).isTrue();
        assertThat(result.getModel()).hasSize(1);




    }
}
