package com.pajk.plutus.test.ut.biz.manager.account;

import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.service.SellerService;
import com.pajk.plutus.biz.dao.mapper.single.account.AccountBookFlowMapper;
import com.pajk.plutus.biz.dao.mapper.single.account.AccountBookMapper;
import com.pajk.plutus.biz.dao.mapper.single.account.AccountMapper;
import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.dao.repo.AccountRepository;
import com.pajk.plutus.biz.dao.repo.impl.AccountQueryRepositoryImpl;
import com.pajk.plutus.biz.dao.repo.impl.AccountRepositoryImpl;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.manager.impl.AccountManagerImpl;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookFlowDAO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountDAO;
import com.pajk.plutus.client.model.enums.account.BookFlowSubType;
import com.pajk.plutus.client.model.enums.account.BookFlowType;
import com.pajk.plutus.client.model.enums.account.BookType;
import com.pajk.plutus.test.ut.BaseServiceUT;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by  guguangming on 2018/01/03
 **/
public class BaseAccountManagerUT extends BaseServiceUT {
    @InjectMocks
    protected AccountManager accountManager = new AccountManagerImpl();

    @InjectMocks
    @Spy
    protected AccountQueryRepository accountQueryRepository = new AccountQueryRepositoryImpl();

    @InjectMocks
    @Spy
    protected AccountRepository accountRepository  = new AccountRepositoryImpl();

    @Mock
    protected ControlCache controlCache;

    @Mock
    protected AccountMapper accountMapper;

    @Mock
    protected AccountBookMapper accountBookMapper;

    @Mock
    protected AccountBookFlowMapper accountBookFlowMapper;


    protected  long defaultBookId = 11232L;

    protected  long defaultBook = 11232L;

    protected  long defaultBookFlowId = 11L;

    protected  long defaultAccountId = 2L;

    protected  long amount = 110L;

    protected  String  sellerName = "好药师";



    protected AccountBookDAO buildAccountBookDAO() {
        AccountBookDAO bookDAO = new AccountBookDAO();
        bookDAO.setAccountId(1L);
        bookDAO.setActualContractAmt(1111L);
        bookDAO.setBookType(BookType.DEPOSIT.getCode());
        bookDAO.setBalanceAmt(1000L);
        bookDAO.setContractAmt(1000L);
        bookDAO.setSellerId(defaultSellerId);
        bookDAO.setId(1);
        return bookDAO;
    }

    protected AccountBookFlowDAO buildAccountBookFlowDAO() {
        AccountBookFlowDAO flowDAO = new AccountBookFlowDAO();
        flowDAO.setWriteOffStatus(0);
        flowDAO.setFlowType(BookFlowType.VIOLATION.getCode());
        flowDAO.setFlowSubType(BookFlowSubType.PAY_IN_BACK_DEPOSIT.getCode());
        flowDAO.setAmount(amount);
        flowDAO.setSellerId(defaultSellerId);
        return flowDAO;
    }

    protected SellerDO buildSellerDO(){
        SellerDO sellerDO = new SellerDO();
        sellerDO.setName(sellerName);
        sellerDO.setId(defaultSellerId);
        return sellerDO;
    }

    protected AccountDAO  buildAccountDAO(){
        AccountDAO account = new AccountDAO();
        account.setId(defaultAccountId);
        account.setName("账户信息");
        return account;
    }

    protected List<AccountBookDAO> buildListAccountBookDAO(){
        List<AccountBookDAO> list  = new ArrayList<>();
        for(int i=1;i<5 ;i++){
            AccountBookDAO bookDO = new AccountBookDAO();
            bookDO.setSellerId(defaultSellerId);
            bookDO.setContractAmt(0L);
            bookDO.setActualContractAmt(0L);
            bookDO.setBalanceAmt(0L);
            bookDO.setFreezingAmt(0L);
            bookDO.setBookType(i);
            list.add(bookDO);
        }
        return list;
    }

    protected List<AccountBookDAO> buildListAccountBookDAO(int bookType){
        List<AccountBookDAO> list  = new ArrayList<>();
            AccountBookDAO bookDO = new AccountBookDAO();
            bookDO.setSellerId(defaultSellerId);
            bookDO.setContractAmt(0L);
            bookDO.setActualContractAmt(0L);
            bookDO.setBalanceAmt(0L);
            bookDO.setFreezingAmt(0L);
            bookDO.setAccountId(defaultAccountId);
            bookDO.setBookType(bookType);
            list.add(bookDO);
        return list;
    }

}
