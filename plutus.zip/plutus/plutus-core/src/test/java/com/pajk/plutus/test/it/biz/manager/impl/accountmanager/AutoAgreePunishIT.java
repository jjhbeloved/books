package com.pajk.plutus.test.it.biz.manager.impl.accountmanager;

import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.test.it.BaseIT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * Created by lizhijun on 2017/12/25.
 */
public class AutoAgreePunishIT extends BaseIT {

    @Autowired
    private VoucherManager voucherManager;

    @Test
    public void test1(){
        ResultDTO<VoidEntity> resultDTO1 = voucherManager.autoAgreePunish();

        System.out.println(resultDTO1);
    }
}
