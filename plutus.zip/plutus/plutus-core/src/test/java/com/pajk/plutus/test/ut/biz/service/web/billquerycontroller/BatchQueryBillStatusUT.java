package com.pajk.plutus.test.ut.biz.service.web.billquerycontroller;

import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.manager.BillExtManager;
import com.pajk.plutus.biz.manager.impl.BillExtManagerImpl;
import com.pajk.plutus.biz.model.query.bill.BillStatusDTO;
import com.pajk.plutus.biz.service.web.BillQueryController;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 18/1/2.
 * Modify by fanhuafeng on 18/1/2
 */
public class BatchQueryBillStatusUT extends BaseWebServiceUT {

    @InjectMocks
    private BillQueryController billQueryController = new BillQueryController();


    @InjectMocks
    @Spy
    private BillExtManager billExtManager = new BillExtManagerImpl();

    private final static String CHANNEL = "all";
    private final static String SOURCE = "procStatus";
    private final static String SYSTEM = "taskcenter";
    private final static String TYPE = "Status";
    private final static String KEY = "bill";

    @Test
    public void test01(){
        mockitoPermissionOk();


        KyCallResult<AppResourceDO> appResourceResult= new KyCallResult<>();

        appResourceResult.setModel(null);


        Mockito.doReturn(appResourceResult).when(appResourceService).getAppResource(SYSTEM, CHANNEL, TYPE, SOURCE, KEY);

        BatchResultDTO<BillStatusDTO> result = billQueryController.batchQueryBillStatus();

        assertThat(result.isSuccess()).isTrue();


    }

    @Test
    public void test02(){
        mockitoPermissionOk();


        KyCallResult<AppResourceDO> appResourceResult= new KyCallResult<>();

        appResourceResult.setSuccess(false);


        Mockito.doReturn(appResourceResult).when(appResourceService).getAppResource(SYSTEM, CHANNEL, TYPE, SOURCE, KEY);

        BatchResultDTO<BillStatusDTO> result = billQueryController.batchQueryBillStatus();

        assertThat(result.isSuccess()).isTrue();


    }


    @Test
    public void test03(){
        mockitoPermissionOk();


        KyCallResult<AppResourceDO> appResourceResult= new KyCallResult<>();
        AppResourceDO resourceDO = new AppResourceDO();
        resourceDO.val = "a:b;c:d";
        appResourceResult.setModel(resourceDO);


        Mockito.doReturn(appResourceResult).when(appResourceService).getAppResource(SYSTEM, CHANNEL, TYPE, SOURCE, KEY);

        BatchResultDTO<BillStatusDTO> result = billQueryController.batchQueryBillStatus();

        assertThat(result.isSuccess()).isTrue();


    }
}
