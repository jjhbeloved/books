package com.pajk.plutus.test.it.biz.service.web;

import com.pajk.plutus.biz.common.util.JsonUtil;
import com.pajk.plutus.biz.model.param.restapi.PageQueryAccountBookParam;
import com.pajk.plutus.biz.model.param.restapi.PageQueryVoucherParam;
import com.pajk.plutus.biz.model.param.restapi.QueryStatusByTypeParam;
import com.pajk.plutus.biz.model.param.restapi.QueryVoucherParam;
import com.pajk.plutus.biz.model.result.dto.account.AccountBookDTO;
import com.pajk.plutus.biz.model.result.dto.process.NodeKeyDTO;
import com.pajk.plutus.biz.model.result.dto.voucher.VoucherDTO;
import com.pajk.plutus.biz.model.result.dto.voucher.VoucherSummaryDTO;
import com.pajk.plutus.biz.service.web.DepositQueryController;
import com.pajk.plutus.test.it.BaseControllerIT;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fuyongda on 2017/12/20.
 * Modified by fuyongda on 2017/12/20.
 */
public class DepositQueryControllerIT extends BaseControllerIT {

    @Autowired
    private DepositQueryController depositQueryController;

    @Test
    public void testQueryVoucher() {
        QueryVoucherParam param = new QueryVoucherParam();
        param.setVoucherId("88");
        param.setSellerId(defaultSellerId);
        ResultDTO<VoucherDTO> resultDTO = depositQueryController.queryVoucher(param);

        System.out.println(JsonUtil.obj2Str(resultDTO));
        assertThat(resultDTO).isNotNull();
    }

    @Test
    public void testQueryVoucherOpt() {
        QueryVoucherParam param = new QueryVoucherParam();
        param.setVoucherId("88");
        param.setSellerId(12026100507L);
        ResultDTO<VoucherDTO> resultDTO = depositQueryController.queryVoucherOpt(param);

        System.out.println(JsonUtil.obj2Str(resultDTO));
        assertThat(resultDTO).isNotNull();
    }

    @Test
    public void testQueryStatusByType() {
        QueryStatusByTypeParam param1 = new QueryStatusByTypeParam();
        param1.setVoucherType(1000);
        BatchResultDTO<NodeKeyDTO> resultDTO1 = depositQueryController.queryStatusByType(param1);

        QueryStatusByTypeParam param2 = new QueryStatusByTypeParam();
        param2.setVoucherType(2000);
        BatchResultDTO<NodeKeyDTO> resultDTO2 = depositQueryController.queryStatusByType(param2);

        System.out.println(JsonUtil.obj2Str(resultDTO1));
        System.out.println(JsonUtil.obj2Str(resultDTO2));
        assertThat(resultDTO1).isNotNull();
        assertThat(resultDTO2).isNotNull();
    }

    @Test
    public void testPageQueryVoucher(){
        PageQueryVoucherParam pageQueryVoucherParam = new PageQueryVoucherParam();
        pageQueryVoucherParam.setCreateEnd("2017-12-30");
        pageQueryVoucherParam.setCreateStart("2017-12-26");
        pageQueryVoucherParam.setVoucherSubType(-1);
        pageQueryVoucherParam.setNodeKey("all");
        pageQueryVoucherParam.setVoucherType(1000);
        pageQueryVoucherParam.setPageNo(1);
        pageQueryVoucherParam.setPageSize(20);

        PageResultDTO<VoucherSummaryDTO> pageResultDTO = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        System.out.println(pageResultDTO);
    }

    @Test
    public void testPageQueryAccountBook() {
        PageQueryAccountBookParam bookParam = new PageQueryAccountBookParam();
        bookParam.setStatus(-1);
        bookParam.setPageNo(1);
        bookParam.setPageSize(20);

        PageResultDTO<AccountBookDTO> resultDTO = depositQueryController.pageQueryAccountBook(bookParam);

        System.out.println(resultDTO);
    }

}
