package com.pajk.plutus.test.ut.biz.manager.voucher;

import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDAO;
import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDeliveryDAO;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fuyongda on 2017/12/28.
 * Modified by fuyongda on 2017/12/28.
 */
public class QueryVoucherDetailUT extends BaseVoucherManagerUT {

    @Test(description = "单据不存在")
    public void test1() {
        Mockito.doReturn(null).when(voucherMapper).queryBySellerAndId(defaultSellerId, voucherId);

        ResultDTO<VoucherDO> resultDTO = voucherManager.queryVoucherDetail(defaultSellerId, voucherId, userParam);

        assertThat(resultDTO.isSuccess()).isFalse();
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.VOUCHER_NOT_EXISTS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.VOUCHER_NOT_EXISTS.getDesc());
        assertThat(resultDTO.getModel()).isNull();
    }

    @Test(description = "缴费单")
    public void test2() {
        String evidenceFlow = "1q2w3e4r5t";
        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setVoucherType(VoucherType.PAYMENT.getCode());
        voucherDAO.setExtPropsStr(";evidenceFlow:" + evidenceFlow + ";");
        Mockito.doReturn(voucherDAO).when(voucherMapper).queryBySellerAndId(defaultSellerId, voucherId);

        ResultDTO<VoucherDO> resultDTO = voucherManager.queryVoucherDetail(defaultSellerId, voucherId, userParam);

        assertThat(resultDTO.isSuccess()).isTrue();
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(resultDTO.getModel()).isNotNull();
        assertThat(resultDTO.getModel().getPaymentPropDO()).isNotNull();
        assertThat(resultDTO.getModel().getPaymentPropDO().getEvidenceFlow()).isEqualTo(evidenceFlow);
    }

    @Test(description = "违规单据违规发货扩展属性不存在")
    public void test3() {
        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setVoucherType(VoucherType.VIOLATION.getCode());
        voucherDAO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION.getCode());
        Mockito.doReturn(voucherDAO).when(voucherMapper).queryBySellerAndId(defaultSellerId, voucherId);

        Mockito.doReturn(null).when(voucherDeliveryMapper).queryByVoucherId(voucherId);

        ResultDTO<VoucherDO> resultDTO = voucherManager.queryVoucherDetail(defaultSellerId, voucherId, userParam);

        assertThat(resultDTO.isSuccess()).isFalse();
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.VOUCHER_DELIVERY_NOT_EXISTS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.VOUCHER_DELIVERY_NOT_EXISTS.getDesc());
        assertThat(resultDTO.getModel()).isNull();
    }

    @Test(description = "违规单，不是发货延迟")
    public void test4() {
        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setVoucherType(VoucherType.VIOLATION.getCode());
        voucherDAO.setVoucherSubType(VoucherSubType.FAKE_VIOLATION.getCode());
        Mockito.doReturn(voucherDAO).when(voucherMapper).queryBySellerAndId(defaultSellerId, voucherId);

        ResultDTO<VoucherDO> resultDTO = voucherManager.queryVoucherDetail(defaultSellerId, voucherId, userParam);

        assertThat(resultDTO.isSuccess()).isTrue();
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(resultDTO.getModel()).isNotNull();
        assertThat(resultDTO.getModel().getVoucherDeliveryDO()).isNull();
    }

    @Test(description = "其他单据类型")
    public void test5() {
        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setVoucherType(VoucherType.UNKNOWN.getCode());
        Mockito.doReturn(voucherDAO).when(voucherMapper).queryBySellerAndId(defaultSellerId, voucherId);

        ResultDTO<VoucherDO> resultDTO = voucherManager.queryVoucherDetail(defaultSellerId, voucherId, userParam);

        assertThat(resultDTO.isSuccess()).isTrue();
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(resultDTO.getModel()).isNotNull();
        assertThat(resultDTO.getModel().getVoucherDeliveryDO()).isNull();
    }

    @Test(description = "违规单，发货延迟，成功")
    public void test6() {
        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setVoucherType(VoucherType.VIOLATION.getCode());
        voucherDAO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION.getCode());
        Mockito.doReturn(voucherDAO).when(voucherMapper).queryBySellerAndId(defaultSellerId, voucherId);

        VoucherDeliveryDAO voucherDeliveryDAO = new VoucherDeliveryDAO();
        Mockito.doReturn(voucherDeliveryDAO).when(voucherDeliveryMapper).queryByVoucherId(voucherId);

        ResultDTO<VoucherDO> resultDTO = voucherManager.queryVoucherDetail(defaultSellerId, voucherId, userParam);

        assertThat(resultDTO.isSuccess()).isTrue();
        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(resultDTO.getModel()).isNotNull();
        assertThat(resultDTO.getModel().getVoucherDeliveryDO()).isNotNull();
    }

}
