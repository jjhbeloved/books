package com.pajk.plutus.test.ut.biz.service.web.depositquerycontroller;

import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherMapper;
import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.dao.repo.impl.VoucherQueryRepositoryImpl;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDAO;
import com.pajk.plutus.biz.model.param.restapi.PageQueryVoucherParam;
import com.pajk.plutus.biz.model.result.dto.voucher.VoucherSummaryDTO;
import com.pajk.plutus.biz.service.web.DepositQueryController;
import com.pajk.plutus.client.model.enums.voucher.VoucherStatus;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseWebServiceUT;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fuyongda on 2017/12/29.
 * Modified by fuyongda on 2017/12/29.
 */
public class PageQueryVoucherUT extends BaseWebServiceUT {

    @InjectMocks
    private DepositQueryController depositQueryController = new DepositQueryController();

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @InjectMocks
    @Spy
    private VoucherQueryRepository voucherQueryRepository = new VoucherQueryRepositoryImpl();

    @Mock
    private VoucherMapper voucherMapper;

    @Mock
    private ControlCache controlCache;

    private String role = "SELLER_OP";
    private AppResourceDO appResourceDO = new AppResourceDO();
    private SellerDO sellerDO = new SellerDO();

    @Test(description = "分页查询->超过最大数量")
    public void test1() {
        mockitoPermissionOk();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        pageQueryVoucherParam.setPageSize(200000);
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.PAGE_SIZE_OUT_OF_MAX_VALUE.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.PAGE_SIZE_OUT_OF_MAX_VALUE.getDesc());
    }

    @Test(description = "分页查询 pageNo错误 返回->超过最大数量")
    public void test2() {
        mockitoPermissionOk();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        pageQueryVoucherParam.setPageNo(-2);
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.PARAM_ERROR.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.PARAM_ERROR.getDesc());
    }

    @Test(description = "voucherType 参数错误")
    public void test3() {
        mockitoPermissionOk();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        pageQueryVoucherParam.setVoucherType(VoucherType.UNKNOWN.getCode());
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.PARAM_ERROR.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.PARAM_ERROR.getDesc());
    }

    @Test(description = "voucherSubType 参数错误")
    public void test4() {
        mockitoPermissionOk();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        pageQueryVoucherParam.setVoucherSubType(VoucherSubType.UNKNOWN.getCode());
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.PARAM_ERROR.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.PARAM_ERROR.getDesc());
    }

    @Test(description = "commitEndDate > commitStartDate 参数错误")
    public void test5() {
        mockitoPermissionOk();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        pageQueryVoucherParam.setVoucherId(null);
        pageQueryVoucherParam.setVoucherSubType(-1);
        pageQueryVoucherParam.setCommitStart("2017-12-28");
        pageQueryVoucherParam.setCommitEnd("2017-12-21");
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.PARAM_ERROR.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.PARAM_ERROR.getDesc());
    }

    @Test(description = "commitEndDate is null, commitStartDate is not null, voucherId is empty, nodeKey is all, " +
            "keyStr is not empty, VoucherType.Payment")
    public void test6() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        mockData();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        pageQueryVoucherParam.setVoucherSubType(-1);
        pageQueryVoucherParam.setCommitEnd(null);
        pageQueryVoucherParam.setVoucherId(null);
        pageQueryVoucherParam.setVoucherType(VoucherType.PAYMENT.getCode());
        pageQueryVoucherParam.setNodeKey("all");
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "commitEndDate is null, commitStartDate is null, voucherSubType == -1")
    public void test7() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        mockData();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        pageQueryVoucherParam.setVoucherSubType(-1);
        pageQueryVoucherParam.setVoucherId(null);
        pageQueryVoucherParam.setCommitEnd(null);
        pageQueryVoucherParam.setCommitStart(null);
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "commitEndDate is not null, commitStartDate is null, status is empty, " +
            "keyStr is empty, VoucherType.Payment")
    public void test8() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        mockData();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        pageQueryVoucherParam.setKeyStr(null);
        pageQueryVoucherParam.setVoucherType(VoucherType.PAYMENT.getCode());
        pageQueryVoucherParam.setCommitStart(null);
        pageQueryVoucherParam.setVoucherId(null);
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "createEndDate > createStartDate 参数错误")
    public void test9() {
        mockitoPermissionOk();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        pageQueryVoucherParam.setVoucherSubType(-1);
        pageQueryVoucherParam.setCreateStart("2017-12-28");
        pageQueryVoucherParam.setCreateEnd("2017-12-21");
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.PARAM_ERROR.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.PARAM_ERROR.getDesc());
    }

    @Test(description = "createEndDate is null, createStartDate is not null, keyStr is empty, VoucherType.VIOLATION")
    public void test10() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        mockData();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        pageQueryVoucherParam.setKeyStr(null);
        pageQueryVoucherParam.setVoucherType(VoucherType.VIOLATION.getCode());
        pageQueryVoucherParam.setCreateEnd(null);
        pageQueryVoucherParam.setVoucherId(null);
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "createEndDate is null, createStartDate is null, voucherSubType == -1, " +
            "keyStr is not empty, VoucherType.Payment")
    public void test11() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        mockData();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        pageQueryVoucherParam.setVoucherSubType(-1);
        pageQueryVoucherParam.setCreateEnd(null);
        pageQueryVoucherParam.setCreateStart(null);
        pageQueryVoucherParam.setVoucherId(null);
        pageQueryVoucherParam.setVoucherType(VoucherType.PAYMENT.getCode());
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "createEndDate is not null, createStartDate is null, keyStr is not empty, VoucherType.VIOLATION")
    public void test12() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        mockData();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        pageQueryVoucherParam.setVoucherType(VoucherType.VIOLATION.getCode());
        pageQueryVoucherParam.setCreateStart(null);
        pageQueryVoucherParam.setVoucherId(null);
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "createEndDate is null, createStartDate is null, commitEndDate is null, commitStartDate is null")
    public void test13() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        mockData();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        pageQueryVoucherParam.setCreateStart(null);
        pageQueryVoucherParam.setCreateEnd(null);
        pageQueryVoucherParam.setCommitStart(null);
        pageQueryVoucherParam.setCommitEnd(null);
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "status is all")
    public void test14() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        mockData();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        pageQueryVoucherParam.setNodeKey("all");
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "appResource is null")
    public void test15() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(null);

        mockSellerDO(sellerDO);

        mockData();

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "role匹配，显示操作按钮")
    public void test16() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        Mockito.doReturn(1).when(voucherMapper).pageQueryCount(Matchers.any());

        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setRole(role);

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
        assertThat(result.getModel().get(0)).isNotNull();
        assertThat(result.getModel().get(0).getButtons()).isNotNull();
        assertThat(result.getModel().get(0).getButtons().size()).isEqualTo(1);
    }

    @Test(description = "role不匹配, 流程实例id为空, 未删除, 状态是已创建, subType是假货")
    public void test17() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        Mockito.doReturn(1).when(voucherMapper).pageQueryCount(Matchers.any());

        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setProcInstId(null);
        voucherDAO.setIsDeleted(0);
        voucherDAO.setNodeKey(VoucherStatus.CREATED.getCode());
        voucherDAO.setVoucherSubType(VoucherSubType.FAKE_VIOLATION.getCode());

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "role不匹配, 流程实例id为空, 未删除, 状态是已创建, subType是虚假宣传")
    public void test18() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        Mockito.doReturn(1).when(voucherMapper).pageQueryCount(Matchers.any());

        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setProcInstId(null);
        voucherDAO.setIsDeleted(0);
        voucherDAO.setNodeKey(VoucherStatus.CREATED.getCode());
        voucherDAO.setVoucherSubType(VoucherSubType.FALSE_CONDUCT_VIOLATION.getCode());

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "role不匹配, 流程实例id为空, 未删除, 状态不是已创建, subType是假货")
    public void test19() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        Mockito.doReturn(1).when(voucherMapper).pageQueryCount(Matchers.any());

        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setProcInstId(null);
        voucherDAO.setIsDeleted(0);
        voucherDAO.setNodeKey(VoucherStatus.DELETED.getCode());
        voucherDAO.setVoucherSubType(VoucherSubType.FAKE_VIOLATION.getCode());

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "role不匹配, 流程实例id为空, 未删除, 状态不是已创建, subType是虚假宣传")
    public void test20() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        Mockito.doReturn(1).when(voucherMapper).pageQueryCount(Matchers.any());

        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setProcInstId(null);
        voucherDAO.setIsDeleted(0);
        voucherDAO.setNodeKey(VoucherStatus.DELETED.getCode());
        voucherDAO.setVoucherSubType(VoucherSubType.FALSE_CONDUCT_VIOLATION.getCode());

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "role不匹配, 流程实例id为空, 已删除, 状态是已创建, subType是假货")
    public void test21() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        Mockito.doReturn(1).when(voucherMapper).pageQueryCount(Matchers.any());

        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setProcInstId(null);
        voucherDAO.setIsDeleted(1);
        voucherDAO.setNodeKey(VoucherStatus.CREATED.getCode());
        voucherDAO.setVoucherSubType(VoucherSubType.FAKE_VIOLATION.getCode());

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "role不匹配, 流程实例id为空, 已删除, 状态是已创建, subType是虚假宣传")
    public void test22() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        Mockito.doReturn(1).when(voucherMapper).pageQueryCount(Matchers.any());

        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setProcInstId(null);
        voucherDAO.setIsDeleted(1);
        voucherDAO.setNodeKey(VoucherStatus.CREATED.getCode());
        voucherDAO.setVoucherSubType(VoucherSubType.FALSE_CONDUCT_VIOLATION.getCode());

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "role不匹配, 流程实例id不为空, 未删除, 状态是已创建, subType是假货")
    public void test23() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        Mockito.doReturn(1).when(voucherMapper).pageQueryCount(Matchers.any());

        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setProcInstId("1234");
        voucherDAO.setIsDeleted(0);
        voucherDAO.setNodeKey(VoucherStatus.CREATED.getCode());
        voucherDAO.setVoucherSubType(VoucherSubType.FAKE_VIOLATION.getCode());

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "role不匹配, 流程实例id不为空, 未删除, 状态是已创建, subType是虚假宣传")
    public void test24() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        mockSellerDO(sellerDO);

        Mockito.doReturn(1).when(voucherMapper).pageQueryCount(Matchers.any());

        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setProcInstId("1234");
        voucherDAO.setIsDeleted(0);
        voucherDAO.setNodeKey(VoucherStatus.CREATED.getCode());
        voucherDAO.setVoucherSubType(VoucherSubType.FALSE_CONDUCT_VIOLATION.getCode());

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "查询seller失败")
    public void test25() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        KyCallResult<SellerDO> kyCallResult = new KyCallResult<>();
        kyCallResult.setSuccess(false);
        Mockito.doReturn(kyCallResult).when(sellerService).getSellerById(Matchers.anyLong());

        Mockito.doReturn(1).when(voucherMapper).pageQueryCount(Matchers.any());

        VoucherDAO voucherDAO = new VoucherDAO();

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
    }

    @Test(description = "查询seller成功")
    public void test26() {
        mockitoPermissionOk();

        mockitoCurrentUserRoleOK(role);

        mockAppResourceDO(appResourceDO);

        SellerDO sellerDO = new SellerDO();
        sellerDO.setName("seller");
        mockSellerDO(sellerDO);

        Mockito.doReturn(1).when(voucherMapper).pageQueryCount(Matchers.any());

        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setRole(role);

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());

        PageQueryVoucherParam pageQueryVoucherParam = this.buildPageQueryVoucherParam();
        PageResultDTO<VoucherSummaryDTO> result = depositQueryController.pageQueryVoucher(pageQueryVoucherParam);

        assertThat(result.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(result.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
        assertThat(result.getModel().size()).isEqualTo(1);
        assertThat(result.getModel().get(0)).isNotNull();
        assertThat(result.getModel().get(0).getButtons()).isNotNull();
        assertThat(result.getModel().get(0).getButtons().size()).isEqualTo(1);
        assertThat(result.getModel().get(0).getSellerName()).isEqualTo("seller");
    }

    private void mockData() {
        Mockito.doReturn(1).when(voucherMapper).pageQueryCount(Matchers.any());

        VoucherDAO voucherDAO = new VoucherDAO();

        List<VoucherDAO> list = new LinkedList<>();
        list.add(voucherDAO);
        Mockito.doReturn(list).when(voucherMapper).pageQuery(Matchers.any());
    }

    private PageQueryVoucherParam buildPageQueryVoucherParam() {
        String voucherId = "1221";
        String nodeCatKey = "sellerDeal";
        int pageSize = 20;
        int pageNo = 1;
        String commitStart = "2017-12-10";
        String commitEnd = "2017-12-28";
        String createStart = "2017-12-10";
        String createEnd = "2017-12-28";
        int voucherType = VoucherType.VIOLATION.getCode();
        int voucherSubType = VoucherSubType.DELAY_DELIVERY_VIOLATION.getCode();
        String keyStr = "keyStr";

        PageQueryVoucherParam pageQueryVoucherParam = new PageQueryVoucherParam();
        pageQueryVoucherParam.setCommitStart(commitStart);
        pageQueryVoucherParam.setCommitEnd(commitEnd);
        pageQueryVoucherParam.setCreateEnd(createEnd);
        pageQueryVoucherParam.setCreateStart(createStart);
        pageQueryVoucherParam.setNodeKey(nodeCatKey);
        pageQueryVoucherParam.setPageNo(pageNo);
        pageQueryVoucherParam.setPageSize(pageSize);
        pageQueryVoucherParam.setVoucherType(voucherType);
        pageQueryVoucherParam.setVoucherSubType(voucherSubType);
        pageQueryVoucherParam.setVoucherId(voucherId);
        pageQueryVoucherParam.setSellerId(defaultSellerId);
        pageQueryVoucherParam.setKeyStr(keyStr);
        return pageQueryVoucherParam;
    }

}
