package com.pajk.plutus.test.ut.biz.service.gw;

import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.common.util.ResultUtil;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.BillManager;
import com.pajk.plutus.biz.model.bill.*;
import com.pajk.plutus.biz.service.gw.BillQueryGWServiceImpl;
import com.pajk.plutus.client.api.gw.BillQueryGWService;
import com.pajk.plutus.client.model.enums.bill.BillType;
import com.pajk.plutus.client.model.enums.bill.SettlementType;
import com.pajk.plutus.client.model.enums.trade.PayToType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.client.model.result.gw.bill.ConfirmSettlementGW;
import com.pajk.plutus.client.model.result.gw.bill.PageSettlementGW;
import com.pajk.plutus.client.model.result.gw.bill.SettlementOrderGW;
import com.pajk.plutus.test.ut.BaseGwServiceUT;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import net.pocrd.dubboext.DubboExtProperty;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.testng.annotations.Test;
import org.testng.collections.Lists;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

/**
 * @author david
 * @since created by on 17/12/18 11:04
 */
public class BillQueryGWServiceImplUT extends BaseGwServiceUT {

    @InjectMocks
    private BillQueryGWService billQueryGWService = new BillQueryGWServiceImpl();

    @Mock
    private BillManager billManager;

    @Mock
    private ControlCache controlCache;

    private long sellerId = 700009L;

    private String role = "admin";
    private String defaultKey = "admin";
    private String key = "adminX";

    @Test
    public void testQuerySettlement() {
        long billId = 1L;
        long appId = 1L;
        long userId = 1L;
        long domainId = 3L;

        mockitoPermissionOk();

        ResultDTO<BillSettlementDO> resultDTO = ResultUtil.returnResultDTO(ErrorCode.ERROR);
        doReturn(resultDTO).when(billManager).querySettlement(anyLong(), anyLong());

        SettlementOrderGW settlementOrderGW = billQueryGWService.querySettlement(appId, userId, domainId, sellerId, billId);
        assert settlementOrderGW == null;

        BillSettlementDO billSettlementDO = createBillSettlement();
        resultDTO = new ResultDTO<>(billSettlementDO);
        doReturn(resultDTO).when(billManager).querySettlement(anyLong(), anyLong());
        settlementOrderGW = billQueryGWService.querySettlement(appId, userId, domainId, sellerId, billId);
        assert settlementOrderGW != null;

        billSettlementDO.setBillSettlementItemDOS(Lists.newArrayList());
        resultDTO = new ResultDTO<>(billSettlementDO);
        doReturn(resultDTO).when(billManager).querySettlement(anyLong(), anyLong());
        settlementOrderGW = billQueryGWService.querySettlement(appId, userId, domainId, sellerId, billId);
        assert settlementOrderGW == null;
    }

    @Test
    public void testQueryConfirmSettlement() throws Exception {
        long billId = 1L;
        long appId = 1L;
        long userId = 1L;
        long domainId = 3L;

        mockitoPermissionOk();

        DubboExtProperty.clearNotificaitons();
        ResultDTO<BillSettlementDO> resultDTO = ResultUtil.returnResultDTO(ErrorCode.ERROR);
        doReturn(resultDTO).when(billManager).queryConfirmSettlement(anyLong(), anyLong());
        ConfirmSettlementGW confirmSettlementGW = billQueryGWService.queryConfirmSettlement(appId, userId, domainId, sellerId, billId);
        assert confirmSettlementGW == null;
        DubboExtProperty.clearNotificaitons();

        resultDTO = new ResultDTO<>();
        BillSettlementDO billSettlementDO = new BillSettlementDO();
        resultDTO.setModel(billSettlementDO);
        doReturn(resultDTO).when(billManager).queryConfirmSettlement(anyLong(), anyLong());
        confirmSettlementGW = billQueryGWService.queryConfirmSettlement(appId, userId, domainId, sellerId, billId);
        assert confirmSettlementGW == null;
        DubboExtProperty.clearNotificaitons();

        mockitoCurrentUserRoleOK(role);

        mockitoGetDefaltButtons();
        billSettlementDO = createBillSettlement();
        billSettlementDO.setProcInstId(null);
        resultDTO.setModel(billSettlementDO);
        doReturn(resultDTO).when(billManager).queryConfirmSettlement(anyLong(), anyLong());
        confirmSettlementGW = billQueryGWService.queryConfirmSettlement(appId, userId, domainId, sellerId, billId);
        assert Objects.equals(confirmSettlementGW.actionButtons.get(0).key, defaultKey);
        DubboExtProperty.clearNotificaitons();

        billSettlementDO = createBillSettlement();
        resultDTO.setModel(billSettlementDO);
        doReturn(resultDTO).when(billManager).queryConfirmSettlement(anyLong(), anyLong());
        mockitoGetButtons();
        confirmSettlementGW = billQueryGWService.queryConfirmSettlement(appId, userId, domainId, sellerId, billId);
        assert Objects.equals(confirmSettlementGW.actionButtons.get(0).key, key);
        DubboExtProperty.clearNotificaitons();

        billSettlementDO.setRole("xb");
        confirmSettlementGW = billQueryGWService.queryConfirmSettlement(appId, userId, domainId, sellerId, billId);
        assert confirmSettlementGW.actionButtons.size() == 0;
        DubboExtProperty.clearNotificaitons();
    }

    @Test
    public void testPageQuerySettlement() throws Exception {
    }

    private BillSettlementDO createBillSettlement() {
        BillSettlementDO billSettlementDO = new BillSettlementDO();
        billSettlementDO.setSettlementType(SettlementType.PA_PAY.getCode());
        billSettlementDO.setPayToType(PayToType.PAY_TO_PLATFORM.getCode());
        billSettlementDO.setBillAmt(22L);
        billSettlementDO.setActualBillAmt(22L);
        billSettlementDO.setBillAmt(22L);
        billSettlementDO.setRole(role);
        billSettlementDO.setProcInstId(333L);

        BillSettlementItemDO billSettlementItemDO = new BillSettlementItemDO();
        billSettlementItemDO.setId(123L);
        billSettlementItemDO.setBillId(123L);
        billSettlementItemDO.setBillAmt(123L);
        billSettlementItemDO.setActualBillAmt(123L);
        billSettlementItemDO.setBillType(BillType.ITEM_COST.getCode());
        billSettlementDO.setBillSettlementItemDOS(Lists.newArrayList(billSettlementItemDO));

        ConfirmInfoDO confirmInfoDO = new ConfirmInfoDO();
        billSettlementDO.setConfirmInfoDO(confirmInfoDO);

        InvoiceInfoDO invoiceInfoDO = new InvoiceInfoDO();
        billSettlementDO.setInvoiceInfoDO(invoiceInfoDO);

        List<PaymentInfoDO> paymentInfoDOS = Lists.newArrayList(new PaymentInfoDO());
        billSettlementDO.setPaymentInfoDOS(paymentInfoDOS);

        InvoiceInfoSnapshotDO invoiceInfoSnapshotDO = new InvoiceInfoSnapshotDO();
        billSettlementDO.setInvoiceInfoSnapshotDO(invoiceInfoSnapshotDO);

        AccountInfoSnapshotDO accountInfoSnapshotDO = new AccountInfoSnapshotDO();
        billSettlementDO.setAccountInfoSnapshotDO(accountInfoSnapshotDO);

        SettlementOperationDO settlementOperationDO = new SettlementOperationDO();
        settlementOperationDO.setOperationVote("x");
        settlementOperationDO.setOperationStartTime(new Date());
        settlementOperationDO.setOperationEndTime(new Date());
        List<SettlementOperationDO> settlementOperationGWS = Lists.newArrayList(settlementOperationDO);
        billSettlementDO.setSettlementOperationDOS(settlementOperationGWS);
        return billSettlementDO;
    }

    private void mockitoGetDefaltButtons() {
        ButtonDO buttonDO = new ButtonDO();
        buttonDO.setKey(defaultKey);
        List<ButtonDO> buttonDOS = Lists.newArrayList(buttonDO);
        BatchResultDTO<ButtonDO> resultDTO = new BatchResultDTO<>(buttonDOS);
        doReturn(resultDTO).when(billManager).getDefaultButtons();
    }

    private void mockitoGetButtons() {
        ButtonDO buttonDO = new ButtonDO();
        buttonDO.setKey(key);
        List<ButtonDO> buttonDOS = Lists.newArrayList(buttonDO);
        BatchResultDTO<ButtonDO> resultDTO = new BatchResultDTO<>(buttonDOS);
        doReturn(resultDTO).when(billManager).getButtons(anyLong(), anyString());
    }

    @Test
    public void checkDate() {
        final long userId = 10000L;
        final long sellerId = 100L;
        final long appId = 1L;
        final long domainId = 10L;
        String startTime = "";
        String endTime = "2017-12";
        String role = "SELLER_OP";
        when(controlCache.getBillSettlementQueryDaySpan()).thenReturn(367);
        when(controlCache.getBillSettlementQueryDayInterval()).thenReturn(365);

        PageSettlementGW pageSettlementGW;
        final KyCallResult<String> stringKyCallResult = new KyCallResult<>();
        stringKyCallResult.setSuccess(true);
        stringKyCallResult.setModel(role);
        when(permissionService.getCurRole(anyLong(), anyLong())).thenReturn(stringKyCallResult);
        pageSettlementGW = billQueryGWService.pageQuerySettlement(
                appId, userId, domainId, sellerId, startTime, endTime, 1, 10);
        assertThat(pageSettlementGW).isNull();
//        assertThat(e.getMessage()).contains("null start or end time");

        startTime = "2018-01";
        pageSettlementGW = billQueryGWService.pageQuerySettlement(
                appId, userId, domainId, sellerId, startTime, endTime, 1, 10);
        assertThat(pageSettlementGW).isNull();
//        assertThat(e.getMessage()).contains("start time is behind end time");

        startTime = "2008-01";
        endTime = "2008-12";
        pageSettlementGW = billQueryGWService.pageQuerySettlement(
                appId, userId, domainId, sellerId, startTime, endTime, 1, 10);
        assertThat(pageSettlementGW).isNull();
//        assertThat(e.getMessage()).contains("query start time is earlier than limit");

        startTime = "2016-01";
        endTime = "2017-12";
        pageSettlementGW = billQueryGWService.pageQuerySettlement(
                appId, userId, domainId, sellerId, startTime, endTime, 1, 10);
        assertThat(pageSettlementGW).isNull();
//        assertThat(e.getMessage()).contains("query interval is longer than threshold");
    }
}