package com.pajk.plutus.test.ut.biz.manager.voucher;

import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDAO;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.taskcenter.client.model.dto.*;
import com.pajk.taskcenter.client.model.result.BatchResult;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fuyongda on 2018/1/4.
 * Modified by fuyongda on 2018/1/4.
 */
public class SellerConfirmPaymentUT extends BaseVoucherManagerUT {

    private String transitionKey = "transitionKey";
    private String nodeKey = "nodeKey";
    private String remark = "remark";
    private String evidenceFlow = "evidenceFlow";
    private String evidenceFile = "evidenceFile";
    private String role = "role";
    private String path = "path";

    @Test(description = "缴费单不存在")
    public void test1() {
        ResultDTO<VoidEntity> resultDTO = voucherManager.sellerConfirmPayment(defaultSellerId, voucherId,
                transitionKey, nodeKey, remark, evidenceFlow, evidenceFile, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.VOUCHER_NOT_EXISTS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.VOUCHER_NOT_EXISTS.getDesc());
    }

    @Test(description = "审批前置检查失败")
    public void test2() {
        mockData();

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        ResultDTO<VoidEntity> resultDTO = voucherManager.sellerConfirmPayment(defaultSellerId, voucherId,
                transitionKey, nodeKey, remark, evidenceFlow, evidenceFile, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.NO_PERMISSION_TO_OPT.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.NO_PERMISSION_TO_OPT.getDesc());
    }

    @Test(description = "审批前置检查失败")
    public void test3() {
        mockData();

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        ResultDTO<VoidEntity> resultDTO = voucherManager.sellerConfirmPayment(defaultSellerId, voucherId,
                transitionKey, "", remark, evidenceFlow, evidenceFile, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.STATUS_NOT_MATCH.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.STATUS_NOT_MATCH.getDesc());
    }

    @Test(description = "审批任务失败")
    public void test4() {
        mockData();

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        mockFlowCompleteTask(false);

        userParam.setPath(path);
        ResultDTO<VoidEntity> resultDTO = voucherManager.sellerConfirmPayment(defaultSellerId, voucherId,
                transitionKey, nodeKey, remark, evidenceFlow, evidenceFile, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.PROCESS_COMPLETE.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.PROCESS_COMPLETE.getDesc());
    }

    @Test(description = "审批任务成功, remark is blank, evidenceFile is blank, evidenceFlow is blank, 更新voucher失败")
    public void test5() {
        mockData();

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        mockFlowCompleteTask(true);

        userParam.setPath(path);
        ResultDTO<VoidEntity> resultDTO = voucherManager.sellerConfirmPayment(defaultSellerId, voucherId,
                transitionKey, nodeKey, "", "", "", userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.STORE_DB_FAILED.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(" confirmPayment voucher fail.");
    }

    @Test(description = "成功")
    public void test6() {
        mockData();

        mockitoCurrentUserRoleOK(role);

        mockFlowGetNodeInfoList();

        mockFlowCompleteTask(true);

        Mockito.doReturn(1).when(voucherMapper).updateByOPT(Matchers.any());

        userParam.setPath(path);
        ResultDTO<VoidEntity> resultDTO = voucherManager.sellerConfirmPayment(defaultSellerId, voucherId,
                transitionKey, nodeKey, remark, evidenceFlow, evidenceFile, userParam);

        assertThat(resultDTO.getResultCode()).isEqualTo(ErrorCode.SUCCESS.getCode());
        assertThat(resultDTO.getResultMsg()).isEqualTo(ErrorCode.SUCCESS.getDesc());
    }

    private void mockFlowCompleteTask(boolean success) {
        TaskInstDTO taskInstDTO = new TaskInstDTO();

        List<TaskInstDTO> taskInstDTOList = new LinkedList<>();
        taskInstDTOList.add(taskInstDTO);

        CompleteTaskResultDTO completeTaskResultDTO = new CompleteTaskResultDTO();
        completeTaskResultDTO.setTaskInstDTOList(taskInstDTOList);

        List<CompleteTaskResultDTO> list = new LinkedList<>();
        list.add(completeTaskResultDTO);

        BatchResult<CompleteTaskResultDTO> batchResultDTO = new BatchResult<>();
        batchResultDTO.setSuccess(success);
        batchResultDTO.setModel(list);

        Mockito.doReturn(batchResultDTO).when(flowService).completeTask(Matchers.any());
    }

    private void mockData() {
        VoucherDAO voucherDAO = new VoucherDAO();
        voucherDAO.setRole(role);
        voucherDAO.setNodeKey(nodeKey);
        voucherDAO.setExtProps(new HashMap<>());
        Mockito.doReturn(voucherDAO).when(voucherMapper).queryBySellerAndId(defaultSellerId, voucherId);

        AccountBookDAO accountBookDAO = new AccountBookDAO();

        List<AccountBookDAO> list = new LinkedList<>();
        list.add(accountBookDAO);
        Mockito.doReturn(list).when(accountBookMapper).queryBySeller(defaultSellerId);
    }

    private void mockFlowGetNodeInfoList() {
        TransitionDTO transitionDTO = new TransitionDTO();
        transitionDTO.setTransitionKey(transitionKey);

        List<TransitionDTO> transitionDTOS = new LinkedList<>();
        transitionDTOS.add(transitionDTO);

        NodeDTO nodeDTO = new NodeDTO();
        nodeDTO.setPath(path);
        nodeDTO.setTransitionDTOList(transitionDTOS);

        GetNodeInfoResultDTO getNodeInfoResultDTO = new GetNodeInfoResultDTO();
        getNodeInfoResultDTO.setNodeDTO(nodeDTO);

        List<GetNodeInfoResultDTO> list = new LinkedList<>();
        list.add(getNodeInfoResultDTO);

        BatchResult<GetNodeInfoResultDTO> batchResult = new BatchResult<>();
        batchResult.setSuccess(true);
        batchResult.setModel(list);

        Mockito.doReturn(batchResult).when(flowService).getNodeInfoList(Matchers.any());
    }

}
