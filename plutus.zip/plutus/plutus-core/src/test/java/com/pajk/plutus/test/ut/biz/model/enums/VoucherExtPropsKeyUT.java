package com.pajk.plutus.test.ut.biz.model.enums;

import com.pajk.plutus.biz.model.enums.VoucherExtPropsKey;
import com.pajk.plutus.test.ut.BaseServiceUT;
import org.testng.annotations.Test;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by lizhijun on 2018/1/3.
 */
public class VoucherExtPropsKeyUT extends BaseServiceUT {


    @Test
    public void test(){
        VoucherExtPropsKey voucherExtPropsKey = VoucherExtPropsKey.EVIDENCE_FLOW;
        assertThat(voucherExtPropsKey.getCode()).isEqualTo(VoucherExtPropsKey.EVIDENCE_FLOW.getCode());
        assertThat(voucherExtPropsKey.getDesc()).isEqualTo(VoucherExtPropsKey.EVIDENCE_FLOW.getDesc());
        assertThat(voucherExtPropsKey.isEquals(VoucherExtPropsKey.EVIDENCE_FLOW.getCode())).isTrue();
        assertThat(voucherExtPropsKey.isEquals(VoucherExtPropsKey.EVIDENCE_FLOW)).isTrue();
        VoucherExtPropsKey voucherExtPropsKey2 = null;
        assertThat(voucherExtPropsKey.isEquals(voucherExtPropsKey2)).isFalse();
        assertThat(VoucherExtPropsKey.containKey(voucherExtPropsKey.getCode())).isTrue();
        assertThat(VoucherExtPropsKey.containKey("code")).isFalse();
    }
}
