package com.pajk.plutus.test.ut.biz.model.enums;

import com.pajk.plutus.biz.model.enums.FlowTypeEnum;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 18/1/4.
 * Modify by fanhuafeng on 18/1/4
 */
public class FlowTypeEnumUT {



    @Test
    public void test01(){

        FlowTypeEnum a0 = null;
        FlowTypeEnum a1 = FlowTypeEnum.BILL;
        FlowTypeEnum a2 = FlowTypeEnum.PAYMENT;



        assertThat(FlowTypeEnum.BILL.isEquals(a0)).isFalse();
        assertThat(FlowTypeEnum.BILL.isEquals(a2)).isFalse();
        assertThat(FlowTypeEnum.BILL.isEquals(a1)).isTrue();

        a2.getDesc();


    }


    @Test
    public void test02(){
        String code = "test";
        FlowTypeEnum a0 = FlowTypeEnum.valueOfCode(code);
        assertThat(a0.isEquals(FlowTypeEnum.UNKNOWN)).isTrue();
    }
}
