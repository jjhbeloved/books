package com.pajk.plutus.test.ut.biz.common.util.commonutil;

import com.pajk.plutus.biz.common.util.CommonUtil;
import org.testng.annotations.Test;

import static org.assertj.core.api.Java6Assertions.assertThat;

/**
 * Created by lizhijun on 2018/1/4.
 */
public class CheckFileUT {
    @Test
    public void test(){
        assertThat( CommonUtil.checkFile(null)).isFalse();
        assertThat( CommonUtil.checkFile("[{}]")).isFalse();
        assertThat( CommonUtil.checkFile("[{]")).isFalse();
    }
}
