package com.pajk.plutus.test.ut.biz.service.gw.deposigwservice;

import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.dao.repo.VoucherRepository;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.impl.VoucherManagerImpl;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.service.gw.DepositGWServiceImpl;
import com.pajk.plutus.client.api.gw.DepositGWService;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.VoidGwEntity;
import com.pajk.plutus.test.ut.BaseGwServiceUT;
import com.pajk.taskcenter.client.model.dto.*;
import com.pajk.taskcenter.client.model.result.BatchResult;
import org.apache.commons.lang3.math.NumberUtils;
import org.mockito.*;
import org.testng.annotations.Test;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by lizhijun on 2017/12/29.
 */
public class SellerDealPunishUT extends BaseGwServiceUT {

    @InjectMocks
    private DepositGWService depositGWService = new DepositGWServiceImpl();

    @InjectMocks
    @Spy
    private VoucherManager voucherManager = new VoucherManagerImpl();

    @Mock
    private VoucherRepository voucherRepository;

    @Mock
    private VoucherQueryRepository voucherQueryRepository;

    @Mock
    private AccountQueryRepository accountQueryRepository;

    private static final String voucherId = "10000190";

    private static final long procInstId = 100001L;

    private static final String path = "plutus.sellerDealPunish";

    private static final String transitionKey = "transitionKey1";

    private static final String transitionName = "transitionName1";


    @Test(description = "备注太长")
    public void test1(){
        String transitionKey = "transitionKey";
        String nodeKey = "nodeKey";
        StringBuilder sb = new StringBuilder();
        for (int i = 0 ;i< 100 ;i++){
            sb.append("remark");
        }
        mockitoPermissionOk();
        String evidenceFile="";

        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,sb.toString(),evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(voidGwEntity).isNull();

    }

    @Test(description = "文件格式不对")
    public void test2(){
        String transitionKey = "transitionKey";
        String nodeKey = "nodeKey";
        String remark = "remark";
        mockitoPermissionOk();
        String evidenceFile="[{\"name\":123}]";

        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_PARAM_ERROR);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "没有权限操作:查询角色失败")
    public void test3(){
        String transitionKey = "transitionKey";
        String nodeKey = "nodeKey";
        String remark = "remark";
        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";


        Mockito.doReturn(Optional.of(buildVoucherDO())).when(voucherQueryRepository).queryVoucherById(defaultSellerId,voucherId);
        mockRole("role2",true);


        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_NO_PERMISSION_TO_OPT);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "没有权限操作:角色不匹配")
    public void test4(){
        String transitionKey = "transitionKey";
        String nodeKey = "nodeKey";
        String remark = "remark";
        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey",1,1);

        mockRole("role2",false);

        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_NO_PERMISSION_TO_OPT);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "没有权限操作:节点不对")
    public void test5(){
        String transitionKey = "transitionKey";
        String nodeKey = "nodeKey1";
        String remark = "remark";
        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey2",2,2);

        mockRole("role1",false);

        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_STATUS_NOT_MATCH);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "没有权限操作:获取节点操作信息失败")
    public void test6(){
        String transitionKey = "transitionKey";
        String nodeKey = "nodeKey1";
        String remark = "remark";
        long procInstId = 100001L;
        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",3,3);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,true,false,false,path,transitionKey,transitionName);

        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_NO_PERMISSION_TO_OPT);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "没有权限操作:获取节点操作信息失败")
    public void test7(){
        String nodeKey = "nodeKey1";
        String remark = "remark";
        long procInstId = 100001L;
        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";
        mockVoucher("role1","nodeKey1",4,4);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,false,true,false,path,transitionKey,transitionName);

        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_NO_PERMISSION_TO_OPT);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "没有权限操作:获取节点操作信息失败")
    public void test8(){
        String transitionKey = "transitionKey";
        String nodeKey = "nodeKey1";
        String remark = "remark";
        long procInstId = 100001L;
        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",5,5);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,true,false,false,path,transitionKey,transitionName);


        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_NO_PERMISSION_TO_OPT);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "没有权限操作:获取节点操作信息发生异常")
    public void test9(){
        String transitionKey = "transitionKey";
        String nodeKey = "nodeKey1";
        String remark = "remark";

        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",6,6);

        mockRole("role1",false);

        mockNodeList(nodeKey,true,false,false,false,path,transitionKey,transitionName);


        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_NO_PERMISSION_TO_OPT);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "没有权限操作:操作path不匹配")
    public void test10(){
        String transitionKey = "transitionKey1";
        String nodeKey = "nodeKey1";
        String remark = "remark";

        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",7,7);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,false,false,false,"path1",transitionKey,transitionName);


        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_NO_PERMISSION_TO_OPT);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "没有权限操作:节点和操作不匹配")
    public void test11(){
        String transitionKey = "transitionKey1";
        String nodeKey = "nodeKey1";
        String remark = "remark";

        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",8,8);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,false,false,false,path,"transitionKey2",transitionName);


        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_NO_PERMISSION_TO_OPT);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "没有权限操作:taskCenter节点中操作信息为空")
    public void test12(){
        String transitionKey = "transitionKey1";
        String nodeKey = "nodeKey1";
        String remark = "remark";

        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",9,9);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,false,false,true,path,"transitionKey1",transitionName);


        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_NO_PERMISSION_TO_OPT);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "操作失败:查询账本信息为空")
    public void test13(){
        String transitionKey = "transitionKey1";
        String nodeKey = "nodeKey1";
        String remark = "remark";

        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",10,10);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,false,false,false,path,"transitionKey1",transitionName);

        mockAccountBook(true);


        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_FAILURE);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "操作失败:执行task操作发生异常")
    public void test15(){
        String transitionKey = "transitionKey1";
        String nodeKey = "nodeKey1";
        String remark = "remark";

        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",12,12);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,false,false,false,path,"transitionKey1",transitionName);

        mockAccountBook(false);

        mockCompeteTask(false,true,false,false,false,false,false);


        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_FAILURE);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "操作失败:执行task失败")
    public void test16(){
        String transitionKey = "transitionKey1";
        String nodeKey = "nodeKey1";
        String remark = "remark";

        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",13,13);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,false,false,false,path,"transitionKey1",transitionName);

        mockAccountBook(false);

        mockCompeteTask(true,false,false,false,false,false,false);


        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_FAILURE);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "操作失败:执行task失败,不可nodeEnter")
    public void test17(){
        String transitionKey = "transitionKey1";
        String nodeKey = "nodeKey1";
        String remark = "remark";

        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",14,14);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,false,false,false,path,"transitionKey1",transitionName);

        mockAccountBook(false);

        mockCompeteTask(false,false,true,false,false,false,false);


        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_FAILURE);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "操作失败:执行task失败,可nodeEnter, 执行nodeEnter异常")
    public void test18(){
        String transitionKey = "transitionKey1";
        String nodeKey = "nodeKey1";
        String remark = "remark";

        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",15,15);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,false,false,false,path,"transitionKey1",transitionName);

        mockAccountBook(false);

        mockCompeteTask(false,false,true,true,false,true,false);


        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_FAILURE);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "操作失败:执行task失败,可nodeEnter, 执行nodeEnter失败")
    public void test19(){
        String transitionKey = "transitionKey1";
        String nodeKey = "nodeKey1";
        String remark = "remark";

        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",16,16);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,false,false,false,path,"transitionKey1",transitionName);

        mockAccountBook(false);

        mockCompeteTask(false,false,true,true,true,false,false);


        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_FAILURE);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "操作失败:执行task失败,可nodeEnter, 执行nodeEnter成功,非终结点,更新数据发生异常")
    public void test20(){
        String transitionKey = "transitionKey1";
        String nodeKey = "nodeKey1";
        String remark = "remark";

        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",17,17);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,false,false,false,path,"transitionKey1",transitionName);

        mockAccountBook(false);

        mockCompeteTask(false,false,true,true,false,false,false);

        Mockito.doThrow(new RuntimeException()).when(voucherRepository).auditPunish(Matchers.any(),Matchers.any(),Matchers.any(),Matchers.any());


        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_FAILURE);
        assertThat(voidGwEntity).isNull();
    }

    @Test(description = "执行task失败,可nodeEnter, 执行nodeEnter成功,更新数据库成功")
    public void test21(){
        String transitionKey = "transitionKey1";
        String nodeKey = "nodeKey1";
        String remark = "remark";

        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",0,18);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,false,false,false,path,"transitionKey1",transitionName);

        mockAccountBook(false);

        mockCompeteTask(false,false,true,true,false,false,false);


        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(voidGwEntity).isNotNull();
    }

    @Test(description = "执行task成功,是终结点,更新数据库异常")
    public void test22(){
        String transitionKey = "transitionKey1";
        String nodeKey = "nodeKey1";
        String remark = "remark";

        mockitoPermissionOk();
        String evidenceFile="[{\"fileKey\":123}]";

        mockVoucher("role1","nodeKey1",19,0);

        mockRole("role1",false);

        mockNodeList(nodeKey,false,false,false,false,path,"transitionKey1",transitionName);

        mockAccountBook(true);

        mockCompeteTask(false,false,false,false,false,false,true);

        Mockito.doThrow(new RuntimeException()).when(voucherRepository).auditPunish(Matchers.any(),Matchers.any(),Matchers.any(),Matchers.any());

        VoidGwEntity voidGwEntity =depositGWService.sellerDealPunish(defaultAppId,defaultUserId,defaultSellerId,voucherId,transitionKey,nodeKey,remark,evidenceFile);
        assertThat(NumberUtils.toLong(getDubboErrorCode())).isEqualTo(JkApiCode.C_FAILURE);
        assertThat(voidGwEntity).isNull();
    }


    private void mockAccountBook(boolean isEmpty){
        List<AccountBookDO> accountBookDOs = new LinkedList<>();
        if(!isEmpty){
            AccountBookDO accountBookDO = new AccountBookDO();
            accountBookDO.setSellerId(defaultSellerId);
            accountBookDO.setId(1);
            accountBookDOs.add(accountBookDO);
        }

        Mockito.doReturn(Optional.of(accountBookDOs)).when(accountQueryRepository).queryBookBySeller(defaultSellerId);

    }

    private void mockVoucher(String role,String nodeKey,long expectAmt, long expectPoint){
        VoucherDO voucherDO = buildVoucherDO();
        voucherDO.setRole(role);
        voucherDO.setNodeKey(nodeKey);
        voucherDO.setExpectAmt(expectAmt);
        voucherDO.setExpectPoint(expectPoint);
        Mockito.doReturn(Optional.of(voucherDO)).when(voucherQueryRepository).queryVoucherById(defaultSellerId,voucherId);
    }

    private VoucherDO buildVoucherDO(){
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setSellerId(defaultSellerId);
        voucherDO.setGmtCreated(new Date());
        voucherDO.setVoucherId(voucherId);
        voucherDO.setVoucherSubType(VoucherSubType.FAKE_VIOLATION);
        voucherDO.setVoucherType(VoucherType.VIOLATION);
        voucherDO.setProcInstId(String.valueOf(procInstId));
        return voucherDO;
    }




}
