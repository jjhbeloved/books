package com.pajk.plutus.test.ut.biz.mq.consumer.base;

import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.alibaba.rocketmq.common.message.MessageQueue;
import com.pajk.kylin.helpcenter.api.model.message.SellerAddMsg;
import com.pajk.plutus.biz.common.util.HessianUtils;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.mq.consumer.base.BaseConsumer;
import com.pajk.plutus.biz.mq.consumer.seller.KylinAddSellerConsumer;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.test.ut.BaseServiceUT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fuyongda on 2016/12/23.
 * Modified by fuyongda on 2017/5/11.
 */
public class BaseConsumerUT extends BaseServiceUT {

    @InjectMocks
    private BaseConsumer baseConsumer = new KylinAddSellerConsumer();

    @Mock
    private AccountManager accountManager;

    @Test(description = "nameServer是localTest")
    public void testInit1() {
        baseConsumer.setNameServer("localTest");
        ReflectionTestUtils.setField(baseConsumer, "rocketMqDomainName", "localTest");

        try {
            baseConsumer.init();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "System.getProperty(\"rocketmq.namesrv.domain\")为空")
    public void testInit2() {
        try {
            baseConsumer.init();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "System.getProperty(\"rocketmq.namesrv.domain\")不为空")
    public void testInit3() {
        System.setProperty("rocketmq.namesrv.domain", "nameServer");

        try {
            baseConsumer.init();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(description = "Destroy")
    public void testDestroy() {
        baseConsumer.setMaxConsumeThread(10);
        baseConsumer.setMinConsumeThread(1);
        baseConsumer.setGroup("group");
        baseConsumer.setNameServer("");
        baseConsumer.getNotifyLog();
        ReflectionTestUtils.setField(baseConsumer, "rocketMqDomainName", "");

        try {
            baseConsumer.init();
        } catch (Exception e) {
            e.printStackTrace();
        }

        baseConsumer.destroy();
    }

    @Test(description = "msgs空")
    public void testConsumeMessage1() {
        ConsumeConcurrentlyStatus consumeConcurrentlyStatus = baseConsumer.consumeMessage(null, null);

        assertThat(consumeConcurrentlyStatus).isEqualTo(ConsumeConcurrentlyStatus.CONSUME_SUCCESS);
    }

    @Test(description = "reconsumeTimes >= maxRetryCount")
    public void testConsumeMessage2() {
        MessageExt messageExt = new MessageExt();
        messageExt.setReconsumeTimes(100);
        messageExt.setBody("body".getBytes());

        List<MessageExt> msgs = new ArrayList<>();
        msgs.add(messageExt);
        msgs.add(null);

        ConsumeConcurrentlyContext context = new ConsumeConcurrentlyContext(new MessageQueue());

        ConsumeConcurrentlyStatus consumeConcurrentlyStatus = baseConsumer.consumeMessage(msgs, context);

        assertThat(consumeConcurrentlyStatus).isEqualTo(ConsumeConcurrentlyStatus.CONSUME_SUCCESS);
    }

    @Test(description = "reconsumeTimes < maxRetryCount, 执行失败")
    public void testConsumeMessage3() throws IOException {
        SellerAddMsg sellerAddMsg = new SellerAddMsg();
        sellerAddMsg.setSellerId(defaultSellerId);

        MessageExt messageExt = new MessageExt();
        messageExt.setReconsumeTimes(1);
        messageExt.setBody(HessianUtils.encode(sellerAddMsg));

        List<MessageExt> msgs = new ArrayList<>();
        msgs.add(messageExt);

        ResultDTO<VoidEntity> result = new ResultDTO<>();
        result.setResultCode(ErrorCode.C_EXCEPTION);
        Mockito.doReturn(result).when(accountManager).createAccount(Matchers.anyLong());

        ConsumeConcurrentlyContext context = new ConsumeConcurrentlyContext(new MessageQueue());

        ConsumeConcurrentlyStatus consumeConcurrentlyStatus = baseConsumer.consumeMessage(msgs, context);

        assertThat(consumeConcurrentlyStatus).isEqualTo(ConsumeConcurrentlyStatus.RECONSUME_LATER);
    }

}
