package com.pajk.plutus.test.ut.biz.common.util.commonutil;

import com.pajk.plutus.biz.common.util.CommonUtil;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by fanhuafeng on 17/12/28.
 * Modify by fanhuafeng on 17/12/28
 */
public class IntegerToIntUT {

    @Test
    public void test01(){
        int i = CommonUtil.integerToInt(null);
        assertThat(i).isEqualTo(0);

        Integer int3 = 30;
        int i2 = CommonUtil.integerToInt(int3);
        assertThat(i2).isEqualTo(30);

    }
}
