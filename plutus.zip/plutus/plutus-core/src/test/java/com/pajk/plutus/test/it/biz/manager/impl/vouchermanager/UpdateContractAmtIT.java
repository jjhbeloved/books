package com.pajk.plutus.test.it.biz.manager.impl.vouchermanager;

import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.permission.AuthResourceProperties;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.test.it.BaseIT;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

/**
 * Created by lizhijun on 2017/12/22.
 */
public class UpdateContractAmtIT extends BaseIT {

    @Autowired
    private VoucherManager voucherManager;

    @Test
    public void testSuccess(){
        long sellerId = 20021820000L;
        long accountBookId =2L;
        long baseContractAmt = 200000L ;

        long updateContractAmt = 300000L;
        String remark = "remark_remark";
        UserParam userParam = new UserParam();

        userParam.setAppId(AuthResourceProperties.APPID);
        userParam.setDomainId(AuthResourceProperties.DOMAIN_ID);
        userParam.setUserId(20019550008L);

        ResultDTO<VoidEntity> resultDTO =  voucherManager.updateContractAmt(sellerId,accountBookId,baseContractAmt,updateContractAmt,remark
        ,userParam);
        System.out.println(resultDTO);

    }
}
