package com.pajk.plutus.biz.model.bill;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 *
 * @author dutianyi
 * @date 2017/12/18
 */
public class SellerInvoiceInfoDO extends BaseDO {

    private static final long serialVersionUID = -4180496803827934030L;

    private Long id;

    private Date gmtCreated;

    private Date gmtModified;

    private Integer version;

    private Long sellerId;

    /**
     * 状态 0:可用 1:不可用
     */
    private Integer status;

    /**
     * 发票抬头
     */
    private String invoiceTitle;

    /**
     * 发票联系人
     */
    private String contact;

    /**
     * 发票联系人电话
     */
    private String contactTel;

    /**
     * 发票地址信息
     */
    private String invoiceAddress;

    /**
     * 纳税人识别号
     */
    private String taxpayerNumber;

    /**
     * 发票电话信息
     */
    private String invoiceTel;

    /**
     * 发票寄送地址
     */
    private String address;

    /**
     * 发票开户行信息
     */
    private String invoiceBankName;

    /**
     * 发票开户行账户信息
     */
    private String invoiceBankAccount;

    /**
     * 发票类型 1:增值税专用发票 2:增值税普通发票
     */
    private Integer invoiceType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getInvoiceTitle() {
        return invoiceTitle;
    }

    public void setInvoiceTitle(String invoiceTitle) {
        this.invoiceTitle = invoiceTitle;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getContactTel() {
        return contactTel;
    }

    public void setContactTel(String contactTel) {
        this.contactTel = contactTel;
    }

    public String getInvoiceAddress() {
        return invoiceAddress;
    }

    public void setInvoiceAddress(String invoiceAddress) {
        this.invoiceAddress = invoiceAddress;
    }

    public String getTaxpayerNumber() {
        return taxpayerNumber;
    }

    public void setTaxpayerNumber(String taxpayerNumber) {
        this.taxpayerNumber = taxpayerNumber;
    }

    public String getInvoiceTel() {
        return invoiceTel;
    }

    public void setInvoiceTel(String invoiceTel) {
        this.invoiceTel = invoiceTel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getInvoiceBankName() {
        return invoiceBankName;
    }

    public void setInvoiceBankName(String invoiceBankName) {
        this.invoiceBankName = invoiceBankName;
    }

    public String getInvoiceBankAccount() {
        return invoiceBankAccount;
    }

    public void setInvoiceBankAccount(String invoiceBankAccount) {
        this.invoiceBankAccount = invoiceBankAccount;
    }

    public Integer getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(Integer invoiceType) {
        this.invoiceType = invoiceType;
    }

}
