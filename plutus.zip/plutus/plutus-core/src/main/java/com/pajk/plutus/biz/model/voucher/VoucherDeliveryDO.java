package com.pajk.plutus.biz.model.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * Created by fuyongda on 2017/12/17.
 * Modified by fuyongda on 2017/12/17.
 */
public class VoucherDeliveryDO extends BaseDO {

    private static final long serialVersionUID = 4985222418945862743L;

    /**
     * 主键id
     */
    private Long id;

    /**
     * 创建时间
     */
    private Date gmtCreated;

    /**
     * 更新时间
     */
    private Date gmtModified;

    /**
     * 版本号
     */
    private Integer version;

    /**
     * 卖家id
     */
    private Long sellerId;

    /**
     * 业务单据id
     */
    private String voucherId;

    /**
     * 违规规则id
     */
    private String ruleId;

    /**
     * 单据金额(单位分)(通过zeus任务计算的订单的违规金额)
     */
    private long amount;

    /**
     * 订单id
     */
    private String tradeId;

    /**
     * 支付方式 在线支付1或者货到付款2
     */
    private int payMode;

    /**
     * b2c 或者o2o ..
     */
    private String tradeMode;

    /**
     * 结算模式 1 佣金 2 结算价
     */
    private int statementMode;

    /**
     * 商品总金额(现金+健康生活通)(单位分)
     */
    private long totalAmt;

    /**
     * 商品结算总金额(结算价总和)(单位分)
     */
    private long settleAmt;

    /**
     * 支付时间
     */
    private Date payTime;

    /**
     * 下单时间
     */
    private Date createTime;

    /**
     * 发货时间
     */
    private Date deliveryTime;

    /**
     * 物流揽件时间
     */
    private Date lgTime;

    /**
     * 物流送达时间
     */
    private Date arrivedTime;

    /**
     * 物流公司公司id
     */
    private Long companyId;

    /**
     * 物流公司名
     */
    private String companyName;

    /**
     * 运单号
     */
    private String trackingNumber;

    /**
     * 是否有物流追踪信息 0 无 1 有
     */
    private int traceSupported;

    /**
     * 省(买家收货)
     */
    private String uProv;

    /**
     * 市(买家收货)
     */
    private String uCity;

    /**
     * 区(买家收货)
     */
    private String uArea;

    /**
     * 省(卖家发货)
     */
    private String sProv;

    /**
     * 市(卖家发货)
     */
    private String sCity;

    /**
     * 区(卖家发货)
     */
    private String sArea;

    /**
     * 扩展字段
     */
    private String extProps;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public String getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(String voucherId) {
        this.voucherId = voucherId;
    }

    public String getRuleId() {
        return ruleId;
    }

    public void setRuleId(String ruleId) {
        this.ruleId = ruleId;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public String getTradeId() {
        return tradeId;
    }

    public void setTradeId(String tradeId) {
        this.tradeId = tradeId;
    }

    public int getPayMode() {
        return payMode;
    }

    public void setPayMode(int payMode) {
        this.payMode = payMode;
    }

    public String getTradeMode() {
        return tradeMode;
    }

    public void setTradeMode(String tradeMode) {
        this.tradeMode = tradeMode;
    }

    public int getStatementMode() {
        return statementMode;
    }

    public void setStatementMode(int statementMode) {
        this.statementMode = statementMode;
    }

    public long getTotalAmt() {
        return totalAmt;
    }

    public void setTotalAmt(long totalAmt) {
        this.totalAmt = totalAmt;
    }

    public long getSettleAmt() {
        return settleAmt;
    }

    public void setSettleAmt(long settleAmt) {
        this.settleAmt = settleAmt;
    }

    public Date getPayTime() {
        return payTime;
    }

    public void setPayTime(Date payTime) {
        this.payTime = payTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getDeliveryTime() {
        return deliveryTime;
    }

    public void setDeliveryTime(Date deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    public Date getLgTime() {
        return lgTime;
    }

    public void setLgTime(Date lgTime) {
        this.lgTime = lgTime;
    }

    public Date getArrivedTime() {
        return arrivedTime;
    }

    public void setArrivedTime(Date arrivedTime) {
        this.arrivedTime = arrivedTime;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    public int getTraceSupported() {
        return traceSupported;
    }

    public void setTraceSupported(int traceSupported) {
        this.traceSupported = traceSupported;
    }

    public String getuProv() {
        return uProv;
    }

    public void setuProv(String uProv) {
        this.uProv = uProv;
    }

    public String getuCity() {
        return uCity;
    }

    public void setuCity(String uCity) {
        this.uCity = uCity;
    }

    public String getuArea() {
        return uArea;
    }

    public void setuArea(String uArea) {
        this.uArea = uArea;
    }

    public String getsProv() {
        return sProv;
    }

    public void setsProv(String sProv) {
        this.sProv = sProv;
    }

    public String getsCity() {
        return sCity;
    }

    public void setsCity(String sCity) {
        this.sCity = sCity;
    }

    public String getsArea() {
        return sArea;
    }

    public void setsArea(String sArea) {
        this.sArea = sArea;
    }

    public String getExtProps() {
        return extProps;
    }

    public void setExtProps(String extProps) {
        this.extProps = extProps;
    }

}
