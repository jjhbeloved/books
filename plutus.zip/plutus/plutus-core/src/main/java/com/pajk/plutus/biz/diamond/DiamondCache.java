package com.pajk.plutus.biz.diamond;

import com.pajk.plutus.biz.conf.MiscConfig;
import com.taobao.diamond.client.Diamond;
import com.taobao.diamond.manager.SkipInitialCallbackListener2;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.StringReader;
import java.util.Properties;

/**
 * Created by fanhuafeng on 17/2/22.
 * Modify by fanhuafeng on 17/2/22
 */
public abstract class DiamondCache extends SkipInitialCallbackListener2 {

    private static final Logger logger = LoggerFactory.getLogger(DiamondCache.class);

    protected static final String DIAMOND_PLUTUS_GROUP = "PLUTUS_GROUP";

    private static final String NOTIFY_LOG = "DiamondCacheNotifyLog";

    protected Properties properties = new Properties();


    public DiamondCache(String initialConfig) {
        super(initialConfig);
    }

    public abstract String getDataId();

    public String getNotifyLog() {
        return NOTIFY_LOG;
    }


    public void init(String dataId) {
        try {
            properties = new Properties();
            String info = Diamond.getConfig(dataId, DIAMOND_PLUTUS_GROUP, 5000L);
            Diamond.addListener2(dataId, DIAMOND_PLUTUS_GROUP, this);
            loadProperties(info);

        } catch (IOException e) {
            logger.error("read {} config error, e:", dataId, e);
        }
    }

    public void loadProperties(String info) {
        logger.info(
                "=====================================\n" +
                        "diamond {} config: \n{}\n" +
                        "==========================================",
                getDataId(), info);

        if (StringUtils.isBlank(info)) {
            return;
        }

        Properties tempProperties = new Properties();

        try {
            StringReader reader = new StringReader(info);
            tempProperties.load(reader);
            properties.clear();
            properties.putAll(tempProperties);
        } catch (IOException e) {
            logger.error(getNotifyLog() + "load {} Info IOException, info={}, e:", getDataId(), info, e);
        }
    }

    public String getValue(String key) {
        String key2 = MiscConfig.getDubboEnv() + "." + key;
        String value = "";
        if (properties.containsKey(key2)) {
            value = (String) properties.get(key2);
        }
        return value;
    }

    public String getValue(String key, String defaultValue) {
        String value = getValue(key);
        if (StringUtils.isBlank(value)) {
            value = defaultValue;
        }
        return value;
    }

    public int getIntValue(String key) {
        return getIntValue(key, 0);
    }

    public int getIntValue(String key, int defaultValue) {
        String value = getValue(key);
        return NumberUtils.toInt(value, defaultValue);
    }

    public long getLongValue(String key) {
        return getLongValue(key, 0);
    }

    public long getLongValue(String key, long defaultValue) {
        String value = getValue(key);
        return NumberUtils.toLong(value, defaultValue);
    }

}
