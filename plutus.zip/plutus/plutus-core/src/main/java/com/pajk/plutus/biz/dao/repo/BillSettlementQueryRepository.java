package com.pajk.plutus.biz.dao.repo;

import com.pajk.plutus.biz.model.bill.BillSettlementDO;
import com.pajk.plutus.biz.model.bill.BillSettlementItemDO;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * @author david
 * @since created by on 17/12/14 00:15
 */
public interface BillSettlementQueryRepository {


    /**
     * 获取 账单总表关键信息
     *
     * @param billId 账单ID
     * @return 账单总表关键信息
     */
    Optional<BillSettlementDO> querySettlementByBillId(long billId);

    /**
     * 获取 账单总表关键信息
     *
     * @param billId   账单ID
     * @param sellerId sellerId
     * @return 账单总表关键信息
     */
    Optional<BillSettlementDO> querySettlementByBillId(long billId, long sellerId);

    /**
     * 获取 账单总表明细
     *
     * @param billId 账单ID
     * @return 账单总表明细
     */
    Optional<BillSettlementDO> querySettlementDetailByBillId(long billId);

    /**
     * 获取 账单总表明细
     *
     * @param billId   账单ID
     * @param sellerId sellerId
     * @return 账单总表明细
     */
    Optional<BillSettlementDO> querySettlementDetailByBillId(long billId, long sellerId);

    /**
     * 通过账单id获取账单项列表
     *
     * @param billId 账单id
     * @return 账单项列表
     */
    List<BillSettlementItemDO> querySettlementItemByBillId(long billId);

    /**
     * 统计数量
     *
     * @param params 查询参数
     * @return 数量
     */
    int count(Map<String, Object> params);

    /**
     * 获取分页账单数据
     *
     * @param pageNo   起始页码
     * @param pageSize 每页数量
     * @param params   查询参数
     * @return 对账列表
     */
    List<BillSettlementDO> pageList(int pageNo, int pageSize, Map<String, Object> params);
}
