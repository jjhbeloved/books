package com.pajk.plutus.biz.model.query.voucher;

import com.pajk.plutus.biz.model.query.PageQuery;

/**
 * Created by cuidongchao on 2017/12/17.
 */
public class ViolationRuleSellerPageQuery extends PageQuery {
}
