package com.pajk.plutus.biz.conf;

import com.alibaba.dubbo.config.RegistryConfig;
import com.google.common.collect.Lists;
import com.pajk.hawaii.client.HawaiiClient;
import com.pajk.hawaii.client.HawaiiClientFactoryBean;
import com.pajk.hawaii.client.JobExecutor;
import com.pajk.hawaii.client.JobListener;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.List;
import java.util.Map;

/**
 * Created by cuidongchao on 2017/8/17.
 */
@Configuration
public class HawaiiConfig {

    private static final Logger logger = LoggerFactory.getLogger(HawaiiConfig.class);

    @Value("${hawaii.app.name}")
    private String appName;

    @Value("${hawaii.app.key}")
    private String appKey;

    @Value("${public.dubbo.version}")
    private String dubboVersion;

    private int threadCount = 20;
    // 本地TaskMessage消息监听端口,默认50115
    private int localPort = 50115;
    private int maxWaitingTask = Integer.MAX_VALUE;

    @Autowired(required = false)
    Map<String, JobListener> jobListenerMap;

    @Autowired
    private RegistryConfig registryConfig;

    @Bean(name = "hawaiiClient")
    public HawaiiClient hawaiiClient() {

        HawaiiClientFactoryBean hawaiiClientFactoryBean = new HawaiiClientFactoryBean(appName, appKey);

        // 50115 has been used by hugo_agent
        if (!StringUtils.equals(dubboVersion, "LATEST")) {
            localPort = 50117;
        }
        hawaiiClientFactoryBean.setDubboVersion(dubboVersion); // 设置Dubbo服务版本 (此版本号只影响Hawaii关联Service)
        hawaiiClientFactoryBean.setCheck(false);// 检查provider是否存在，默认为false,即发现没有provider也不会出错（可选）
        JobExecutor jobExecutor = new JobExecutor(threadCount, localPort, maxWaitingTask);
        hawaiiClientFactoryBean.setJobExecutor(jobExecutor);
        hawaiiClientFactoryBean.setRegistryConfig(registryConfig);

        if (!CollectionUtils.isEmpty(jobListenerMap)) {
            logger.info("jobListener:{}", jobListenerMap.keySet());
            List<JobListener> jobListeners = Lists.newArrayList(jobListenerMap.values());
            hawaiiClientFactoryBean.setJobListeners(new HashSet<>(jobListeners));
        }

        HawaiiClient hawaiiClient = null;
        try {
            hawaiiClient = hawaiiClientFactoryBean.getObject();
        } catch (Exception e) {
            logger.error("启动HawaiiClient失败", e);
        }

        return hawaiiClient;
    }

}
