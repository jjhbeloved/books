package com.pajk.plutus.biz.dao.mapper.single.bill;

import com.pajk.plutus.biz.model.mapper.single.bill.BillSettlementDAO;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by arjaylv on 2017/12/11.
 *
 * @author arjaylv
 */
public interface BillSettlementMapper {

    /**
     * 查询 账单信息
     *
     * @param id       账单ID
     * @param sellerId 商户ID(可选, 为null不查询)
     * @return 结果
     */
    BillSettlementDAO queryByIdAndSellerId(@Param("id") long id, @Param("sellerId") Long sellerId);

    /**
     * 根据指定条件批量查找账单信息
     *
     * @param sellerId
     * @param startTime
     * @param endTime
     * @param startRow
     * @param pageSize
     * @return
     */
    List<BillSettlementDAO> pageQuery(@Param("sellerId") Long sellerId,
                                      @Param("startTime") Date startTime,
                                      @Param("endTime") Date endTime,
                                      @Param("startRow") int startRow,
                                      @Param("pageSize") int pageSize);

    /**
     * 更新 确认账单主表信息
     *
     * @param billSettlementDAO 更新内容
     * @return 影响行数
     */
    int updateConfirm(BillSettlementDAO billSettlementDAO);

    /**
     * 统计总条数
     *
     * @param params
     * @return
     */
    int count(Map<String, Object> params);

    /**
     * 根据条件查询列表
     *
     * @param params
     * @return
     */
    List<BillSettlementDAO> paging(Map<String, Object> params);
}
