package com.pajk.plutus.biz.model.result.dto.account;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by  guguangming on 2017/12/13
 **/
public class AccountBookFlowDTO extends BaseDO {
    private static final long serialVersionUID = 5928656610142046766L;
    /**
     * 收支形成时间
     */
    private String gmtStatement;
    /**
     * 金额(单位分)
     */
    private long amount;
    /**
     * 收支明细类型
     */
    private String flowType ;
    /**
     * 单号
     */
    private String voucherId;

    public String getGmtStatement() {
        return gmtStatement;
    }

    public void setGmtStatement(String gmtStatement) {
        this.gmtStatement = gmtStatement;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public String getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(String voucherId) {
        this.voucherId = voucherId;
    }

    public String getFlowType() {
        return flowType;
    }

    public void setFlowType(String flowType) {
        this.flowType = flowType;
    }
}
