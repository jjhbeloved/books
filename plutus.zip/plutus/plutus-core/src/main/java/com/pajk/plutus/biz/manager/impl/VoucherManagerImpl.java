package com.pajk.plutus.biz.manager.impl;

import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.common.aop.ClassLogger;
import com.pajk.plutus.biz.common.idgen.IDPool;
import com.pajk.plutus.biz.common.util.*;
import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.dao.repo.AccountRepository;
import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.dao.repo.VoucherRepository;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.TransactionWrapper;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.permission.UserUtil;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.account.AccountBookFlowDO;
import com.pajk.plutus.biz.model.account.AccountDO;
import com.pajk.plutus.biz.model.account.StatementDO;
import com.pajk.plutus.biz.model.enums.OptTypeEnum;
import com.pajk.plutus.biz.model.enums.VoucherExtPropsKey;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.biz.model.query.account.BookFlowPageQuery;
import com.pajk.plutus.biz.model.query.account.BookPageQuery;
import com.pajk.plutus.biz.model.query.account.VoucherPageQuery;
import com.pajk.plutus.biz.model.query.voucher.VoucherDeliveryPageQuery;
import com.pajk.plutus.biz.model.voucher.PaymentPropDO;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.model.voucher.VoucherDeliveryDO;
import com.pajk.plutus.biz.model.voucher.VoucherLogDO;
import com.pajk.plutus.client.model.enums.account.*;
import com.pajk.plutus.client.model.enums.voucher.*;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.taskcenter.client.model.dto.CompleteTaskResultDTO;
import com.pajk.taskcenter.client.model.dto.CreateProcInstResultDTO;
import com.pajk.taskcenter.client.model.dto.TaskInstDTO;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by lizhijun on 2017/12/17.
 */
@Component
@ClassLogger
public class VoucherManagerImpl extends AbstractManagerImpl implements VoucherManager, TransactionWrapper {

    private static final Logger logger = LoggerFactory.getLogger(VoucherManagerImpl.class);

    private static final String EVIDENCE_FLOW = "evidenceFlow";
    private static final String ADD_BALANCE_TIPS = "新建并提交成功,该缴费金额为X元";
    private static final String PUNISH_SYSTEM_AGREE_REMARK = "超过四天商家未申述系统自动同意违规";
    private static final String OUT_PRE = "P";

    private static final int QUERY_BOOK_PAGE_SIZE = 500;
    private static final int QUERY_BOOK_FLOW_PAGE_SIZE = 500;


    @Autowired
    private VoucherQueryRepository voucherQueryRepository;

    @Autowired
    private VoucherRepository voucherRepository;

    @Autowired
    private AccountQueryRepository accountQueryRepository;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    @Qualifier("voucherIDPool")
    private IDPool voucherIDPool;

    @Autowired
    private ControlCache controlCache;

    @Override
    public ResultDTO<VoucherDO> queryVoucherDetail(long sellerId, String voucherId, UserParam userParam) {
        Optional<VoucherDO> optional = voucherQueryRepository.queryVoucherById(sellerId, voucherId);
        if (!optional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.VOUCHER_NOT_EXISTS);
        }

        VoucherDO voucherDO = optional.get();

        VoucherType voucherType = voucherDO.getVoucherType();
        if (VoucherType.PAYMENT.isEquals(voucherType)) {
            Map<String, String> extPropsMap = voucherDO.getExtProps();

            PaymentPropDO paymentPropDO = new PaymentPropDO();
            paymentPropDO.setEvidenceFlow(extPropsMap.get(EVIDENCE_FLOW));

            voucherDO.setPaymentPropDO(paymentPropDO);
        } else if (VoucherType.VIOLATION.isEquals(voucherType) &&
                VoucherSubType.DELAY_DELIVERY_VIOLATION.isEquals(voucherDO.getVoucherSubType())) {
            Optional<VoucherDeliveryDO> optional1 = voucherQueryRepository.queryVoucherDeliveryByVoucherId(voucherId);
            if (!optional1.isPresent()) {
                return ResultUtil.returnResultDTO(ErrorCode.VOUCHER_DELIVERY_NOT_EXISTS);
            }
            voucherDO.setVoucherDeliveryDO(optional1.get());
        }

        ResultDTO<VoucherDO> result = new ResultDTO<>();
        result.setModel(voucherDO);
        return result;
    }

    @Override
    public PageResultDTO<VoucherDO> pageQueryVoucher(VoucherPageQuery voucherPageQuery, UserParam userParam) {

        int total = this.queryVoucherCount(voucherPageQuery);

        PageResultDTO<VoucherDO> resultDTO = new PageResultDTO<>();
        resultDTO.setPageNo(voucherPageQuery.getPageNo());
        resultDTO.setPageSize(voucherPageQuery.getPageSize());
        if (0 >= total) {
            return resultDTO;
        }
        resultDTO.setTotalCount(total);
        Optional<List<VoucherDO>> optional = voucherQueryRepository.pageQueryVoucher(voucherPageQuery);
        resultDTO.setModel(optional.orElseGet(LinkedList::new));
        return resultDTO;
    }

    @Override
    public ResultDTO<VoidEntity> deletePunish(long sellerId, String voucherId, UserParam userParam) {
        ResultDTO<VoidEntity> resultDTO = new ResultDTO<>();
        Optional<VoucherDO> voucherOption = voucherQueryRepository.queryVoucherById(sellerId, voucherId);
        if (!voucherOption.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.VOUCHER_NOT_EXISTS);
        }

        VoucherDO voucherDO = voucherOption.get();
        if (VoucherDeleteFlag.IS_DELETE.isEquals(voucherDO.getIsDeleted())) {
            return resultDTO;
        }

        if (!canDeletePunish(voucherDO)) {
            logger.warn("deletePunish fail,status not match! voucherId={}", voucherId);
            return ResultUtil.returnResultDTO(ErrorCode.STATUS_NOT_MATCH);
        }
        voucherDO.setIsDeleted(VoucherDeleteFlag.IS_DELETE.getCode());
        voucherDO.setNodeKey(VoucherStatus.DELETED.getCode());
        VoucherLogDO voucherLog =
                VoucherLogUtils.buildSimpleOperationLog(sellerId, voucherId, userParam, OptTypeEnum.DELETE_PUNISH);
        return transactionWrapper(() -> {
            voucherRepository.deletePunish(voucherDO,voucherLog);
            return new ResultDTO<>();
        }, "voucher.deletePunish");
    }

    @Override
    public ResultDTO<VoidEntity> createPunish(long sellerId, VoucherSubType voucherSubType, long expectAmt,
                                              String createFile, String createRemark, UserParam userParam) {
        BookPageQuery bookPageQuery = new BookPageQuery();
        bookPageQuery.setSellerId(sellerId);
        bookPageQuery.setBookType(BookType.DEPOSIT.getCode());
        if (0 == accountQueryRepository.queryBookCount(bookPageQuery)) {
            ResultDTO<VoidEntity> ret = this.createAccount(sellerId);
            if (!ErrorCode.SUCCESS.eq(ret.getResultCode())) {
                return ret;
            }
        } else {
            Optional<AccountBookDO> validBook =
                    accountQueryRepository.queryValidBookBySeller(sellerId, BookType.DEPOSIT.getCode());
            if (!validBook.isPresent()) {
                logger.info(TroyUtil.getKVItem(getNotifyLog(),
                        "create voucher, but book is invalid. sellerId=" + sellerId));
                return new ResultDTO<>();
            }

            // 违规单金额不允许超过合同金
            if(expectAmt > validBook.get().getContractAmt()){
                return ResultUtil.returnResultDTO(ErrorCode.ADD_FAIL_EXPECT_GT_CONTRACT);
            }
        }

        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setOutId(getVoucherOutId());
        voucherDO.setVoucherType(VoucherType.VIOLATION);
        voucherDO.setVoucherSubType(voucherSubType);
        voucherDO.setSellerId(sellerId);
        voucherDO.setCreateRemark(createRemark);
        voucherDO.setCreateFile(createFile);
        voucherDO.setExpectAmt(expectAmt);
        voucherDO.setActualAmt(expectAmt);
        voucherDO.setNodeKey(VoucherStatus.CREATED.getCode());
        voucherDO.setPayFlag(VoucherPayFlag.NO_FINISHED.getCode());
        VoucherLogDO voucherLog = VoucherLogUtils.buildCreatePunishLog(sellerId,voucherSubType,expectAmt,createFile,
                createRemark,userParam, OptTypeEnum.CREATE_PUNISH);
        return transactionWrapper(() -> {
            voucherRepository.createPunish(voucherDO,voucherLog);
            return new ResultDTO<>();
        }, "voucher.createPunish");
    }


    @Override
    public ResultDTO<VoidEntity> submitPunish(long sellerId, String voucherId, UserParam userParam) {
        Optional<VoucherDO> optional = voucherQueryRepository.queryVoucherById(sellerId, voucherId);
        if (!optional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.VOUCHER_NOT_EXISTS);
        }
        VoucherDO voucherDO = optional.get();
        if (VoucherStatus.CREATED.isEquals(voucherDO.getNodeKey()) && Objects.isNull(voucherDO.getProcInstId())) {
            ResultDTO<CreateProcInstResultDTO> resultDTO =
                    createProcess(VoucherProcNameType.DEPOSIT_VIOLATION_COMMON.getCode(), voucherId,
                            VoucherProcNameType.DEPOSIT_VIOLATION_COMMON.getCode());

            if (!resultDTO.isSuccess()) {
                return ResultUtil.returnResultDTO(resultDTO);
            }
            CreateProcInstResultDTO createProcInstResultDTO = resultDTO.getModel();
            voucherDO.setProcInstId(String.valueOf(createProcInstResultDTO.getProcInstId()));
            // 这里流程定义来保证只会有一个 nextNode
            TaskInstDTO taskInstDTO = createProcInstResultDTO.getTaskInstDTOList().get(0);
            setNodeInfo(voucherDO, false, taskInstDTO, null);
            voucherDO.setProcStartTime(new Date());
            VoucherLogDO voucherLog =
                    VoucherLogUtils.buildSimpleOperationLog(sellerId, voucherId, userParam, OptTypeEnum.SUBMIT_PUNISH);
            return transactionWrapper(() -> {
                voucherRepository.submitPunish(voucherDO,voucherLog);
                return new ResultDTO<>();
            }, "voucher.submitPunish");
        } else {
            return ResultUtil.returnResultDTO(ErrorCode.STATUS_NOT_MATCH);
        }
    }

    @Override
    public ResultDTO<VoidEntity> auditPunish(long sellerId, String voucherId, String transitionKey,
                                             String nodeKey, String remark, UserParam userParam) {
        Optional<VoucherDO> optional = voucherQueryRepository.queryVoucherById(sellerId, voucherId);
        if (!optional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.VOUCHER_NOT_EXISTS);
        }
        VoucherDO voucherDO = optional.get();

        ResultDTO<VoidEntity> checkError = checkPreAuditProcess(userParam.getAppId(),userParam.getUserId(),
                voucherDO.getRole(),voucherDO.getNodeKey(),NumberUtils.toLong(voucherDO.getProcInstId()),
                nodeKey, transitionKey,userParam.getPath());

        if (!ErrorCode.SUCCESS.eq(checkError.getResultCode())) {
            if (ErrorCode.STATUS_NOT_MATCH.eq(checkError.getResultCode())) {
                return ResultUtil.returnResultDTO(ErrorCode.STATUS_NOT_MATCH);
            } else {
                return ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);
            }
        }
        Optional<List<AccountBookDO>> accountBookOptional = accountQueryRepository.queryBookBySeller(sellerId);
        if (!accountBookOptional.isPresent()) {
            logger.warn("auditPunish fail ! accountBook not exist voucherId={},sellerId={}", voucherId, sellerId);
            return ResultUtil.returnResultDTO(ErrorCode.BOOK_NOT_EXISTS);
        }
        List<AccountBookDO> bookList = accountBookOptional.get();

        long procInstId = NumberUtils.toLong(voucherDO.getProcInstId());
        ResultDTO<CompleteTaskResultDTO> resultDTO = completeTask(procInstId, nodeKey, transitionKey,
                voucherDO.getRole(), new HashMap<>(), UserUtil.getUserId(), remark);
        if (!resultDTO.isSuccess()) {
            logger.warn("sellerConfirmPayment fail. cause completeTask errorCode={}, errorMsg={}",
                    resultDTO.getResultCode(), resultDTO.getResultMsg());
            return ResultUtil.returnResultDTO(resultDTO);
        }
        CompleteTaskResultDTO taskResultDTO = resultDTO.getModel();
        boolean endFlag = taskResultDTO.getEndFlag();
        TaskInstDTO taskInstDTO = taskResultDTO.getTaskInstDTOList().get(0);
        setNodeInfo(voucherDO, endFlag, taskInstDTO, transitionKey);

        if (endFlag) {
            if (StringUtils.equals(transitionKey,
                    controlCache.getVoucherPunishSecondAuditPassTransitionKey())) {
                voucherDO.setActualAmt(0L);
                voucherDO.setActualPoint(0L);
                voucherDO.setPayFlag(VoucherPayFlag.NO_NEED_DEAL.getCode());
            } else if (StringUtils.equals(transitionKey, controlCache.getVoucherPunishFirstAuditRefuseTransitionKey())
                    || StringUtils.equals(transitionKey, controlCache.getVoucherPunishSecondAuditRefuseTransitionKey())) {
                voucherDO.setPayFlag(VoucherPayFlag.FINISHED.getCode());
            }
        } else {
            if (StringUtils.equals(transitionKey,
                    controlCache.getVoucherPunishFirstAuditBackTransitionKey())) {
                voucherDO.setProcStartTime(new Date());
            }
            // else 其余情况无特例 直接更新即可
        }

        VoucherLogDO voucherLog = VoucherLogUtils.buildAuditLog(sellerId,voucherId,transitionKey,nodeKey,remark,null,
                userParam,OptTypeEnum.AUDIT_PUNISH);

        return transactionWrapper(() -> {
            List<AccountBookFlowDO> accountBookFlows = new LinkedList<>();
            List<AccountBookDO> books = new LinkedList<>();
            if (VoucherPayFlag.FINISHED.isEquals(voucherDO.getPayFlag())) {
                buildEndBookAndFlow(voucherDO, bookList, books, accountBookFlows);
            }
            voucherRepository.auditPunish(voucherDO, books, accountBookFlows,voucherLog);
            return new ResultDTO<>();
        }, "voucher.auditPunish");
    }


    @Override
    public ResultDTO<VoidEntity> sellerDealPunish(long sellerId, String voucherId, String transitionKey, String nodeKey,
                                                  String evidenceRemark, String evidenceFile, UserParam userParam) {
        Optional<VoucherDO> optional = voucherQueryRepository.queryVoucherById(sellerId, voucherId);
        if (!optional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.VOUCHER_NOT_EXISTS);
        }
        VoucherDO voucherDO = optional.get();

        ResultDTO<VoidEntity> checkError = checkPreAuditProcess(userParam.getAppId(),userParam.getUserId(),
                voucherDO.getRole(),voucherDO.getNodeKey(),NumberUtils.toLong(voucherDO.getProcInstId()),
                nodeKey, transitionKey,userParam.getPath());
        if (!ErrorCode.SUCCESS.eq(checkError.getResultCode())){
            if(ErrorCode.STATUS_NOT_MATCH.eq(checkError.getResultCode())){
                return ResultUtil.returnResultDTO(ErrorCode.STATUS_NOT_MATCH);
            }else{
                return ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);
            }
        }

        Optional<List<AccountBookDO>> accountBookOptional =
                accountQueryRepository.queryBookBySeller(voucherDO.getSellerId());
        if (!accountBookOptional.isPresent() || CollectionUtils.isEmpty(accountBookOptional.get())) {
            logger.warn("sellerDealPunish fail ! accountBook not exist voucherId={}", voucherId);
            return ResultUtil.returnResultDTO(ErrorCode.BOOK_NOT_EXISTS);
        }
        List<AccountBookDO> bookList = accountBookOptional.get();

        long procInstId = NumberUtils.toLong(voucherDO.getProcInstId());
        ResultDTO<CompleteTaskResultDTO> resultDTO = completeTask(procInstId, nodeKey, transitionKey,
                voucherDO.getRole(), new HashMap<>(), UserUtil.getUserId(), evidenceRemark);
        if (!resultDTO.isSuccess()) {
            logger.warn("sellerConfirmPayment fail. cause completeTask errorCode={}, errorMsg={}",
                    resultDTO.getResultCode(), resultDTO.getResultMsg());
            return ResultUtil.returnResultDTO(resultDTO);
        }
        CompleteTaskResultDTO taskResultDTO = resultDTO.getModel();
        boolean endFlag = taskResultDTO.getEndFlag();
        TaskInstDTO taskInstDTO = taskResultDTO.getTaskInstDTOList().get(0);
        setNodeInfo(voucherDO, endFlag, taskInstDTO, transitionKey);

        VoucherLogDO voucherLog = VoucherLogUtils.buildAuditLog(sellerId,voucherId,transitionKey,nodeKey,evidenceRemark,
                evidenceFile, userParam,OptTypeEnum.SELLER_DEAL_PUNISH);

        return transactionWrapper(() -> {
            List<AccountBookFlowDO> accountBookFlows = new LinkedList<>();
            List<AccountBookDO> books = new LinkedList<>();
            if (endFlag) {//同意
                voucherDO.setPayFlag(VoucherPayFlag.FINISHED.getCode());
                buildEndBookAndFlow(voucherDO, bookList, books, accountBookFlows);
            }
            //其余情况即为申诉
            voucherDO.setEvidenceRemark(evidenceRemark);
            voucherDO.setEvidenceFile(evidenceFile);
            voucherRepository.auditPunish(voucherDO, books, accountBookFlows, voucherLog);
            return new ResultDTO<>();
        }, "voucher.sellerDealPunish");
    }

    @Override
    public ResultDTO<VoidEntity> updateContractAmt(long sellerId, long accountBookId, long baseContractAmt,
                                                   long updateContractAmt,String remark, UserParam userParam){
        BookType bookType = BookType.DEPOSIT;
        VoucherSubType voucherSubType = VoucherSubType.ADD_DEPOSIT;
        ResultDTO<AccountBookDO> bookResult = queryAndCreateAccountBook(sellerId,bookType.getCode());
        if(!ErrorCode.SUCCESS.eq(bookResult.getResultCode())){
            return ResultUtil.returnResultDTO(bookResult);
        }
        AccountBookDO bookDO = bookResult.getModel();

        String outId = getVoucherOutId();
        //创建流程
        ResultDTO<CreateProcInstResultDTO> resultDTO =
                createProcess(voucherSubType.getProc().getCode(),outId,voucherSubType.name());
        if (!resultDTO.isSuccess()) {
            return ResultUtil.returnResultDTO(resultDTO);
        }
        CreateProcInstResultDTO createProcInstResultDTO = resultDTO.getModel();

        long amount = updateContractAmt - baseContractAmt;
        VoucherDO voucherDO = buildVoucherDO(sellerId,outId,voucherSubType,remark,amount);
        voucherDO.setProcStartTime(new Date());
        voucherDO.setProcInstId(String.valueOf(createProcInstResultDTO.getProcInstId()));

        // 这里流程定义来保证只会有一个 nextNode
        TaskInstDTO taskInstDTO = createProcInstResultDTO.getTaskInstDTOList().get(0);
        setNodeInfo(voucherDO, false, taskInstDTO, null);

        AccountBookFlowDO bookFlowDO = buildAccountBookFlow(voucherDO,bookDO);
        bookFlowDO.setStatus(BookFlowStatus.NO_FINISHED);
        bookFlowDO.setGmtStatement(null);
        bookFlowDO.setAmount(mathSymbolAmt(voucherDO,amount));
        bookDO.setContractAmt(bookDO.getContractAmt() + amount);
        StatementDO statementDO = buildStatement(sellerId, SubjectEnum.DEPOSIT.getCode(),new Date(),
                null,amount,null,null,null,null,null,null,null);
        VoucherLogDO voucherLog = VoucherLogUtils.buildUpdateContractAmtLog(sellerId, accountBookId, baseContractAmt,
                updateContractAmt, remark, userParam, OptTypeEnum.UPDATE_CONTRACT_AMT);
        return transactionWrapper(() -> {
            voucherRepository.updateContractAmt(voucherDO,bookDO,bookFlowDO,statementDO,baseContractAmt,voucherLog);
            return new ResultDTO<>();
        }, "voucher.updateContractAmt");
    }

    @Override
    public ResultDTO<VoidEntity> sellerConfirmPayment(long sellerId, String voucherId, String transitionKey,
                                                      String nodeKey, String remark, String evidenceFlow,
                                                      String evidenceFile, UserParam userParam) {
        Optional<VoucherDO> optional = voucherQueryRepository.queryVoucherById(sellerId, voucherId);
        if (!optional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.VOUCHER_NOT_EXISTS);
        }

        VoucherDO voucherDO = optional.get();

        ResultDTO<VoidEntity> checkError = checkPreAuditProcess(userParam.getAppId(),userParam.getUserId(),
                voucherDO.getRole(),voucherDO.getNodeKey(),NumberUtils.toLong(voucherDO.getProcInstId()),
                nodeKey, transitionKey,userParam.getPath());
        if (!ErrorCode.SUCCESS.eq(checkError.getResultCode())){
            if(ErrorCode.STATUS_NOT_MATCH.eq(checkError.getResultCode())){
                return ResultUtil.returnResultDTO(ErrorCode.STATUS_NOT_MATCH);
            }else{
                return ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);
            }
        }
        //  审批流程
        ResultDTO<CompleteTaskResultDTO> resultDTO = completeTask(NumberUtils.toLong(voucherDO.getProcInstId()), nodeKey,
                transitionKey, voucherDO.getRole(), new HashMap<>(), UserUtil.getUserId(), remark);
        if (!resultDTO.isSuccess()) {
            logger.warn("sellerConfirmPayment fail. cause completeTask errorCode={}, errorMsg={}",
                    resultDTO.getResultCode(), resultDTO.getResultMsg());
            return ResultUtil.returnResultDTO(resultDTO.getResultCode(), resultDTO.getResultMsg());
        }
        CompleteTaskResultDTO taskResultDTO = resultDTO.getModel();
        boolean endFlag = taskResultDTO.getEndFlag();
        TaskInstDTO taskInstDTO = taskResultDTO.getTaskInstDTOList().get(0);
        setNodeInfo(voucherDO, endFlag, taskInstDTO, transitionKey);

        if (StringUtils.isNotBlank(remark)) {
            voucherDO.setEvidenceRemark(remark);
        }
        if(StringUtils.isNotBlank(evidenceFile)){
            voucherDO.setEvidenceFile(evidenceFile);
        }
        if(StringUtils.isNotBlank(evidenceFlow)){
            voucherDO.getExtProps().put(VoucherExtPropsKey.EVIDENCE_FLOW.getCode(),evidenceFlow);
        }

        VoucherLogDO voucherLog = VoucherLogUtils.buildSellerAuditPaymentLog(sellerId, voucherId, transitionKey,
                nodeKey, remark, evidenceFile, evidenceFlow, userParam, OptTypeEnum.SELLER_CONFIRM_PAYMENT);
        return transactionWrapper(() -> {
            voucherRepository.confirmPayment(voucherDO,voucherLog);
            return new ResultDTO<>();
        }, "voucher.sellerConfirmPayment");
    }

    @Override
    public ResultDTO<VoidEntity> auditPayment(long sellerId, String voucherId, String transitionKey, String nodeKey,
                                              String remark, UserParam userParam) {
        Optional<VoucherDO> optional = voucherQueryRepository.queryVoucherById(sellerId, voucherId);
        if (!optional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.VOUCHER_NOT_EXISTS);
        }
        VoucherDO voucherDO = optional.get();

        Optional<List<AccountBookDO>> accountBookOptional = accountQueryRepository.queryBookBySeller(sellerId);
        if (!accountBookOptional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.BOOK_NOT_EXISTS);
        }

        List<AccountBookDO> bookList = accountBookOptional.get();

        ResultDTO<VoidEntity> checkError = checkPreAuditProcess(userParam.getAppId(),userParam.getUserId(),
                voucherDO.getRole(),voucherDO.getNodeKey(),NumberUtils.toLong(voucherDO.getProcInstId()),
                nodeKey, transitionKey,userParam.getPath());
        if (!ErrorCode.SUCCESS.eq(checkError.getResultCode())) {
            return ResultUtil.returnResultDTO(checkError);
        }
        long procInstId = NumberUtils.toLong(voucherDO.getProcInstId());
        ResultDTO<CompleteTaskResultDTO> resultDTO = completeTask(procInstId, nodeKey, transitionKey,
                voucherDO.getRole(), new HashMap<>(), UserUtil.getUserId(), remark);
        if (!resultDTO.isSuccess()) {
            return ResultUtil.returnResultDTO(resultDTO.getResultCode(), resultDTO.getResultMsg());
        }
        CompleteTaskResultDTO taskResultDTO = resultDTO.getModel();
        boolean endFlag = taskResultDTO.getEndFlag();

        TaskInstDTO taskInstDTO = taskResultDTO.getTaskInstDTOList().get(0);
        setNodeInfo(voucherDO, endFlag, taskInstDTO, transitionKey);

        VoucherLogDO voucherLog = VoucherLogUtils.buildAuditLog(sellerId,voucherId,transitionKey,nodeKey,remark,
                null, userParam,OptTypeEnum.AUDIT_PAYMENT);
        return transactionWrapper(() -> {
            if (endFlag) {
                voucherDO.setPayFlag(VoucherPayFlag.FINISHED.getCode());
                if(VoucherSubType.PAY_IN_BACK_DEPOSIT.isEquals(voucherDO.getVoucherSubType())
                        ||VoucherSubType.ADD_DEPOSIT.isEquals(voucherDO.getVoucherSubType())){
                    long amount = mathSymbolAmt(voucherDO,voucherDO.getExpectAmt());
                    AccountBookDO accountBook = buildAccountBook(bookList,BookType.DEPOSIT,amount);

                    Optional<AccountBookFlowDO> flowDOOptional = accountQueryRepository
                            .queryBookFlowByOutId(accountBook.getId(), BookFlowOutType.FC_VOUCHER.getCode(), voucherId);
                    if (!flowDOOptional.isPresent()) {
                        return ResultUtil.returnResultDTO(ErrorCode.FAILURE);
                    }
                    AccountBookFlowDO bookFlowDO = flowDOOptional.get();
                    bookFlowDO.setStatus(BookFlowStatus.FINISHED);
                    bookFlowDO.setGmtStatement(voucherDO.getProcEndTime());

                    //查询财务应收应付记录
                    Optional<StatementDO> statementOptional = voucherQueryRepository
                            .queryStatementByVoucher(StatementOutType.FC_VOUCHER.getCode(),voucherId);
                    if(!statementOptional.isPresent()){
                        logger.warn("[auditPayment] statement is null, voucher={}",voucherId);
                        return ResultUtil.returnResultDTO(ErrorCode.FAILURE);
                    }
                    StatementDO statementDO = statementOptional.get();
                    statementDO.setStatus(StatementStatus.FINISHED);

                    voucherRepository.auditPayment(voucherDO, accountBook, bookFlowDO, statementDO,voucherLog);
                }
            } else {
                voucherRepository.auditPayment(voucherDO,voucherLog);
            }
            return new ResultDTO<>();
        }, "voucher.financeConfirmPayment");
    }

    @Override
    public ResultDTO<VoidEntity> autoCreatePunish(Date startTime, Date endTime) {
        VoucherDeliveryPageQuery pageQuery = new VoucherDeliveryPageQuery();
        pageQuery.setStartCreated(startTime);
        pageQuery.setEndCreated(endTime);

        int total = voucherQueryRepository.queryCount(pageQuery);
        if (0 == total) {
            return new ResultDTO<>();
        }
        pageQuery.setPageSize(100);
        Optional<List<VoucherDeliveryDO>> ret = voucherQueryRepository.pageQueryVoucherDelivery(pageQuery);
        while (ret.isPresent() && ret.get().size() > 0) {
            for (VoucherDeliveryDO deliveryDO : ret.get()) {
                handleVoucherDeliveryDO(deliveryDO);
            }
            pageQuery.setPageNo(pageQuery.getPageNo() + 1);
            ret = voucherQueryRepository.pageQueryVoucherDelivery(pageQuery);
        }
        return new ResultDTO<>();
    }

    @Override
    public ResultDTO<VoidEntity> autoAgreePunish(){

        //diamond 最大允许申述天数
        int day = controlCache.getVoucherPunishAutoAgreeInterval();
        Date procStartTime = TimeUtils.addDate(TimeUtils.getBeginOfDate(new Date()),-day);
        //分页查询t+4的未申述的违规单 , procStartTime 比较  voucherType为违规单
        VoucherPageQuery pageQuery = new VoucherPageQuery();
        pageQuery.setCommitEnd(procStartTime);
        pageQuery.setVoucherType(VoucherType.VIOLATION.getCode());
        List<String> nodeKeys = new LinkedList<>();
        nodeKeys.add(VoucherStatus.SELLER_DEAL.getCode());
        pageQuery.setNodeKeys(nodeKeys);
        int total = voucherQueryRepository.queryVoucherCount(pageQuery);

        if(total == 0){
            return ResultUtil.returnResultDTO(ErrorCode.SUCCESS);
        }

        Optional<List<VoucherDO>> voucherOptional = voucherQueryRepository.pageQueryVoucher(pageQuery);
        int actual = 0;
        pageQuery.setPageSize(100);
        while(voucherOptional.isPresent() && !CollectionUtils.isEmpty(voucherOptional.get())){
            List<VoucherDO> voucherDOs = voucherOptional.get();
            for (VoucherDO voucherDO : voucherDOs){
                ResultDTO<VoidEntity> resultDTO = autoAgreePunish(voucherDO);
                if(ErrorCode.SUCCESS.eq(resultDTO.getResultCode())){
                    actual ++;
                }
            }
            pageQuery.setPageNo(pageQuery.getPageNo() + 1);
            voucherOptional = voucherQueryRepository.pageQueryVoucher(pageQuery);
        }

        logger.info("[autoAgreePunish] must agree total={}, but actual={}",total,actual);
        return ResultUtil.returnResultDTO(ErrorCode.SUCCESS);
    }


    @Override
    public ResultDTO<String> addBalanceAmt(long sellerId, long accountBookId, long paramAmount, String remark,
                                           UserParam userParam) {
        Optional<AccountBookDO> bookOptional =
                accountQueryRepository.queryBookBySellerAndBookId(sellerId, accountBookId);
        if (!bookOptional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.BOOK_NOT_EXISTS);
        }
        // TODO: 2017/12/26 如果账本已经冻结  需要报警kv?
        AccountBookDO bookDO = bookOptional.get();

        return doAddBalanceAmt(sellerId, bookDO, paramAmount, remark, userParam);
    }

    @Override
    public ResultDTO<VoidEntity> batchAddBalanceAmt() {
        BookPageQuery bookPageQuery = new BookPageQuery();
        bookPageQuery.setBookType(BookType.DEPOSIT.getCode());
        bookPageQuery.setStatus(BookStatus.VALID.getCode());
        int total = accountQueryRepository.queryBookCount(bookPageQuery);
        logger.info("[batchAddBalanceAmt] deposit valid accountBook's count is {}", total);
        if (0 == total) {
            return new ResultDTO<>();
        }

        // Map<Long, AccountBookDO>  Map<sellerId, accountBook>
        Map<Long, AccountBookDO> bookMap = new HashMap<>();

        int pageSize = QUERY_BOOK_PAGE_SIZE;
        int index = total % pageSize == 0 ? total / pageSize : total / pageSize + 1;
        bookPageQuery.setPageSize(pageSize);
        for (int i = 0; i < index; i++) {
            bookPageQuery.setPageNo(i + 1);
            Optional<List<AccountBookDO>> optional = accountQueryRepository.pageQueryBook(bookPageQuery);

            optional.ifPresent(n -> bookMap.putAll(
                    n.stream().collect(Collectors.toMap(AccountBookDO::getSellerId, v -> v))
            ));
        }

        bookMap.forEach(this::addBalanceAmt);

        return new ResultDTO<>();
    }

    /**
     * 根据确认的违规单创建补齐缴费的缴费单
     * 系统定时任务调用的话，只传前面两个参数，剩余的为null
     * 商管手动创建调用的加，paramAmount不能为null
     *
     * @param sellerId    商家id
     * @param bookDO      账本
     * @param paramAmount 商管在页面传入的金额
     * @param remark      商管在页面传入的备注
     * @param userParam   userParam
     * @return ResultDTO<String>
     */
    private ResultDTO<String> doAddBalanceAmt(long sellerId, AccountBookDO bookDO, Long paramAmount,
                                              String remark, UserParam userParam) {
        ResultDTO<String> result = new ResultDTO<>();

        long accountBookId = bookDO.getId();
        BookFlowPageQuery pageQuery = buildBookFlowPageQuery(sellerId, accountBookId);
        int total = accountQueryRepository.queryBookFlowCount(pageQuery);
        logger.info("[doAddBalanceAmt] queryBookFlowCount, count is {}, pageQuery is {}",
                total, JsonUtil.obj2Str(pageQuery));
        if (total == 0) {
            return ResultUtil.returnResultDTO(ErrorCode.ADD_FAIL_CASE_AMOUNT_ZERO);
        }

        long amount = 0L;
        int pageSize = QUERY_BOOK_FLOW_PAGE_SIZE;
        int index = total % pageSize == 0 ? total / pageSize : total / pageSize + 1;
        pageQuery.setPageSize(pageSize);
        List<List<AccountBookFlowDO>> lists = new LinkedList<>();
        for (int i = 0; i < index; i++) {
            pageQuery.setPageNo(i + 1);
            Optional<List<AccountBookFlowDO>> optional = accountQueryRepository.pageQueryBookFlow(pageQuery);
            if (optional.isPresent()) {
                lists.add(optional.get());
                amount += optional.get().stream().mapToLong(AccountBookFlowDO::getAmount).sum();
            }
        }

        if (amount == 0) {
            return ResultUtil.returnResultDTO(ErrorCode.ADD_FAIL_CASE_AMOUNT_ZERO);
        }
        amount = Math.abs(amount);

        String voucherId = getVoucherOutId();
        String procName = VoucherProcNameType.DEPOSIT_PAYMENT.getCode();
        ResultDTO<CreateProcInstResultDTO> resultDTO = createProcess(procName, voucherId, procName);
        logger.info("[doAddBalanceAmt] createProcess, procName is {}, voucherId is {}, resultDTO is {}",
                procName, voucherId, JsonUtil.obj2Str(resultDTO));
        if (!resultDTO.isSuccess()) {
            return ResultUtil.returnResultDTO(resultDTO.getResultCode(), resultDTO.getResultMsg());
        }

        CreateProcInstResultDTO createProcInstResultDTO = resultDTO.getModel();
        TaskInstDTO taskInstDTO = createProcInstResultDTO.getTaskInstDTOList().get(0);
        Long procInstId = createProcInstResultDTO.getProcInstId();

        VoucherDO voucherDO = buildPaymentVoucherDO(voucherId, amount, sellerId, procInstId, remark);
        setNodeInfo(voucherDO, false, taskInstDTO, null);

        AccountBookFlowDO bookFlowDO = buildAccountBookFlow(voucherDO, bookDO);
        bookFlowDO.setStatus(BookFlowStatus.NO_FINISHED);
        bookFlowDO.setGmtStatement(null);
        bookFlowDO.setAmount(mathSymbolAmt(voucherDO, amount));

        StatementDO statementDO = buildStatement(sellerId, SubjectEnum.SERVICE_FEE.getCode(), new Date(),
                null, amount, null, null, null, null, null, null, null);

        VoucherLogDO voucherLog;
        if (null == paramAmount) {
            voucherLog = VoucherLogUtils
                    .buildSystemAddBalanceAmtLog(sellerId, accountBookId, amount, OptTypeEnum.SYSTEM_ADD_BALANCE_AMT);
        } else {
            result.setModel(ADD_BALANCE_TIPS.replace("X", String.valueOf(CommonUtil.fenToYuan(amount))));
            voucherLog = VoucherLogUtils.buildAddBalanceAmtLog(sellerId,
                    accountBookId, amount, remark, userParam, OptTypeEnum.ADD_BALANCE_AMT);
        }

        return transactionWrapper(() -> {
            voucherRepository.addBalanceAmt(voucherDO, bookFlowDO, statementDO, lists,
                    BookFlowWriteOffOutType.FC_VOUCHER.getCode(), voucherLog);
            return result;
        }, "voucher.addBalanceAmt");
    }



    private ResultDTO<String> addBalanceAmt(long sellerId, AccountBookDO accountBookDO) {
        return this.doAddBalanceAmt(sellerId, accountBookDO, null, null, null);
    }

    private ResultDTO<AccountBookDO> queryAndCreateAccountBook(long sellerId, int bookType) {
        Optional<AccountBookDO> bookOptional = accountQueryRepository.queryBookBySeller(sellerId, bookType);
        if (!bookOptional.isPresent()) {
            ResultDTO<VoidEntity> createResult = this.createAccount(sellerId);
            if (!ErrorCode.SUCCESS.eq(createResult.getResultCode())) {
                logger.info(TroyUtil.getKVItem(getNotifyLog(),
                        "[queryAndCreateAccountBook] create voucher error. sellerId=" + sellerId));
                return ResultUtil.returnResultDTO(ErrorCode.FAILURE);
            }
            bookOptional = accountQueryRepository.queryBookBySeller(sellerId, bookType);
            if (!bookOptional.isPresent()) {
                return ResultUtil.returnResultDTO(ErrorCode.FAILURE);
            }
        }

        AccountBookDO bookDO = bookOptional.get();
        if (BookStatus.INVALID.isEquals(bookDO.getStatus())) {
            return ResultUtil.returnResultDTO(ErrorCode.BOOK_IS_IN_VALID);
        }

        return new ResultDTO<>(bookDO);
    }

    private VoucherDO buildVoucherDO(long sellerId, String outId, VoucherSubType subType, String remark, long amount) {
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setSellerId(sellerId);
        voucherDO.setOutId(outId);
        voucherDO.setVoucherType(subType.getParent());
        voucherDO.setVoucherSubType(subType);
        voucherDO.setCreateRemark(remark);
        voucherDO.setExpectAmt(amount);
        voucherDO.setActualAmt(amount);
        voucherDO.setPayFlag(VoucherPayFlag.NO_FINISHED.getCode());
        return voucherDO;
    }

    private void handleVoucherDeliveryDO(VoucherDeliveryDO deliveryDO) {
        if (Objects.nonNull(deliveryDO.getVoucherId())) {
            return;
        }
        Long sellerId = deliveryDO.getSellerId();
        BookPageQuery bookPageQuery = new BookPageQuery();
        bookPageQuery.setSellerId(sellerId);
        bookPageQuery.setBookType(BookType.DEPOSIT.getCode());
        if (0 == accountQueryRepository.queryBookCount(bookPageQuery)) {
            ResultDTO<VoidEntity> ret = this.createAccount(sellerId);
            if (!ErrorCode.SUCCESS.eq(ret.getResultCode())) {
                return;
            }
        } else {
            Optional<AccountBookDO> validBook =
                    accountQueryRepository.queryValidBookBySeller(sellerId, BookType.DEPOSIT.getCode());
            if (!validBook.isPresent()) {
                logger.info(TroyUtil.getKVItem(getNotifyLog(),
                        "create voucher, but book is invalid. sellerId=" + sellerId));
                return;
            }
        }

        String outId = getVoucherOutId();

        ResultDTO<CreateProcInstResultDTO> resultDTO =
                createProcess(VoucherProcNameType.DEPOSIT_VIOLATION_DELIVERY.getCode(), outId,
                        VoucherProcNameType.DEPOSIT_VIOLATION_DELIVERY.getCode());
        if (!resultDTO.isSuccess()) {
            return;
        }
        VoucherDO voucherDO = new VoucherDO();
        voucherDO.setOutId(outId);
        voucherDO.setVoucherType(VoucherType.VIOLATION);
        voucherDO.setVoucherSubType(VoucherSubType.DELAY_DELIVERY_VIOLATION);
        voucherDO.setSellerId(deliveryDO.getSellerId());
        voucherDO.setExpectAmt(deliveryDO.getAmount());
        voucherDO.setObjId(deliveryDO.getTradeId());
        voucherDO.setObjType(VoucherObjType.TRADE.getCode());

        CreateProcInstResultDTO createProcInstResultDTO = resultDTO.getModel();
        voucherDO.setProcInstId(String.valueOf(createProcInstResultDTO.getProcInstId()));
        // 这里流程定义来保证只会有一个 nextNode
        TaskInstDTO taskInstDTO = createProcInstResultDTO.getTaskInstDTOList().get(0);
        setNodeInfo(voucherDO, false, taskInstDTO, null);
        voucherDO.setProcStartTime(new Date());
        VoucherLogDO voucherLog = VoucherLogUtils.buildCreatePunishLog(sellerId,
                VoucherSubType.DELAY_DELIVERY_VIOLATION, voucherDO.getExpectAmt(), null, null, null,
                OptTypeEnum.SYSTEM_CREATE_PUNISH);
        ResultDTO<VoidEntity> ret = transactionWrapper(() -> {
            voucherRepository.autoCreatePunish(voucherDO, deliveryDO,voucherLog);
            return new ResultDTO<>();
        }, "voucher.autoCreatePunish");
        if (!ErrorCode.SUCCESS.eq(ret.getResultCode())) {
            logger.warn("voucher.autoCreatePunish occurs error: voucherDO={}, deliveryDO={}, error={}",
                    JsonUtil.obj2Str(voucherDO), deliveryDO.toString(), ret.toString());
        }
    }

    private AccountBookDO buildAccountBook(List<AccountBookDO> bookList, BookType bookType, long amount) {
        AccountBookDO bookDO = bookList.stream().
                filter(book -> bookType.isEquals(book.getBookType())).findFirst().orElse(new AccountBookDO());
        bookDO.setBalanceAmt(bookDO.getBalanceAmt() + amount);
        return bookDO;
    }

    private long mathSymbolAmt(VoucherDO voucherDO, long amount) {
        long amt = 0L;
        if (StringUtils.equals("+", voucherDO.getVoucherSubType().getSymbol())) {
            amt += amount;
        } else {
            amt -= amount;

        }
        return amt;
    }

    private AccountBookFlowDO buildAccountBookFlow(VoucherDO voucher, AccountBookDO accountBook) {

        AccountBookFlowDO bookFlowDO = new AccountBookFlowDO();
        bookFlowDO.setBookId(accountBook.getId());
        bookFlowDO.setBookType(accountBook.getBookType());
        bookFlowDO.setFlowSubType(BookFlowSubType.valueOf(voucher.getVoucherSubType().getCode()));
        bookFlowDO.setFlowType(BookFlowType.valueOf(voucher.getVoucherType().getCode()));
        bookFlowDO.setGmtStatement(new Date());
        bookFlowDO.setOutId(voucher.getVoucherId());
        bookFlowDO.setOutType(BookFlowOutType.FC_VOUCHER);
        bookFlowDO.setSellerId(accountBook.getSellerId());
        bookFlowDO.setStatus(BookFlowStatus.FINISHED);
//        bookFlowDO.setWriteOffType(BookFlowWriteOffOutType.FC_VOUCHER);

        return bookFlowDO;
    }

    private StatementDO buildStatement(long sellerId,int subject,Date firstTime,Date secondTime,
                                       Long platformReceivable,Long platformReceivableTax,Long platformPayable,
                                       Long platformPayableTax,Long platformReceipts,Long platformReceiptsTax,
                                       Long platformPaid, Long platformPaidTax){

        StatementDO statementDO = new StatementDO();
        statementDO.setSellerId(sellerId);
        statementDO.setFirstTime(firstTime);
        statementDO.setSecondTime(secondTime);
        statementDO.setStatus(StatementStatus.NO_FINISHED);
        statementDO.setOutType(StatementOutType.FC_VOUCHER);
        statementDO.setSubject(SubjectEnum.valueOf(subject));
        statementDO.setPlatformReceivable(platformReceivable);
        statementDO.setPlatformReceivableTax(platformReceivableTax);
        statementDO.setPlatformPayable(platformPayable);
        statementDO.setPlatformPayableTax(platformPayableTax);
        statementDO.setPlatformReceipts(platformReceipts);
        statementDO.setPlatformReceiptsTax(platformReceiptsTax);
        statementDO.setPlatformPaid(platformPaid);
        statementDO.setPlatformPaidTax(platformPaidTax);
        return statementDO;
    }

    private boolean canDeletePunish(VoucherDO voucherDO) {
        return VoucherStatus.CREATED.isEquals(voucherDO.getNodeKey())
                && ((VoucherSubType.FAKE_VIOLATION.isEquals(voucherDO.getVoucherSubType())
                || VoucherSubType.FALSE_CONDUCT_VIOLATION.isEquals(voucherDO.getVoucherSubType())));
    }

    private void setNodeInfo(VoucherDO voucherDO, boolean endFlag, TaskInstDTO taskInstDTO, String buttonKey) {
        if (endFlag) {
            voucherDO.setNodeKey(buttonKey);
            voucherDO.setNodeCatKey(buttonKey);
            voucherDO.setRole("");
            //设置数据库流程结束时间
            voucherDO.setProcEndTime(new Date());
        } else {
            voucherDO.setNodeKey(taskInstDTO.getNodeKey());
            voucherDO.setNodeCatKey(taskInstDTO.getNodeCatKey());
            voucherDO.setRole(taskInstDTO.getRole());
        }
    }

    private int queryVoucherCount(VoucherPageQuery voucherPageQuery) {
        return voucherQueryRepository.queryVoucherCount(voucherPageQuery);
    }

    private void buildEndBookAndFlow(VoucherDO voucherDO, List<AccountBookDO> bookList, List<AccountBookDO> books,
                                     List<AccountBookFlowDO> accountBookFlows) {
        if (voucherDO.getExpectAmt() > 0) {
            long amount = mathSymbolAmt(voucherDO, voucherDO.getExpectAmt());
            AccountBookDO accountBook = buildAccountBook(bookList, BookType.DEPOSIT, amount);
            AccountBookFlowDO accountBookFlow = buildAccountBookFlow(voucherDO, accountBook);
            accountBookFlow.setAmount(amount);

            books.add(accountBook);
            accountBookFlows.add(accountBookFlow);
            voucherDO.setActualAmt(voucherDO.getExpectAmt());
        }

        if (voucherDO.getExpectPoint() > 0) {
            long amount = mathSymbolAmt(voucherDO, voucherDO.getExpectPoint());
            AccountBookDO accountBook = buildAccountBook(bookList, BookType.INTEGRATION, amount);
            AccountBookFlowDO accountBookFlow = buildAccountBookFlow(voucherDO, accountBook);
            accountBookFlow.setAmount(amount);
            books.add(accountBook);
            accountBookFlows.add(accountBookFlow);
            voucherDO.setActualPoint(voucherDO.getExpectAmt());
        }
    }

    private BookFlowPageQuery buildBookFlowPageQuery(long sellerId, long accountBookId) {
        BookFlowPageQuery pageQuery = new BookFlowPageQuery();
        pageQuery.setSellerId(sellerId);
        pageQuery.setBookId(accountBookId);
        pageQuery.setHasWriteOff(false);
        List<Integer> flowTypes = new LinkedList<>();
        flowTypes.add(BookFlowType.VIOLATION.getCode());
        pageQuery.setFlowTypes(flowTypes);
        Date endDate = new Date();
        pageQuery.setStatementEnd(endDate);
        int span = controlCache.getAccountBookFlowWriteOffQueryDaySpan();
        pageQuery.setStatementStart(TimeUtils.addDate(endDate, -span));
        return pageQuery;
    }

    private VoucherDO buildPaymentVoucherDO(String voucherId, long amount, long sellerId, long procInstId, String remark) {
        VoucherDO voucher = new VoucherDO();
        voucher.setOutId(voucherId);
        voucher.setSellerId(sellerId);
        voucher.setVoucherType(VoucherType.PAYMENT);
        voucher.setVoucherSubType(VoucherSubType.PAY_IN_BACK_DEPOSIT);
        voucher.setPayFlag(VoucherPayFlag.NO_FINISHED.getCode());
        voucher.setActualAmt(amount);
        voucher.setExpectAmt(amount);
        voucher.setProcInstId(String.valueOf(procInstId));
        voucher.setCreateRemark(remark);
        voucher.setProcStartTime(new Date());
        return voucher;
    }

    private ResultDTO<VoidEntity> autoAgreePunish(VoucherDO voucherDO) {
        String nodeKey = voucherDO.getNodeKey();
        String transitionKey = controlCache.getVoucherPunishSellerAgreeTransitionKey();


        // 1 查询账本信息 存在即存在所有类型账本
        Optional<List<AccountBookDO>> accountBookOptional =
                accountQueryRepository.queryBookBySeller(voucherDO.getSellerId());
        if (!accountBookOptional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.BOOK_NOT_EXISTS);
        }
        List<AccountBookDO> bookList = accountBookOptional.get();

        long procInstId = NumberUtils.toLong(voucherDO.getProcInstId());
        // 2 校验按钮是否符合节点信息
        if (!isContainButtonKey(procInstId, nodeKey, transitionKey)) {
            return ResultUtil.returnResultDTO(ErrorCode.FLOW_OPT_NOT_MATCH);
        }

        // 3 审批流程
        ResultDTO<CompleteTaskResultDTO> resultDTO =
                completeState(procInstId, nodeKey, transitionKey, new HashMap<>(), PUNISH_SYSTEM_AGREE_REMARK);

        if (!resultDTO.isSuccess()) {
            return ResultUtil.returnResultDTO(resultDTO.getResultCode(), resultDTO.getResultMsg());
        }
        CompleteTaskResultDTO taskResultDTO = resultDTO.getModel();
        boolean endFlag = taskResultDTO.getEndFlag();
        TaskInstDTO taskInstDTO = taskResultDTO.getTaskInstDTOList().get(0);
        setNodeInfo(voucherDO, endFlag, taskInstDTO, transitionKey);

        List<AccountBookFlowDO> accountBookFlows = new LinkedList<>();
        List<AccountBookDO> books = new LinkedList<>();
        voucherDO.setPayFlag(VoucherPayFlag.FINISHED.getCode());
        buildEndBookAndFlow(voucherDO, bookList, books, accountBookFlows);

        VoucherLogDO voucherLog = VoucherLogUtils.buildSystemAuditLog(voucherDO.getSellerId(),voucherDO.getVoucherId(),
                transitionKey,nodeKey,OptTypeEnum.SYSTEM_AGREE_PUNISH);
        ResultDTO<VoidEntity> ret =  transactionWrapper(() -> {
            voucherRepository.auditPunish(voucherDO, books, accountBookFlows, voucherLog);
            return new ResultDTO<>();
        }, "voucher.autoAgreePunish");
        if(!ErrorCode.SUCCESS.eq(ret.getResultCode())){
            logger.warn("[autoAgreePunish] occurs error: voucherDO={}, books={},bookFlows={} error={}",
                    voucherDO.toString(), JsonUtil.obj2Str(books), JsonUtil.obj2Str(accountBookFlows),ret.toString());
        }
        return ret;
    }

    /**
     * 组合账本数据
     * @param sellerId  卖家ID
     * @param bookType  账本类型
     * @return  账本数据
     */
    private AccountBookDO buildBook(long sellerId, int bookType){
        AccountBookDO bookDO = new AccountBookDO();
        bookDO.setSellerId(sellerId);
        bookDO.setContractAmt(0L);
        bookDO.setActualContractAmt(0L);
        bookDO.setBalanceAmt(0L);
        bookDO.setFreezingAmt(0L);
        bookDO.setBookType(BookType.valueOf(bookType));
        return bookDO;

    }

    /**
     * 根据卖家ID创建账户及账本
     *
     * @param sellerId 卖家ID
     * @return ResultDTO<VoidEntity>
     */
    private ResultDTO<VoidEntity> createAccount(long sellerId){
        KyCallResult<SellerDO> kyCallResult = sellerService.getSellerById(sellerId);
        if (!kyCallResult.isSuccess()) {
            return  ResultUtil.returnResultDTO(ErrorCode.SELLER_NOT_EXISTS);
        }

        Optional<AccountDO> optionalAccountDO = accountQueryRepository.queryAccountBySeller(sellerId);

        Map<BookType,AccountBookDO> bookDOMap = new HashMap<>(4) ;
        AccountDO accountDO;
        if (optionalAccountDO.isPresent()) {
            accountDO = optionalAccountDO.get();
            Optional<List<AccountBookDO>> optionalBookDO = accountQueryRepository.queryBookBySeller(sellerId);
            optionalBookDO.ifPresent(bookDOs ->
                    bookDOMap.putAll(bookDOs.stream()
                            .collect(Collectors.toMap(AccountBookDO::getBookType,sellerDO->sellerDO))));
        } else {
            accountDO = new AccountDO();
            accountDO.setSellerId(sellerId);
            accountDO.setName(kyCallResult.getModel().getName());
        }
        List<AccountBookDO> bookDOs = new LinkedList<>();
        if (!bookDOMap.containsKey(BookType.DEPOSIT)) {
            bookDOs.add(buildBook(sellerId, BookType.DEPOSIT.getCode()));
        }
        if (!bookDOMap.containsKey(BookType.GIFT)) {
            bookDOs.add(buildBook(sellerId, BookType.GIFT.getCode()));
        }
        if (!bookDOMap.containsKey(BookType.INTEGRATION)) {
            bookDOs.add(buildBook(sellerId, BookType.INTEGRATION.getCode()));
        }
        if (!bookDOMap.containsKey(BookType.ANNUAL_FEE)) {
            bookDOs.add(buildBook(sellerId, BookType.ANNUAL_FEE.getCode()));
        }
        if (CollectionUtils.isEmpty(bookDOs)) {
            return ResultUtil.returnResultDTO(ErrorCode.SUCCESS);
        }
        AccountDO finalAccountDO = accountDO;

        return transactionWrapper(() -> {
            if (finalAccountDO.getId() <= 0L ) {
                accountRepository.createAccountAndBook(finalAccountDO,bookDOs);
            } else {
                accountRepository.createAccountBook(bookDOs);
            }
            return new ResultDTO<>();
        }, "voucher.createAccount");
    }

    private String getVoucherOutId(){
        return OUT_PRE + voucherIDPool.getNewId();
    }

    private String getNotifyLog() {
        return "VoucherManagerNotifyLog";
    }

}
