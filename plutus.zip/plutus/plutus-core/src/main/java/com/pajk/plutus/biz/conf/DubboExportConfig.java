package com.pajk.plutus.biz.conf;

import com.alibaba.dubbo.config.spring.ServiceBean;
import com.pajk.plutus.client.api.gw.BillGWService;
import com.pajk.plutus.client.api.gw.BillQueryGWService;
import com.pajk.plutus.client.api.gw.DepositGWService;
import com.pajk.plutus.client.api.gw.DepositQueryGWService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by fanhuafeng on 17/3/6.
 * Modify by fanhuafeng on 17/3/6
 */
@Configuration
public class DubboExportConfig {

    @Value("${public.dubbo.version}")
    private String providerVersion;

    @Value("${dubbo.consumer.timeout}")
    private int commonTimeOut = 3000;

    @Bean
    @Autowired
    public ServiceBean<DepositGWService> depositGWServiceBean(DepositGWService service) {
        ServiceBean<DepositGWService> sb = new ServiceBean<>();
        sb.setInterface(DepositGWService.class);
        sb.setTimeout(commonTimeOut);
        sb.setVersion(providerVersion);
        sb.setRef(service);
        return sb;
    }

    @Bean
    @Autowired
    public ServiceBean<DepositQueryGWService> depositQueryGWServiceBean(DepositQueryGWService service) {
        ServiceBean<DepositQueryGWService> sb = new ServiceBean<>();
        sb.setInterface(DepositQueryGWService.class);
        sb.setTimeout(commonTimeOut);
        sb.setVersion(providerVersion);
        sb.setRef(service);
        return sb;
    }

    @Bean
    @Autowired
    public ServiceBean<BillGWService> billGwServiceServiceBean(BillGWService service) {
        ServiceBean<BillGWService> sb = new ServiceBean<>();
        sb.setInterface(BillGWService.class);
        sb.setTimeout(commonTimeOut);
        sb.setVersion(providerVersion);
        sb.setRef(service);
        return sb;
    }

    @Bean
    @Autowired
    public ServiceBean<BillQueryGWService> billQueryGWServiceBean(BillQueryGWService service) {
        ServiceBean<BillQueryGWService> sb = new ServiceBean<>();
        sb.setInterface(BillQueryGWService.class);
        sb.setTimeout(commonTimeOut);
        sb.setVersion(providerVersion);
        sb.setRef(service);
        return sb;
    }
}
