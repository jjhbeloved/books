package com.pajk.plutus.biz.service.gw;

import com.pajk.plutus.biz.common.aop.GwLogger;
import com.pajk.plutus.biz.common.util.CommonUtil;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.client.api.gw.DepositGWService;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.VoidGwEntity;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import net.pocrd.dubboext.DubboExtProperty;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by  guguangming on 2017/12/13
 **/
@Service
@GwLogger
public class DepositGWServiceImpl extends AbstractGwServiceImpl implements DepositGWService {

    private static final int EVIDENCE_FLOW_MAX_LENGTH = 200;
    private static final int REMARK_MAX_LENGTH = 500;
    private static final String VOUCHER = "nmd.voucher";
    private static final String UPDATE="update";

    @Autowired
    private VoucherManager voucherManager;

    @Override
    public VoidGwEntity sellerConfirmPayment(long appId, long userId, long sellerId, String voucherId,
                                             String transitionKey, String nodeKey, String remark,
                                             String evidenceFlow, String evidenceFile) {
        String path = "plutus.sellerConfirmPayment";

        if (StringUtils.length(remark) > REMARK_MAX_LENGTH ||
                ! (CommonUtil.checkStringLength(evidenceFlow, EVIDENCE_FLOW_MAX_LENGTH))) {
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }

        if(!CommonUtil.isValidVoucherId(voucherId)){
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }

        if(StringUtils.isNotBlank(evidenceFile)){
            if(!CommonUtil.checkFile(evidenceFile)){
                DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
                return null;
            }
        }
        UserParam userParam = new UserParam(appId, userId);
        userParam.setPath(path);
        return gwWrapper(() -> {
            ResultDTO<VoidEntity> result = voucherManager.sellerConfirmPayment(sellerId,
                    voucherId, transitionKey, nodeKey, remark, evidenceFlow, evidenceFile, userParam);
            return mergeErrorCode(result);
        }, userId, sellerId, appId, VOUCHER, UPDATE);
    }

    @Override
    public VoidGwEntity sellerDealPunish(long appId, long userId, long sellerId, String voucherId, String transitionKey,
                                         String nodeKey, String evidenceRemark, String evidenceFile) {
        String path = "plutus.sellerDealPunish";

        if (StringUtils.length(evidenceRemark) > REMARK_MAX_LENGTH) {
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }

        if(!CommonUtil.isValidVoucherId(voucherId)){
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }

        if(StringUtils.isNotBlank(evidenceFile)){
            if(!CommonUtil.checkFile(evidenceFile)){
                DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
                return null;
            }
        }
        UserParam userParam = new UserParam(appId, userId);
        userParam.setPath(path);

        return gwWrapper(() -> {
            ResultDTO<VoidEntity> result = voucherManager.sellerDealPunish(sellerId, voucherId, transitionKey, nodeKey,
                    evidenceRemark, evidenceFile, userParam);
            return mergeErrorCode(result);
        }, userId, sellerId, appId, VOUCHER, UPDATE);
    }

    private VoidGwEntity mergeErrorCode(ResultDTO<VoidEntity> result) {
        if (ErrorCode.SUCCESS.eq(result.getResultCode())) {
            return new VoidGwEntity();
        } else if (ErrorCode.VOUCHER_NOT_EXISTS.eq(result.getResultCode())) {
            DubboExtProperty.setErrorCode(JkApiCode.VOUCHER_NOT_EXISTS);
        } else if (ErrorCode.STATUS_NOT_MATCH.eq(result.getResultCode())) {
            DubboExtProperty.setErrorCode(JkApiCode.STATUS_NOT_MATCH);
        } else if (ErrorCode.NO_PERMISSION_TO_OPT.eq(result.getResultCode())) {
            DubboExtProperty.setErrorCode(JkApiCode.NO_PERMISSION_TO_OPT);
        } else {
            DubboExtProperty.setErrorCode(JkApiCode.FAILURE);
        }
        return null;
    }

}
