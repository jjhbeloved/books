package com.pajk.plutus.biz.exceptions;

/**
 * Created by fanhuafeng on 17/2/23.
 * Modify by fanhuafeng on 17/2/23
 */
public class DBException extends RuntimeException {

    private static final long serialVersionUID = -6919463227133991969L;
    private int code;

    public DBException(int code, String message) {
        super(message);
        this.code = code;
    }

    public int getCode() {
        return code;
    }

}
