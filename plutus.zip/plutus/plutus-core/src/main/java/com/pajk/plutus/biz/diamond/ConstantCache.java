package com.pajk.plutus.biz.diamond;

import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.concurrent.Executor;

/**
 * Created by fanhuafeng on 17/3/23.
 * Modify by fanhuafeng on 17/3/23
 */
@Service("constantCache")
public class ConstantCache extends DiamondCache {

    private static final String DATA_ID = "com.pajk.plutus.constant";

    /**
     * 内网使用的文件网关url
     */
    private static final String FILEGW_INNER = "filegw.domain.inner";

    /**
     * 外网使用的文件网关url
     */
    private static final String FILEGW_OUTER = "filegw.domain.outer";

    public ConstantCache() {
        super("");
    }

    @Override
    public void receiveConfigInfo0(String dataId, String group, String configInfo) {
        loadProperties(configInfo);
    }

    @Override
    public Executor getExecutor() {
        return null;
    }

    @PostConstruct
    public void init() {
        super.init(DATA_ID);
    }

    @Override
    public String getDataId() {
        return DATA_ID;
    }

    public String getFilegwDomainInner() {
        return getValue(FILEGW_INNER);
    }

    public String getFilegwDomainOuter() {
        return getValue(FILEGW_OUTER);
    }

}
