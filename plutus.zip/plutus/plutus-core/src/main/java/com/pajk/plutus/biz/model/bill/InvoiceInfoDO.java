package com.pajk.plutus.biz.model.bill;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * @author david
 * @since created by on 17/12/14 10:45
 */
public class InvoiceInfoDO extends BaseDO {

    private static final long serialVersionUID = 3384721955108341396L;

    private Long invoiceAmt;

    private Long invoiceTax;

    private String trackingNumber;

    private String invoiceId;

    public Long getInvoiceAmt() {
        return invoiceAmt;
    }

    public void setInvoiceAmt(Long invoiceAmt) {
        this.invoiceAmt = invoiceAmt;
    }

    public Long getInvoiceTax() {
        return invoiceTax;
    }

    public void setInvoiceTax(Long invoiceTax) {
        this.invoiceTax = invoiceTax;
    }

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    public String getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(String invoiceId) {
        this.invoiceId = invoiceId;
    }
}
