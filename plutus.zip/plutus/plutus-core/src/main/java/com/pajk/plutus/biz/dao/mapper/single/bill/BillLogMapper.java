package com.pajk.plutus.biz.dao.mapper.single.bill;

import com.pajk.plutus.biz.model.mapper.single.bill.BillLogDAO;

/**
 * Created by arjaylv on 2017/12/11.
 *
 * @author arjaylv
 */
public interface BillLogMapper {

    int insert(BillLogDAO billLogDAO);

}
