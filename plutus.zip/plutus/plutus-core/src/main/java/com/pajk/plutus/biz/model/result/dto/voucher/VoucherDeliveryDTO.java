package com.pajk.plutus.biz.model.result.dto.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by guguangming on 2017/12/14
 * Modified by fuyongda on 2017/12/17
 **/
public class VoucherDeliveryDTO extends BaseDO {

    private static final long serialVersionUID = -7742792158136348985L;

    /**
     * 订单id
     */
    private String tradeId;

    /**
     * 支付时间
     */
    private String payTime;

    /**
     * 物流揽收时间
     */
    private String lgTime;

    /**
     * 物流时间
     */
    private String deliveryTime;

    /**
     * 物流运单号
     */
    private String trackingNumber;

    /**
     * 物流公司id
     */
    private String companyId;

    /**
     * 物流公司名称
     */
    private String companyName;

    /**
     * 收货地址(省和市)
     */
    private String address;

    /**
     * 交易金额(单位分)
     */
    private long amount;

    /**
     * 支付类型
     */
    private String payMode;

    public String getPayMode() {
        return payMode;
    }

    public void setPayMode(String payMode) {
        this.payMode = payMode;
    }

    public String getTradeId() {
        return tradeId;
    }

    public void setTradeId(String tradeId) {
        this.tradeId = tradeId;
    }

    public String getPayTime() {
        return payTime;
    }

    public void setPayTime(String payTime) {
        this.payTime = payTime;
    }

    public String getLgTime() {
        return lgTime;
    }

    public void setLgTime(String lgTime) {
        this.lgTime = lgTime;
    }

    public String getDeliveryTime() {
        return deliveryTime;
    }

    public void setDeliveryTime(String deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

}
