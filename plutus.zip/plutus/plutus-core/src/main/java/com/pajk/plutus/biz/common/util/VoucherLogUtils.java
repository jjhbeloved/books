package com.pajk.plutus.biz.common.util;

import com.alibaba.fastjson.JSONObject;
import com.pajk.plutus.biz.model.enums.OptTypeEnum;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.biz.model.voucher.VoucherLogDO;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import org.apache.commons.lang3.math.NumberUtils;

/**
 * Created by  guguangming on 2017/12/28
 **/
public class VoucherLogUtils {

    private VoucherLogUtils() {
    }

    /**
     * 审核相关日志
     *
     * @param sellerId      商家id
     * @param voucherId     单据id
     * @param transitionKey 操作
     * @param nodeKey       节点名称
     * @param remark        备注信息
     * @param fileName      备注文件
     * @param userParam     用户信息
     * @return VoucherLogDO
     */
    public static VoucherLogDO buildAuditLog(long sellerId, String voucherId, String transitionKey, String nodeKey, String remark,
                                             String fileName, UserParam userParam, OptTypeEnum optTypeEnum) {
        VoucherLogDO logDO = buildDefaultVoucherLog(sellerId, voucherId, userParam, optTypeEnum);
        JSONObject jo = new JSONObject();
        jo.put("nodeKey", nodeKey);
        jo.put("transitionKey", transitionKey);
        jo.put("remark", remark);
        jo.put("fileName", fileName);
        logDO.setMsg(jo.toJSONString());
        return logDO;
    }

    /**
     * 创建违规单日志
     *
     * @param sellerId       商户id
     * @param voucherSubType 违规单分类
     * @param expectAmt      金额
     * @param createFile     文件
     * @param createRemark   备注
     * @param userParam      用户信息
     * @param optTypeEnum    操作
     * @return VoucherLogDO
     */
    public static VoucherLogDO buildCreatePunishLog(long sellerId, VoucherSubType voucherSubType, long expectAmt, String createFile, String createRemark, UserParam userParam, OptTypeEnum optTypeEnum) {
        VoucherLogDO logDO;
        if (OptTypeEnum.SYSTEM_CREATE_PUNISH.isEquals(optTypeEnum)) {
            logDO = buildSystemVoucherLog(sellerId, null, optTypeEnum);
        } else {
            logDO = buildDefaultVoucherLog(sellerId, null, userParam, optTypeEnum);
        }
        JSONObject jo = new JSONObject();
        jo.put("voucherSubType", voucherSubType);
        jo.put("expectAmt", expectAmt);
        jo.put("remark", createRemark);
        jo.put("fileName", createFile);
        logDO.setMsg(jo.toJSONString());
        return logDO;
    }

    /**
     * 修改合同缴费创建单据日志
     *
     * @param sellerId          商户id
     * @param accountBookId     账户id
     * @param baseContractAmt   原始合同金额
     * @param updateContractAmt 更新合同金额
     * @param remark            备注
     * @param userParam         用户信息
     * @param optTypeEnum       操作类型
     * @return VoucherLogDO
     */
    public static VoucherLogDO buildUpdateContractAmtLog(long sellerId, long accountBookId, long baseContractAmt,
                                                         long updateContractAmt, String remark, UserParam userParam, OptTypeEnum optTypeEnum) {
        VoucherLogDO logDO = buildDefaultVoucherLog(sellerId, null, userParam, optTypeEnum);

        JSONObject jo = new JSONObject();
        jo.put("accountBookId", accountBookId);
        jo.put("baseContractAmt", baseContractAmt);
        jo.put("updateContractAmt", updateContractAmt);
        jo.put("remark", remark);
        logDO.setMsg(jo.toJSONString());
        return logDO;
    }

    /**
     * 创建补齐缴费
     *
     * @param sellerId      商户id
     * @param accountBookId 账本id
     * @param paramAmount   金额
     * @param remark        备注
     * @param userParam     用户信息
     * @param optTypeEnum   操作类型
     * @return VoucherLogDO
     */
    public static VoucherLogDO buildAddBalanceAmtLog(long sellerId, long accountBookId, long paramAmount, String remark, UserParam userParam, OptTypeEnum optTypeEnum) {
        VoucherLogDO logDO = buildDefaultVoucherLog(sellerId, null, userParam, optTypeEnum);
        JSONObject jo = new JSONObject();
        jo.put("accountBookId", accountBookId);
        jo.put("amount", paramAmount);
        jo.put("remark", remark);
        logDO.setMsg(jo.toJSONString());
        return logDO;
    }

    /**
     * 构建系统创建补齐缴费单据
     *
     * @param sellerId      商户id
     * @param accountBookId 账本id
     * @param amount        补充金额
     * @param optTypeEnum   日志类型
     * @return VoucherLogDO
     */
    public static VoucherLogDO buildSystemAddBalanceAmtLog(long sellerId, long accountBookId, long amount, OptTypeEnum optTypeEnum) {
        VoucherLogDO logDO = buildSystemVoucherLog(sellerId, null, optTypeEnum);
        JSONObject jo = new JSONObject();
        jo.put("accountBookId", accountBookId);
        jo.put("amount", amount);
        logDO.setMsg(jo.toJSONString());
        return logDO;
    }

    /**
     * 系统自动审核
     *
     * @param sellerId      商户id
     * @param voucherId     单据id
     * @param transitionKey 操作
     * @param nodeKey       节点
     * @param optTypeEnum   日志类型
     * @return VoucherLogDO
     */
    public static VoucherLogDO buildSystemAuditLog(long sellerId, String voucherId, String transitionKey, String nodeKey, OptTypeEnum optTypeEnum) {
        VoucherLogDO logDO = buildSystemVoucherLog(sellerId, voucherId, optTypeEnum);
        JSONObject jo = new JSONObject();
        jo.put("nodeKey", nodeKey);
        jo.put("transitionKey", transitionKey);
        logDO.setMsg(jo.toJSONString());
        return logDO;
    }

    /**
     * 简单操作如删除提交等日志
     *
     * @param sellerId    商户id
     * @param voucherId   单据id
     * @param userParam   用户信息
     * @param optTypeEnum 日志类型
     * @return VoucherLogDO
     */
    public static VoucherLogDO buildSimpleOperationLog(long sellerId, String voucherId, UserParam userParam, OptTypeEnum optTypeEnum) {
        return buildDefaultVoucherLog(sellerId, voucherId, userParam, optTypeEnum);
    }

    /**
     * 商家确认缴费
     *
     * @param sellerId      商户ud
     * @param voucherId     单据id
     * @param transitionKey 操作
     * @param nodeKey       节点
     * @param remark        备注
     * @param evidenceFile  附件
     * @param evidenceFlow  流水
     * @param userParam     用户信息
     * @param optTypeEnum   操作类型
     * @return VoucherLogDO
     */
    public static VoucherLogDO buildSellerAuditPaymentLog(long sellerId, String voucherId, String transitionKey, String nodeKey,
                                                          String remark, String evidenceFile, String evidenceFlow, UserParam userParam,
                                                          OptTypeEnum optTypeEnum) {
        VoucherLogDO logDO = buildDefaultVoucherLog(sellerId, voucherId, userParam, optTypeEnum);
        JSONObject jo = new JSONObject();
        jo.put("nodeKey", nodeKey);
        jo.put("transitionKey", transitionKey);
        jo.put("remark", remark);
        jo.put("fileName", evidenceFile);
        jo.put("evidenceFlow", evidenceFlow);
        logDO.setMsg(jo.toJSONString());
        return logDO;
    }

    private static VoucherLogDO buildDefaultVoucherLog(long sellerId, String voucherId, UserParam userParam, OptTypeEnum optTypeEnum) {
        VoucherLogDO logDO = new VoucherLogDO();
        logDO.setSellerId(sellerId);
        logDO.setVoucherId(NumberUtils.toLong(voucherId));
        logDO.setOperator(getOperatorId(userParam));
        logDO.setOptType(optTypeEnum.getCode());
        return logDO;
    }

    private static String getOperatorId(UserParam userParam) {
        return userParam != null ? "u_id:" + userParam.getUserId() + ";u_name:" + userParam.getUserName() + ";appId:"
                + userParam.getAppId() + ";domainId:" + userParam.getDomainId() : "";
    }

    private static VoucherLogDO buildSystemVoucherLog(long sellerId, String voucherId, OptTypeEnum optTypeEnum) {
        VoucherLogDO logDO = new VoucherLogDO();
        logDO.setOperator("SYSTEM");
        logDO.setSellerId(sellerId);
        logDO.setVoucherId(NumberUtils.toLong(voucherId));
        logDO.setOptType(optTypeEnum.getCode());
        return logDO;
    }

}
