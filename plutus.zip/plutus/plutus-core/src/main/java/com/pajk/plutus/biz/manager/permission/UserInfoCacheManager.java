package com.pajk.plutus.biz.manager.permission;

import com.pajk.user.api.LoginServiceWebExport;
import com.pajk.user.api.UserService;
import com.pajk.user.api.result.Result;
import com.pajk.user.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * Created by liuli on 2016/12/30.
 */
@Component
public class UserInfoCacheManager {


    private Logger logger = LoggerFactory.getLogger(UserInfoCacheManager.class);

    @Autowired
    private LoginServiceWebExport loginService;
    @Autowired
    private UserService userService;

    public User getUser(String token) {
        Result<String> result = loginService.decodeUserToken(token);
        String[] values = result.getModel().split("\\|");
        if (values.length > 1) {
            User user = userService.getUserById(Long.parseLong(values[1]));
            return user;
        }
        return null;
    }
}
