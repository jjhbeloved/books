package com.pajk.plutus.biz.model.bill;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * @author david
 * @since created by on 17/12/14 11:39
 */
public class SettlementOperationDO extends BaseDO {


    private static final long serialVersionUID = 51884332641777245L;

    private String operationDesc; //节点状态，nodeKey文案

    private Date operationStartTime; //任务分配时间, 格式:yyyy-MM-dd HH:mm:ss

    private Date operationEndTime; //实际审批时间, 格式:yyyy-MM-dd HH:mm:ss

    private String operationRole;  //审批角色

    private String operationVote;  // 审批意见

    private String operationMemo;  //审批备注

    public String getOperationDesc() {
        return operationDesc;
    }

    public void setOperationDesc(String operationDesc) {
        this.operationDesc = operationDesc;
    }

    public Date getOperationStartTime() {
        return operationStartTime;
    }

    public void setOperationStartTime(Date operationStartTime) {
        this.operationStartTime = operationStartTime;
    }

    public Date getOperationEndTime() {
        return operationEndTime;
    }

    public void setOperationEndTime(Date operationEndTime) {
        this.operationEndTime = operationEndTime;
    }

    public String getOperationRole() {
        return operationRole;
    }

    public void setOperationRole(String operationRole) {
        this.operationRole = operationRole;
    }

    public String getOperationVote() {
        return operationVote;
    }

    public void setOperationVote(String operationVote) {
        this.operationVote = operationVote;
    }

    public String getOperationMemo() {
        return operationMemo;
    }

    public void setOperationMemo(String operationMemo) {
        this.operationMemo = operationMemo;
    }
}
