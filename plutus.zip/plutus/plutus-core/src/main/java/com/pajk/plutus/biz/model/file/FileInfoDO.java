package com.pajk.plutus.biz.model.file;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by fuyongda on 2017/12/19.
 * Modified by fuyongda on 2017/12/19.
 */
public class FileInfoDO extends BaseDO {

    private static final long serialVersionUID = -411652234301006926L;

    /**
     * 文件下载链接
     */
    private String url;

    /**
     * 文件名(含后缀)
     */
    private String name;

    /**
     * tfs的key
     */
    private String tfsKey;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTfsKey() {
        return tfsKey;
    }

    public void setTfsKey(String tfsKey) {
        this.tfsKey = tfsKey;
    }

}
