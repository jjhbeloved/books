package com.pajk.plutus.biz.dao.repo.impl;

import com.pajk.plutus.biz.dao.mapper.single.account.AccountBookFlowMapper;
import com.pajk.plutus.biz.dao.mapper.single.account.AccountBookMapper;
import com.pajk.plutus.biz.dao.mapper.single.account.AccountMapper;
import com.pajk.plutus.biz.dao.repo.AccountRepository;
import com.pajk.plutus.biz.exceptions.DBException;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.account.AccountDO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountDAO;
import com.pajk.plutus.client.model.result.ErrorCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Repository;

/**
 * Created by lizhijun on 2017/12/17.
 */
@Repository
@Transactional(value = "transactionManager", rollbackFor = Exception.class)
public class AccountRepositoryImpl implements AccountRepository {
    @Autowired
    private AccountMapper accountMapper;
    @Autowired
    private AccountBookMapper accountBookMapper;
    @Autowired
    private AccountBookFlowMapper accountBookFlowMapper;

    @Override
    public void createAccountAndBook(AccountDO accountDO,List<AccountBookDO> bookDOs){
        AccountDAO accountDAO = convertToAccount(accountDO);
        accountMapper.create(accountDAO);
        long accountId = accountDAO.getId();

        bookDOs.forEach(bookDO -> {
            bookDO.setAccountId(accountId);
            accountBookMapper.create(convertToAccountBook(bookDO));
        });

    }

    @Override
    public void createAccountBook(List<AccountBookDO> bookDOs){
        bookDOs.forEach(bookDO -> accountBookMapper.create(convertToAccountBook(bookDO)));
    }



    @Override
    public int updateWriteOffToFinish(long paymentFlowId, int version, List<Long> ids, int pageSize) {
        int count = accountBookFlowMapper.updateWriteOffToFinish(paymentFlowId,version);

        if(count <= 0){
            throw new DBException(ErrorCode.C_STORE_DB_FAILED, "updateWriteOffToFinish fail.");
        }
        int index = ids.size() % pageSize == 0 ? ids.size() / pageSize : ids.size() / pageSize + 1 ;
        for (int i = 0; i < index ; i++){
            List<Long> limitList = ids.stream().skip(pageSize * i).
                    limit(pageSize).parallel().collect(Collectors.toList());
            int hasDo = accountBookFlowMapper.batchUpdateWriteOffToFinish(limitList);
            if(hasDo != limitList.size()){
                throw new DBException(ErrorCode.C_STORE_DB_FAILED, "updateWriteOffToFinish fail.");
            }
        }
        return count;
    }


    private AccountDAO convertToAccount(AccountDO accountDO){
        AccountDAO accountDAO = new AccountDAO();
        accountDAO.setSellerId(accountDO.getSellerId());
        accountDAO.setName(accountDO.getName());
        return accountDAO;
    }

    private AccountBookDAO convertToAccountBook(AccountBookDO bookDO){
        AccountBookDAO bookDAO = new AccountBookDAO();
        bookDAO.setSellerId(bookDO.getSellerId());
        bookDAO.setAccountId(bookDO.getAccountId());
        bookDAO.setContractAmt(bookDO.getContractAmt());
        bookDAO.setActualContractAmt(bookDO.getActualContractAmt());
        bookDAO.setBalanceAmt(bookDO.getBalanceAmt());
        bookDAO.setFreezingAmt(bookDO.getFreezingAmt());
        bookDAO.setBookType(bookDO.getBookType().getCode());
        return bookDAO;

    }
}
