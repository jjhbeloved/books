package com.pajk.plutus.biz.model.process;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * 审批记录
 *
 * Created by fuyongda on 2017/12/18.
 * Modified by fuyongda on 2017/12/18.
 */
public class TaskDO extends BaseDO {

    private static final long serialVersionUID = -1504174533560836265L;

    /**
     * 审批记录描述
     */
    private String desc;

    /**
     * 审批角色中文名
     */
    private String roleName;

    /**
     * 任务分配时间
     */
    private Date startTime;

    /**
     * 审批时间
     */
    private Date endTime;

    /**
     * 审批备注
     */
    private String approvalMemo;

    /**
     * 对应审批line的名称 如:通过  拒绝等
     */
    private String approvalVote;

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getApprovalMemo() {
        return approvalMemo;
    }

    public void setApprovalMemo(String approvalMemo) {
        this.approvalMemo = approvalMemo;
    }

    public String getApprovalVote() {
        return approvalVote;
    }

    public void setApprovalVote(String approvalVote) {
        this.approvalVote = approvalVote;
    }

}
