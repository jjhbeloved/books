package com.pajk.plutus.biz.dao.mapper.single.voucher;

import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherLogDAO; /**
 * Created by  guguangming on 2017/12/15
 **/
public interface VoucherLogMapper {
    /**
     * 新增日志
     * @param voucherLogDAO
     */
    void create(VoucherLogDAO voucherLogDAO);
}
