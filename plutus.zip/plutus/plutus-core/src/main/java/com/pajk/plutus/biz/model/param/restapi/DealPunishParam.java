package com.pajk.plutus.biz.model.param.restapi;

import com.pajk.thunderbird.domain.result.BaseDO;

import javax.validation.constraints.NotNull;

/**
 * Created by lizhijun on 2017/12/19.
 */
public class DealPunishParam extends BaseDO{
    private static final long serialVersionUID = -3030406831987221889L;
    /**
     * 商户Id
     */
    @NotNull
    private Long sellerId;
    /**
     * 单据Id
     */
    @NotNull
    private String voucherId;

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public String getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(String voucherId) {
        this.voucherId = voucherId;
    }
}
