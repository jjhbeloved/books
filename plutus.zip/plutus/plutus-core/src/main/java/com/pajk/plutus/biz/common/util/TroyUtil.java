package com.pajk.plutus.biz.common.util;

import com.pajk.troy.client.constants.MonitorConstants;
import com.pajk.troy.client.utils.JsonUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by fanhuafeng on 17/2/21.
 * Modify by fanhuafeng on 17/2/21
 */
public class TroyUtil {

    private TroyUtil() {

    }

    public static String getKVItem(String key, String msg) {
        Map<String, String> map = new HashMap<>();
        map.put(MonitorConstants.KV_ITEM_KEY, key);
        map.put("key", key);
        map.put("msg", msg);
        return JsonUtils.mapToJson(map);
    }

}
