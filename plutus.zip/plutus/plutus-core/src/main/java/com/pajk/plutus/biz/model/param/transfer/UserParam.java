package com.pajk.plutus.biz.model.param.transfer;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by lizhijun on 2017/12/21.
 */
public class UserParam extends BaseDO {

    private static final long serialVersionUID = -8038394554215366167L;

    private long appId;
    private long userId;
    private String userName;
    private long domainId;

    private String path;

    public UserParam() {
    }

    public UserParam(long appId, long userId) {
        this.appId = appId;
        this.userId = userId;
    }

    public UserParam(long appId, long userId, long domainId) {
        this(appId, userId);
        this.domainId = domainId;
    }

    public long getAppId() {
        return appId;
    }

    public void setAppId(long appId) {
        this.appId = appId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }


    public long getDomainId() {
        return domainId;
    }

    public void setDomainId(long domainId) {
        this.domainId = domainId;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
