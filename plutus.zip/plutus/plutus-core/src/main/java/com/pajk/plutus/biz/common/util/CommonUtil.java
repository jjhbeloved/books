package com.pajk.plutus.biz.common.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pajk.plutus.client.model.result.ErrorCode;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.Objects;

/**
 * Created by fanhuafeng on 17/2/23.
 * Modify by fanhuafeng on 17/2/23
 */
public class CommonUtil {
    private static final Logger logger = LoggerFactory.getLogger(CommonUtil.class);

    private static final String TRACKING_NO_REGEX = "^[0-9a-zA-Z]+$";

    private static final int TRACKING_NUMBER_MAX_LENGTH = 64;

    private static final String FILE_KEY = "fileKey";

    private CommonUtil() {
    }

    /**
     * 初步判断 手机号码是否正确
     *
     * @param phone 手机号码
     * @return boolean
     */
    public static boolean isPhone(String phone) {
        return StringUtils.isNotBlank(phone)
                && NumberUtils.isDigits(phone)
                && 11 == phone.length()
                && phone.startsWith("1");
    }




    public static boolean isValidSellerId(long sellerId) {
        long right4 = sellerId % 10000;
        long right2 = sellerId % 100;

        return right4 < 1000 && right2 < 10 && sellerId > 0;
    }

    public static boolean isValidVoucherId(String voucherIdStr) {
        long voucherId = NumberUtils.toLong(voucherIdStr, 0);
        return 0 < voucherId;
    }

    /**
     * Integer 转为 int
     * 如果 为null 转为0
     */
    public static int integerToInt(Integer i) {
        if (Objects.isNull(i)) {
            return 0;
        }
        return i;
    }

    /**
     * 校验分页的翻页合法性
     *
     * @param pageNo      页码
     * @param pageSize    每页大小
     * @param maxPageSize 每页最大大小
     * @param maxSize     获取最多的数据量
     * @return ErrorCode
     */
    public static ErrorCode checkPage(int pageNo, int pageSize, int maxPageSize, int maxSize){
        if (pageNo <= 0 || pageSize <= 0  ){
            return ErrorCode.PARAM_ERROR;
        }

        if(pageSize > maxPageSize
                || pageNo * pageSize > maxSize){
            return  ErrorCode.PAGE_SIZE_OUT_OF_MAX_VALUE;
        }
        return ErrorCode.SUCCESS;


    }

    /**
     *
     * @param start 开始时间
     * @param end 结束时间
     * @param daySpan  从 开始时间往前推 时间 单位 天
     * @param dayInterval 结束时间-开始时间 的时间间隔 单位 天
     * @return
     *    ErrorCode.PARAM_ERROR
     *    ErrorCode.QUERY_INTERVAL_OVER_THRESHOLD
     *    ErrorCode.QUERY_TOO_OLD
     *    ErrorCode.SUCCESS
     */
    public static ErrorCode checkQueryTime(Date start, Date end, int daySpan, int dayInterval ){

        if(null == start || null == end){
            return ErrorCode.PARAM_ERROR;
        }

        if(end.getTime() < start.getTime() ) {
            return ErrorCode.PARAM_ERROR;
        }

        if(end.getTime() - start.getTime() > TimeUtils.ONE_DAY_MILLISECOND * dayInterval ){
            return ErrorCode.QUERY_INTERVAL_OVER_THRESHOLD;
        }

        if(start.getTime() < System.currentTimeMillis() - TimeUtils.ONE_DAY_MILLISECOND * daySpan ){
            return ErrorCode.QUERY_TOO_OLD;
        }

        return ErrorCode.SUCCESS;


    }

    /**
     * 校验String长度 并且不能参数为空
     * @param data 参数
     * @param length 长度
     */
    public static boolean checkStringLength(String data, int length) {
        return StringUtils.isNotBlank(data) && data.length() <= length;
    }


    /**
     * 检查文件的格式
     * @param files 格式如 [{fileName:"fileName1", fileKey:"fileKey1"},fileName:"fileName2", fileKey:"fileKey2"}]
     * @return 是否合法
     */
    public static boolean checkFile(String files){
        JSONArray ja = null;
        try {
            ja = JSONArray.parseArray(files);
            if(null != ja){
                for (Object o : ja){
                    JSONObject jo = (JSONObject) o;
                    if(StringUtils.isBlank(jo.getString(FILE_KEY))){
                        return false;
                    }
                }
            }else{
                return false;
            }
        } catch (Exception e) {
            logger.warn("[checkFile] occurs error, str is {}", files, e);
            return false;
        }
        return true;
    }

    /**
     * 通过分转为元 但是保留2为小数点
     * @param amount 分
     * @return String 元
     */
    public static String fenToYuan(long amount){
        BigDecimal b1 = new BigDecimal(Long.toString(amount));
        BigDecimal b2 = new BigDecimal(Long.toString(100L));
        return String.format("%.2f", b1.divide(b2,2, RoundingMode.HALF_UP));
    }
}
