package com.pajk.plutus.biz.model.mapper.single.account;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;


/**
 * 账户表
 */
public class AccountDAO extends BaseDO {

    private static final long serialVersionUID = 792868661014904966L;

    /**
     * 主键id 创建流程时用作obj_id
     **/
    private long id;

    /**
     * 创建时间
     **/
    private Date gmtCreated;

    /**
     * 更新时间
     **/
    private Date gmtModified;

    /**
     * 版本号
     **/
    private int version;

    /**
     * 卖家id
     **/
    private long sellerId;

    /**
     * 是否冻结 0 冻结 1 正常
     **/
    private int status;

    /**
     * 账户名
     **/
    private String name;

    /**
     * 财务系统对应的客户id
     **/
     private String customerId;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
}
