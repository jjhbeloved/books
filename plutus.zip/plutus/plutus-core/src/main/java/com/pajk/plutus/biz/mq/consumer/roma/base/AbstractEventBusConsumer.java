package com.pajk.plutus.biz.mq.consumer.roma.base;

import com.alibaba.rocketmq.common.message.MessageExt;
import com.pajk.plutus.biz.exceptions.RomaIgnoreException;
import com.pajk.plutus.biz.model.roma.PromiseWrapper;
import com.pajk.roma.common.ServiceStatus;
import com.pajk.roma.consumer.RomaMessageProcessor;
import com.pajk.roma.message.RomaDbMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import reactor.Environment;
import reactor.bus.Event;
import reactor.bus.EventBus;
import reactor.rx.Promises;

import javax.annotation.Resource;

/**
 * Created by fanhuafeng on 17/2/27.
 * Modify by fanhuafeng on 17/2/27
 */
public abstract class AbstractEventBusConsumer<T> extends RomaBasedConsumer {

    private static final Logger logger = LoggerFactory.getLogger(AbstractEventBusConsumer.class);

    @Resource
    private EventBus eventBus;

    @Autowired
    private Environment environment;

    @Override
    public RomaMessageProcessor genRomaMessageProcessor() {
        return (msg, msgExt, context) -> {
            try {
                T model = transform(msg, msgExt, context);
                logger.info("[ROMA-model]:{}", model);
                String selector = selector(model);
                if (!isSelectorRegistered(selector)) {
                    logger.info("[ROMA-selector]未注册,忽略消息,selector:{},model:{}", selector, model);
                    return ServiceStatus.SUCCESS;
                }
                //msgExt.getReconsumeTimes()
                PromiseWrapper<T, ServiceStatus> pw = new PromiseWrapper<>(model, Promises.prepare(environment));
                eventBus.notify(selector(model), Event.wrap(pw));
                ServiceStatus result = pw.getPromise().poll();
                return result == null ? ServiceStatus.CONSUMER_RETRY : result;

            } catch (RomaIgnoreException e) {
                logger.warn("roma消息忽略,msg:{}", e.getMessage());
                return ServiceStatus.SUCCESS;
            }
        };
    }

    public abstract T transform(RomaDbMessage.RomaDbData msg, MessageExt msgExt, Object context)
            throws RomaIgnoreException;

    public abstract boolean isSelectorRegistered(String key);

    public abstract String selector(T t);

}
