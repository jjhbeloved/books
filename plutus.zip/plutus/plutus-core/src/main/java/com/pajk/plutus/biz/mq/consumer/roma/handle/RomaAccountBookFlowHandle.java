package com.pajk.plutus.biz.mq.consumer.roma.handle;

import com.pajk.plutus.biz.common.util.BlockingMsg;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.model.roma.PromiseWrapper;
import com.pajk.plutus.biz.model.roma.RomaBookFlowInfo;
import com.pajk.plutus.biz.mq.consumer.roma.consumer.RomaAccountBookFlowConsumer;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.roma.common.ServiceStatus;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import reactor.bus.Event;
import reactor.bus.EventBus;
import reactor.spring.context.annotation.Consumer;
import reactor.spring.context.annotation.Selector;

import javax.annotation.Resource;

/**
 * Created by lizhijun on 2017/12/17.
 */
@Consumer
public class RomaAccountBookFlowHandle implements BlockingMsg {
    private static final Logger logger = LoggerFactory.getLogger(RomaAccountBookFlowHandle.class);


    @Resource
    private EventBus eventBus;

    @Autowired
    private AccountManager accountManager;


    @Selector(RomaAccountBookFlowConsumer.SELECTOR_PREFIX + "0->1")
    public void onFinish(Event<PromiseWrapper<RomaBookFlowInfo, ServiceStatus>> event){
        blockingExec(event, bookFlowInfo ->  doWriteOff(bookFlowInfo) ?
                ServiceStatus.SUCCESS : ServiceStatus.CONSUMER_RETRY
        );
    }

    private boolean doWriteOff(RomaBookFlowInfo bookFlowInfo){
        ResultDTO<VoidEntity> resultDTO = accountManager.doWriteOff(bookFlowInfo.getId());

        if(ErrorCode.SUCCESS.eq(resultDTO.getResultCode()) ||
                ErrorCode.WRITE_OFF_FLOW_NOT_EXISTS.eq(resultDTO.getResultCode())){
            return true;
        }
        return false;
    }


}
