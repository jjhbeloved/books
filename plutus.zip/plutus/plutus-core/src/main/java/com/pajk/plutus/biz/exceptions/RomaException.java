package com.pajk.plutus.biz.exceptions;

/**
 * Created by fanhuafeng on 17/4/24.
 * Modify by fanhuafeng on 17/4/24
 */
public class RomaException extends RuntimeException {

    private static final long serialVersionUID = -5418458405134668643L;

    public RomaException() {
    }

    public RomaException(String message) {
        super(message);
    }

}
