package com.pajk.plutus.biz.dao.mapper.single.bill;

import com.pajk.plutus.biz.model.mapper.single.bill.InvoiceInfoSnapshotDAO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by arjaylv on 2017/12/11.
 *
 * @author arjaylv
 */
public interface InvoiceInfoSnapshotMapper {

    int insert(InvoiceInfoSnapshotDAO invoiceInfoSnapshotDAO);

    List<InvoiceInfoSnapshotDAO> queryByBillId(@Param("billId") long billId);

    /**
     * 根据账单id列表批量查询发票信息快照，按创建时间升序排列
     *
     * @param billIds
     * @return
     */
    List<InvoiceInfoSnapshotDAO> queryByBillIds(@Param("billIds") List<Long> billIds);

}
