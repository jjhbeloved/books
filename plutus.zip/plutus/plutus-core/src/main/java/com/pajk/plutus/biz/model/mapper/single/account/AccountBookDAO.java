package com.pajk.plutus.biz.model.mapper.single.account;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;


/**
 * 账本表
 */
public class AccountBookDAO extends BaseDO {

    private static final long serialVersionUID = 992865661014204666L;

    /**
     * 主键id 创建流程时用作obj_id
     **/
    private long id;

    /**
     * 创建时间
     **/
    private Date gmtCreated;

    /**
     * 更新时间
     **/
    private Date gmtModified;

    /**
     * 版本号
     **/
    private int version;

    /**
     * 卖家id
     **/
    private long sellerId;

    /**
     * 是否冻结 0 冻结 1 正常
     **/
    private int status;
    /**
     * 账户id
     **/
    private long accountId;

    /**
     * 类型,1保证金 2积分 3馈赠金 4 年费 5 佣金
     **/
    private int bookType;

    /**
     * 合同金额(单位分)
     **/
    private long contractAmt;

    /**
     * 实收合同金额(单位分)
     **/
    private long actualContractAmt;

    /**
     * 账本余额(单位分)
     **/
    private long balanceAmt;

    /**
     * 冻结金额(单位分)
     **/
    private long freezingAmt;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public int getVersion() {
        return version;
    }


    public void setVersion(int version) {
        this.version = version;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public long getAccountId() {
        return accountId;
    }

    public void setAccountId(long accountId) {
        this.accountId = accountId;
    }

    public int getBookType() {
        return bookType;
    }

    public void setBookType(int bookType) {
        this.bookType = bookType;
    }

    public long getContractAmt() {
        return contractAmt;
    }

    public void setContractAmt(long contractAmt) {
        this.contractAmt = contractAmt;
    }

    public long getActualContractAmt() {
        return actualContractAmt;
    }

    public void setActualContractAmt(long actualContractAmt) {
        this.actualContractAmt = actualContractAmt;
    }

    public long getBalanceAmt() {
        return balanceAmt;
    }

    public void setBalanceAmt(long balanceAmt) {
        this.balanceAmt = balanceAmt;
    }

    public long getFreezingAmt() {
        return freezingAmt;
    }

    public void setFreezingAmt(long freezingAmt) {
        this.freezingAmt = freezingAmt;
    }
}
