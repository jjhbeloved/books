package com.pajk.plutus.biz.model.bill;

import com.google.common.collect.Lists;
import com.pajk.plutus.client.model.enums.bill.SettlementType;
import com.pajk.plutus.client.model.enums.trade.PayToType;
import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;
import java.util.List;

/**
 * @author david
 * @since created by on 17/12/14 00:24
 */
public class BillSettlementDO extends BaseDO {

    private static final long serialVersionUID = -3399462225688727705L;

    private Long id;

    private Integer version;

    private Long sellerId;

    /**
     * 单据编号 idgen生成
     */
    private Long billNo;

    private String sellerName;

    /**
     * 统计月份(默认每个月的1号)
     */
    private Date month;

    /**
     * 收款方式、合作模式 1:平台收款 2:商家收款
     * {@link PayToType#code}
     */
    private Integer payToType;

    /**
     * 结算类型 1:平安应收 2:平安应付
     * {@link SettlementType#code}
     */
    private Integer settlementType;

    /**
     * 对账总金额(分)
     */
    private Long billAmt;

    /**
     * 实际确认对账总金额(分)
     */
    private Long actualBillAmt;

    /**
     * 流程返回的实例id
     */
    private Long procInstId;

    /**
     * 账单状态
     */
    private String nodeKey;

    /**
     * 运营看到的节点描述
     */
    private String nodeKeyName;

    /**
     * 商户看到的节点
     */
    private String nodeCatKey;

    /**
     * 商户看到的节点描述
     */
    private String nodeCatKeyName;

    /**
     * 当前状态可执行角色
     */
    private String role;

    /**
     * 流程开始时间
     */
    private Date startTime;

    /**
     * 流程完成时间
     */
    private Date finishTime;

    /**
     * 商户账单确认上传的附件信息
     */
    private ConfirmInfoDO confirmInfoDO;

    /**
     * 确认支付时提交的相关信息
     */
    private List<PaymentInfoDO> paymentInfoDOS = Lists.newLinkedList();

    /**
     * 发票信息
     */
    private InvoiceInfoDO invoiceInfoDO;

    /**
     * 发票信息快照
     */
    private InvoiceInfoSnapshotDO invoiceInfoSnapshotDO;

    /**
     * 账户信息快照
     */
    private AccountInfoSnapshotDO accountInfoSnapshotDO;

    private SellerInvoiceInfoDO sellerInvoiceInfoDO;

    private SellerAccountInfoDO sellerAccountInfoDO;

    /**
     * 流程按钮信息
     */
    private List<ButtonDO> buttonDOs;

    /**
     * 层叠按钮信息
     */
    private List<CascadeButtonDO> cascadeButtonDOs;

    /**
     * 扩展字段
     */
    private String extProps;

    private List<BillSettlementItemDO> billSettlementItemDOS = Lists.newLinkedList();

    private List<SettlementOperationDO> settlementOperationDOS = Lists.newLinkedList();

    private BillLogDO billLogDO;

    private String buttonKey;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Long getBillNo() {
        return billNo;
    }

    public void setBillNo(Long billNo) {
        this.billNo = billNo;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public Date getMonth() {
        return month;
    }

    public void setMonth(Date month) {
        this.month = month;
    }

    public Integer getPayToType() {
        return payToType;
    }

    public void setPayToType(Integer payToType) {
        this.payToType = payToType;
    }

    public Integer getSettlementType() {
        return settlementType;
    }

    public void setSettlementType(Integer settlementType) {
        this.settlementType = settlementType;
    }

    public Long getBillAmt() {
        return billAmt;
    }

    public void setBillAmt(Long billAmt) {
        this.billAmt = billAmt;
    }

    public Long getActualBillAmt() {
        return actualBillAmt;
    }

    public void setActualBillAmt(Long actualBillAmt) {
        this.actualBillAmt = actualBillAmt;
    }

    public Long getProcInstId() {
        return procInstId;
    }

    public void setProcInstId(Long procInstId) {
        this.procInstId = procInstId;
    }

    public String getNodeKey() {
        return nodeKey;
    }

    public void setNodeKey(String nodeKey) {
        this.nodeKey = nodeKey;
    }

    public String getNodeKeyName() {
        return nodeKeyName;
    }

    public void setNodeKeyName(String nodeKeyName) {
        this.nodeKeyName = nodeKeyName;
    }

    public String getNodeCatKey() {
        return nodeCatKey;
    }

    public void setNodeCatKey(String nodeCatKey) {
        this.nodeCatKey = nodeCatKey;
    }

    public String getNodeCatKeyName() {
        return nodeCatKeyName;
    }

    public void setNodeCatKeyName(String nodeCatKeyName) {
        this.nodeCatKeyName = nodeCatKeyName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(Date finishTime) {
        this.finishTime = finishTime;
    }

    public ConfirmInfoDO getConfirmInfoDO() {
        return confirmInfoDO;
    }

    public void setConfirmInfoDO(ConfirmInfoDO confirmInfoDO) {
        this.confirmInfoDO = confirmInfoDO;
    }

    public List<PaymentInfoDO> getPaymentInfoDOS() {
        return paymentInfoDOS;
    }

    public void setPaymentInfoDOS(List<PaymentInfoDO> paymentInfoDOS) {
        this.paymentInfoDOS = paymentInfoDOS;
    }

    public InvoiceInfoDO getInvoiceInfoDO() {
        return invoiceInfoDO;
    }

    public void setInvoiceInfoDO(InvoiceInfoDO invoiceInfoDO) {
        this.invoiceInfoDO = invoiceInfoDO;
    }

    public InvoiceInfoSnapshotDO getInvoiceInfoSnapshotDO() {
        return invoiceInfoSnapshotDO;
    }

    public void setInvoiceInfoSnapshotDO(InvoiceInfoSnapshotDO invoiceInfoSnapshotDO) {
        this.invoiceInfoSnapshotDO = invoiceInfoSnapshotDO;
    }

    public AccountInfoSnapshotDO getAccountInfoSnapshotDO() {
        return accountInfoSnapshotDO;
    }

    public void setAccountInfoSnapshotDO(AccountInfoSnapshotDO accountInfoSnapshotDO) {
        this.accountInfoSnapshotDO = accountInfoSnapshotDO;
    }

    public SellerInvoiceInfoDO getSellerInvoiceInfoDO() {
        return sellerInvoiceInfoDO;
    }

    public void setSellerInvoiceInfoDO(SellerInvoiceInfoDO sellerInvoiceInfoDO) {
        this.sellerInvoiceInfoDO = sellerInvoiceInfoDO;
    }

    public SellerAccountInfoDO getSellerAccountInfoDO() {
        return sellerAccountInfoDO;
    }

    public void setSellerAccountInfoDO(SellerAccountInfoDO sellerAccountInfoDO) {
        this.sellerAccountInfoDO = sellerAccountInfoDO;
    }

    public List<ButtonDO> getButtonDOs() {
        return buttonDOs;
    }

    public void setButtonDOs(List<ButtonDO> buttonDOs) {
        this.buttonDOs = buttonDOs;
    }

    public List<CascadeButtonDO> getCascadeButtonDOs() {
        return cascadeButtonDOs;
    }

    public void setCascadeButtonDOs(List<CascadeButtonDO> cascadeButtonDOs) {
        this.cascadeButtonDOs = cascadeButtonDOs;
    }

    public String getExtProps() {
        return extProps;
    }

    public void setExtProps(String extProps) {
        this.extProps = extProps;
    }

    public List<BillSettlementItemDO> getBillSettlementItemDOS() {
        return billSettlementItemDOS;
    }

    public void setBillSettlementItemDOS(List<BillSettlementItemDO> billSettlementItemDOS) {
        this.billSettlementItemDOS = billSettlementItemDOS;
    }

    public List<SettlementOperationDO> getSettlementOperationDOS() {
        return settlementOperationDOS;
    }

    public void setSettlementOperationDOS(List<SettlementOperationDO> settlementOperationDOS) {
        this.settlementOperationDOS = settlementOperationDOS;
    }

    public BillLogDO getBillLogDO() {
        return billLogDO;
    }

    public void setBillLogDO(BillLogDO billLogDO) {
        this.billLogDO = billLogDO;
    }

    public String getButtonKey() {
        return buttonKey;
    }

    public void setButtonKey(String buttonKey) {
        this.buttonKey = buttonKey;
    }

}
