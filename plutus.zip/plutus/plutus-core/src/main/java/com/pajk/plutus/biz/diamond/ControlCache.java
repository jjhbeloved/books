package com.pajk.plutus.biz.diamond;

import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.concurrent.Executor;

/**
 * Created by fanhuafeng on 17/2/22.
 * Modify by fanhuafeng on 17/2/22
 */
@Service("controlCache")
public class ControlCache extends DiamondCache {

    private static final String DATA_ID = "com.pajk.plutus.control";

    /*************************************保证金查询控制开关************************************************/


    /*************************************账户账本查询控制开关**********************************************/
    private static final String ACCOUNT_BOOK_FLOW_WRITE_OFF_QUERY_DAY_SPAN = "account.book.flow.write.off.query.day.span";
    private static final String ACCOUNT_BOOK_FLOW_DEFAULT_QUERY_DAY_SPAN = "account.book.flow.default.query.day.span";


    /****************************************违规单审核控制相关**********************************************/
    private static final String VOUCHER_PUNISH_SECOND_AUDIT_PASS_TRANSITION_KEY = "voucher.punish.second.audit.pass";
    private static final String VOUCHER_PUNISH_FIRST_AUDIT_REFUSE_TRANSITION_KEY = "voucher.punish.first.audit.refuse";
    private static final String VOUCHER_PUNISH_FIRST_AUDIT_BACK_TRANSITION_KEY = "voucher.punish.first.audit.back";
    private static final String VOUCHER_PUNISH_SECOND_AUDIT_REFUSE_TRANSITION_KEY = "voucher.punish.second.audit.refuse";
    private static final String VOUCHER_PUNISH_SELLER_AGREE_TRANSITION_KEY = "voucher.punish.seller.agree";


    /**************************************违规发货数据控制开关*******************************/
    private static final String VOUCHER_DELIVERY_AUTO_PROCESS_INTERVAL = "voucher.delivery.auto.process.interval";

    private static final String VOUCHER_PUNISH_AUTO_AGREE_INTERVAL = "voucher.punish.auto.agree.interval";


    /****************************************自动对账账单查询相关**********************************************/
    private static final String BILL_SETTLEMENT_QUERY_DAY_SPAN = "bill.settlement.query.day.span";
    private static final String BILL_SETTLEMENT_QUERY_DAY_INTERVAL = "bill.settlement.query.day.interval";


    /****************************************违规单查询控制相关**********************************************/
    private static final String VOUCHER_PAGE_QUERY_DAY_SPAN = "voucher.page.query.day.span";



    public ControlCache() {
        super("");
    }

    @Override
    public void receiveConfigInfo0(String dataId, String group, String configInfo) {
        loadProperties(configInfo);
    }

    @Override
    public Executor getExecutor() {
        return null;
    }

    @PostConstruct
    public void init() {
        super.init(DATA_ID);
    }

    @Override
    public String getDataId() {
        return DATA_ID;
    }


    /*************************************保证金查询控制开关************************************************/


    /*************************************账户账本查询控制开关**********************************************/
    public int getAccountBookFlowWriteOffQueryDaySpan() {
        return getIntValue(ACCOUNT_BOOK_FLOW_WRITE_OFF_QUERY_DAY_SPAN, 60);
    }

    public int getAccountBookFlowDefaultQueryDaySpan(){
        return getIntValue(ACCOUNT_BOOK_FLOW_DEFAULT_QUERY_DAY_SPAN, 60);
    }

    /**********二级商管通过**********/
    public String getVoucherPunishSecondAuditPassTransitionKey() {
        return getValue(VOUCHER_PUNISH_SECOND_AUDIT_PASS_TRANSITION_KEY, "agree");
    }

    /**********一级商管拒绝**********/
    public String getVoucherPunishFirstAuditRefuseTransitionKey() {
        return getValue(VOUCHER_PUNISH_FIRST_AUDIT_REFUSE_TRANSITION_KEY, "auditRefuse");
    }

    /**********一级商管驳回**********/
    public String getVoucherPunishFirstAuditBackTransitionKey() {
        return getValue(VOUCHER_PUNISH_FIRST_AUDIT_BACK_TRANSITION_KEY, "back");
    }

    /***********二级商管拒绝*********/
    public String getVoucherPunishSecondAuditRefuseTransitionKey() {
        return getValue(VOUCHER_PUNISH_SECOND_AUDIT_REFUSE_TRANSITION_KEY, "auditRefuse");
    }

    /*************商家同意transitionKey****************/
    public String getVoucherPunishSellerAgreeTransitionKey() {
        return getValue(VOUCHER_PUNISH_SELLER_AGREE_TRANSITION_KEY, "sellerAgree");
    }

    /**
     * 获取需要自动处理的违规发货记录创建时间距定时任务执行时的天数
     *
     * @return 配置数值，默认为0
     */
    public int getVoucherDeliveryAutoProcessInterval() {
        return getIntValue(VOUCHER_DELIVERY_AUTO_PROCESS_INTERVAL);
    }

    /*****************获取需要自动同意违规单的触发天数***********/
    public int getVoucherPunishAutoAgreeInterval() {
        return getIntValue(VOUCHER_PUNISH_AUTO_AGREE_INTERVAL, 4);
    }

    /****************************************自动对账账单查询相关**********************************************/
    /**
     * 对账账单最早可查询前多少天
     *
     * @return 天数
     */
    public int getBillSettlementQueryDaySpan() {
        return getIntValue(BILL_SETTLEMENT_QUERY_DAY_SPAN, 367);
    }

    /**
     * 对账账单最多可查询间隔多少天
     *
     * @return 天数
     */
    public int getBillSettlementQueryDayInterval() {
        return getIntValue(BILL_SETTLEMENT_QUERY_DAY_INTERVAL, 367);
    }

    /**
     * 单据查询查询间隔天数控制
     *
     * @return 天数
     */
    public int getVoucherPageQueryDaySpan() {
        return getIntValue(VOUCHER_PAGE_QUERY_DAY_SPAN, 60);
    }


}
