package com.pajk.plutus.biz.dao.repo;

import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.account.AccountDO;

import java.util.List;

/**
 * Created by lizhijun on 2017/12/17.
 */
public interface AccountRepository {
    void createAccountAndBook(AccountDO accountDO,List<AccountBookDO> bookDOs);

    void createAccountBook(List<AccountBookDO> bookDOs);

    int updateWriteOffToFinish(long paymentFlowId, int version, List<Long> ids, int pageSize);
}
