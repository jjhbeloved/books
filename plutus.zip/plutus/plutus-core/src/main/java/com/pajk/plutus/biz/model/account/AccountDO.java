package com.pajk.plutus.biz.model.account;

import com.pajk.plutus.client.model.enums.account.AccountStatus;
import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * Created by lizhijun on 2017/12/19.
 */
public class AccountDO extends BaseDO {

    private static final long serialVersionUID = 3965365301488491926L;

    /**
     * 主键id
     **/
    private long id;

    /**
     * 创建时间
     **/
    private Date gmtCreated;

    /**
     * 更新时间
     **/
    private Date gmtModified;

    /**
     * 版本号
     **/
    private int version;

    /**
     * 卖家id
     **/
    private long sellerId;

    /**
     * 是否冻结 0 冻结 1 正常
     **/
    private AccountStatus status;

    /**
     * 账户名
     **/
    private String name;

    /**
     * 财务系统对应的客户id
     **/
    private String customerId;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public AccountStatus getStatus() {
        return status;
    }

    public void setStatus(AccountStatus status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
}
