package com.pajk.plutus.biz.model.result.dto.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by  guguangming on 2017/12/14
 **/
public class FileInfoDTO extends BaseDO {
    private static final long serialVersionUID = 5928612610142041266L;

    private String fileKey;

    private String fileName;

    public String getFileKey() {
        return fileKey;
    }

    public void setFileKey(String fileKey) {
        this.fileKey = fileKey;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
