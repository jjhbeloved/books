package com.pajk.plutus.biz.mq.consumer.seller;

import com.pajk.kylin.api.service.SellerService;
import com.pajk.kylin.helpcenter.api.model.message.SellerAddMsg;
import com.pajk.plutus.biz.common.util.JsonUtil;
import com.pajk.plutus.biz.common.util.TroyUtil;
import com.pajk.plutus.biz.mq.consumer.base.BaseConsumer;
import com.pajk.plutus.client.model.topic.KylinTopic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.Serializable;

/**
 * Created by lizhijun on 2017/12/23.
 */
public abstract class AbstractSellerConsumer extends BaseConsumer {

    private static final Logger logger = LoggerFactory.getLogger(AbstractSellerConsumer.class);

    @Autowired
    private SellerService sellerService;

    @Override
    public String getTopic() {
        return getKylinTopic().getTopic();
    }

    @Override
    public String getTags() {
        return getKylinTopic().getTags();
    }

    protected abstract KylinTopic getKylinTopic();


    @Override
    public boolean doConsumeMessage(Serializable message, int reconsumeTimes) {

        if(null == message || !(message instanceof  SellerAddMsg)){
            return true;
        }



        SellerAddMsg sellerAddMsg = (SellerAddMsg)message ;

        if(logger.isDebugEnabled()){
            logger.debug("AbstractSellerConsumer:topic={}  tradeInfo={} reconsumeTimes={}",
                    getKylinTopic().getTopicStr(),
                    JsonUtil.obj2Str(sellerAddMsg), reconsumeTimes);
        }

        if(DEFAULT_RECONSUME_TIMES < reconsumeTimes ){
            StringBuilder sb = new StringBuilder();
            sb.append("AbstractSellerConsumer:");
            sb.append(getKylinTopic().getTopicStr());
            sb.append(" 执行超过").append(reconsumeTimes).append("次失败,");
            logger.info(TroyUtil.getKVItem(getNotifyLog(), sb.toString()));
            return true;
        }

        return doConsumeMessage(sellerAddMsg, reconsumeTimes);


    }


    protected abstract boolean doConsumeMessage(SellerAddMsg sellerAddMsg, int reconsumeTimes);
}