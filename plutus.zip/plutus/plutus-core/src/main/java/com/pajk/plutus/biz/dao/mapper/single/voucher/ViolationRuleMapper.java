package com.pajk.plutus.biz.dao.mapper.single.voucher;

import com.pajk.plutus.biz.model.mapper.single.voucher.ViolationRuleDAO;
import com.pajk.plutus.biz.model.query.voucher.ViolationRulePageQuery;

import java.util.List;

/**
 * Created by  guguangming on 2017/12/15
 **/
public interface ViolationRuleMapper {

    /**
     *  查询符合条件的总数量
     * @param pageQuery 查询条件
     * @return int
     */
    int pageQueryCount(ViolationRulePageQuery pageQuery);

    /**
     *  查询符合条件的数据
     * @param pageQuery 查询条件
     * @return  List<ViolationRuleDAO>
     */
    List<ViolationRuleDAO> pageQuery(ViolationRulePageQuery pageQuery);
}
