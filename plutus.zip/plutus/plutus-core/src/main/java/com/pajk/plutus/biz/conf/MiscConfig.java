package com.pajk.plutus.biz.conf;

import com.taobao.diamond.client.DiamondConfigure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by fanhuafeng on 17/2/23.
 * Modify by fanhuafeng on 17/2/23
 */
@Configuration
public class MiscConfig {

    private static final Logger logger = LoggerFactory.getLogger(MiscConfig.class);

    private static Properties properties;

    private static String dubboEnv;

    public static Properties getProperties() {
        return properties;
    }

    public static String getDubboEnv() {
        return dubboEnv;
    }

    static {
        properties = new Properties();
        InputStream is = MiscConfig.class.getClassLoader().getResourceAsStream("application.properties");
        if (is != null) {
            try {
                properties.load(is);
                dubboEnv = (String) properties.get("public.dubbo.version");
            } catch (IOException e) {
                logger.error("properties load misconfig error", e);
            } finally {
                try {
                    is.close();
                } catch (IOException e) {
                    logger.error("read misconfig error", e);
                }
            }
        }

        DiamondConfigure.configDiamondHttpUrl(MiscConfig.getProperties().getProperty("public.diamond.url"));
    }

}
