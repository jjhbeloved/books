package com.pajk.plutus.biz.model.roma;

import reactor.rx.Promise;

/**
 * Created by fanhuafeng on 17/2/27.
 * Modify by fanhuafeng on 17/2/27
 */
public class PromiseWrapper<T, P> {

    private T data;

    private Promise<P> promise;

    public PromiseWrapper() {
    }

    public PromiseWrapper(T data, Promise<P> promise) {
        this.data = data;
        this.promise = promise;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public Promise<P> getPromise() {
        return promise;
    }

    public void setPromise(Promise<P> promise) {
        this.promise = promise;
    }

}
