package com.pajk.plutus.biz.dao.mapper.single.voucher;

import com.pajk.plutus.biz.model.mapper.single.voucher.StatementDAO;
import com.pajk.plutus.biz.model.mapper.single.voucher.StatementUpdateOPT;
import org.apache.ibatis.annotations.Param;

/**
 * Created by  guguangming on 2017/12/15
 **/
public interface StatementMapper {
    StatementDAO queryByOutId(@Param("outType") String outType,@Param("outId") String outId);

    void create(StatementDAO statementDAO);

    int updateByOPT(StatementUpdateOPT updateOPT);
}
