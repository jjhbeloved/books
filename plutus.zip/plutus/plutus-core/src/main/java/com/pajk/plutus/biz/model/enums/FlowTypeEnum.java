package com.pajk.plutus.biz.model.enums;

/**
 * 大的流程种类，用来区别不同页面的状态下拉框
 *
 * Created by fuyongda on 2017/12/20.
 * Modified by fuyongda on 2017/12/20.
 */
    public enum FlowTypeEnum {

    BILL        ("bill"         , "对账"       ),
    PAYMENT     ("payment"      , "缴费单"     ),
    VIOLATION   ("violation"    , "违规单"     ),
    UNKNOWN     ("unknown"      , "未知"       ),
    ;

    private String code;
    private String desc;

    FlowTypeEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public String getCode() {
        return code;
    }

    public boolean isEquals(String code) {
        return this.code.equals(code);
    }

    public boolean isEquals(FlowTypeEnum item) {
        return null != item && isEquals(item.getCode());
    }

    public static FlowTypeEnum valueOfCode(String code) {
        for (FlowTypeEnum item : values()) {
            if (item.isEquals(code)) {
                return item;
            }
        }
        return UNKNOWN;
    }

}
