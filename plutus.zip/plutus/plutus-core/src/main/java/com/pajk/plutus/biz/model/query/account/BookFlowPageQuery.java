package com.pajk.plutus.biz.model.query.account;

import com.pajk.plutus.biz.model.query.PageQuery;

import java.util.Date;
import java.util.List;

/**
 * Created by lizhijun on 2017/12/17.
 */
public class BookFlowPageQuery extends PageQuery {

    /**
     * 账本id
     */
    private Long bookId;
    /**
     * 商家id
     */
    private long sellerId;

    /**
     * 账本流水来源
     */
    private String outType;

    /**
     * 账本流水类型
     */
    private List<Integer> flowTypes;

    /**
     * 账本流水子类型
     */
    private Integer flowSubType;

    /**
     * 账本余额增加或扣减的时间区间-开始
     */
    private Date statementStart;
    /**
     * 账本余额增加或扣减的时间区间-结束
     */
    private Date statementEnd;


    /**
     * 是否绑定销帐id
     */
    private Boolean hasWriteOff;


    public Long getBookId() {
        return bookId;
    }

    public void setBookId(Long bookId) {
        this.bookId = bookId;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public String getOutType() {
        return outType;
    }

    public void setOutType(String outType) {
        this.outType = outType;
    }

    public List<Integer> getFlowTypes() {
        return flowTypes;
    }

    public void setFlowTypes(List<Integer> flowTypes) {
        this.flowTypes = flowTypes;
    }

    public Integer getFlowSubType() {
        return flowSubType;
    }

    public void setFlowSubType(Integer flowSubType) {
        this.flowSubType = flowSubType;
    }

    public Date getStatementStart() {
        return statementStart;
    }

    public void setStatementStart(Date statementStart) {
        this.statementStart = statementStart;
    }

    public Date getStatementEnd() {
        return statementEnd;
    }

    public void setStatementEnd(Date statementEnd) {
        this.statementEnd = statementEnd;
    }

    public Boolean getHasWriteOff() {
        return hasWriteOff;
    }

    public void setHasWriteOff(Boolean hasWriteOff) {
        this.hasWriteOff = hasWriteOff;
    }
}
