package com.pajk.plutus.biz.dao.repo.impl;

import com.pajk.plutus.biz.dao.mapper.single.voucher.StatementMapper;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherDeliveryMapper;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherMapper;
import com.pajk.plutus.biz.dao.repo.VoucherQueryRepository;
import com.pajk.plutus.biz.model.account.StatementDO;
import com.pajk.plutus.biz.model.mapper.single.voucher.StatementDAO;
import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDAO;
import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDeliveryDAO;
import com.pajk.plutus.biz.model.query.account.VoucherPageQuery;
import com.pajk.plutus.biz.model.query.voucher.VoucherDeliveryPageQuery;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.model.voucher.VoucherDeliveryDO;
import com.pajk.plutus.client.model.enums.account.StatementOutType;
import com.pajk.plutus.client.model.enums.account.StatementStatus;
import com.pajk.plutus.client.model.enums.account.SubjectEnum;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import static java.util.stream.Collectors.toList;

/**
 * Created by lizhijun on 2017/12/17.
 */
@Repository
public class VoucherQueryRepositoryImpl implements VoucherQueryRepository {

    @Autowired
    private VoucherMapper voucherMapper;

    @Autowired
    private VoucherDeliveryMapper voucherDeliveryMapper;

    @Autowired
    private StatementMapper statementMapper;


    @Override
    public Optional<VoucherDO> queryVoucherById(long sellerId, String voucherId) {
        VoucherDAO voucherDAO = voucherMapper.queryBySellerAndId(sellerId,voucherId);
        return Optional.ofNullable(toVoucherModel(voucherDAO));
    }



    @Override
    public Optional<VoucherDeliveryDO> queryVoucherDeliveryByVoucherId(String voucherId) {
        VoucherDeliveryDAO voucherDAO = voucherDeliveryMapper.queryByVoucherId(voucherId);
        return Optional.ofNullable(toVoucherDeliveryModel(voucherDAO));
    }

    @Override
    public Optional<List<VoucherDO>> pageQueryVoucher(VoucherPageQuery voucherPageQuery) {
        return Optional.ofNullable(voucherMapper.pageQuery(voucherPageQuery)).map(items->{
            List<VoucherDO> refunds = new LinkedList<>();
            if(!items.isEmpty()){
                refunds.addAll(items.stream().map(this::toVoucherModel).collect(toList()));
            }
            return refunds;
        }) ;
    }

    @Override
    public int queryVoucherCount(VoucherPageQuery voucherPageQuery) {
        return voucherMapper.pageQueryCount(voucherPageQuery);
    }

    @Override
    public int queryCount(VoucherDeliveryPageQuery pageQuery) {
        return voucherDeliveryMapper.pageQueryCount(pageQuery);
    }

    @Override
    public Optional<List<VoucherDeliveryDO>> pageQueryVoucherDelivery(VoucherDeliveryPageQuery pageQuery) {
        return Optional.ofNullable(voucherDeliveryMapper.pageQuery(pageQuery)
                .stream().map(this::toVoucherDeliveryModel).collect(toList()));
    }

    @Override
    public Optional<StatementDO> queryStatementByVoucher(String outType,String voucherId){
        return Optional.ofNullable(toStatementModel(statementMapper.queryByOutId(outType,voucherId)));
    }


    private VoucherDO toVoucherModel(VoucherDAO voucherDAO) {
        if (null == voucherDAO) {
            return null;
        }
        VoucherDO voucher = new VoucherDO();
        voucher.setVoucherId(voucherDAO.getVoucherId());
        voucher.setOutId(voucherDAO.getOutId());
        voucher.setActualAmt(voucherDAO.getActualAmt());
        voucher.setActualPoint(voucherDAO.getActualPoint());
        voucher.setCreateFile(voucherDAO.getCreateFile());
        voucher.setCreateRemark(voucherDAO.getCreateRemark());
        voucher.setEvidenceFile(voucherDAO.getEvidenceFile());
        voucher.setEvidenceRemark(voucherDAO.getEvidenceRemark());
        voucher.setExpectAmt(voucherDAO.getExpectAmt());
        voucher.setExpectPoint(voucherDAO.getExpectPoint());
        voucher.setExtProps(voucherDAO.getExtProps());
        voucher.setGmtCreated(voucherDAO.getGmtCreated());
        voucher.setGmtModified(voucherDAO.getGmtModified());
        voucher.setNodeCatKey(voucherDAO.getNodeCatKey());
        voucher.setNodeKey(voucherDAO.getNodeKey());
        voucher.setObjId(voucherDAO.getObjId());
        voucher.setObjType(voucherDAO.getObjType());
        voucher.setPayFlag(voucherDAO.getPayFlag());
        voucher.setProcEndTime(voucherDAO.getProcEndTime());
        voucher.setProcInstId(voucherDAO.getProcInstId());
        voucher.setProcStartTime(voucherDAO.getProcStartTime());
        voucher.setRole(voucherDAO.getRole());
        voucher.setSellerId(voucherDAO.getSellerId());
        voucher.setVersion(voucherDAO.getVersion());
        voucher.setVoucherSubType(VoucherSubType.valueOf(voucherDAO.getVoucherSubType()));
        voucher.setVoucherType(VoucherType.valueOf(voucherDAO.getVoucherType()));
        return voucher;
    }

    private VoucherDeliveryDO toVoucherDeliveryModel(VoucherDeliveryDAO voucherDeliveryDAO) {
        if (null == voucherDeliveryDAO) {
            return null;
        }

        VoucherDeliveryDO voucherDelivery = new VoucherDeliveryDO();
        voucherDelivery.setId(voucherDeliveryDAO.getId());
        voucherDelivery.setGmtCreated(voucherDeliveryDAO.getGmtCreated());
        voucherDelivery.setGmtModified(voucherDeliveryDAO.getGmtModified());
        voucherDelivery.setVersion(voucherDeliveryDAO.getVersion());
        voucherDelivery.setSellerId(voucherDeliveryDAO.getSellerId());
        voucherDelivery.setVoucherId(voucherDeliveryDAO.getVoucherId());
        voucherDelivery.setRuleId(voucherDeliveryDAO.getRuleId());
        voucherDelivery.setAmount(voucherDeliveryDAO.getAmount());
        voucherDelivery.setTradeId(voucherDeliveryDAO.getTradeId());
        voucherDelivery.setPayMode(voucherDeliveryDAO.getPayMode());
        voucherDelivery.setTradeMode(voucherDeliveryDAO.getTradeMode());
        voucherDelivery.setStatementMode(voucherDeliveryDAO.getStatementMode());
        voucherDelivery.setTotalAmt(voucherDeliveryDAO.getTotalAmt());
        voucherDelivery.setSettleAmt(voucherDeliveryDAO.getSettleAmt());
        voucherDelivery.setPayTime(voucherDeliveryDAO.getPayTime());
        voucherDelivery.setCreateTime(voucherDeliveryDAO.getCreateTime());
        voucherDelivery.setLgTime(voucherDeliveryDAO.getLgTime());
        voucherDelivery.setDeliveryTime(voucherDeliveryDAO.getDeliveryTime());
        voucherDelivery.setArrivedTime(voucherDeliveryDAO.getArrivedTime());
        voucherDelivery.setCompanyId(voucherDeliveryDAO.getCompanyId());
        voucherDelivery.setCompanyName(voucherDeliveryDAO.getCompanyName());
        voucherDelivery.setTrackingNumber(voucherDeliveryDAO.getTrackingNumber());
        voucherDelivery.setTraceSupported(voucherDeliveryDAO.getTraceSupported());
        voucherDelivery.setuProv(voucherDeliveryDAO.getuProv());
        voucherDelivery.setuCity(voucherDeliveryDAO.getuCity());
        voucherDelivery.setuArea(voucherDeliveryDAO.getuArea());
        voucherDelivery.setsProv(voucherDeliveryDAO.getsProv());
        voucherDelivery.setsCity(voucherDeliveryDAO.getsCity());
        voucherDelivery.setsArea(voucherDeliveryDAO.getsArea());
        voucherDelivery.setExtProps(voucherDeliveryDAO.getExtProps());
        return voucherDelivery;
    }

    private StatementDO toStatementModel(StatementDAO statementDAO){
        if( null == statementDAO){
            return null;
        }
        StatementDO statementDO = new StatementDO();
        statementDO.setId(statementDAO.getId());
        statementDO.setSellerId(statementDAO.getSellerId());
        statementDO.setVersion(statementDAO.getVersion());
        statementDO.setFirstTime(statementDAO.getFirstTime());
        statementDO.setSecondTime(statementDAO.getSecondTime());
        statementDO.setStatus(StatementStatus.valueOf(statementDAO.getStatus()));
        statementDO.setOutId(statementDAO.getOutId());
        statementDO.setOutType(StatementOutType.valueOfCode(statementDAO.getOutType()));
        statementDO.setSubject(SubjectEnum.valueOf(statementDAO.getSubject()));
        statementDO.setPlatformReceivable(statementDAO.getPlatformReceivable());
        statementDO.setPlatformReceivableTax(statementDAO.getPlatformReceivableTax());
        statementDO.setPlatformPayable(statementDAO.getPlatformPayable());
        statementDO.setPlatformPayableTax(statementDAO.getPlatformPayableTax());
        statementDO.setPlatformReceipts(statementDAO.getPlatformReceipts());
        statementDO.setPlatformReceiptsTax(statementDAO.getPlatformReceiptsTax());
        statementDO.setPlatformPaid(statementDAO.getPlatformPaid());
        statementDO.setPlatformPaidTax(statementDAO.getPlatformPaidTax());




        return statementDO;
    }

}
