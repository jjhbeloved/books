package com.pajk.plutus.biz.dao.mapper.single.bill;

import com.pajk.plutus.biz.model.mapper.single.bill.SellerInvoiceInfoDAO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by arjaylv on 2017/12/11.
 *
 * @author arjaylv
 */
public interface SellerInvoiceInfoMapper {

    List<SellerInvoiceInfoDAO> queryBySellerId(@Param("sellerId") long sellerId,
                                               @Param("status") int status);

}
