package com.pajk.plutus.biz.dao.repo.impl;

import com.pajk.plutus.biz.dao.mapper.single.account.AccountBookFlowMapper;
import com.pajk.plutus.biz.dao.mapper.single.account.AccountBookMapper;
import com.pajk.plutus.biz.dao.mapper.single.account.AccountMapper;
import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.account.AccountBookFlowDO;
import com.pajk.plutus.biz.model.account.AccountDO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookFlowDAO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountDAO;
import com.pajk.plutus.biz.model.query.account.BookFlowPageQuery;
import com.pajk.plutus.biz.model.query.account.BookPageQuery;
import com.pajk.plutus.client.model.enums.account.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Created by lizhijun on 2017/12/17.
 */
@Repository
public class AccountQueryRepositoryImpl implements AccountQueryRepository {
    @Autowired
    private AccountMapper accountMapper;
    @Autowired
    private AccountBookMapper bookMapper;
    @Autowired
    private AccountBookFlowMapper bookFlowMapper;

    @Override
    public Optional<AccountDO> queryAccountBySeller(long sellerId){
        return Optional.ofNullable(toModelAccount(accountMapper.queryBySeller(sellerId)));
    }

    @Override
    public Optional<List<AccountBookDO>> queryBookBySeller(long sellerId){
        return Optional.ofNullable(bookMapper.queryBySeller(sellerId)).map(bookDAOs->{
            List<AccountBookDO> bookDOs = new LinkedList<>();
            if(!bookDAOs.isEmpty()){
                bookDOs.addAll(bookDAOs.stream().map(this::toModelBook).collect(Collectors.toList()));
            }
            return bookDOs;
        });
    }

    @Override
    public Optional<AccountBookDO> queryBookBySeller(long sellerId, int bookType){
        return Optional.ofNullable(toModelBook(bookMapper.queryBySellerAndType(sellerId,bookType)));
    }

    @Override
    public Optional<AccountBookDO> queryValidBookBySeller(long sellerId, int bookType){
        return Optional.ofNullable(toModelBook(bookMapper.queryValidBookBySeller(sellerId,bookType)));
    }

    @Override
    public Optional<List<AccountBookDO>> pageQueryBook(BookPageQuery pageQuery) {
        return Optional.ofNullable(bookMapper.pageQuery(pageQuery)).map(bookDAOs->{
            List<AccountBookDO> bookDOs = new LinkedList<>();
            if(!bookDAOs.isEmpty()){
                bookDOs.addAll(bookDAOs.stream().map(this::toModelBook).collect(Collectors.toList()));
            }
            return bookDOs;
        });
    }

    @Override
    public int queryBookCount(BookPageQuery pageQuery) {
        return bookMapper.pageQueryCount(pageQuery);
    }


    @Override
    public Optional<AccountBookDO> queryBookBySellerAndBookId(long sellerId,long bookId){
        return Optional.ofNullable(toModelBook(bookMapper.queryBookBySellerAndBookId(sellerId,bookId)));
    }

    @Override
    public Optional<List<AccountBookFlowDO>> pageQueryBookFlow(BookFlowPageQuery pageQuery) {
        return Optional.ofNullable(bookFlowMapper.pageQuery(pageQuery)).map(flowDAOs->{
            List<AccountBookFlowDO> flowDOs = new LinkedList<>();
            if(!flowDAOs.isEmpty()){
                flowDOs.addAll(flowDAOs.stream().map(this::toModelBookFlow).collect(Collectors.toList()));
            }
            return flowDOs;
        });
    }

    @Override
    public int queryBookFlowCount(BookFlowPageQuery pageQuery){
        return bookFlowMapper.pageQueryCount(pageQuery);
    }

    @Override
    public int queryBookFlowCountByWriteOffId(int bookType, String writeOffType, String writeOffId){
        return bookFlowMapper.queryCountByWriteOffId(bookType,writeOffType,writeOffId);
    }

    @Override
    public Optional<List<Long>> queryBookFlowIdsByWriteOffId(int bookType, String writeOffType, String writeOffId,
                                                             int pageNo, int pageSize){
        int startRow = (pageNo - 1) * pageSize;
        return Optional.ofNullable(bookFlowMapper.
                pageQueryIdsByWriteOffId(bookType,writeOffType,writeOffId,startRow,pageSize)
        );
    }

    @Override
    public Optional<AccountBookFlowDO> queryBookFlowById(long id) {
        return Optional.ofNullable(toModelBookFlow(bookFlowMapper.queryById(id)));
    }

    @Override
    public Optional<AccountBookFlowDO> queryBookFlowByOutId(long accountBookId, String outType, String outId){
        return Optional.ofNullable(toModelBookFlow(bookFlowMapper.queryByOutId(accountBookId,outType,outId)));
    }


    private AccountDO toModelAccount(AccountDAO accountDAO){
        if(null == accountDAO){
            return null;
        }
        AccountDO accountDO = new AccountDO();
        accountDO.setSellerId(accountDAO.getSellerId());
        accountDO.setName(accountDAO.getName());
        accountDO.setId(accountDAO.getId());
        accountDO.setStatus(AccountStatus.valueOf(accountDAO.getStatus()));
        accountDO.setVersion(accountDAO.getVersion());
        accountDO.setGmtCreated(accountDAO.getGmtCreated());
        return accountDO;
    }

    private AccountBookDO toModelBook(AccountBookDAO item){
        if(null == item){
            return null;
        }
        AccountBookDO bookDO = new AccountBookDO();
        bookDO.setId(item.getId());
        bookDO.setGmtCreated(item.getGmtCreated());
        bookDO.setGmtModified(item.getGmtModified());
        bookDO.setVersion(item.getVersion());

        bookDO.setSellerId(item.getSellerId());

        bookDO.setStatus(BookStatus.valueOf(item.getStatus()));
        bookDO.setAccountId(item.getAccountId());
        bookDO.setBookType(BookType.valueOf(item.getBookType()));

        bookDO.setActualContractAmt(item.getActualContractAmt());
        bookDO.setBalanceAmt(item.getBalanceAmt());
        bookDO.setContractAmt(item.getContractAmt());
        bookDO.setFreezingAmt(item.getFreezingAmt());



        return bookDO;
    }

    private AccountBookFlowDO toModelBookFlow(AccountBookFlowDAO bookFlowDAO){
        if(null == bookFlowDAO){
            return null;
        }
        AccountBookFlowDO bookFlowDO = new AccountBookFlowDO();
        bookFlowDO.setId(bookFlowDAO.getId());
        bookFlowDO.setGmtCreated(bookFlowDAO.getGmtCreated());
        bookFlowDO.setGmtModified(bookFlowDAO.getGmtModified());
        bookFlowDO.setVersion(bookFlowDAO.getVersion());
        bookFlowDO.setSellerId(bookFlowDAO.getSellerId());
        bookFlowDO.setStatus(BookFlowStatus.valueOf(bookFlowDAO.getStatus()));
        bookFlowDO.setFlowType(BookFlowType.valueOf(bookFlowDAO.getFlowType()));
        bookFlowDO.setFlowSubType(BookFlowSubType.valueOf(bookFlowDAO.getFlowSubType()));

        bookFlowDO.setOutType(BookFlowOutType.valueOfCode(bookFlowDAO.getOutType()));
        bookFlowDO.setOutId(bookFlowDAO.getOutId());
        bookFlowDO.setBookType(BookType.valueOf(bookFlowDAO.getBookType()));
        bookFlowDO.setBookId(bookFlowDAO.getBookId());
        bookFlowDO.setAmount(bookFlowDAO.getAmount());
        bookFlowDO.setGmtStatement(bookFlowDAO.getGmtStatement());
        bookFlowDO.setWriteOffStatus(BookFlowWriteOffStatus.valueOf(bookFlowDAO.getWriteOffStatus()));

        bookFlowDO.setWriteOffType(BookFlowWriteOffOutType.valueOfCode(bookFlowDAO.getWriteOffType()));
        bookFlowDO.setWriteOffId(bookFlowDAO.getWriteOffId());
        bookFlowDO.setMsg(bookFlowDAO.getMsg());
        return bookFlowDO;
    }
}
