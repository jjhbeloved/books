package com.pajk.plutus.biz.model.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * Created by fuyongda on 2017/12/17.
 * Modified by fuyongda on 2017/12/17.
 */
public class VoucherLogDO extends BaseDO {

    private static final long serialVersionUID = -547274524025887716L;

    /**
     * 商户id
     */
    private long sellerId;
    /**
     * 单据id
     */
    private long voucherId;

    /**
     * 创建时间
     */
    private Date gmtCreated;

    /**
     * 操作类型
     */
    private String optType;

    /**
     * 操作人
     */
    private String operator;

    /**
     * 操作描述
     */
    private String msg;

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public String getOptType() {
        return optType;
    }

    public void setOptType(String optType) {
        this.optType = optType;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public long getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(long voucherId) {
        this.voucherId = voucherId;
    }
}
