package com.pajk.plutus.biz.manager.permission;

import com.pajk.user.model.User;

public class UserUtil {


    private static ThreadLocal<User> userInfo = new ThreadLocal<>();

    /**
     * 存放当前用户信息
     *
     * @param user
     */
    public static void putUser(User user) {
        userInfo.set(user);
    }

    /**
     * 获取当前用户信息
     *
     * @return
     */
    public static User getCurrentUser() {
        return userInfo.get();
    }

    /**
     * 移除当前用户信息
     */
    public static void removeCurrentUser() {
        userInfo.remove();
    }

    /**
     * 获取用户id
     *
     * @return
     */
    public static String getUserId() {
        User user = getCurrentUser();
        return user != null ? user.getId().toString() : null;
    }

    public static String getUserName() {
        User user = getCurrentUser();
        return user != null ? user.getName() : null;
    }

}
