package com.pajk.plutus.biz.model.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by lizhijun on 2017/12/22.
 */
public enum VoucherExtPropsKey {

    EVIDENCE_FLOW("evidenceFlow","银行流水"),
    ;

    private String code;
    private String desc;

    VoucherExtPropsKey(String code, String desc){
        this.code = code ;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isEquals(String code){
        return StringUtils.equals(code, this.getCode());
    }

    public boolean isEquals(VoucherExtPropsKey item) {
        return null != item && isEquals(item.getCode());
    }


    public static boolean containKey(String key) {
        for (VoucherExtPropsKey item : values()) {
            if (StringUtils.equals(key, item.getCode())) {
                return true;
            }
        }
        return false;
    }
}
