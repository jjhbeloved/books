package com.pajk.plutus.biz.conf;

import com.pajk.troy.client.bootstrap.MonitorBootstrap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by fanhuafeng on 17/4/19.
 * Modify by fanhuafeng on 17/4/19
 */
@Configuration
public class TroyConfig {

    private static final Logger logger = LoggerFactory.getLogger(TroyConfig.class);

    @Value("${dubbo.application.name}")
    private String appName;

    @Value("${troy.agent.host}")
    private String agentHost;

    @Value("${troy.agent.port:16777}")
    private String agentPort;

    private boolean enable = true;

    private boolean uriStatEnable = false;

    private boolean logStatEnable = true;

    private boolean springStatEnable = true;

    private boolean jdbcStatEnable = true;

    private boolean dubboProviderStatEnable = true;

    private boolean dubboConsumerStatEnable = true;

    private boolean rocketMQProducerStatEnable = true;

    private boolean rocketMQConsumerStatEnable = true;

    @Bean
    public MonitorBootstrap monitorBootstrap() {
        logger.info("autoconfig MonitorBootstrap...");
        logger.info("agentHost:{},agentPort:{},appName:{}", agentHost, agentPort, appName);
        logger.info("monitorEnable:{},uriStatEnable:{},logStatEnable:{},springStatEnable:{},jdbcStatEnable:{}," +
                        "dubboProviderStatEnable:{},dubboConsumerStatEnable:{},rocketMQConsumerStatEnable{}," +
                        "rocketMQProducerStatEnable:{}",
                enable, uriStatEnable, logStatEnable, springStatEnable, jdbcStatEnable, dubboProviderStatEnable,
                dubboConsumerStatEnable, rocketMQConsumerStatEnable, rocketMQProducerStatEnable);
        return createMonitorBootstrap();
    }

    private MonitorBootstrap createMonitorBootstrap() {
        // 是否开启监控，默认开启
        MonitorBootstrap.setMonitorEnable(enable);
        // 是否开启URI监控，默认关闭
        MonitorBootstrap.setUriStatEnable(uriStatEnable);
        // 是否开启异常监控，默认开启
        MonitorBootstrap.setLogStatEnable(logStatEnable);
        // 是否开启方法监控，默认开启
        MonitorBootstrap.setSpringStatEnable(springStatEnable);
        // 是否开启JDBC监控，默认开启
        MonitorBootstrap.setJdbcStatEnable(jdbcStatEnable);
        // 是否开启dubboProvider监控，默认开启
        MonitorBootstrap.setDubboProviderStatEnable(dubboProviderStatEnable);
        // 是否开启dubboConsumer监控，默认开启
        MonitorBootstrap.setDubboConsumerStatEnable(dubboConsumerStatEnable);
        // 是否开启rocketMQProducer监控，默认关闭
        MonitorBootstrap.setRocketMQConsumerStatEnable(rocketMQConsumerStatEnable);
        // 是否开启rocketMQConsumer监控，默认关闭
        MonitorBootstrap.setRocketMQProducerStatEnable(rocketMQProducerStatEnable);
        // 启动monitor
        MonitorBootstrap.start(agentHost, agentPort, appName);

        logger.info("troy is initialized: agent host:{}, app name:{}, enable:{}", agentHost, appName, enable);

        return MonitorBootstrap.getInstance();
    }

}
