package com.pajk.plutus.biz.model.param.restapi;

import com.pajk.thunderbird.domain.result.BaseDO;

import javax.validation.constraints.NotNull;

/**
 * Created by lizhijun on 2017/12/19.
 */
public class AuditPunishParam extends BaseDO {

    private static final long serialVersionUID = 4377667146093682923L;
    /**
     * 商家Id
     */
    @NotNull
    private Long sellerId;
    /**
     * 单据Id
     */
    @NotNull
    private String voucherId;
    @NotNull
    private String transitionKey;
    @NotNull
    private String nodeKey;
    private String remark;

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public String getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(String voucherId) {
        this.voucherId = voucherId;
    }

    public String getTransitionKey() {
        return transitionKey;
    }

    public void setTransitionKey(String transitionKey) {
        this.transitionKey = transitionKey;
    }

    public String getNodeKey() {
        return nodeKey;
    }

    public void setNodeKey(String nodeKey) {
        this.nodeKey = nodeKey;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
