package com.pajk.plutus.biz.model.query.bill;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * Created by sunjin on 2017/12/19.
 */
public class RemarkDTO implements Serializable{
    private static final long serialVersionUID = -4013723877521272953L;

    private Long sellerId;

    @NotNull
    private Long billId;
    @NotBlank
    private String buttonKey;
    @Length(max = 500)
    private String remark;

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public String getButtonKey() {
        return buttonKey;
    }

    public void setButtonKey(String buttonKey) {
        this.buttonKey = buttonKey;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
