package com.pajk.plutus.biz.model.bill;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * @author david
 * @since created by on 17/12/14 10:20
 */
public class InvoiceInfoSnapshotDO extends BaseDO {

    private static final long serialVersionUID = 1882599813242162276L;

    private Long id;

    /**
     * 单据id
     */
    private Long billId;

    /**
     * 发票抬头
     */
    private String invoiceTitle;

    /**
     * 发票联系人
     */
    private String contact;

    /**
     * 发票联系人电话
     */
    private String contactTel;

    /**
     * 发票地址信息
     */
    private String invoiceAddress;

    /**
     * 纳税人识别号
     */
    private String taxpayerNumber;

    /**
     * 发票电话信息
     */
    private String invoiceTel;

    /**
     * 发票寄送地址
     */
    private String address;

    /**
     * 发票开户行信息
     */
    private String invoiceBankName;

    /**
     * 发票开户行账户信息
     */
    private String invoiceBankAccount;

    /**
     * 发票类型 1:增值税专用发票 2:增值税普通发票
     */
    private Integer invoiceType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public String getInvoiceTitle() {
        return invoiceTitle;
    }

    public void setInvoiceTitle(String invoiceTitle) {
        this.invoiceTitle = invoiceTitle;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getContactTel() {
        return contactTel;
    }

    public void setContactTel(String contactTel) {
        this.contactTel = contactTel;
    }

    public String getInvoiceAddress() {
        return invoiceAddress;
    }

    public void setInvoiceAddress(String invoiceAddress) {
        this.invoiceAddress = invoiceAddress;
    }

    public String getTaxpayerNumber() {
        return taxpayerNumber;
    }

    public void setTaxpayerNumber(String taxpayerNumber) {
        this.taxpayerNumber = taxpayerNumber;
    }

    public String getInvoiceTel() {
        return invoiceTel;
    }

    public void setInvoiceTel(String invoiceTel) {
        this.invoiceTel = invoiceTel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getInvoiceBankName() {
        return invoiceBankName;
    }

    public void setInvoiceBankName(String invoiceBankName) {
        this.invoiceBankName = invoiceBankName;
    }

    public String getInvoiceBankAccount() {
        return invoiceBankAccount;
    }

    public void setInvoiceBankAccount(String invoiceBankAccount) {
        this.invoiceBankAccount = invoiceBankAccount;
    }

    public Integer getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(Integer invoiceType) {
        this.invoiceType = invoiceType;
    }
}
