package com.pajk.plutus.biz.model.roma;

import com.pajk.roma.message.RomaDbMessage;
import org.apache.commons.lang3.math.NumberUtils;

/**
 * Created by lizhijun on 2017/12/17.
 */
public class RomaBookFlowInfo {

    public RomaBookFlowInfo() {
    }

    private long id;
    private long sellerId;
    private ValueChange status;
    // 当前消息被某个订阅组重新消费了几次（订阅组之间独立计数）
    private int reconsumeTimes;

    public RomaBookFlowInfo(RomaDbMessage.RomaDbData changeData){
        changeData.getFieldsValueList().forEach(f -> {
            switch (f.getFieldName()) {
                case "id":
                    setId(NumberUtils.toLong(f.getNewValue()));
                    break;
                case "seller_id":
                    setSellerId(NumberUtils.toLong(f.getNewValue()));
                    break;
                case "status":
                    setStatus(new ValueChange(f.getOldValue(), f.getNewValue()));
                    break;
                default:
                    break;

            }
        });
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public ValueChange getStatus() {
        return status;
    }

    public void setStatus(ValueChange status) {
        this.status = status;
    }

    public int getReconsumeTimes() {
        return reconsumeTimes;
    }

    public void setReconsumeTimes(int reconsumeTimes) {
        this.reconsumeTimes = reconsumeTimes;
    }
}
