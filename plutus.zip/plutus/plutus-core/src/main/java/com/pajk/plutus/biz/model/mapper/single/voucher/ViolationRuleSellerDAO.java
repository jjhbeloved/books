package com.pajk.plutus.biz.model.mapper.single.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * 违规规则商户表
 */
public class ViolationRuleSellerDAO extends BaseDO {

    private static final long serialVersionUID = 7849474450044494393L;

    /**
     * 主键id
     */
    private long id;

    /**
     * 创建时间
     */
    private Date gmtCreated;

    /**
     * 更新时间
     */
    private Date gmtModified;

    /**
     * 0 未删除 1 删除
     */
    private int isDeleted;

    /**
     * 版本号
     */
    private int version;

    /**
     * 卖家id
     */
    private long sellerId;

    /**
     * 商家名
     */
    private String name;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public int getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(int isDeleted) {
        this.isDeleted = isDeleted;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
