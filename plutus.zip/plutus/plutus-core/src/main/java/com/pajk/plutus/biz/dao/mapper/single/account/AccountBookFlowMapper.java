package com.pajk.plutus.biz.dao.mapper.single.account;

import com.pajk.plutus.biz.model.mapper.single.account.AccountBookFlowDAO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookFlowUpdateOPT;
import com.pajk.plutus.biz.model.query.account.BookFlowPageQuery;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by  guguangming on 2017/12/15
 **/
public interface AccountBookFlowMapper {
    List<AccountBookFlowDAO> pageQuery(BookFlowPageQuery pageQuery);

    int pageQueryCount(BookFlowPageQuery pageQuery);

    List<Long> pageQueryIdsByWriteOffId(@Param("bookType") int bookType,
                                    @Param("writeOffType") String writeOffType,
                                    @Param("writeOffId") String writeOffId,
                                    @Param("startRow") int startRow,
                                    @Param("pageSize") int pageSize);

    int queryCountByWriteOffId(@Param("bookType") int bookType,
                               @Param("writeOffType") String writeOffType,
                               @Param("writeOffId") String writeOffId);

    int batchUpdateWriteOffToFinish(@Param("ids") List<Long> ids);

    int updateWriteOffToFinish(@Param("id") long id, @Param("version") int version);

    AccountBookFlowDAO queryById(@Param("id") long id);

    AccountBookFlowDAO queryByOutId(@Param("bookId") long bookId,
                                 @Param("outType") String outType,
                                 @Param("outId") String outId);

    int updateByOPT(AccountBookFlowUpdateOPT opt);

    void create(AccountBookFlowDAO accountBookFlowDAO);

    int batchUpdateWriteOffId(@Param("ids")List<Long> ids, @Param("writeOffId")String writeOffId,@Param("writeOffType")String writeOffType);
}
