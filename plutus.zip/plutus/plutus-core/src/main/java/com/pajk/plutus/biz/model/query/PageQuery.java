package com.pajk.plutus.biz.model.query;


import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by fanhuafeng on 15-3-19.
 * Modify by fanhuafeng on 15-3-19
 */
public class PageQuery extends BaseDO {

    private static final long serialVersionUID = -7304713318859825120L;
    private int pageNo = 1;
    private int pageSize = 10;

    public int getStartRow() {
        return (pageNo - 1) * pageSize;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}