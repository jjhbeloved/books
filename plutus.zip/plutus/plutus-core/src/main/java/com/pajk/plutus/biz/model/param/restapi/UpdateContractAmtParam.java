package com.pajk.plutus.biz.model.param.restapi;

import com.pajk.thunderbird.domain.result.BaseDO;

import javax.validation.constraints.NotNull;

/**
 * Created by lizhijun on 2017/12/19.
 */
public class UpdateContractAmtParam extends BaseDO {
    private static final long serialVersionUID = 5050288802431523750L;
    @NotNull
    private Long sellerId;
    @NotNull
    private Long accountBookId;
    @NotNull
    private Long baseContractAmt;
    @NotNull
    private Long updateContractAmt;

    private String remark;


    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Long getAccountBookId() {
        return accountBookId;
    }

    public void setAccountBookId(Long accountBookId) {
        this.accountBookId = accountBookId;
    }

    public Long getBaseContractAmt() {
        return baseContractAmt;
    }

    public void setBaseContractAmt(Long baseContractAmt) {
        this.baseContractAmt = baseContractAmt;
    }

    public Long getUpdateContractAmt() {
        return updateContractAmt;
    }

    public void setUpdateContractAmt(Long updateContractAmt) {
        this.updateContractAmt = updateContractAmt;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
