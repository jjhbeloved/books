package com.pajk.plutus.biz.exceptions;

/**
 * @author david
 * @modify david on 17/9/17 20:53
 * <ul>
 * <li>create</li>
 * </ul>
 * @since created by on 17/9/17 20:53
 */
public class BaseException extends RuntimeException {

    private int code;
    private String msg;

    public static final int SUCCESS = 100000;
    public static final String SUCCESS_MSG = "处理成功";

    public static final int SYSTEM_ERROR = 100001;
    public static final String SYSTEM_ERROR_MSG = "系统异常, 数据库异常";

    public static final int PARAM_ERROR = 100002;
    public static final String PARAM_ERROR_MSG = "参数非法";

    public static final int NO_PERMISSION_ERROR = 100003;
    public static final String NO_PERMISSION_ERROR_MSG = "您无权此操作";

    public static final int DATABASE_ERROR = 100006;
    public static final String DATABASE_ERROR_MSG = "数据库异常";

    public static final int PAGE_PARAM_ERROR = 100003;
    public static final String PAGE_PARAM_ERROR_MSG = "分页参数非法";

    public static final int SERVICE_INVOKE_ERROR = 100004;
    public static final String SERVICE_INVOKE_ERROR_MSG = "服务调用异常";

    public static final int RESOURCE_OCCUPANCY = 100005;
    public static final String RESOURCE_OCCUPANCY_MSG = "资源占用,请稍后再试!!!";


    public static final int NO_PERMISSION = 100024;
    public static final String NO_PERMISSION_MSG = "您无权限此操作!!!";



    public BaseException(String message) {
        super(message);
    }

    public BaseException(String message, Throwable cause) {
        super(message, cause);
    }

    public BaseException(int code, String msg) {
        super(msg);
        this.code = code;
        this.msg = msg;
    }

    public BaseException(int code, String msg, Throwable cause) {
        super(cause);
        this.code = code;
        this.msg = msg;
    }

    public static String genernalMsg(Long id, int code, String msg) {
        return id + msg + "[" + code + "]";
    }

    public static String genernalMsg(int code, String msg) {
        return msg + "[" + code + "]";
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
