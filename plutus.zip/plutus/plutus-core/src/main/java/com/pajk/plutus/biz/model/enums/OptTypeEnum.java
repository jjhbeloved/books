package com.pajk.plutus.biz.model.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by  guguangming on 2017/12/28
 **/
public enum OptTypeEnum {
    CREATE_PUNISH("CREATE_PUNISH", "创建违规单"),
    DELETE_PUNISH("DELETE_PUNISH", "删除违规单"),
    SUBMIT_PUNISH("SUBMIT_PUNISH", "提交违规单"),
    AUDIT_PUNISH("AUDIT_PUNISH", "商管审核违规单"),
    SELLER_DEAL_PUNISH("SELLER_DEAL_PUNISH", "商家审核处理违规单"),
    UPDATE_CONTRACT_AMT("UPDATE_CONTRACT_AMT", "删除违规单"),
    SELLER_CONFIRM_PAYMENT("SELLER_CONFIRM_PAYMENT", "商家确认缴费"),
    AUDIT_PAYMENT("AUDIT_PAYMENT", "财务审核违规单"),
    ADD_BALANCE_AMT("ADD_BALANCE_AMT", "商管创建补充缴费"),
    SYSTEM_CREATE_PUNISH("AUTO_CREATE_PUNISH", "系统创建违规单"),
    SYSTEM_ADD_BALANCE_AMT("SYSTEM_ADD_BALANCE_AMT", "系统创建补充缴费"),
    SYSTEM_AGREE_PUNISH("SYSTEM_ADD_BALANCE_AMT", "T+4系统统一缴费"),
    UNKNOWN("UNKNOWN", "未知");

    private String code;
    private String desc;

    OptTypeEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public boolean isEquals(OptTypeEnum item) {
        return null != item && isEquals(item.getCode());
    }

    public String getCode() {
        return this.code;
    }

    public String getDesc() {
        return this.desc;
    }

    public boolean isEquals(String s) {

        return StringUtils.equals(s, code);

    }
}
