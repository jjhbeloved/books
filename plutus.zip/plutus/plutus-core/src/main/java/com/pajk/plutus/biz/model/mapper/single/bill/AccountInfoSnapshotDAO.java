package com.pajk.plutus.biz.model.mapper.single.bill;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * Created by arjaylv on 2017/12/11.
 *
 * @author arjaylv
 */
public class AccountInfoSnapshotDAO extends BaseDO {

    private static final long serialVersionUID = -1314197627438519562L;

    private Long id;

    private Date gmtCreated;

    /**
     * 单据id
     */
    private Long billId;

    /**
     * 收款的银行账户
     */
    private String purchaserAccount;

    /**
     * 收款的银行账户名称
     */
    private String purchaserAccountName;

    /**
     * 收款的开户行
     */
    private String purchaserBankName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public String getPurchaserAccount() {
        return purchaserAccount;
    }

    public void setPurchaserAccount(String purchaserAccount) {
        this.purchaserAccount = purchaserAccount;
    }

    public String getPurchaserAccountName() {
        return purchaserAccountName;
    }

    public void setPurchaserAccountName(String purchaserAccountName) {
        this.purchaserAccountName = purchaserAccountName;
    }

    public String getPurchaserBankName() {
        return purchaserBankName;
    }

    public void setPurchaserBankName(String purchaserBankName) {
        this.purchaserBankName = purchaserBankName;
    }

}
