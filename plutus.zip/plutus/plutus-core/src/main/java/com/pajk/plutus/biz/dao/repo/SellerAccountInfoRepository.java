package com.pajk.plutus.biz.dao.repo;

import com.pajk.plutus.biz.model.bill.SellerAccountInfoDO;

import java.util.Optional;

/**
 * @author david
 * @since created by on 17/12/19 13:18
 */
public interface SellerAccountInfoRepository {


    /**
     * 查询商户账号有效信息, 由于一个商户下可能有n个账号, 取查询的第一个
     *
     * @param sellerId 商户ID
     * @return 商户账号信息
     */
    Optional<SellerAccountInfoDO> queryBySellerId(long sellerId);

    /**
     * 查询商户账号信息, 由于一个商户下可能有n个账号, 取查询的第一个
     *
     * @param sellerId 商户ID
     * @param status   商户账户信息状态 0 可用 1 不可用
     * @return 商户账号信息
     */
    Optional<SellerAccountInfoDO> queryBySellerId(long sellerId, int status);
}
