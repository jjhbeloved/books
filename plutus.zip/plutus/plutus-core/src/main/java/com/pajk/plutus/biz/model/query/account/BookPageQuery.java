package com.pajk.plutus.biz.model.query.account;

import com.pajk.plutus.biz.model.query.PageQuery;

/**
 * Created by lizhijun on 2017/12/17.
 */
public class BookPageQuery extends PageQuery {
    private static final long serialVersionUID = -7313163292141502986L;

    private Long sellerId;
    private Integer status;
    private Long balanceAmtStart;
    private Long balanceAmtEnd;
    private int bookType;

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Long getBalanceAmtStart() {
        return balanceAmtStart;
    }

    public void setBalanceAmtStart(Long balanceAmtStart) {
        this.balanceAmtStart = balanceAmtStart;
    }

    public Long getBalanceAmtEnd() {
        return balanceAmtEnd;
    }

    public void setBalanceAmtEnd(Long balanceAmtEnd) {
        this.balanceAmtEnd = balanceAmtEnd;
    }

    public int getBookType() {
        return bookType;
    }

    public void setBookType(int bookType) {
        this.bookType = bookType;
    }
}
