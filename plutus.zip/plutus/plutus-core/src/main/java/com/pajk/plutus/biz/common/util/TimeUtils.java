package com.pajk.plutus.biz.common.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by fanhuafeng on 17/3/7.
 * Modify by fanhuafeng on 17/3/7
 */
public class TimeUtils {

    private static final Logger logger = LoggerFactory.getLogger(TimeUtils.class);

    public static final long ONE_DAY_MILLISECOND = 86400000L; // 60 * 60 * 24 * 1000L

    public static final long ONE_HOUR_MILLISECOND = 3600000L; //60 * 60  * 1000L

    private static final String DEFAULT_DATA_FORMAT = "yyyy-MM-dd HH:mm:ss";

    public static final String SIMPLE_DATA_FORMAT = "yyyy-MM-dd";

    public static final String MONTH_FORMAT = "yyyy-MM";

    private TimeUtils() {
    }

    public static Date addMonth(Date date, int month) {
        final Calendar currentCalendar = Calendar.getInstance();
        currentCalendar.setTime(date);
        currentCalendar.add(Calendar.MONTH, month);
        return currentCalendar.getTime();
    }

    public static Date addDate(Date date, int day) {
        final Calendar currentCalendar = Calendar.getInstance();
        currentCalendar.setTime(date);
        currentCalendar.add(Calendar.DATE, day);
        return currentCalendar.getTime();
    }

    public static Date getBeginOfDate(Date d) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);

        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        return cal.getTime();
    }

    public static Date getEndOfDate(Date d) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);

        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 59);
        cal.set(Calendar.SECOND, 59);
        cal.set(Calendar.MILLISECOND, 999);

        return cal.getTime();
    }

    /**
     * date 转换为 utc time millis
     *
     * @param date date
     * @return utc time millis
     */
    public static long getTimeMillis(Date date) {
        return getTimeMillis(date, 0);
    }

    /**
     * date 转换为 utc time millis, use default value
     *
     * @param date date
     * @return utc time millis
     */
    public static long getTimeMillis(Date date, long defaultValue) {
        if (null == date) {
            return defaultValue;
        }
        return date.getTime();
    }

    /**
     * date 转换为 utc time seconds
     *
     * @param date date
     * @return utc time seconds
     */
    public static long getTimeSeconds(Date date) {
        return getTimeSeconds(date, 0);
    }

    /**
     * date 转换为 utc time seconds, use default value
     *
     * @param date date
     * @return utc time seconds
     */
    public static long getTimeSeconds(Date date, long defaultValue) {
        if (null == date) {
            return defaultValue;
        }
        return date.getTime() / 1000;
    }

    public static Date parse(String strDate) {
        return parse(strDate, DEFAULT_DATA_FORMAT);
    }

    public static Date parse(String strDate, String pattern) {
        if (StringUtils.isBlank(strDate) || StringUtils.isBlank(pattern)) {
            return null;
        }
        try {
            return new SimpleDateFormat(pattern).parse(strDate);
        } catch (Exception e) {
            logger.warn("SimpleDateFormat.parse exception. strDate={}, pattern={}, e:", strDate, pattern, e);
            return null;
        }
    }

    public static String format(Date date, String pattern) {
        if (null == date || StringUtils.isEmpty(pattern)) {
            return null;
        }

        try {
            return new SimpleDateFormat(pattern).format(date);
        } catch (Exception e) {
            logger.warn("SimpleDateFormat.format exception. ate={}, pattern={}, e:", date, pattern, e);
            return null;
        }
    }

    public static String format(Date date) {
        return format(date, DEFAULT_DATA_FORMAT);
    }

}
