package com.pajk.plutus.biz.model.mapper.single.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * Created by cuidongchao on 2017/12/18.
 */
public class VoucherUpdateOPT extends BaseDO {

    private String voucherId;

    private Long sellerId;

    private Integer version;

    private Long actualAmt;

    private Integer payFlag;

    private Integer isDeleted;

    private String procInstId;

    private String nodeKey;

    private String nodeCatKey;

    private String role;

    private Date procStartTime;

    private Date procEndTime;

    private String evidenceRemark;

    private String evidenceFile;

    private String extPropsStr;


    public String getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(String voucherId) {
        this.voucherId = voucherId;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Long getActualAmt() {
        return actualAmt;
    }

    public void setActualAmt(Long actualAmt) {
        this.actualAmt = actualAmt;
    }

    public Integer getPayFlag() {
        return payFlag;
    }

    public void setPayFlag(Integer payFlag) {
        this.payFlag = payFlag;
    }

    public Integer getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getProcInstId() {
        return procInstId;
    }

    public void setProcInstId(String procInstId) {
        this.procInstId = procInstId;
    }

    public String getNodeKey() {
        return nodeKey;
    }

    public void setNodeKey(String nodeKey) {
        this.nodeKey = nodeKey;
    }

    public String getNodeCatKey() {
        return nodeCatKey;
    }

    public void setNodeCatKey(String nodeCatKey) {
        this.nodeCatKey = nodeCatKey;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Date getProcStartTime() {
        return procStartTime;
    }

    public void setProcStartTime(Date procStartTime) {
        this.procStartTime = procStartTime;
    }

    public Date getProcEndTime() {
        return procEndTime;
    }

    public void setProcEndTime(Date procEndTime) {
        this.procEndTime = procEndTime;
    }

    public String getEvidenceRemark() {
        return evidenceRemark;
    }

    public void setEvidenceRemark(String evidenceRemark) {
        this.evidenceRemark = evidenceRemark;
    }

    public String getEvidenceFile() {
        return evidenceFile;
    }

    public void setEvidenceFile(String evidenceFile) {
        this.evidenceFile = evidenceFile;
    }

    public String getExtPropsStr() {
        return extPropsStr;
    }

    public void setExtPropsStr(String extPropsStr) {
        this.extPropsStr = extPropsStr;
    }

}
