package com.pajk.plutus.biz.manager;

import com.google.common.collect.Lists;
import com.pajk.plutus.biz.common.util.JsonUtil;
import com.pajk.taskcenter.client.model.dto.GetNodeInfoResultDTO;
import com.pajk.taskcenter.client.model.dto.NodeDTO;
import com.pajk.taskcenter.client.model.query.ProcessInstQuery;
import com.pajk.taskcenter.client.model.result.BatchResult;
import com.pajk.taskcenter.client.service.FlowService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.List;

/**
 * Created by fanhuafeng on 18/1/4.
 * Modify by fanhuafeng on 18/1/4
 */
public abstract class AbstractTaskService {


    private final static Logger logger = LoggerFactory.getLogger(AbstractTaskService.class);

    @Autowired
    protected FlowService flowService;


    /**
     * 获取流程指定节点的 输出按钮
     *
     * @param procInstId 流程吗
     * @param nodeKey    节点值
     * @return 输出按钮列表
     */
    protected NodeDTO getNodeInfo(long procInstId, String nodeKey) {
        ProcessInstQuery processInstQuery = new ProcessInstQuery();
        processInstQuery.setProcInstId(procInstId);
        processInstQuery.setNodeKey(nodeKey);
        List<ProcessInstQuery> processInstQueries = Lists.newArrayList(processInstQuery);
        List<GetNodeInfoResultDTO> getNodeInfoResultDTOS = getNodeInfoList(processInstQueries);
        if (CollectionUtils.isEmpty(getNodeInfoResultDTOS)) {
            return null;
        }
        return getNodeInfoResultDTOS.get(0).getNodeDTO();
    }

    /**
     * 批量获取流程指定节点的 详细信息
     *
     * @param processInstQueries 查询流程入参
     * @return 输出详细信息列表
     */
    protected List<GetNodeInfoResultDTO> getNodeInfoList(List<ProcessInstQuery> processInstQueries) {
        try {
            BatchResult<GetNodeInfoResultDTO> batchResult = flowService.getNodeInfoList(processInstQueries);
            if (batchResult.isSuccess()) {
                return batchResult.getModel();
            }
            logger.warn("get transitions element in:{} fail, code:{}, msg:{}",
                    JsonUtil.obj2Str(processInstQueries), batchResult.getErrorCode(), batchResult.getErrorMsg());
        } catch (Exception e) {
            logger.warn("get transitions element in:{} exception ", JsonUtil.obj2Str(processInstQueries), e);
        }
        return Collections.emptyList();
    }

}
