package com.pajk.plutus.biz.manager;

import com.pajk.plutus.biz.model.query.bill.BillStatusDTO;
import com.pajk.plutus.biz.model.query.bill.SellerDTO;
import com.pajk.thunderbird.domain.result.BatchResultDTO;

public interface BillExtManager {

    /**
     * 获取商家列表信息
     *
     * @return 商家列表数据
     */
    BatchResultDTO<SellerDTO> getSellers();

    /**
     * 获取状态列表
     *
     * @return 状态列表
     */
    BatchResultDTO<BillStatusDTO> getBillStatus();

}
