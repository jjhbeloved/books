package com.pajk.plutus.biz.model.param.restapi;

import com.pajk.thunderbird.domain.result.BaseDO;

import javax.validation.constraints.NotNull;

/**
 *
 * Created by lizhijun on 2017/12/19.
 */
public class CreatePunishParam extends BaseDO {
    private static final long serialVersionUID = -7512395036017359690L;
    /**
     * 商户Id
     */
    @NotNull
    private Long sellerId;
    /**
     * 单据子类型
     */
    @NotNull
    private Integer voucherSubType;
    /**
     * 期望金额
     */
    @NotNull
    private Long expectAmt;
    /**
     * 文件说明
     */
    private String createFile;
    /**
     * 备注说明
     */
    private String createRemark;

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Integer getVoucherSubType() {
        return voucherSubType;
    }

    public void setVoucherSubType(Integer voucherSubType) {
        this.voucherSubType = voucherSubType;
    }

    public Long getExpectAmt() {
        return expectAmt;
    }

    public void setExpectAmt(Long expectAmt) {
        this.expectAmt = expectAmt;
    }

    public String getCreateFile() {
        return createFile;
    }

    public void setCreateFile(String createFile) {
        this.createFile = createFile;
    }

    public String getCreateRemark() {
        return createRemark;
    }

    public void setCreateRemark(String createRemark) {
        this.createRemark = createRemark;
    }
}
