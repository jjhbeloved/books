package com.pajk.plutus.biz.model.bill;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.List;

/**
 * @author david
 * @since created by on 17/12/17 18:35
 */
public class BillInfoDO extends BaseDO {

    private static final long serialVersionUID = -4985608378534387457L;

    /**
     * 商户账单确认上传的附件信息
     */
    private ConfirmInfoDO confirmInfo;

    /**
     * 确认支付时提交的相关信息
     */
    private List<PaymentInfoDO> paymentInfo;

    /**
     * 发票信息
     */
    private InvoiceInfoDO invoiceInfo;

    public ConfirmInfoDO getConfirmInfo() {
        return confirmInfo;
    }

    public void setConfirmInfo(ConfirmInfoDO confirmInfo) {
        this.confirmInfo = confirmInfo;
    }

    public List<PaymentInfoDO> getPaymentInfo() {
        return paymentInfo;
    }

    public void setPaymentInfo(List<PaymentInfoDO> paymentInfo) {
        this.paymentInfo = paymentInfo;
    }

    public InvoiceInfoDO getInvoiceInfo() {
        return invoiceInfo;
    }

    public void setInvoiceInfo(InvoiceInfoDO invoiceInfo) {
        this.invoiceInfo = invoiceInfo;
    }
}
