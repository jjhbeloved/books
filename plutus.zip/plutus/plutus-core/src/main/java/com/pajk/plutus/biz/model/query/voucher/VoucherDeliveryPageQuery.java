package com.pajk.plutus.biz.model.query.voucher;

import com.pajk.plutus.biz.model.query.PageQuery;

import java.util.Date;

/**
 * Created by cuidongchao on 2017/12/17.
 */
public class VoucherDeliveryPageQuery extends PageQuery {

    private Integer voucherIdEmptyFlag;

    /**
     * 创建日期查询起始值（包含）
     */
    private Date startCreated;

    /**
     * 创建日期查询截止值（不包含）
     */
    private Date endCreated;

    public Integer getVoucherIdEmptyFlag() {
        return voucherIdEmptyFlag;
    }

    public void setVoucherIdEmptyFlag(Integer voucherIdEmptyFlag) {
        this.voucherIdEmptyFlag = voucherIdEmptyFlag;
    }

    public Date getStartCreated() {
        return startCreated;
    }

    public void setStartCreated(Date startCreated) {
        this.startCreated = startCreated;
    }

    public Date getEndCreated() {
        return endCreated;
    }

    public void setEndCreated(Date endCreated) {
        this.endCreated = endCreated;
    }
}
