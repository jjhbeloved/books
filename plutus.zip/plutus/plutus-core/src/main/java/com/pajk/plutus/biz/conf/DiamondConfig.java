package com.pajk.plutus.biz.conf;

import com.taobao.diamond.client.DiamondConfigure;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

/**
 * Created by fanhuafeng on 17/2/22.
 * Modify by fanhuafeng on 17/2/22
 */
@Configuration
public class DiamondConfig {

    @Value("${public.diamond.url}")
    private String configServer;

    @PostConstruct
    public void init() {
        DiamondConfigure.configDiamondHttpUrl(configServer);
    }

}
