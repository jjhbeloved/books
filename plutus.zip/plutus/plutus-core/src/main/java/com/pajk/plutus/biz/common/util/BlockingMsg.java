package com.pajk.plutus.biz.common.util;

import com.pajk.plutus.biz.model.roma.PromiseWrapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.bus.Event;

/**
 * 消息阻塞式执行，用于适配metaq的消息分发，使用本接口提供的方法处理消息时，要注意promise.poll()返回null的情况
 * Created by fanhuafeng on 17/2/27.
 * Modify by fanhuafeng on 17/2/27
 */
public interface BlockingMsg {

    Logger logger = LoggerFactory.getLogger(BlockingMsg.class);

    /**
     * 阻塞执行，拿到handler执行结果，抛任何异常都会重试
     *
     * @param e       PromiseWrapped的事件体
     * @param handler 方法体关心执行逻辑即可，无需关心需要重试的异常
     * @param <T>
     * @param <R>
     */
    default <D, T extends PromiseWrapper<D, R>, R> void blockingExec(Event<T> e, java.util.function.Function<D, R> handler) {
        try {
            e.getData().getPromise().accept(handler.apply(e.getData().getData()));
        } catch (Exception t) {
            logger.error("[BlockingMsg handle]exception,will retry,data:" + e.getData(), t);
            e.getData().getPromise().accept(null);
        }
    }
}
