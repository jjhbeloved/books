package com.pajk.plutus.biz.model.query.bill;

import com.pajk.plutus.biz.model.result.dto.process.TransitionDTO;

import java.io.Serializable;
import java.util.List;

/**
 * @author david
 * @since created by on 17/12/13 19:31
 */
public class ButtonDTO implements Serializable {

    private static final long serialVersionUID = 3092220019799065032L;
    /**
     * 操作按钮中文展示，transitionName的值
     */
    private String name;

    /**
     * 操作按钮的key，transitionKey的值
     */
    private String key;

    /**
     * 流程操作接口名称apiName
     */
    private String path;

    List<TransitionDTO> transitions;

    public List<TransitionDTO> getTransitions() {
        return transitions;
    }

    public void setTransitions(List<TransitionDTO> transitions) {
        this.transitions = transitions;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
