package com.pajk.plutus.biz.model.query.bill;

import com.alibaba.fastjson.annotation.JSONField;
import com.google.common.collect.Lists;
import com.pajk.plutus.biz.model.bill.FileInfoDO;

import java.io.Serializable;
import java.util.List;

/**
 * 附件信息
 * @author sunjin
 * @since created by on 17/12/14 10:44
 */
public class ConfirmInfoDTO implements Serializable {

    private static final long serialVersionUID = -3238846522329496789L;
    @JSONField(name = "file_info")
    private List<FileInfoDO> fileInfoDO = Lists.newLinkedList();

    private String remark;


}
