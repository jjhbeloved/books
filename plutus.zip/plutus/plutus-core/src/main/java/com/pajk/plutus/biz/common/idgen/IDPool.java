package com.pajk.plutus.biz.common.idgen;

/**
 * Created by lizhijun on 2016/10/10.
 */
public interface IDPool {

    String getNewId();

}
