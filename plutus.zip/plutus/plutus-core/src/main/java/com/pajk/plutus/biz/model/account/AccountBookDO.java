package com.pajk.plutus.biz.model.account;

import com.pajk.plutus.client.model.enums.account.BookStatus;
import com.pajk.plutus.client.model.enums.account.BookType;
import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * Created by lizhijun on 2017/12/17.
 */
public class AccountBookDO extends BaseDO {

    private static final long serialVersionUID = 3965365301488491926L;

    /**
     * 主键id 创建流程时用作obj_id
     **/
    private long id;

    /**
     * 创建时间
     **/
    private Date gmtCreated;

    /**
     * 更新时间
     **/
    private Date gmtModified;

    /**
     * 版本号
     **/
    private int version;

    /**
     * 卖家id
     **/
    private long sellerId;


    /**
     * 账户id
     **/
    private long accountId;

    /**
     * 账本状态
     */
    private BookStatus status;

    /**
     * 类型
     **/
    private BookType bookType;

    /**
     * 合同金额(单位分)
     **/
    private long contractAmt;

    /**
     * 实收合同金额(单位分)
     **/
    private long actualContractAmt;

    /**
     * 账本余额(单位分)
     **/
    private long balanceAmt;

    /**
     * 冻结金额(单位分)
     **/
    private long freezingAmt;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public BookStatus getStatus() {
        return status;
    }

    public void setStatus(BookStatus status) {
        this.status = status;
    }

    public long getAccountId() {
        return accountId;
    }

    public void setAccountId(long accountId) {
        this.accountId = accountId;
    }

    public BookType getBookType() {
        return bookType;
    }

    public void setBookType(BookType bookType) {
        this.bookType = bookType;
    }

    public long getContractAmt() {
        return contractAmt;
    }

    public void setContractAmt(long contractAmt) {
        this.contractAmt = contractAmt;
    }

    public long getActualContractAmt() {
        return actualContractAmt;
    }

    public void setActualContractAmt(long actualContractAmt) {
        this.actualContractAmt = actualContractAmt;
    }

    public long getBalanceAmt() {
        return balanceAmt;
    }

    public void setBalanceAmt(long balanceAmt) {
        this.balanceAmt = balanceAmt;
    }

    public long getFreezingAmt() {
        return freezingAmt;
    }

    public void setFreezingAmt(long freezingAmt) {
        this.freezingAmt = freezingAmt;
    }
}
