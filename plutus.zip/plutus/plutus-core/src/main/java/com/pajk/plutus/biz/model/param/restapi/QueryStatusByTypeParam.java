package com.pajk.plutus.biz.model.param.restapi;

import com.pajk.thunderbird.domain.result.BaseDO;

import javax.validation.constraints.NotNull;

/**
 * Created by lizhijun on 2017/12/19.
 */
public class QueryStatusByTypeParam extends BaseDO {

    private static final long serialVersionUID = -6678787933103267500L;

    @NotNull
    private Integer voucherType;

    public Integer getVoucherType() {
        return voucherType;
    }

    public void setVoucherType(Integer voucherType) {
        this.voucherType = voucherType;
    }

}
