package com.pajk.plutus.biz.model.result.dto.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by  guguangming on 2017/12/14
 **/
public class PaymentPropDTO extends BaseDO {
    private static final long serialVersionUID = 5928656645142041266L;
    /**
     * 银行流水
     */
    private String evidenceFlow;

    public String getEvidenceFlow() {
        return evidenceFlow;
    }

    public void setEvidenceFlow(String evidenceFlow) {
        this.evidenceFlow = evidenceFlow;
    }
}
