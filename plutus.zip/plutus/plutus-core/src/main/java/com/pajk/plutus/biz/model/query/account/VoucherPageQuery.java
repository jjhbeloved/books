package com.pajk.plutus.biz.model.query.account;

import com.pajk.plutus.biz.model.query.PageQuery;

import java.util.Date;
import java.util.List;

/**
 * Created by  guguangming on 2017/12/17
 **/
public class VoucherPageQuery extends PageQuery {

    private static final long serialVersionUID = -6313163292141502988L;


    /**
     * 单据id
     */
    private String voucherId;
    /**
     * 商户ID
     */
    private Long sellerId;

    /**
     * 单据类型,缴费单(缴钱缴积分)1000, 违规单(扣保证金扣积分)2000 赔偿单(扣保证金扣积分) 3000 清零单(清算保证金和积分)4000
     */
    private Integer voucherType;

    /**
     * 单据子类型
     */
    private Integer voucherSubType;

    /**
     * 流程节点
     */
    private List<String> nodeKeys;

    /**
     * 流程group  对应商家前台查看状态
     */
    private List<String> nodeCatKeys;

    /**
     * 业务类型 如trade ,sku
     */
    private String objType;

    /**
     * 业务实体id
     */
    private String objId;

    /**
     * 创建开始时间 即单据创建时间
     */
    private Date createStart;

    /**
     * 创建结束时间 即单据创建时间
     */
    private Date createEnd;


    /**
     * 提交日期start 即流程开始时间
     */
    private Date commitStart;

    /**
     * 提交日期 即流程开始时间
     */
    private Date commitEnd;

    /**
     * 是否允许查询新建
     */
    private Boolean showCreated;

    public String getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(String voucherId) {
        this.voucherId = voucherId;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Integer getVoucherType() {
        return voucherType;
    }

    public void setVoucherType(Integer voucherType) {
        this.voucherType = voucherType;
    }

    public Integer getVoucherSubType() {
        return voucherSubType;
    }

    public void setVoucherSubType(Integer voucherSubType) {
        this.voucherSubType = voucherSubType;
    }

    public List<String> getNodeKeys() {
        return nodeKeys;
    }

    public void setNodeKeys(List<String> nodeKeys) {
        this.nodeKeys = nodeKeys;
    }

    public List<String> getNodeCatKeys() {
        return nodeCatKeys;
    }

    public void setNodeCatKeys(List<String> nodeCatKeys) {
        this.nodeCatKeys = nodeCatKeys;
    }

    public String getObjType() {
        return objType;
    }

    public void setObjType(String objType) {
        this.objType = objType;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public Date getCreateStart() {
        return createStart;
    }

    public void setCreateStart(Date createStart) {
        this.createStart = createStart;
    }

    public Date getCreateEnd() {
        return createEnd;
    }

    public void setCreateEnd(Date createEnd) {
        this.createEnd = createEnd;
    }

    public Date getCommitStart() {
        return commitStart;
    }

    public void setCommitStart(Date commitStart) {
        this.commitStart = commitStart;
    }

    public Date getCommitEnd() {
        return commitEnd;
    }

    public void setCommitEnd(Date commitEnd) {
        this.commitEnd = commitEnd;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Boolean getShowCreated() {
        return showCreated;
    }

    public void setShowCreated(Boolean showCreated) {
        this.showCreated = showCreated;
    }
}
