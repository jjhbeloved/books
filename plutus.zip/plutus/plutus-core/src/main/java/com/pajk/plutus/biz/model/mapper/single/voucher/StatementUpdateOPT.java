package com.pajk.plutus.biz.model.mapper.single.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by lizhijun on 2017/12/24.
 */
public class StatementUpdateOPT extends BaseDO {
    private static final long serialVersionUID = 6970171241208200813L;

    private long sellerId;
    private long id;
    private int version;

    /***************************************update************************************/
    private Integer status;

    /**
     * 平台应付税费
     */
    private Long platformPayableTax;

    /**
     * 平台实付
     */
    private Long platformPaid;

    /**
     * 平台实付税费
     */
    private Long platformPaidTax;

    /**
     * 平台应收税费
     */
    private Long platformReceivableTax;

    /**
     * 平台实收
     */
    private Long platformReceipts;

    /**
     * 平台实收税费
     */
    private Long platformReceiptsTax;

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public Long getPlatformPayableTax() {
        return platformPayableTax;
    }

    public void setPlatformPayableTax(Long platformPayableTax) {
        this.platformPayableTax = platformPayableTax;
    }

    public Long getPlatformPaid() {
        return platformPaid;
    }

    public void setPlatformPaid(Long platformPaid) {
        this.platformPaid = platformPaid;
    }

    public Long getPlatformPaidTax() {
        return platformPaidTax;
    }

    public void setPlatformPaidTax(Long platformPaidTax) {
        this.platformPaidTax = platformPaidTax;
    }

    public Long getPlatformReceivableTax() {
        return platformReceivableTax;
    }

    public void setPlatformReceivableTax(Long platformReceivableTax) {
        this.platformReceivableTax = platformReceivableTax;
    }

    public Long getPlatformReceipts() {
        return platformReceipts;
    }

    public void setPlatformReceipts(Long platformReceipts) {
        this.platformReceipts = platformReceipts;
    }

    public Long getPlatformReceiptsTax() {
        return platformReceiptsTax;
    }

    public void setPlatformReceiptsTax(Long platformReceiptsTax) {
        this.platformReceiptsTax = platformReceiptsTax;
    }

}
