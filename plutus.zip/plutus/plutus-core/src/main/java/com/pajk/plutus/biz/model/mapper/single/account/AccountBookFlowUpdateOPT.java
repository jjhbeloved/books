package com.pajk.plutus.biz.model.mapper.single.account;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * Created by lizhijun on 2017/12/21.
 */
public class AccountBookFlowUpdateOPT extends BaseDO {

    private static final long serialVersionUID = 395142119527674452L;
    /**************************************************query*****************************************************/

    /**
     * 主键id
     **/
    private long id;

    /**
     * 版本号
     **/
    private int version;

    /**
     * 商户id
     **/
    private long sellerId;

    /**************************************************update*****************************************************/


    /**
     * 账本流水状态
     **/
    private Integer status;

    /**
     * 完成时间
     * @return
     */
    private Date gmtStatement;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getGmtStatement() {
        return gmtStatement;
    }

    public void setGmtStatement(Date gmtStatement) {
        this.gmtStatement = gmtStatement;
    }
}

