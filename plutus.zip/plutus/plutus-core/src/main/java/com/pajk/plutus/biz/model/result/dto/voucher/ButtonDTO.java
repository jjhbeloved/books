package com.pajk.plutus.biz.model.result.dto.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by lizhijun on 2017/12/15.
 */
public class ButtonDTO extends BaseDO {
    private static final long serialVersionUID = 5928656610116741266L;
    /**
     * 调用接口名
     */
    private String path;
    /**
     * 按钮名
     */
    private String name;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
