package com.pajk.plutus.biz.common.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.framework.AdvisedSupport;
import org.springframework.aop.framework.AopProxy;
import org.springframework.aop.support.AopUtils;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by fanhuafeng on 17/2/21.
 * Modify by fanhuafeng on 17/2/21
 */
public class JsonUtil {

    private static final Logger logger = LoggerFactory.getLogger(JsonUtil.class);

    private JsonUtil() {
    }

    public static String obj2Str(Object obj) {
        if (null == obj) {
            return null;
        }
        try {
            if (AopUtils.isAopProxy(obj)) {
                return JSONObject.toJSONString(getProxyTargetObject(obj));

            } else {
                return JSONObject.toJSONString(obj);
            }

        } catch (Exception e) {
            logger.warn("Json2Str Exception: ", e);
            return null;
        }
    }

    public static Map<String, String> parse(String jsonStr) {
        Map<String, String> map = new HashMap<>();
        if (StringUtils.isBlank(jsonStr)) {
            return map;
        }
        try {
            map = (Map) JSON.parse(jsonStr);
        } catch (Exception e) {
            logger.warn("Json2Str Exception: ", e);
        }
        return map;
    }

    public static JSONObject parseJSONObject(String str) {
        if (StringUtils.isEmpty(str)) {
            return null;
        }
        try {
            return JSONObject.parseObject(str);
        } catch (Exception e) {
            logger.warn("JSONObject parse fail. str={}, exception: e", str, e);
            return null;

        }
    }

    public static <T> T parseObject(String str, Class<T> clazz) {
        return parseObject(str, clazz, null);
    }

    public static <T> T parseObject(String str, Class<T> clazz, T defaultValue) {
        if (StringUtils.isEmpty(str)) {
            return defaultValue;
        }
        try {
            return JSONObject.parseObject(str, clazz);
        } catch (Exception e) {
            logger.warn("JsonParseObject fail. class={}, str={}, exception: e", clazz.toString(), str, e);
            return defaultValue;
        }
    }

    private static Object getProxyTargetObject(Object proxy) throws Exception {
        Field h = proxy.getClass().getSuperclass().getDeclaredField("h");
        h.setAccessible(true);
        AopProxy aopProxy = (AopProxy) h.get(proxy);
        Field advised = aopProxy.getClass().getDeclaredField("advised");
        advised.setAccessible(true);
        return ((AdvisedSupport) advised.get(aopProxy)).getTargetSource().getTarget();
    }

}
