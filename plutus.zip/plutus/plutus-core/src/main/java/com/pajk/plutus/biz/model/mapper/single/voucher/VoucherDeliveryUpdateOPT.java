package com.pajk.plutus.biz.model.mapper.single.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by cuidongchao on 2017/12/22.
 */
public class VoucherDeliveryUpdateOPT extends BaseDO {

    private Long id;

    private Integer version;

    private Long sellerId;

    private String voucherId;

    private String extProps;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public String getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(String voucherId) {
        this.voucherId = voucherId;
    }

    public String getExtProps() {
        return extProps;
    }

    public void setExtProps(String extProps) {
        this.extProps = extProps;
    }
}
