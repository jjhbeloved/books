package com.pajk.plutus.biz.model.param.restapi;

import com.pajk.thunderbird.domain.result.BaseDO;

import javax.validation.constraints.NotNull;

/**
 * @author david
 * @since created by on 17/12/21 15:33
 */
public class PageQuerySettlementParam extends BaseDO {

    private static final long serialVersionUID = 2226775134574547716L;

    /**
     * 格式:yyyy-MM
     */
    @NotNull
    private String startTime;

    /**
     * 格式:yyyy-MM
     */
    @NotNull
    private String endTime;

    private Long sellerId;

    /**
     * 账单状态，不传默认查所有状态
     */
    private String nodeKey;

    /**
     * 起始页,默认从1开始
     */
    private int pageNo = 1;

    /**
     * 每页显示条数
     */
    private int pageSize = 20;

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public String getNodeKey() {
        return nodeKey;
    }

    public void setNodeKey(String nodeKey) {
        this.nodeKey = nodeKey;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}
