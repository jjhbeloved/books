package com.pajk.plutus.biz.common.idgen.impl;

import com.pajk.idgen.IDGenService;
import com.pajk.idgen.client.MemIDPool;
import com.pajk.plutus.biz.common.idgen.IDPool;

/**
 * Created by lizhijun on 2016/10/10.
 */
public class IDPoolImpl extends MemIDPool implements IDPool {

    public IDPoolImpl(String configDomain, String configKey, int allocCount, IDGenService generator) {
        super(configDomain, configKey, allocCount, generator);
    }

    @Override
    public String getNewId() {
        String borrowId = borrow();
        consume(borrowId);
        return borrowId;
    }

}
