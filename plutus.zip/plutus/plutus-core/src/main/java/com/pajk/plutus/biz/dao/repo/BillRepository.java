package com.pajk.plutus.biz.dao.repo;

import com.pajk.plutus.biz.model.bill.BillSettlementDO;
import com.pajk.plutus.biz.model.bill.SellerAccountInfoDO;
import com.pajk.plutus.biz.model.bill.SellerInvoiceInfoDO;

/**
 * Created by arjaylv on 2017/12/13.
 *
 * @author arjaylv
 */
public interface BillRepository {

    /**
     * 更新账单
     *
     * @param billSettlementDO 账单信息
     */
    void updateConfirmSettlement(BillSettlementDO billSettlementDO);

    /**
     * 记录票务信息快照
     *
     * @param billSettlementDO    账单信息
     * @param sellerInvoiceInfoDO 发票信息
     */
    void updateConfirmInvoice(BillSettlementDO billSettlementDO, SellerInvoiceInfoDO sellerInvoiceInfoDO);

    /**
     * 更新收票
     *
     * @param billSettlementDO 账单信息
     */
    void updateReceiveInvoice(BillSettlementDO billSettlementDO);

    /**
     * 更新付款
     *
     * @param billSettlementDO    账单信息
     * @param sellerAccountInfoDO 付款账户信息
     */
    void updateConfirmPayment(BillSettlementDO billSettlementDO, SellerAccountInfoDO sellerAccountInfoDO);

    /**
     * 更新收款
     *
     * @param billSettlementDO 账单信息
     */
    void updateConfirmReceivePayment(BillSettlementDO billSettlementDO);

    /**
     * 更新审核确认账单
     *
     * @param billSettlementDO 账单信息
     */
    void updateConfirmOnlyRemark(BillSettlementDO billSettlementDO);

}
