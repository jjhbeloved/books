package com.pajk.plutus.biz.dao.repo;

import com.pajk.plutus.biz.model.bill.SellerInvoiceInfoDO;

import java.util.Optional;

/**
 * @author dutianyi
 * @date 2017/12/18
 */
public interface SellerInvoiceInfoRepository {

    /**
     * 查询商户票据有效信息, 由于一个商户下可能有n条票据, 取查询的第一条
     *
     * @param sellerId 商户ID
     * @return 商户票据信息
     */
    Optional<SellerInvoiceInfoDO> queryBySellerId(long sellerId);

    /**
     * 查询商户票据信息, 由于一个商户下可能有n条票据, 取查询的第一条
     *
     * @param sellerId 商户ID
     * @param status   商户票务信息状态 0 可用 1 不可用
     * @return 商户票据信息
     */
    Optional<SellerInvoiceInfoDO> queryBySellerId(long sellerId, int status);
}
