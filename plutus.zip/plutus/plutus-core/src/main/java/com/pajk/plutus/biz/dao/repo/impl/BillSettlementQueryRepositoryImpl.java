package com.pajk.plutus.biz.dao.repo.impl;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.pajk.plutus.biz.common.util.ValidateSetUtil;
import com.pajk.plutus.biz.dao.mapper.single.bill.AccountInfoSnapshotMapper;
import com.pajk.plutus.biz.dao.mapper.single.bill.BillSettlementItemMapper;
import com.pajk.plutus.biz.dao.mapper.single.bill.BillSettlementMapper;
import com.pajk.plutus.biz.dao.mapper.single.bill.InvoiceInfoSnapshotMapper;
import com.pajk.plutus.biz.dao.repo.BillSettlementQueryRepository;
import com.pajk.plutus.biz.model.bill.*;
import com.pajk.plutus.biz.model.mapper.single.bill.AccountInfoSnapshotDAO;
import com.pajk.plutus.biz.model.mapper.single.bill.BillSettlementDAO;
import com.pajk.plutus.biz.model.mapper.single.bill.BillSettlementItemDAO;
import com.pajk.plutus.biz.model.mapper.single.bill.InvoiceInfoSnapshotDAO;
import com.pajk.plutus.biz.model.query.PageQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author david
 * @since created by on 17/12/14 00:15
 */
@Repository
public class BillSettlementQueryRepositoryImpl implements BillSettlementQueryRepository {

    @Autowired
    private BillSettlementMapper billSettlementMapper;

    @Autowired
    private BillSettlementItemMapper billSettlementItemMapper;

    @Autowired
    private InvoiceInfoSnapshotMapper invoiceInfoSnapshotMapper;

    @Autowired
    private AccountInfoSnapshotMapper accountInfoSnapshotMapper;

    @Override
    public Optional<BillSettlementDO> querySettlementByBillId(long billId) {
        BillSettlementDAO billSettlementDAO = billSettlementMapper.queryByIdAndSellerId(billId, null);
        return Optional.ofNullable(billSettlementDAO)
                .map(this::toQueryModel);
    }

    @Override
    public Optional<BillSettlementDO> querySettlementByBillId(long billId, long sellerId) {
        BillSettlementDAO billSettlementDAO = billSettlementMapper.queryByIdAndSellerId(billId, sellerId);
        return Optional.ofNullable(billSettlementDAO)
                .map(this::toQueryModel);
    }

    @Override
    public Optional<BillSettlementDO> querySettlementDetailByBillId(long billId) {
        BillSettlementDAO billSettlementDAO = billSettlementMapper.queryByIdAndSellerId(billId, null);
        return Optional.ofNullable(billSettlementDAO)
                .map(this::toDetailModel);
    }

    @Override
    public Optional<BillSettlementDO> querySettlementDetailByBillId(long billId, long sellerId) {
        BillSettlementDAO billSettlementDAO = billSettlementMapper.queryByIdAndSellerId(billId, sellerId);
        return Optional.ofNullable(billSettlementDAO)
                .map(this::toDetailModel);
    }

    @Override
    public List<BillSettlementItemDO> querySettlementItemByBillId(long billId) {
        return billSettlementItemMapper.queryByBillId(billId)
                .stream()
                .map(this::toBillSettlementItemModel)
                .collect(Collectors.toList());
    }

    @Override
    public int count(Map<String, Object> params) {
        return billSettlementMapper.count(params);
    }

    @Override
    public List<BillSettlementDO> pageList(int pageNo, int pageSize, Map<String, Object> params) {
        PageQuery pageInfo = new PageQuery();
        pageInfo.setPageNo(pageNo);
        pageInfo.setPageSize(pageSize);
        params.put("offset", pageInfo.getStartRow());
        params.put("limit", pageInfo.getPageSize());
        return toDetailModels(billSettlementMapper.paging(params));
    }


    private BillSettlementDO toBillSettlementModel(BillSettlementDAO billSettlementDAO) {
        BillSettlementDO billSettlementDO = new BillSettlementDO();

        billSettlementDO.setId(billSettlementDAO.getId());
        billSettlementDO.setVersion(billSettlementDAO.getVersion());
        billSettlementDO.setSellerId(billSettlementDAO.getSellerId());
        billSettlementDO.setBillNo(billSettlementDAO.getBillNo());
        billSettlementDO.setMonth(billSettlementDAO.getMonth());
        billSettlementDO.setPayToType(billSettlementDAO.getPayToType());
        billSettlementDO.setSettlementType(billSettlementDAO.getSettlementType());
        billSettlementDO.setBillAmt(billSettlementDAO.getBillAmt());
        billSettlementDO.setActualBillAmt(billSettlementDAO.getActualBillAmt());
        billSettlementDO.setProcInstId(billSettlementDAO.getProcInstId());
        billSettlementDO.setNodeKey(billSettlementDAO.getNodeKey());
        billSettlementDO.setNodeCatKey(billSettlementDAO.getNodeCatKey());
        billSettlementDO.setRole(billSettlementDAO.getRole());
        billSettlementDO.setStartTime(billSettlementDAO.getStartTime());
        billSettlementDO.setFinishTime(billSettlementDAO.getFinishTime());

        String confirmInfo = billSettlementDAO.getConfirmInfo();
        String paymentInfo = billSettlementDAO.getPaymentInfo();
        String invoiceInfo = billSettlementDAO.getInvoiceInfo();
        ValidateSetUtil.validateNonNullSet(confirmInfo, param -> billSettlementDO.setConfirmInfoDO(JSONObject.parseObject(param, ConfirmInfoDO.class)));
        ValidateSetUtil.validateNonNullSet(paymentInfo, param -> billSettlementDO.setPaymentInfoDOS(JSONObject.parseArray(param, PaymentInfoDO.class)));
        ValidateSetUtil.validateNonNullSet(invoiceInfo, param -> billSettlementDO.setInvoiceInfoDO(JSONObject.parseObject(param, InvoiceInfoDO.class)));
        billSettlementDO.setExtProps(billSettlementDAO.getExtProps());
        return billSettlementDO;
    }

    private BillSettlementItemDO toBillSettlementItemModel(BillSettlementItemDAO billSettlementItemDAO) {
        BillSettlementItemDO billSettlementItemDO = new BillSettlementItemDO();

        billSettlementItemDO.setId(billSettlementItemDAO.getId());
        billSettlementItemDO.setVersion(billSettlementItemDAO.getVersion());
        billSettlementItemDO.setBillId(billSettlementItemDAO.getBillId());
        billSettlementItemDO.setSellerId(billSettlementItemDAO.getSellerId());
        billSettlementItemDO.setBillType(billSettlementItemDAO.getBillType());
        billSettlementItemDO.setBillAmt(billSettlementItemDAO.getBillAmt());
        billSettlementItemDO.setActualBillAmt(billSettlementItemDAO.getActualBillAmt());

        return billSettlementItemDO;
    }

    private InvoiceInfoSnapshotDO toInvoiceInfoSnapshotModel(InvoiceInfoSnapshotDAO invoiceInfoSnapshotDAO) {
        InvoiceInfoSnapshotDO invoiceInfoSnapshotDO = new InvoiceInfoSnapshotDO();

        invoiceInfoSnapshotDO.setId(invoiceInfoSnapshotDAO.getId());
        invoiceInfoSnapshotDO.setBillId(invoiceInfoSnapshotDAO.getBillId());
        invoiceInfoSnapshotDO.setInvoiceTitle(invoiceInfoSnapshotDAO.getInvoiceTitle());
        invoiceInfoSnapshotDO.setContact(invoiceInfoSnapshotDAO.getContact());
        invoiceInfoSnapshotDO.setContactTel(invoiceInfoSnapshotDAO.getContactTel());
        invoiceInfoSnapshotDO.setInvoiceAddress(invoiceInfoSnapshotDAO.getInvoiceAddress());
        invoiceInfoSnapshotDO.setTaxpayerNumber(invoiceInfoSnapshotDAO.getTaxpayerNumber());
        invoiceInfoSnapshotDO.setInvoiceTel(invoiceInfoSnapshotDAO.getInvoiceTel());
        invoiceInfoSnapshotDO.setAddress(invoiceInfoSnapshotDAO.getAddress());
        invoiceInfoSnapshotDO.setInvoiceBankName(invoiceInfoSnapshotDAO.getInvoiceBankName());
        invoiceInfoSnapshotDO.setInvoiceBankAccount(invoiceInfoSnapshotDAO.getInvoiceBankAccount());
        invoiceInfoSnapshotDO.setInvoiceType(invoiceInfoSnapshotDAO.getInvoiceType());

        return invoiceInfoSnapshotDO;
    }

    private AccountInfoSnapshotDO toAccountInfoSnapshotModel(AccountInfoSnapshotDAO accountInfoSnapshotDAO) {
        AccountInfoSnapshotDO accountInfoSnapshotDO = new AccountInfoSnapshotDO();

        accountInfoSnapshotDO.setId(accountInfoSnapshotDAO.getId());
        accountInfoSnapshotDO.setBillId(accountInfoSnapshotDAO.getBillId());
        accountInfoSnapshotDO.setPurchaserAccount(accountInfoSnapshotDAO.getPurchaserAccount());
        accountInfoSnapshotDO.setPurchaserAccountName(accountInfoSnapshotDAO.getPurchaserAccountName());
        accountInfoSnapshotDO.setPurchaserBankName(accountInfoSnapshotDAO.getPurchaserBankName());

        return accountInfoSnapshotDO;
    }

    private BillSettlementDO toQueryModel(BillSettlementDAO billSettlementDAO) {
        BillSettlementDO billSettlementDO = toBillSettlementModel(billSettlementDAO);
        List<BillSettlementItemDO> billSettlementItemDOS = querySettlementItemByBillId(billSettlementDAO.getId());
        billSettlementDO.setBillSettlementItemDOS(billSettlementItemDOS);

        return billSettlementDO;
    }

    private BillSettlementDO toDetailModel(BillSettlementDAO billSettlementDAO) {
        BillSettlementDO billSettlementDO = toBillSettlementModel(billSettlementDAO);

        long billId = billSettlementDAO.getId();
        List<BillSettlementItemDO> billSettlementItemDOS = querySettlementItemByBillId(billId);
        billSettlementDO.setBillSettlementItemDOS(billSettlementItemDOS);
        List<InvoiceInfoSnapshotDO> invoiceInfoSnapshotDOS = queryInvoiceInfoSnapshotByBillId(billId);
        ValidateSetUtil.setFirstIfListNotEmpty(invoiceInfoSnapshotDOS, billSettlementDO::setInvoiceInfoSnapshotDO);
        List<AccountInfoSnapshotDO> accountInfoSnapshotDOS = queryAccountInfoSnapshotMapperByBillId(billId);
        ValidateSetUtil.setFirstIfListNotEmpty(accountInfoSnapshotDOS, billSettlementDO::setAccountInfoSnapshotDO);

        return billSettlementDO;
    }

    private List<BillSettlementDO> toDetailModels(List<BillSettlementDAO> billSettlementDAOS) {
        if (CollectionUtils.isEmpty(billSettlementDAOS)) {
            return new LinkedList<>();
        }
        List<BillSettlementDO> billSettlementDOS = Lists.newLinkedList();
        List<Long> billIds = Lists.newLinkedList();
        Map<Long, BillSettlementDO> billSettlementDOMap = Maps.newHashMap();
        billSettlementDAOS.forEach(billSettlementDAO -> {
            BillSettlementDO billSettlementDO = toBillSettlementModel(billSettlementDAO);
            long billId = billSettlementDO.getId();
            billIds.add(billId);
            billSettlementDOS.add(billSettlementDO);
            billSettlementDOMap.put(billSettlementDO.getId(), billSettlementDO);
        });
        Map<Long, List<InvoiceInfoSnapshotDO>> setInvoiceInfoSnapshotDO = queryInvoiceInfoSnapshotByBillIds(billIds);
        Map<Long, List<AccountInfoSnapshotDO>> setAccountInfoSnapshotDO = queryAccountInfoSnapshotMapperByBillIds(billIds);

        billSettlementDOMap.forEach((billId, billSettlementDO) -> {
            List<InvoiceInfoSnapshotDO> invoiceInfoSnapshotDOS = setInvoiceInfoSnapshotDO.get(billId);
            ValidateSetUtil.setFirstIfListNotEmpty(invoiceInfoSnapshotDOS, billSettlementDO::setInvoiceInfoSnapshotDO);
            List<AccountInfoSnapshotDO> accountInfoSnapshotDOS = setAccountInfoSnapshotDO.get(billId);
            ValidateSetUtil.setFirstIfListNotEmpty(accountInfoSnapshotDOS, billSettlementDO::setAccountInfoSnapshotDO);
        });
        return billSettlementDOS;
    }

    private List<InvoiceInfoSnapshotDO> queryInvoiceInfoSnapshotByBillId(long billId) {
        return invoiceInfoSnapshotMapper.queryByBillId(billId)
                .stream()
                .map(this::toInvoiceInfoSnapshotModel)
                .collect(Collectors.toList());
    }

    private List<AccountInfoSnapshotDO> queryAccountInfoSnapshotMapperByBillId(long billId) {
        return accountInfoSnapshotMapper.queryByBillId(billId)
                .stream()
                .map(this::toAccountInfoSnapshotModel)
                .collect(Collectors.toList());
    }

    private Map<Long, List<InvoiceInfoSnapshotDO>> queryInvoiceInfoSnapshotByBillIds(List<Long> billIds) {
        List<InvoiceInfoSnapshotDAO> x = invoiceInfoSnapshotMapper.queryByBillIds(billIds);
        return x
                .stream()
                .map(this::toInvoiceInfoSnapshotModel)
                .collect(Collectors.groupingBy(InvoiceInfoSnapshotDO::getBillId));
    }

    private Map<Long, List<AccountInfoSnapshotDO>> queryAccountInfoSnapshotMapperByBillIds(List<Long> billIds) {
        return accountInfoSnapshotMapper.queryByBillIds(billIds)
                .stream()
                .map(this::toAccountInfoSnapshotModel)
                .collect(Collectors.groupingBy(AccountInfoSnapshotDO::getBillId));
    }
}
