package com.pajk.plutus.biz.model.result.dto.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.List;

/**
 * Created by guguangming on 2017/12/13
 */
public class VoucherSummaryDTO extends BaseDO {

    private static final long serialVersionUID = 5928656610242046766L;

    private String voucherId;

    private long sellerId;

    private String sellerName;

    private String sellerType;

    private String sellerStatus;

    private String voucherType;

    private String voucherSubType;

    private long amount;

    private String nodeKeyName ;

    private String procStartTime;

    private String gmtCreated;

    private String keyStr;

    private List<ButtonDTO> buttons;

    public String getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(String voucherId) {
        this.voucherId = voucherId;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public String getSellerType() {
        return sellerType;
    }

    public void setSellerType(String sellerType) {
        this.sellerType = sellerType;
    }

    public String getSellerStatus() {
        return sellerStatus;
    }

    public void setSellerStatus(String sellerStatus) {
        this.sellerStatus = sellerStatus;
    }

    public String getVoucherType() {
        return voucherType;
    }

    public void setVoucherType(String voucherType) {
        this.voucherType = voucherType;
    }

    public String getVoucherSubType() {
        return voucherSubType;
    }

    public void setVoucherSubType(String voucherSubType) {
        this.voucherSubType = voucherSubType;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public String getNodeKeyName() {
        return nodeKeyName;
    }

    public void setNodeKeyName(String nodeKeyName) {
        this.nodeKeyName = nodeKeyName;
    }

    public String getProcStartTime() {
        return procStartTime;
    }

    public void setProcStartTime(String procStartTime) {
        this.procStartTime = procStartTime;
    }

    public String getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(String gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public String getKeyStr() {
        return keyStr;
    }

    public void setKeyStr(String keyStr) {
        this.keyStr = keyStr;
    }

    public List<ButtonDTO> getButtons() {
        return buttons;
    }

    public void setButtons(List<ButtonDTO> buttons) {
        this.buttons = buttons;
    }
}
