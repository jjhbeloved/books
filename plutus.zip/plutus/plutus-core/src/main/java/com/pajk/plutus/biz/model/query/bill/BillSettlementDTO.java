package com.pajk.plutus.biz.model.query.bill;

import com.google.common.collect.Lists;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author sunjin
 * @since created by on 17/12/14 00:24
 */
public class BillSettlementDTO implements Serializable {

    private static final long serialVersionUID = -8451845935507064929L;

    private String month; //统计月份(默认每个月的1号)

    private Long sellerId; //商家ID

    private String sellerName; //商家名称

    private String settlementType; //结算类型, PA_RECEIPT:平安应收, PA_PAY:平安应付

    private String payToType; //收款方式、合作模式, PAY_TO_SELLER:平台模式, PAY_TO_PLATEFORM:自营模式

    private Long billAmt; //对账总金额(分)

    private Long actualBillAmt; //实际确认对账总金额(分)

    private String confirmFileUrl; //商户账单确认附件url，根据confirmFileId去tfs获取文件url，商户确认账单后被驳回时有值

    private String confirmFileName; //商户账单确认附件名称，商户确认账单后被驳回时有值

    private String confirmRemark; //商户账单确认备注，商户确认账单后被驳回时有值

    private String nodeKeyName; //账单节点状态（中文描述）

    private Long billId; //账单id

    private Long invoiceAmt; //发票本金(分)

    private Long invoiceTaxAmt; //发票税额(分)

    private String invoiceTrackingNumber; //寄送发票物流单号

    private String invoiceId; //发票id号

    private String paymentNo; //支付流水号

    private String paymentFileUrl; //支付附件url，根据paymentFileId去tfs获取文件url

    private String paymentFileName; //支付附件名称

    private AccountDTO account;// 商户对应发票信息，没确认开票的发票信息取自此表

    private InvoiceDTO invoice; // 商户对应的账户信息，没确认付款的账户信息取自此表

    private InvoiceSnapshotDTO invoiceSnapshot; //发票信息快照表，发票确认之后的账单发票信息

    private AccountSnapshotDTO accountSnapshot;  // 账户信息快照表，付款确认之后的账户信息

    private List<ButtonDTO> actionButtons = Lists.newLinkedList();  //操作按钮

    private List<BillSettlementItemDTO> settlementItems = Lists.newLinkedList();//单据明细

    private List<SettlementOperationDTO> settlementOperations;//操作记录

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public String getSettlementType() {
        return settlementType;
    }

    public void setSettlementType(String settlementType) {
        this.settlementType = settlementType;
    }

    public String getPayToType() {
        return payToType;
    }

    public void setPayToType(String payToType) {
        this.payToType = payToType;
    }

    public Long getBillAmt() {
        return billAmt;
    }

    public void setBillAmt(Long billAmt) {
        this.billAmt = billAmt;
    }

    public Long getActualBillAmt() {
        return actualBillAmt;
    }

    public void setActualBillAmt(Long actualBillAmt) {
        this.actualBillAmt = actualBillAmt;
    }

    public String getConfirmFileUrl() {
        return confirmFileUrl;
    }

    public void setConfirmFileUrl(String confirmFileUrl) {
        this.confirmFileUrl = confirmFileUrl;
    }

    public String getConfirmFileName() {
        return confirmFileName;
    }

    public void setConfirmFileName(String confirmFileName) {
        this.confirmFileName = confirmFileName;
    }

    public String getConfirmRemark() {
        return confirmRemark;
    }

    public void setConfirmRemark(String confirmRemark) {
        this.confirmRemark = confirmRemark;
    }

    public String getNodeKeyName() {
        return nodeKeyName;
    }

    public void setNodeKeyName(String nodeKeyName) {
        this.nodeKeyName = nodeKeyName;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public Long getInvoiceAmt() {
        return invoiceAmt;
    }

    public void setInvoiceAmt(Long invoiceAmt) {
        this.invoiceAmt = invoiceAmt;
    }

    public Long getInvoiceTaxAmt() {
        return invoiceTaxAmt;
    }

    public void setInvoiceTaxAmt(Long invoiceTaxAmt) {
        this.invoiceTaxAmt = invoiceTaxAmt;
    }

    public String getInvoiceTrackingNumber() {
        return invoiceTrackingNumber;
    }

    public void setInvoiceTrackingNumber(String invoiceTrackingNumber) {
        this.invoiceTrackingNumber = invoiceTrackingNumber;
    }

    public String getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(String invoiceId) {
        this.invoiceId = invoiceId;
    }

    public String getPaymentNo() {
        return paymentNo;
    }

    public void setPaymentNo(String paymentNo) {
        this.paymentNo = paymentNo;
    }

    public String getPaymentFileUrl() {
        return paymentFileUrl;
    }

    public void setPaymentFileUrl(String paymentFileUrl) {
        this.paymentFileUrl = paymentFileUrl;
    }

    public String getPaymentFileName() {
        return paymentFileName;
    }

    public void setPaymentFileName(String paymentFileName) {
        this.paymentFileName = paymentFileName;
    }

    public AccountDTO getAccount() {
        return account;
    }

    public void setAccount(AccountDTO account) {
        this.account = account;
    }

    public InvoiceDTO getInvoice() {
        return invoice;
    }

    public void setInvoice(InvoiceDTO invoice) {
        this.invoice = invoice;
    }

    public InvoiceSnapshotDTO getInvoiceSnapshot() {
        return invoiceSnapshot;
    }

    public void setInvoiceSnapshot(InvoiceSnapshotDTO invoiceSnapshot) {
        this.invoiceSnapshot = invoiceSnapshot;
    }

    public AccountSnapshotDTO getAccountSnapshot() {
        return accountSnapshot;
    }

    public void setAccountSnapshot(AccountSnapshotDTO accountSnapshot) {
        this.accountSnapshot = accountSnapshot;
    }

    public List<ButtonDTO> getActionButtons() {
        return actionButtons;
    }

    public void setActionButtons(List<ButtonDTO> actionButtons) {
        this.actionButtons = actionButtons;
    }

    public List<BillSettlementItemDTO> getSettlementItems() {
        return settlementItems;
    }

    public void setSettlementItems(List<BillSettlementItemDTO> settlementItems) {
        this.settlementItems = settlementItems;
    }

    public List<SettlementOperationDTO> getSettlementOperations() {
        return settlementOperations;
    }

    public void setSettlementOperations(List<SettlementOperationDTO> settlementOperations) {
        this.settlementOperations = settlementOperations;
    }
}
