package com.pajk.plutus.biz.service.web;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.plutus.biz.common.util.CommonUtil;
import com.pajk.plutus.biz.common.util.JsonUtil;
import com.pajk.plutus.biz.common.util.ResultUtil;
import com.pajk.plutus.biz.common.util.TimeUtils;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.permission.AuthResourceProperties;
import com.pajk.plutus.biz.manager.permission.UserUtil;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.account.AccountBookFlowDO;
import com.pajk.plutus.biz.model.enums.FlowTypeEnum;
import com.pajk.plutus.biz.model.param.restapi.*;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.biz.model.process.FlowStatusDO;
import com.pajk.plutus.biz.model.query.account.BookFlowPageQuery;
import com.pajk.plutus.biz.model.query.account.BookPageQuery;
import com.pajk.plutus.biz.model.query.account.VoucherPageQuery;
import com.pajk.plutus.biz.model.result.dto.account.AccountBookDTO;
import com.pajk.plutus.biz.model.result.dto.account.AccountBookFlowDTO;
import com.pajk.plutus.biz.model.result.dto.account.AuditFlowDTO;
import com.pajk.plutus.biz.model.result.dto.process.NodeKeyDTO;
import com.pajk.plutus.biz.model.result.dto.process.TransitionDTO;
import com.pajk.plutus.biz.model.result.dto.voucher.*;
import com.pajk.plutus.biz.model.voucher.PaymentPropDO;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.model.voucher.VoucherDeliveryDO;
import com.pajk.plutus.client.model.enums.account.BookStatus;
import com.pajk.plutus.client.model.enums.account.BookType;
import com.pajk.plutus.client.model.enums.seller.SellerServiceType;
import com.pajk.plutus.client.model.enums.seller.SellerStatus;
import com.pajk.plutus.client.model.enums.trade.PayMode;
import com.pajk.plutus.client.model.enums.voucher.*;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.taskcenter.client.model.dto.NodeDTO;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by  guguangming on 2017/12/13
 **/
@RestController("depositQueryController")
@RequestMapping("/plutus/depositQuery")
public class DepositQueryController extends AbstractWebController  {

    private static final Logger logger = LoggerFactory.getLogger(DepositQueryController.class);


    @Autowired
    private AccountManager accountManager;

    @Autowired
    private VoucherManager voucherManager;

    @Autowired
    private ControlCache controlCache;

    private static final int MAX_SIZE = 10000;
    private static final int MAX_PAGE_SIZE = 300;

    private static final String ACCOUNT = "opt.account";
    private static final String VOUCHER = "opt.voucher";
    private static final String QUERY = "query";
    private static final String FILE_NAME = "fileName";
    private static final String FILE_KEY = "fileKey";

    /**
     * 保证金列表查询
     *
     * @return 账本列表 PageResultDTO<AccountBookDTO>
     */
    @RequestMapping(value = "/pageQueryAccountBook", method = RequestMethod.POST)
    public PageResultDTO<AccountBookDTO> pageQueryAccountBook(@Valid @RequestBody PageQueryAccountBookParam bookParam) {
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        logger.info("DepositQueryController.pageQueryAccountBook, bookParam:{}, userParam:{}",
                bookParam, userParam);
        BookPageQuery pageQuery = new BookPageQuery();
        pageQuery.setPageNo(bookParam.getPageNo());
        pageQuery.setPageSize(bookParam.getPageSize());
        pageQuery.setBookType(BookType.DEPOSIT.getCode());
        pageQuery.setSellerId(bookParam.getSellerId());


        ErrorCode errorCode = CommonUtil.checkPage(bookParam.getPageNo(), bookParam.getPageSize(), MAX_PAGE_SIZE, MAX_SIZE);
        if (!ErrorCode.SUCCESS.eq(errorCode)) {
            return ResultUtil.returnPageResultDTO(errorCode);
        }


        if (null != bookParam.getBalanceAmtStart()) {
            if (bookParam.getBalanceAmtStart() >= 0) {
                pageQuery.setBalanceAmtStart(bookParam.getBalanceAmtStart());
            } else {
                return ResultUtil.returnPageResultDTO(ErrorCode.PARAM_ERROR);
            }
        }

        if (null != bookParam.getBalanceAmtEnd()) {
            if (bookParam.getBalanceAmtEnd() >= 0) {
                pageQuery.setBalanceAmtEnd(bookParam.getBalanceAmtEnd());
            } else {
                return ResultUtil.returnPageResultDTO(ErrorCode.PARAM_ERROR);
            }
        }


        if (bookParam.getStatus() >= 0) {
            if (BookStatus.UNKNOWN.isEquals(BookStatus.valueOf(bookParam.getStatus()))) {
                return ResultUtil.returnPageResultDTO(ErrorCode.PARAM_ERROR);
            }
            pageQuery.setStatus(bookParam.getStatus());
        }
        PageResultDTO<AccountBookDTO> result = new PageResultDTO<>();
        result.setPageNo(bookParam.getPageNo());
        result.setPageSize(bookParam.getPageSize());

        return pageWrapper(() -> {
            PageResultDTO<AccountBookDO> pageQueryResult = accountManager.pageQueryBook(pageQuery);

            result.getModel().addAll(pageQueryResult.getModel().stream().map(this::toInfoBook).collect(Collectors.toList()));

            result.setTotalCount(pageQueryResult.getTotalCount());
            return result;

        }, ACCOUNT, QUERY);
    }

    /**
     * 保证金列表查询
     *
     * @return 账本列表 PageResultDTO<AccountBookDTO>
     */
    @RequestMapping(value = "/queryAccountBook", method = RequestMethod.POST)
    public ResultDTO<AccountBookDTO> queryAccountBook(@Valid @RequestBody BookAndSellerParam param) {
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        logger.info("DepositQueryController.queryAccountBook, param:{}, userParam:{}",
                param, userParam);
        return wrapper(() -> {
            ResultDTO<AccountBookDO> resultBookDO = accountManager.queryBookBySeller(param.getSellerId(), BookType.DEPOSIT);
            if (!ErrorCode.SUCCESS.eq(resultBookDO.getResultCode())) {
                return ResultUtil.returnResultDTO(ErrorCode.BOOK_NOT_EXISTS);
            }
            return new ResultDTO<>(toInfoBook(resultBookDO.getModel()));
        }, ACCOUNT, QUERY);
    }


    /**
     * 保证金收支明细接口
     *
     * @param param 请求类
     * @return 账本收支明细列表 PageResultDTO<AccountBookFlowDTO>
     */
    @RequestMapping(value = "/pageQueryAccountBookFlow", method = RequestMethod.POST)
    public PageResultDTO<AccountBookFlowDTO> pageQueryAccountBookFlow(
            @Valid @RequestBody PageQueryAccountBookFlowParam param) {
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        logger.info("DepositQueryController.pageQueryAccountBookFlow, param:{}, userParam:{}",
                param, userParam);
        PageResultDTO<AccountBookFlowDTO> result = new PageResultDTO<>();
        result.setPageNo(param.getPageNo());
        result.setPageSize(param.getPageSize());

        Date start = TimeUtils.parse(param.getGmtStatementStart());
        Date end = TimeUtils.parse(param.getGmtStatementEnd());

        if(null != start && null != end){
            if(end.getTime() < start.getTime()){
                return ResultUtil.returnPageResultDTO(ErrorCode.PARAM_ERROR);
            }
        }
        ErrorCode errorCode = CommonUtil.checkPage(param.getPageNo(), param.getPageSize(), MAX_PAGE_SIZE, MAX_SIZE);
        if (!ErrorCode.SUCCESS.eq(errorCode)) {
            return ResultUtil.returnPageResultDTO(errorCode);
        }

        BookFlowPageQuery pageQuery = new BookFlowPageQuery();
        pageQuery.setPageNo(param.getPageNo());
        pageQuery.setPageSize(param.getPageSize());
        pageQuery.setBookId(param.getAccountBookId());
        pageQuery.setSellerId(param.getSellerId());
        pageQuery.setStatementStart(start);
        pageQuery.setStatementEnd(end);
        if (param.getFlowType() > 0) {
            List<Integer> flowTypes = new LinkedList<>();
            flowTypes.add(param.getFlowType());
            pageQuery.setFlowTypes(flowTypes);
        }

        return pageWrapper(() -> {
            PageResultDTO<AccountBookFlowDO> result1 = accountManager.pageQueryBookFlow(pageQuery);

            result.setTotalCount(result1.getTotalCount());
            result.setModel(toInfoBookFlows(result1.getModel()));
            return result;

        }, ACCOUNT, QUERY);
    }


    /**
     * 查询待补缴纳的
     *
     * @return 返回待缴纳的金额
     */
    @RequestMapping(value = "/queryMustAddAmt", method = RequestMethod.POST)
    public ResultDTO<Long> queryMustAddAmt(@Valid @RequestBody BookAndSellerParam param) {
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        logger.info("DepositQueryController.queryMustAddAmt, param:{}, userParam:{}",
                param, userParam);
        return wrapper(() -> accountManager.queryMustAddAmt(param.getSellerId(), param.getAccountBookId())
                , VOUCHER, QUERY);
    }

    /**
     * 根据单据大类查询的单据子类型
     *
     * @return PageResultDTO<VoucherSubTypeDTO>
     */
    @RequestMapping(value = "/queryVoucherSubType", method = RequestMethod.POST)
    public BatchResultDTO<VoucherSubTypeDTO> queryVoucherSubType(@RequestBody QueryVoucherSubTypeParam param) {
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        logger.info("DepositQueryController.queryVoucherSubType, param:{}, userParam:{}",
                param, userParam);
        if (VoucherType.UNKNOWN.isEquals(VoucherType.valueOf(param.getVoucherType()))) {
            return ResultUtil.returnBatchResultDTO(ErrorCode.PARAM_ERROR);
        }
        return batchWrapper(() -> {
            List<VoucherSubType> subTypes = VoucherSubType.getListByType(param.getVoucherType(), param.getIsCanHandleCreate());
            BatchResultDTO<VoucherSubTypeDTO> result = new BatchResultDTO<>();
            result.getModel().addAll(subTypes.stream().map(this::toInfoSubType).collect(Collectors.toList()));
            return result;
        }, VOUCHER, QUERY);

    }

    /**
     * 批量查询单据
     *
     * @return PageResultDTO<VoucherSummaryDTO>
     */
    @RequestMapping(value = "/pageQueryVoucher", method = RequestMethod.POST)
    public PageResultDTO<VoucherSummaryDTO> pageQueryVoucher(@Valid @RequestBody PageQueryVoucherParam param) {
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        logger.info("DepositQueryController.pageQueryVoucher, param:{}, userParam:{}", param, userParam);

        if(StringUtils.isNotBlank(param.getVoucherId()) && !CommonUtil.isValidVoucherId(param.getVoucherId())){
            return ResultUtil.returnPageResultDTO(ErrorCode.PARAM_ERROR);
        }

        ErrorCode errorCode = CommonUtil.checkPage(param.getPageNo(), param.getPageSize(), MAX_PAGE_SIZE, MAX_SIZE);
        if (!ErrorCode.SUCCESS.eq(errorCode)) {
            return ResultUtil.returnPageResultDTO(errorCode);
        }

        VoucherType voucherTypeEnum = VoucherType.valueOf(param.getVoucherType());
        if (VoucherType.UNKNOWN.isEquals(param.getVoucherType())) {
            return ResultUtil.returnPageResultDTO(ErrorCode.PARAM_ERROR);
        }

        if (-1 != param.getVoucherSubType()) {
            VoucherSubType subTypeEnum = VoucherSubType.valueOf(param.getVoucherSubType());
            if (VoucherSubType.UNKNOWN.isEquals(subTypeEnum)) {
                return ResultUtil.returnPageResultDTO(ErrorCode.PARAM_ERROR);
            }
        }

        PageResultDTO<VoucherSummaryDTO> result = new PageResultDTO<>();
        result.setPageNo(param.getPageNo());
        result.setPageSize(param.getPageSize());
        Date createStartDate = TimeUtils.parse(param.getCreateStart(), TimeUtils.SIMPLE_DATA_FORMAT);
        Date createEndDate = TimeUtils.parse(param.getCreateEnd(), TimeUtils.SIMPLE_DATA_FORMAT);
        if (null != createEndDate) {
            createEndDate = TimeUtils.getEndOfDate(createEndDate);
        }
        if (null != createEndDate && null != createStartDate) {
            if (createEndDate.getTime() < createStartDate.getTime()) {
                return ResultUtil.returnPageResultDTO(ErrorCode.PARAM_ERROR);
            }
        }

        Date commitStartDate = TimeUtils.parse(param.getCommitStart(), TimeUtils.SIMPLE_DATA_FORMAT);
        Date commitEndDate = TimeUtils.parse(param.getCommitEnd(), TimeUtils.SIMPLE_DATA_FORMAT);
        if (null != commitEndDate) {
            commitEndDate = TimeUtils.getEndOfDate(commitEndDate);
        }

        if (null != commitStartDate && null != commitEndDate) {
            if (commitEndDate.getTime() < commitStartDate.getTime()) {
                return ResultUtil.returnPageResultDTO(ErrorCode.PARAM_ERROR);
            }
        }

        if (null == createEndDate && null == createStartDate && null == commitStartDate && null == commitEndDate) {
            Date endDate = new Date();
            createEndDate = endDate;
            int span = controlCache.getVoucherPageQueryDaySpan();
            createStartDate = TimeUtils.addDate(endDate, -span);
        }

        VoucherPageQuery voucherPageQuery = buildPageQueryParam(param.getSellerId(), param.getVoucherId(), param.getNodeKey(),
                voucherTypeEnum, param.getVoucherSubType(), param.getKeyStr(), createStartDate, createEndDate, commitStartDate,
                commitEndDate, param.getPageNo(), param.getPageSize());

        return pageWrapper(() -> {
            PageResultDTO<VoucherDO> pageQueryResult = voucherManager.pageQueryVoucher(voucherPageQuery, userParam);
            String roleName = queryRole(userParam.getAppId(), userParam.getUserId());

            result.setTotalCount(pageQueryResult.getTotalCount());
            result.setModel(pageQueryResult.getModel().stream()
                    .map(item -> toInfoVoucherSummary(item, roleName))
                    .collect(Collectors.toList()));
            return result;
        }, VOUCHER, QUERY);

    }

    /**
     * 查询单据详情
     *
     * @return ResultDTO<VoucherDTO>
     */
    @RequestMapping(value = "/queryVoucher", method = RequestMethod.POST)
    public ResultDTO<VoucherDTO> queryVoucher(@Valid @RequestBody QueryVoucherParam param) {
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        logger.info("DepositQueryController.queryVoucher, param:{}, userParam:{}", param, userParam);
        if(!CommonUtil.isValidVoucherId(param.getVoucherId())){
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }
        return wrapper(() -> {
            ResultDTO<VoucherDO> resultDTO =
                    voucherManager.queryVoucherDetail(param.getSellerId(), param.getVoucherId(), userParam);
            if (!resultDTO.isSuccess()) {
                return ResultUtil.returnResultDTO(resultDTO);
            }

            return buildVoucherDTO(userParam, resultDTO.getModel());
        }, VOUCHER, QUERY);
    }

    /**
     * 查询单据详情(操作相关)
     *
     * @return ResultDTO<VoucherDTO>
     */
    @RequestMapping(value = "/queryVoucherOpt", method = RequestMethod.POST)
    public ResultDTO<VoucherDTO> queryVoucherOpt(@Valid @RequestBody QueryVoucherParam param) {
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        logger.info("DepositQueryController.queryVoucherOpt, param:{}, userParam:{}", param, userParam);
        if(!CommonUtil.isValidVoucherId(param.getVoucherId())){
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }
        return wrapper(() -> {
            ResultDTO<VoucherDO> resultDTO =
                    voucherManager.queryVoucherDetail(param.getSellerId(), param.getVoucherId(), userParam);
            if (!resultDTO.isSuccess()) {
                return ResultUtil.returnResultDTO(resultDTO);
            }

            VoucherDO voucherDO = resultDTO.getModel();
            ResultDTO<VoucherDTO> resultDTO1 = buildVoucherDTO(userParam, voucherDO);
            if (!resultDTO1.isSuccess()) {
                return resultDTO1;
            }

            mergePathAndTransition(userParam.getAppId(), userParam.getUserId(), resultDTO1.getModel(), voucherDO);

            return resultDTO1;
        }, VOUCHER, QUERY);
    }

    /**
     * 根据单据类型查询状态下拉列表
     *
     * @return BatchResultDTO<NodeKeyDTO>
     */
    @RequestMapping(value = "/queryStatusByType", method = RequestMethod.POST)
    public BatchResultDTO<NodeKeyDTO> queryStatusByType(@Valid @RequestBody QueryStatusByTypeParam param) {
        FlowTypeEnum flowTypeEnum =
                FlowTypeEnum.valueOfCode(VoucherType.valueOf(param.getVoucherType()).name().toLowerCase());
        if (FlowTypeEnum.UNKNOWN.isEquals(flowTypeEnum)) {
            return ResultUtil.returnBatchResultDTO(ErrorCode.PARAM_ERROR);
        }

        return batchWrapper(() -> {
            BatchResultDTO<FlowStatusDO> batchResultDTO = batchQueryFlowStatus(flowTypeEnum);
            if (!batchResultDTO.isSuccess()) {
                return ResultUtil.returnBatchResultDTO(ErrorCode.EXCEPTION);
            }

            List<NodeKeyDTO> nodeKeys = batchResultDTO.getModel().stream()
                    .map(this::toInfoNodeKeyDTO).collect(Collectors.toList());

            BatchResultDTO<NodeKeyDTO> batchResultDTO1 = new BatchResultDTO<>();
            batchResultDTO1.setModel(nodeKeys);
            return batchResultDTO1;
        }, VOUCHER, QUERY);
    }

    private ResultDTO<VoucherDTO> buildVoucherDTO(UserParam userParam, VoucherDO voucherDO) {
        VoucherType voucherType = voucherDO.getVoucherType();
        VoucherSubType voucherSubType = voucherDO.getVoucherSubType();
        String nodeKey = voucherDO.getNodeKey();

        VoucherDTO voucherDTO = new VoucherDTO();
        voucherDTO.setVoucherId(voucherDO.getVoucherId());
        voucherDTO.setVoucherType(voucherType.getDesc());
        voucherDTO.setVoucherSubType(voucherSubType.getDesc());
        voucherDTO.setAmount(voucherDO.getExpectAmt()); //应缴(扣)金额(单位分)
        voucherDTO.setNodeKey(nodeKey);
        voucherDTO.setCreateRemark(voucherDO.getCreateRemark());
        voucherDTO.setEvidenceRemark(voucherDO.getEvidenceRemark());

        String procName = voucherDO.getVoucherSubType().getProc().getCode();
        AppResourceDO appResourceDO = getAppResource(procName, nodeKey);
        if (null != appResourceDO) {
            voucherDTO.setNodeKeyName(appResourceDO.key3);
        }

        long sellerId = voucherDO.getSellerId();
        voucherDTO.setSellerId(sellerId);
        ResultDTO<SellerDO> resultDTO1 = querySeller(sellerId);
        if (resultDTO1.isSuccess()) {
            voucherDTO.setSellerName(resultDTO1.getModel().getName());
        }

        long domainId = userParam.getDomainId();
        long userId = userParam.getUserId();
        voucherDTO.setCreateFiles(this.buildFileInfo(domainId, userId, voucherDO.getCreateFile()));
        voucherDTO.setEvidenceFiles(this.buildFileInfo(domainId, userId, voucherDO.getEvidenceFile()));

        if (VoucherType.PAYMENT.isEquals(voucherType)) {
            voucherDTO.setPaymentProp(toInfoPaymentPropDTO(voucherDO.getPaymentPropDO()));
        } else if (VoucherType.VIOLATION.isEquals(voucherType) &&
                VoucherSubType.DELAY_DELIVERY_VIOLATION.isEquals(voucherSubType)) {
            voucherDTO.setVoucherDelivery(toInfoVoucherDeliveryDTO(voucherDO.getVoucherDeliveryDO()));
        }

        long procInstId = NumberUtils.toLong(voucherDO.getProcInstId());
        BatchResultDTO<AuditFlowDTO> batchResultDTO = batchQueryAuditFlow(procInstId, procName);
        if (batchResultDTO.isSuccess()) {
            voucherDTO.setAuditFlows(batchResultDTO.getModel());
        }

        ResultDTO<VoucherDTO> resultDTO = new ResultDTO<>();
        resultDTO.setModel(voucherDTO);
        return resultDTO;
    }

    private AccountBookDTO toInfoBook(AccountBookDO bookDO) {
        AccountBookDTO bookDTO = new AccountBookDTO();
        bookDTO.setSellerId(bookDO.getSellerId());
        bookDTO.setContractAmt(bookDO.getContractAmt());
        bookDTO.setBalanceAmt(bookDO.getBalanceAmt());
        bookDTO.setAccountBookId(bookDO.getId());
        bookDTO.setAccountBookStatus(bookDO.getStatus().getDesc());
        bookDTO.setBookStatusCode(bookDO.getStatus().getCode());

        ResultDTO<SellerDO> resultSeller = querySeller(bookDO.getSellerId());
        if (resultSeller.isSuccess()) {
            SellerDO seller = resultSeller.getModel();
            bookDTO.setSellerName(seller.getName());
            bookDTO.setSellerStatus(SellerStatus.valueOf(seller.getStatus()).getDesc());
            bookDTO.setSellerType(SellerServiceType.valueOf(seller.getServiceType()).getDesc());
        }

        return bookDTO;
    }

    private VoucherSubTypeDTO toInfoSubType(VoucherSubType voucherSubType) {
        VoucherSubTypeDTO subTypeDTO = new VoucherSubTypeDTO();
        subTypeDTO.setName(voucherSubType.getDesc());
        subTypeDTO.setType(voucherSubType.getCode());
        return subTypeDTO;
    }

    private VoucherPageQuery buildPageQueryParam(Long sellerId, String voucherId, String status, VoucherType voucherTypeEnum,
                                                 Integer voucherSubType, String keyStr, Date createStartDate, Date createEndDate,
                                                 Date commitStartDate, Date commitEndDate, int pageNo, int pageSize) {
        VoucherPageQuery pageQuery = new VoucherPageQuery();

        pageQuery.setVoucherType(voucherTypeEnum.getCode());
        if (!StringUtils.isEmpty(voucherId)) {
            pageQuery.setVoucherId(voucherId);
            return pageQuery;
        }

        pageQuery.setPageNo(pageNo);
        pageQuery.setPageSize(pageSize);
        pageQuery.setSellerId(sellerId);

        if (!StringUtils.equals("all", status)) {
            pageQuery.setNodeKeys(Arrays.asList(status.split("\\|")));
        }

        if (-1 != voucherSubType) {
            pageQuery.setVoucherSubType(voucherSubType);
        }

        // 如果是违规单
        if (StringUtils.isNotBlank(keyStr) && VoucherType.VIOLATION.isEquals(voucherTypeEnum)) {
            pageQuery.setObjId(keyStr);
        }

        pageQuery.setCommitStart(commitStartDate);
        pageQuery.setCommitEnd(commitEndDate);
        pageQuery.setCreateStart(createStartDate);
        pageQuery.setCreateEnd(createEndDate);

        return pageQuery;
    }

    private List<AccountBookFlowDTO> toInfoBookFlows(List<AccountBookFlowDO> list) {
        if (CollectionUtils.isEmpty(list)) {
            return new LinkedList<>();
        }
        return list.stream().map(this::toInfoBookFlow).collect(Collectors.toList());
    }

    private AccountBookFlowDTO toInfoBookFlow(AccountBookFlowDO item) {
        AccountBookFlowDTO flow = new AccountBookFlowDTO();
        flow.setAmount(item.getAmount());
        flow.setFlowType(item.getFlowType().getDesc());
        flow.setGmtStatement(TimeUtils.format(item.getGmtStatement()));
        flow.setVoucherId(item.getOutId());

        return flow;
    }

    private PaymentPropDTO toInfoPaymentPropDTO(PaymentPropDO paymentPropDO) {
        if (null == paymentPropDO) {
            return null;
        }

        PaymentPropDTO paymentPropDTO = new PaymentPropDTO();
        paymentPropDTO.setEvidenceFlow(paymentPropDO.getEvidenceFlow());
        return paymentPropDTO;
    }

    private VoucherDeliveryDTO toInfoVoucherDeliveryDTO(VoucherDeliveryDO voucherDeliveryDO) {
        if (null == voucherDeliveryDO) {
            return null;
        }

        VoucherDeliveryDTO voucherDeliveryDTO = new VoucherDeliveryDTO();
        voucherDeliveryDTO.setTradeId(voucherDeliveryDO.getTradeId());
        voucherDeliveryDTO.setLgTime(TimeUtils.format(voucherDeliveryDO.getLgTime()));
        voucherDeliveryDTO.setDeliveryTime(TimeUtils.format(voucherDeliveryDO.getDeliveryTime()));
        voucherDeliveryDTO.setTrackingNumber(voucherDeliveryDO.getTrackingNumber());
        if (null != voucherDeliveryDO.getCompanyId()) {
            voucherDeliveryDTO.setCompanyId(String.valueOf(voucherDeliveryDO.getCompanyId()));
        }
        voucherDeliveryDTO.setCompanyName(voucherDeliveryDO.getCompanyName());
        voucherDeliveryDTO.setAddress(voucherDeliveryDO.getuProv() + voucherDeliveryDO.getuCity());
        voucherDeliveryDTO.setAmount(voucherDeliveryDO.getAmount());

        if (PayMode.PAY_ONLINE.isEquals(voucherDeliveryDO.getPayMode())) {
            voucherDeliveryDTO.setPayTime(TimeUtils.format(voucherDeliveryDO.getPayTime()));
        } else if (PayMode.CASH_ON_DELIVERY.isEquals(voucherDeliveryDO.getPayMode())) {
            voucherDeliveryDTO.setPayTime(TimeUtils.format(voucherDeliveryDO.getCreateTime()));
        }
        voucherDeliveryDTO.setPayMode(PayMode.valueOf(voucherDeliveryDO.getPayMode()).name());

        return voucherDeliveryDTO;
    }

    private List<FileInfoDTO> buildFileInfo(long domainId, long userId, String fileJson) {
        List<FileInfoDTO> list = new LinkedList<>();

        if (StringUtils.isNotBlank(fileJson)) {
            JSONArray ja = null;
            try {
                ja = JSONArray.parseArray(fileJson);
            } catch (Exception e) {
                logger.warn("JSONArray.parseArray fail, str is {}", fileJson, e);
            }

            if (null != ja) {
                ja.forEach(n -> {
                    JSONObject jo = (JSONObject) n;
                    FileInfoDTO fileInfoDTO = new FileInfoDTO();

                    String fileName = jo.getString(FILE_NAME);
                    fileInfoDTO.setFileName(fileName);

                    ResultDTO<String> resultDTO = buildFileUrl(domainId, userId, jo.getString(FILE_KEY), fileName);
                    if (resultDTO.isSuccess()) {
                        fileInfoDTO.setFileKey(resultDTO.getModel());
                    }
                    list.add(fileInfoDTO);
                });
            }
        }

        return list;
    }

    private VoucherSummaryDTO toInfoVoucherSummary(VoucherDO voucherDO, String roleName) {
        VoucherSummaryDTO summaryDTO = new VoucherSummaryDTO();
        summaryDTO.setVoucherId(voucherDO.getVoucherId());
        summaryDTO.setAmount(voucherDO.getExpectAmt());
        summaryDTO.setGmtCreated(TimeUtils.format(voucherDO.getGmtCreated(), TimeUtils.SIMPLE_DATA_FORMAT));
        summaryDTO.setProcStartTime(TimeUtils.format(voucherDO.getProcStartTime(), TimeUtils.SIMPLE_DATA_FORMAT));
        summaryDTO.setVoucherSubType(voucherDO.getVoucherSubType().getDesc());
        summaryDTO.setVoucherType(voucherDO.getVoucherType().getDesc());
        summaryDTO.setKeyStr(voucherDO.getObjId());

        String procName = voucherDO.getVoucherSubType().getProc().getCode();
        String nodeKey = voucherDO.getNodeKey();
        AppResourceDO resource = getAppResource(procName, nodeKey);

        List<ButtonDTO> buttonDTOS = new LinkedList<>();

        if (!Objects.isNull(resource)) {
            summaryDTO.setNodeKeyName(resource.val);

            if (StringUtils.equals(roleName, voucherDO.getRole())) {
                ButtonDTO button = new ButtonDTO();
                button.setName(resource.key3);
                button.setPath(VoucherButton.RESTFUL_OPT.getCode());
                buttonDTOS.add(button);
            } else if (canDeletePunish(voucherDO)) {
                ButtonDTO button = new ButtonDTO();
                button.setName(VoucherButton.RESTFUL_SUBMIT.getDesc());
                button.setPath(VoucherButton.RESTFUL_SUBMIT.getCode());
                ButtonDTO button2 = new ButtonDTO();
                button2.setName(VoucherButton.RESTFUL_DELETE.getDesc());
                button2.setPath(VoucherButton.RESTFUL_DELETE.getCode());
                buttonDTOS.add(button);
                buttonDTOS.add(button2);
            }
        }

        ResultDTO<SellerDO> resultSeller = querySeller(voucherDO.getSellerId());
        if (resultSeller.isSuccess()) {
            SellerDO seller = resultSeller.getModel();
            summaryDTO.setSellerId(seller.getId());
            summaryDTO.setSellerName(seller.getName());
            summaryDTO.setSellerStatus(SellerStatus.valueOf(seller.getStatus()).getDesc());
            summaryDTO.setSellerType(SellerServiceType.valueOf(seller.getServiceType()).getDesc());
        }
        summaryDTO.setButtons(buttonDTOS);
        return summaryDTO;
    }

    private NodeKeyDTO toInfoNodeKeyDTO(FlowStatusDO flowStatusDO) {
        if (null == flowStatusDO) {
            return null;
        }

        NodeKeyDTO nodeKeyDTO = new NodeKeyDTO();
        nodeKeyDTO.setKey(flowStatusDO.getKey());
        nodeKeyDTO.setName(flowStatusDO.getName());
        return nodeKeyDTO;
    }

    private void mergePathAndTransition(long appId, long userId, VoucherDTO voucherDTO, VoucherDO voucherDO) {
        String role = queryRole(appId, userId);
        if (StringUtils.isBlank(role) || !role.equals(voucherDO.getRole())) {
            return;
        }

        NodeDTO nodeDTO = getNodeInfo(NumberUtils.toLong(voucherDO.getProcInstId()), voucherDO.getNodeKey());
        if (null == nodeDTO) {
            return;
        }

        voucherDTO.setApiName(nodeDTO.getPath());

        String procName = voucherDO.getVoucherSubType().getProc().getCode();
        ResultDTO<String> resultDTO1 = queryNodeTip(procName, voucherDO.getNodeKey());

        List<com.pajk.taskcenter.client.model.dto.TransitionDTO> transitionDTOList = nodeDTO.getTransitionDTOList();
        if (!CollectionUtils.isEmpty(transitionDTOList)) {
            JSONObject tipJsonObject = new JSONObject();
            if (resultDTO1.isSuccess()) {
                tipJsonObject = JsonUtil.parseJSONObject(resultDTO1.getModel());
            }

            JSONObject finalTipJsonObject = tipJsonObject;
            List<TransitionDTO> list = transitionDTOList.stream()
                    .map(n -> buildTransitionDTO(n, finalTipJsonObject)).collect(Collectors.toList());
            voucherDTO.setFlowButtons(list);
        }
    }

    private TransitionDTO buildTransitionDTO(com.pajk.taskcenter.client.model.dto.TransitionDTO transitionDTO,
                                             JSONObject jsonObject) {
        if (null == transitionDTO) {
            return null;
        }

        TransitionDTO transitionDTO1 = new TransitionDTO();
        transitionDTO1.setTransitionKey(transitionDTO.getTransitionKey());
        transitionDTO1.setTransitionName(transitionDTO.getTransitionName());
        transitionDTO1.setTips(jsonObject.getString(transitionDTO.getTransitionKey()));
        return transitionDTO1;
    }

    private boolean canDeletePunish(VoucherDO voucherDO) {
        return StringUtils.isBlank(voucherDO.getProcInstId())
                && VoucherDeleteFlag.NOT_DELETE.isEquals(voucherDO.getIsDeleted())
                && VoucherStatus.CREATED.isEquals(voucherDO.getNodeKey())
                && ((VoucherSubType.FAKE_VIOLATION.isEquals(voucherDO.getVoucherSubType())
                || VoucherSubType.FALSE_CONDUCT_VIOLATION.isEquals(voucherDO.getVoucherSubType())));
    }

}
