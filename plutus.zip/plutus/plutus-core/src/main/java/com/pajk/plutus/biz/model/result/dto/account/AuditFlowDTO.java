package com.pajk.plutus.biz.model.result.dto.account;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by guguangming on 2017/12/14
 */
public class AuditFlowDTO extends BaseDO {

    private static final long serialVersionUID = 5928656610142041266L;

    private String nodeKeyDesc;

    private String transitionName;

    private String remark;

    private String allocatingTime;

    private String auditTime;

    private String role;

    public String getNodeKeyDesc() {
        return nodeKeyDesc;
    }

    public void setNodeKeyDesc(String nodeKeyDesc) {
        this.nodeKeyDesc = nodeKeyDesc;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getAllocatingTime() {
        return allocatingTime;
    }

    public void setAllocatingTime(String allocatingTime) {
        this.allocatingTime = allocatingTime;
    }

    public String getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(String auditTime) {
        this.auditTime = auditTime;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getTransitionName() {
        return transitionName;
    }

    public void setTransitionName(String transitionName) {
        this.transitionName = transitionName;
    }

}
