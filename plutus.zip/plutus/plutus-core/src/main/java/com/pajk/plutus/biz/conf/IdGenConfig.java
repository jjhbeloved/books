package com.pajk.plutus.biz.conf;

import com.pajk.idgen.IDGenService;
import com.pajk.plutus.biz.common.idgen.IDPool;
import com.pajk.plutus.biz.common.idgen.impl.IDPoolImpl;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by lizhijun on 2016/11/2.
 */
@Configuration
public class IdGenConfig {

    @Value("${id.generator.domain}")
    private String domain;

    @Value("#{globalIdGenerator}")
    private IDGenService globalIdGenerator;

    @Bean(name = "voucherIDPool")
    public IDPool hawaiiIDPool(@Value("${id.generator.plutus.voucher.id}") String configKey) {
        return new IDPoolImpl(domain, configKey, 20, globalIdGenerator);
    }

}
