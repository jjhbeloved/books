package com.pajk.plutus.biz.model.result.dto.account;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by fanhuafeng on 17/12/20.
 * Modify by fanhuafeng on 17/12/20
 * 保证金账本列表账本按钮
 */
public class BookButtonDTO extends BaseDO {
    private static final long serialVersionUID = -2737561324837719397L;

    /**
     * 是否创建违规单
     */
    private boolean isCreatePunish = false;

    /**
     * 是否创建缴费单
     */
    private boolean isCreatePayMent = false;

    /**
     * 是否清退
     */
    private boolean isToZero = false;

    /**
     * 是否修改合同保证金
     */
    private boolean isUpdateContract = false;



}
