package com.pajk.plutus.biz.model.bill;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * @author david
 * @since created by on 17/12/14 10:45
 */
public class PaymentInfoDO extends BaseDO {

    private static final long serialVersionUID = 2280073145749239420L;

    private String paymentNo;

    private String paymentFileId;

    private String paymentFileName;

    public String getPaymentNo() {
        return paymentNo;
    }

    public void setPaymentNo(String paymentNo) {
        this.paymentNo = paymentNo;
    }

    public String getPaymentFileId() {
        return paymentFileId;
    }

    public void setPaymentFileId(String paymentFileId) {
        this.paymentFileId = paymentFileId;
    }

    public String getPaymentFileName() {
        return paymentFileName;
    }

    public void setPaymentFileName(String paymentFileName) {
        this.paymentFileName = paymentFileName;
    }
}
