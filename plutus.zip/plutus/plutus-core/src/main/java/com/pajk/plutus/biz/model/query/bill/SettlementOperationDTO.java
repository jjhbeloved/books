package com.pajk.plutus.biz.model.query.bill;

import java.io.Serializable;

public class SettlementOperationDTO implements Serializable {


    private static final long serialVersionUID = 674145728270162822L;


    private String operationDesc; //节点状态，nodeKey文案

    private String operationStartTime; //任务分配时间, 格式:yyyy-MM-dd HH:mm:ss

    private String operationEndTime; //实际审批时间, 格式:yyyy-MM-dd HH:mm:ss

    private String operationRole;  //审批角色

    private String operationVote;  // 审批意见

    private String operationMemo;  //审批备注

    public String getOperationDesc() {
        return operationDesc;
    }

    public void setOperationDesc(String operationDesc) {
        this.operationDesc = operationDesc;
    }

    public String getOperationStartTime() {
        return operationStartTime;
    }

    public void setOperationStartTime(String operationStartTime) {
        this.operationStartTime = operationStartTime;
    }

    public String getOperationEndTime() {
        return operationEndTime;
    }

    public void setOperationEndTime(String operationEndTime) {
        this.operationEndTime = operationEndTime;
    }

    public String getOperationRole() {
        return operationRole;
    }

    public void setOperationRole(String operationRole) {
        this.operationRole = operationRole;
    }

    public String getOperationVote() {
        return operationVote;
    }

    public void setOperationVote(String operationVote) {
        this.operationVote = operationVote;
    }

    public String getOperationMemo() {
        return operationMemo;
    }

    public void setOperationMemo(String operationMemo) {
        this.operationMemo = operationMemo;
    }
}
