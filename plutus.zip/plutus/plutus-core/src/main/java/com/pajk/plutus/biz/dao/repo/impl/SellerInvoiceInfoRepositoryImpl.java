package com.pajk.plutus.biz.dao.repo.impl;

import com.pajk.plutus.biz.dao.mapper.single.bill.SellerInvoiceInfoMapper;
import com.pajk.plutus.biz.dao.repo.SellerInvoiceInfoRepository;
import com.pajk.plutus.biz.model.bill.SellerInvoiceInfoDO;
import com.pajk.plutus.biz.model.mapper.single.bill.SellerInvoiceInfoDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Optional;

/**
 * @author dutianyi
 * @date 2017/12/18
 */
@Repository
public class SellerInvoiceInfoRepositoryImpl implements SellerInvoiceInfoRepository {
    @Autowired
    private SellerInvoiceInfoMapper sellerInvoiceInfoMapper;

    @Override
    public Optional<SellerInvoiceInfoDO> queryBySellerId(long sellerId) {
        return queryBySellerId(sellerId, 0);
    }

    @Override
    public Optional<SellerInvoiceInfoDO> queryBySellerId(long sellerId, int status) {
        List<SellerInvoiceInfoDAO> sellerInvoiceInfoDAOS = sellerInvoiceInfoMapper.queryBySellerId(sellerId, status);

        if (CollectionUtils.isEmpty(sellerInvoiceInfoDAOS)) {
            return Optional.empty();
        } else {
            return Optional.ofNullable(sellerInvoiceInfoDAOS.get(0))
                    .map(this::toSellerInvoiceInfoModel);
        }
    }

    private SellerInvoiceInfoDO toSellerInvoiceInfoModel(SellerInvoiceInfoDAO sellerInvoiceInfoDAO) {
        final SellerInvoiceInfoDO sellerInvoiceInfoDO = new SellerInvoiceInfoDO();

        sellerInvoiceInfoDO.setId(sellerInvoiceInfoDAO.getId());
        sellerInvoiceInfoDO.setAddress(sellerInvoiceInfoDAO.getAddress());
        sellerInvoiceInfoDO.setContact(sellerInvoiceInfoDAO.getContact());
        sellerInvoiceInfoDO.setContactTel(sellerInvoiceInfoDAO.getContactTel());
        sellerInvoiceInfoDO.setInvoiceAddress(sellerInvoiceInfoDAO.getInvoiceAddress());
        sellerInvoiceInfoDO.setInvoiceBankAccount(sellerInvoiceInfoDAO.getInvoiceBankAccount());
        sellerInvoiceInfoDO.setInvoiceBankName(sellerInvoiceInfoDAO.getInvoiceBankName());
        sellerInvoiceInfoDO.setInvoiceTel(sellerInvoiceInfoDAO.getInvoiceTel());
        sellerInvoiceInfoDO.setInvoiceTitle(sellerInvoiceInfoDAO.getInvoiceTitle());
        sellerInvoiceInfoDO.setInvoiceType(sellerInvoiceInfoDAO.getInvoiceType());
        sellerInvoiceInfoDO.setSellerId(sellerInvoiceInfoDAO.getSellerId());
        sellerInvoiceInfoDO.setStatus(sellerInvoiceInfoDAO.getStatus());
        sellerInvoiceInfoDO.setTaxpayerNumber(sellerInvoiceInfoDAO.getTaxpayerNumber());
        sellerInvoiceInfoDO.setGmtCreated(sellerInvoiceInfoDAO.getGmtCreated());
        sellerInvoiceInfoDO.setGmtModified(sellerInvoiceInfoDAO.getGmtModified());

        return sellerInvoiceInfoDO;
    }
}
