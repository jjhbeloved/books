package com.pajk.plutus.biz.model.bill;

import com.pajk.plutus.biz.model.process.TransitionDO;
import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.List;

/**
 * @author dutianyi
 * @since created by on 17/12/21 19:31
 */
public class CascadeButtonDO extends BaseDO {
    private static final long serialVersionUID = -5491220847202213588L;

    private String name;

    private List<TransitionDO> transitions;

    private String path;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<TransitionDO> getTransitions() {
        return transitions;
    }

    public void setTransitions(List<TransitionDO> transitions) {
        this.transitions = transitions;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
