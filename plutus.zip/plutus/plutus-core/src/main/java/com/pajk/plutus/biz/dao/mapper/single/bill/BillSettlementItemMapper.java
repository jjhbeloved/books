package com.pajk.plutus.biz.dao.mapper.single.bill;

import com.pajk.plutus.biz.model.mapper.single.bill.BillSettlementItemDAO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by arjaylv on 2017/12/11.
 *
 * @author arjaylv
 */
public interface BillSettlementItemMapper {

    List<BillSettlementItemDAO> queryByBillId(@Param("billId") long billId);

    int updateAmt(BillSettlementItemDAO billSettlementItemDAO);
}
