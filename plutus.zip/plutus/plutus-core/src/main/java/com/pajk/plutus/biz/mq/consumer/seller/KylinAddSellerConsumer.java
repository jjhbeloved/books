package com.pajk.plutus.biz.mq.consumer.seller;

import com.pajk.kylin.helpcenter.api.model.message.SellerAddMsg;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.client.model.topic.KylinTopic;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component("kylinAddSellerConsumer")
public class KylinAddSellerConsumer extends AbstractSellerConsumer {

    @Value("${rocketmq.domain.name}")
    private String rocketMqDomainName;

    @Value("${rocketmq.domain.group}")
    private String rocketMqDomainGroup;

    @Autowired
    private AccountManager accountManager;

    @PostConstruct
    @Override
    public void init() throws Exception {
        setGroup(rocketMqDomainGroup);
        setNameServer(rocketMqDomainName);
        super.init();
    }

    @Override
    protected KylinTopic getKylinTopic() {
        return KylinTopic.KYLIN_ADD_SELLER;
    }

    @Override
    protected boolean doConsumeMessage(SellerAddMsg sellerAddMsg, int reconsumeTimes) {
        ResultDTO<VoidEntity> result = accountManager.createAccount(sellerAddMsg.getSellerId());
        return ErrorCode.SUCCESS.eq(result.getResultCode());
    }
}