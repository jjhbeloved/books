package com.pajk.plutus.biz.model.query.bill;

import java.io.Serializable;

public class SellerDTO implements Serializable {

    private static final Long serialVersionUID = 4638309256007530211L;


    private Long sellerId;// 商户ID

    private String name; // 商户名

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
