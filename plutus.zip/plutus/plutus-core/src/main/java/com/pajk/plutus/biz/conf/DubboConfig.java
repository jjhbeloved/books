package com.pajk.plutus.biz.conf;

import com.alibaba.dubbo.config.*;
import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author yuewenxin
 * @version v 0.1 2015-05-06 17:11:45 aaronyue Exp $$
 */
@Configuration
public class DubboConfig {

    @Value("${dubbo.application.name}")
    private String appName;

    @Value("${public.dubbo.port}")
    private Integer dubboPort;

    @Value("${public.dubbo.registry.url}")
    private String dubboRegistryUrl;

    @Value("${dubbo.registry.protocol}")
    private String dubboRegistryProtocol;

    @Value("${public.dubbo.version}")
    private String consumerVersion;


    @Bean
    public ApplicationConfig application() {
        final ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName(appName);
        return applicationConfig;
    }

    @Bean
    public MonitorConfig monitorConfig() {
        MonitorConfig mc = new MonitorConfig();
        mc.setProtocol("registry");
        return mc;
    }

    @Bean
    public ProviderConfig provider() {
        final ProviderConfig providerConfig = new ProviderConfig();
        providerConfig.setMonitor(monitorConfig());
        return providerConfig;
    }

    // 消费者
    @Bean(autowire = Autowire.BY_NAME)
    public ConsumerConfig consumer() {
        final ConsumerConfig cc = new ConsumerConfig();
        cc.setCheck(false);
        return cc;
    }

    @Bean
    public ProtocolConfig protocol() {
        final ProtocolConfig protocolConfig = new ProtocolConfig();
        protocolConfig.setPort(dubboPort);
        return protocolConfig;
    }

    @Bean
    public RegistryConfig registry() {
        final RegistryConfig registryConfig = new RegistryConfig();
        registryConfig.setAddress(dubboRegistryUrl);
        registryConfig.setProtocol(dubboRegistryProtocol);
        return registryConfig;
    }

}
