package com.pajk.plutus.biz.model.query.bill;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
 * @author david
 * @since created by on 17/12/14 10:59
 */
public class FileInfoDTO implements Serializable{

    private static final long serialVersionUID = 6974713543996785481L;

    @JSONField(name = "confirm_file_id")
    private String confirmFileId;

    @JSONField(name = "confirm_file_name")
    private String confirmFileName;

    public String getConfirmFileId() {
        return confirmFileId;
    }

    public void setConfirmFileId(String confirmFileId) {
        this.confirmFileId = confirmFileId;
    }

    public String getConfirmFileName() {
        return confirmFileName;
    }

    public void setConfirmFileName(String confirmFileName) {
        this.confirmFileName = confirmFileName;
    }
}
