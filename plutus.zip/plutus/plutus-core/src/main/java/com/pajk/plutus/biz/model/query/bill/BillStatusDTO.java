package com.pajk.plutus.biz.model.query.bill;

import java.io.Serializable;

public class BillStatusDTO implements Serializable {


    private static final long serialVersionUID = -4836429915395357186L;

    private String status; // 状态值

    private String name;// 状态名称

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
