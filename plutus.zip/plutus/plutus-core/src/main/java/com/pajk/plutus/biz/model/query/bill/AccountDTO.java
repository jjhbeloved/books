package com.pajk.plutus.biz.model.query.bill;

import com.pajk.plutus.biz.model.bill.SellerAccountInfoDO;

import java.io.Serializable;

public class AccountDTO implements Serializable {

    private static final long serialVersionUID = 2298166718660954469L;

    private String purchaserAccount;// 收款的银行账户
    private String purchaserAccountName;//收款的银行账户名称
    private String purchaserBankName;//收款的开户行

    public String getPurchaserAccount() {
        return purchaserAccount;
    }

    public void setPurchaserAccount(String purchaserAccount) {
        this.purchaserAccount = purchaserAccount;
    }

    public String getPurchaserAccountName() {
        return purchaserAccountName;
    }

    public void setPurchaserAccountName(String purchaserAccountName) {
        this.purchaserAccountName = purchaserAccountName;
    }

    public String getPurchaserBankName() {
        return purchaserBankName;
    }

    public void setPurchaserBankName(String purchaserBankName) {
        this.purchaserBankName = purchaserBankName;
    }


    public static AccountDTO acccountDoToDTO(SellerAccountInfoDO sellerAccountInfoDO) {
        return null;
    }
}
