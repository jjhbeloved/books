package com.pajk.plutus.biz.dao.repo.impl;

import com.pajk.plutus.biz.dao.mapper.single.bill.SellerAccountInfoMapper;
import com.pajk.plutus.biz.dao.repo.SellerAccountInfoRepository;
import com.pajk.plutus.biz.model.bill.SellerAccountInfoDO;
import com.pajk.plutus.biz.model.mapper.single.bill.SellerAccountInfoDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Optional;

/**
 * @author david
 * @since created by on 17/12/19 13:19
 */
@Repository
public class SellerAccountInfoRepositoryImpl implements SellerAccountInfoRepository {

    @Autowired
    private SellerAccountInfoMapper sellerAccountInfoMapper;

    @Override
    public Optional<SellerAccountInfoDO> queryBySellerId(long sellerId) {
        return queryBySellerId(sellerId, 0);
    }

    @Override
    public Optional<SellerAccountInfoDO> queryBySellerId(long sellerId, int status) {
        List<SellerAccountInfoDAO> sellerAccountInfoDAOS = sellerAccountInfoMapper.queryBySellerId(sellerId, status);

        if (CollectionUtils.isEmpty(sellerAccountInfoDAOS)) {
            return Optional.empty();
        } else {
            return Optional.ofNullable(sellerAccountInfoDAOS.get(0))
                    .map(this::toSellerAccountInfoModel);
        }
    }

    private SellerAccountInfoDO toSellerAccountInfoModel(SellerAccountInfoDAO sellerAccountInfoDAO) {
        SellerAccountInfoDO sellerAccountInfoDO = new SellerAccountInfoDO();
        sellerAccountInfoDO.setId(sellerAccountInfoDAO.getId());
        sellerAccountInfoDO.setGmtCreated(sellerAccountInfoDAO.getGmtCreated());
        sellerAccountInfoDO.setGmtModified(sellerAccountInfoDAO.getGmtModified());
        sellerAccountInfoDO.setVersion(sellerAccountInfoDAO.getVersion());
        sellerAccountInfoDO.setSellerId(sellerAccountInfoDAO.getSellerId());
        sellerAccountInfoDO.setStatus(sellerAccountInfoDAO.getStatus());
        sellerAccountInfoDO.setAccountType(sellerAccountInfoDAO.getAccountType());
        sellerAccountInfoDO.setPurchaserAccount(sellerAccountInfoDAO.getPurchaserAccount());
        sellerAccountInfoDO.setPurchaserAccountName(sellerAccountInfoDAO.getPurchaserAccountName());
        sellerAccountInfoDO.setPurchaserBankName(sellerAccountInfoDAO.getPurchaserBankName());
        return sellerAccountInfoDO;
    }
}
