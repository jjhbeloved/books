package com.pajk.plutus.biz.manager.permission;

import com.pajk.plutus.biz.util.WebUtil;
import com.pajk.user.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.google.common.base.Strings.isNullOrEmpty;

/**
 * 用户登录拦截器
 */
@Component
public class UserInterceptor extends HandlerInterceptorAdapter {

    private Logger logger = LoggerFactory.getLogger(UserInterceptor.class);
    @Autowired
    private UserInfoCacheManager userInfoCacheManager;

    @Value("${public.dubbo.version}")
    private String mode;

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response, Object o) throws Exception {
        response.setHeader("Access-Control-Allow-Origin", request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type, If-None-Match, Access-Control-Allow-Headers, Content-Type,Powered-By");
        response.setHeader("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Content-Type", "application/json;charset=utf-8");
        logger.info("getRequestURL:{}", request.getRequestURL());

        if ("options".equals(request.getMethod().toLowerCase())) {
            response.setStatus(200);
            return true;
        }

        String userToken = WebUtil.findCookieValue(request, "_tk");
        if (!isNullOrEmpty(userToken)) {
            User user = userInfoCacheManager.getUser(userToken);
            if (user != null) {
                UserUtil.putUser(user);
                return true;
            }
            logger.warn("user token:{} not found", userToken);
        } else {
            logger.warn("user token is null");
        }
        response.setStatus(401);
        return false;
    }

    @Override
    public void afterCompletion(HttpServletRequest request,
                                HttpServletResponse response, Object o, Exception e) throws Exception {
        UserUtil.removeCurrentUser();
    }
}
