package com.pajk.plutus.biz.model.param.restapi;

import com.pajk.plutus.client.model.enums.account.BookFlowType;
import com.pajk.thunderbird.domain.result.BaseDO;

import javax.validation.constraints.NotNull;

/**
 * Created by lizhijun on 2017/12/19.
 *
 */
public class PageQueryAccountBookFlowParam extends BaseDO {
    private static final long serialVersionUID = 6287020822924609530L;

    /**
     * 商家id
     */
    @NotNull
    private Long sellerId;

    /**
     * 账本id
     */
    @NotNull
    private Long accountBookId;

    /**
     * {@link BookFlowType#code}
     */
    @NotNull
    private Integer flowType;

    /**
     * 产生记录的起始时间
     */
    private String gmtStatementStart;
    /**
     * 产生记录的最终时间
     */
    private String gmtStatementEnd;



    /**
     * 页数 pageNo< 300
     */
    private int pageNo = 1;
    /**
     * 页码  pageNo* pageSiz　< 10000
     */
    private int pageSize = 50;

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Long getAccountBookId() {
        return accountBookId;
    }

    public void setAccountBookId(Long accountBookId) {
        this.accountBookId = accountBookId;
    }

    public String getGmtStatementStart() {
        return gmtStatementStart;
    }

    public void setGmtStatementStart(String gmtStatementStart) {
        this.gmtStatementStart = gmtStatementStart;
    }

    public String getGmtStatementEnd() {
        return gmtStatementEnd;
    }

    public void setGmtStatementEnd(String gmtStatementEnd) {
        this.gmtStatementEnd = gmtStatementEnd;
    }

    public Integer getFlowType() {
        return flowType;
    }

    public void setFlowType(Integer flowType) {
        this.flowType = flowType;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}
