package com.pajk.plutus.biz.model.account;

import com.pajk.plutus.client.model.enums.account.*;
import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * Created by lizhijun on 2017/12/17.
 */
public class AccountBookFlowDO extends BaseDO {

    private static final long serialVersionUID = 892865661014904666L;

    /**
     * 主键id
     **/
    private long id;

    /**
     * 创建时间
     **/
    private Date gmtCreated;

    /**
     * 更新时间
     **/
    private Date gmtModified;

    /**
     * 版本号
     **/
    private int version;

    /**
     * 卖家id
     **/
    private long sellerId;

    /**
     * 未完成0 已完成1
     **/
    private BookFlowStatus status;

    /**
     * 流水类型 {@link BookFlowType}
     **/
    private BookFlowType flowType;

    /**
     * 流水子类型 @link com.pajk.plutus.client.model.enums.BookFlowSubType}
     **/
    private BookFlowSubType flowSubType;

    /**
     * 外部业务渠道 如 fc_voucher
     **/
    private BookFlowOutType outType;

    /**
     * 外部业务id 如fc_voucher的主键id
     **/
    private String outId;

    /**
     * 账本类型同fc_account_book表的book_type
     **/
    private BookType bookType;

    /**
     * 账本id
     **/
    private long bookId;

    /**
     * 金额(单位分)
     **/
    private long amount;

    /**
     * 账本余额增加或扣减的时间
     **/
    private Date gmtStatement;

    /**
     * 是否销帐 未销帐0 已销帐1
     **/
    private BookFlowWriteOffStatus writeOffStatus;

    /**
     * 销帐来源类型如fc_voucher
     **/
    private BookFlowWriteOffOutType writeOffType;

    /**
     * 销帐id (销帐绑定的 fc_voucher的主键(缴费单)id)
     **/
    private String writeOffId;

    /**
     * 流水说明
     **/
    private String msg;

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public BookFlowStatus getStatus() {
        return status;
    }

    public void setStatus(BookFlowStatus status) {
        this.status = status;
    }

    public BookFlowType getFlowType() {
        return flowType;
    }

    public void setFlowType(BookFlowType flowType) {
        this.flowType = flowType;
    }

    public BookFlowSubType getFlowSubType() {
        return flowSubType;
    }

    public void setFlowSubType(BookFlowSubType flowSubType) {
        this.flowSubType = flowSubType;
    }

    public BookFlowOutType getOutType() {
        return outType;
    }

    public void setOutType(BookFlowOutType outType) {
        this.outType = outType;
    }

    public String getOutId() {
        return outId;
    }

    public void setOutId(String outId) {
        this.outId = outId;
    }

    public BookType getBookType() {
        return bookType;
    }

    public void setBookType(BookType bookType) {
        this.bookType = bookType;
    }

    public long getBookId() {
        return bookId;
    }

    public void setBookId(long bookId) {
        this.bookId = bookId;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public Date getGmtStatement() {
        return gmtStatement;
    }

    public void setGmtStatement(Date gmtStatement) {
        this.gmtStatement = gmtStatement;
    }

    public BookFlowWriteOffStatus getWriteOffStatus() {
        return writeOffStatus;
    }

    public void setWriteOffStatus(BookFlowWriteOffStatus writeOffStatus) {
        this.writeOffStatus = writeOffStatus;
    }

    public BookFlowWriteOffOutType getWriteOffType() {
        return writeOffType;
    }

    public void setWriteOffType(BookFlowWriteOffOutType writeOffType) {
        this.writeOffType = writeOffType;
    }

    public String getWriteOffId() {
        return writeOffId;
    }

    public void setWriteOffId(String writeOffId) {
        this.writeOffId = writeOffId;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }
}
