package com.pajk.plutus.biz.model.mapper.single.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * 单据操作记录表
 */
public class VoucherLogDAO extends BaseDO {

    private static final long serialVersionUID = -2176920310326538656L;

    /**
     * 主键id
     */
    private long id;

    /**
     * 创建时间
     */
    private Date gmtCreated;

    /**
     * 卖家id
     */
    private long sellerId;

    /**
     * 单据id
     */
    private long voucherId;

    /**
     * 操作类型
     */
    private String optType;

    /**
     * 操作人
     */
    private String operator;

    /**
     * 操作描述
     */
    private String msg;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public long getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(long voucherId) {
        this.voucherId = voucherId;
    }

    public String getOptType() {
        return optType;
    }

    public void setOptType(String optType) {
        this.optType = optType;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

}
