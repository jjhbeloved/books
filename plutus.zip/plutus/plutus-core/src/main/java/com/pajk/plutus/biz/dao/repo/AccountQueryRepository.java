package com.pajk.plutus.biz.dao.repo;

import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.account.AccountBookFlowDO;
import com.pajk.plutus.biz.model.account.AccountDO;
import com.pajk.plutus.biz.model.query.account.BookFlowPageQuery;
import com.pajk.plutus.biz.model.query.account.BookPageQuery;

import java.util.List;
import java.util.Optional;

/**
 * Created by lizhijun on 2017/12/17.
 */
public interface AccountQueryRepository {
    Optional<AccountDO> queryAccountBySeller(long sellerId);

    Optional<List<AccountBookDO>> queryBookBySeller(long sellerId);

    Optional<AccountBookDO> queryBookBySeller(long sellerId, int bookType);

    Optional<AccountBookDO> queryValidBookBySeller(long sellerId, int bookType);

    Optional<List<AccountBookDO>> pageQueryBook(BookPageQuery pageQuery);

    int queryBookCount(BookPageQuery pageQuery);

    Optional<AccountBookDO> queryBookBySellerAndBookId(long sellerId,long bookId);


    Optional<List<AccountBookFlowDO>> pageQueryBookFlow(BookFlowPageQuery pageQuery);

    int queryBookFlowCount(BookFlowPageQuery pageQuery);

    int queryBookFlowCountByWriteOffId(int bookType, String writeOffType, String writeOffId);

    Optional<List<Long>> queryBookFlowIdsByWriteOffId(int bookType, String writeOffType, String writeOffId,
                                                      int pageNo, int pageSize);

    Optional<AccountBookFlowDO> queryBookFlowById(long id);

    Optional<AccountBookFlowDO> queryBookFlowByOutId(long accountBookId, String outType, String outId);
}
