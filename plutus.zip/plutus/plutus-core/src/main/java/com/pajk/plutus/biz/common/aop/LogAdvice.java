package com.pajk.plutus.biz.common.aop;

import com.pajk.plutus.biz.common.util.JsonUtil;
import net.pocrd.dubboext.DubboExtProperty;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Created by fanhuafeng on 17/3/27.
 * Modify by fanhuafeng on 17/3/27
 */
@Component
@Aspect
public class LogAdvice {

    private static final Logger logger = LoggerFactory.getLogger(LogAdvice.class);

    private static final String LOG_ADVICE_INFO = "[LogAdvice.doAround] throwable=";

    @Pointcut("@within(gwLogger)")
    public void gwLog(GwLogger gwLogger) {

    }

    @Pointcut("@within(classLogger)")
    public void classLog(ClassLogger classLogger) {
    }

    @Pointcut("@annotation(com.pajk.plutus.biz.common.aop.MethodLogger)")
    public void methodLog2() {
    }

    @Pointcut("@annotation(methodLogger)")
    public void methodLog(MethodLogger methodLogger) {
    }

    @Around(value = "gwLog(gwLogger)")
    public Object doAroundWithGwLogger(ProceedingJoinPoint pjp, GwLogger gwLogger) throws Throwable {
        return doAround(pjp, gwLogger.throwExceptionLogLevel(),
                gwLogger.argsMaxLength(), gwLogger.returnObjMaxLength(),
                gwLogger.timeOut(), true);
    }

    @Around(value = "methodLog(methodLogger) ")
    public Object doAroundWithMethodLogger(ProceedingJoinPoint pjp, MethodLogger methodLogger) throws Throwable {
        return doAround(pjp, methodLogger.throwExceptionLogLevel(),
                methodLogger.argsMaxLength(), methodLogger.returnObjMaxLength(),
                methodLogger.timeOut(), false);
    }

    @Around(value = "classLog(classLogger) && !methodLog2() ")
    public Object doAroundWithClassLogger(ProceedingJoinPoint pjp, ClassLogger classLogger) throws Throwable {
        return doAround(pjp, classLogger.throwExceptionLogLevel(),
                classLogger.argsMaxLength(), classLogger.returnObjMaxLength(),
                classLogger.timeOut(), false);
    }

    protected String getDubboErrorCode() {
        return DubboExtProperty.getErrorCode();
    }

    private String getNewString(String str, int maxLength) {
        if (StringUtils.isNotBlank(str) && str.length() > maxLength) {
            return str.substring(0, maxLength);
        } else {
            return str;
        }
    }

    private void doLog(ThrowableLogLevel logLevel, Throwable throwable) {

        if (ThrowableLogLevel.ERROR.equals(logLevel)) {
            logger.error(LOG_ADVICE_INFO, throwable);
        } else if (ThrowableLogLevel.WARN.equals(logLevel)) {
            logger.warn(LOG_ADVICE_INFO, throwable);
        } else if (ThrowableLogLevel.INFO.equals(logLevel)) {
            logger.info(LOG_ADVICE_INFO, throwable);
        } else if (ThrowableLogLevel.DEBUG.equals(logLevel)) {
            logger.debug(LOG_ADVICE_INFO, throwable);
        } else if (ThrowableLogLevel.TRACE.equals(logLevel)) {
            logger.trace(LOG_ADVICE_INFO, throwable);
        }
    }

    private Object doAround(ProceedingJoinPoint pjp, ThrowableLogLevel throwableLogLevel,
                            int argsMaxLength, int returnObjMaxLength, long timeOut, boolean isGw) throws Throwable {
        final long begin = System.currentTimeMillis();

        String args = getNewString(JsonUtil.obj2Str(pjp.getArgs()), argsMaxLength);

        Object returnObj = null;
        try {
            returnObj = pjp.proceed();
        } catch (final Throwable throwable) {
            doLog(throwableLogLevel, throwable);
            throw throwable;
        } finally {
            long timeUsed = System.currentTimeMillis() - begin;
            String returnStr = "no print";
            if (0 < returnObjMaxLength) {
                returnStr = getNewString(JsonUtil.obj2Str(returnObj), returnObjMaxLength);
            }
            if (isGw) {
                logger.info("GwLogAdvice|{}|method:{}|cost:{}ms|args:{}|resultCode:{}|result:{}",
                        timeUsed > timeOut ? "TimeOut" : "",
                        pjp.toLongString(), timeUsed, args, getDubboErrorCode(), returnStr);
            } else {
                logger.info("LogAdvice|{}|method:{}|cost:{}ms|args:{}|return:{}", timeUsed > timeOut ? "TimeOut" : "",
                        pjp.toLongString(), timeUsed, args, returnStr);
            }
        }
        return returnObj;
    }

}
