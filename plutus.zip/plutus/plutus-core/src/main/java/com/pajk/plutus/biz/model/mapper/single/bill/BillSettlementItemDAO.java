package com.pajk.plutus.biz.model.mapper.single.bill;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * Created by arjaylv on 2017/12/11.
 *
 * @author arjaylv
 */
public class BillSettlementItemDAO extends BaseDO {

    private static final long serialVersionUID = 3950294135055952713L;

    private Long id;

    private Date gmtCreated;

    private Date gmtModified;

    private Integer version;

    private Long sellerId;

    /**
     * 账单id
     */
    private Long billId;

    /**
     * 单据类型
     */
    private Integer billType;

    /**
     * 单据金额(分)
     */
    private Long billAmt;

    /**
     * 实际确认单据金额(分)
     */
    private Long actualBillAmt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public Integer getBillType() {
        return billType;
    }

    public void setBillType(Integer billType) {
        this.billType = billType;
    }

    public Long getBillAmt() {
        return billAmt;
    }

    public void setBillAmt(Long billAmt) {
        this.billAmt = billAmt;
    }

    public Long getActualBillAmt() {
        return actualBillAmt;
    }

    public void setActualBillAmt(Long actualBillAmt) {
        this.actualBillAmt = actualBillAmt;
    }

}
