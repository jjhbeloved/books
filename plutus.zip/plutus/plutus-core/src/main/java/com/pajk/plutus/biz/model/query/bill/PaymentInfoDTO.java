package com.pajk.plutus.biz.model.query.bill;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author david
 * @since created by on 17/12/14 10:45
 */
public class PaymentInfoDTO implements Serializable {
    private static final long serialVersionUID = -6702811785796903767L;

    private Long sellerId;

    @NotNull
    private Long billId;
    @NotBlank
    private String buttonKey;
    @NotBlank
    @Length(max = 100)
    private String paymentNo;

    private String paymentFileId;
    @Length(max = 100)
    private String paymentFileName;

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public String getButtonKey() {
        return buttonKey;
    }

    public void setButtonKey(String buttonKey) {
        this.buttonKey = buttonKey;
    }

    public String getPaymentNo() {
        return paymentNo;
    }

    public void setPaymentNo(String paymentNo) {
        this.paymentNo = paymentNo;
    }

    public String getPaymentFileId() {
        return paymentFileId;
    }

    public void setPaymentFileId(String paymentFileId) {
        this.paymentFileId = paymentFileId;
    }

    public String getPaymentFileName() {
        return paymentFileName;
    }

    public void setPaymentFileName(String paymentFileName) {
        this.paymentFileName = paymentFileName;
    }

    @Override
    public String toString(){
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }

}
