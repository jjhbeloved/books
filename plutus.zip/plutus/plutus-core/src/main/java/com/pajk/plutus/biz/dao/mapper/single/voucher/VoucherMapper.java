package com.pajk.plutus.biz.dao.mapper.single.voucher;

import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDAO;
import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherUpdateOPT;
import com.pajk.plutus.biz.model.query.account.VoucherPageQuery;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by  guguangming on 2017/12/15
 **/
public interface VoucherMapper {

    VoucherDAO queryBySellerAndId(@Param("sellerId")long sellerId, @Param("voucherId") String voucherId);

    List<VoucherDAO> pageQuery(VoucherPageQuery voucherPageQuery);

    int pageQueryCount(VoucherPageQuery voucherPageQuery);

    /**
     * 创建
     * @param voucherDAO    单据
     */
    void create(VoucherDAO voucherDAO);

    /**
     * 选择更新字段
     * @param voucherUpdateOPT  参数
     * @return  影响条数
     */
    int updateByOPT(VoucherUpdateOPT voucherUpdateOPT);

}
