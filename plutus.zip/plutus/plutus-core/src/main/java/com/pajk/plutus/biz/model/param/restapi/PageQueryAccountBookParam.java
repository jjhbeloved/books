package com.pajk.plutus.biz.model.param.restapi;

import com.pajk.thunderbird.domain.result.BaseDO;

import javax.validation.constraints.NotNull;

/**
 * Created by lizhijun on 2017/12/19.
 */
public class PageQueryAccountBookParam extends BaseDO {

    private static final long serialVersionUID = -5918114575093028677L;

    private Long sellerId;
    @NotNull
    private Integer status;
    private Long balanceAmtStart;
    private Long balanceAmtEnd;
    private int pageNo = 1;
    private int pageSize = 50;

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Long getBalanceAmtStart() {
        return balanceAmtStart;
    }

    public void setBalanceAmtStart(Long balanceAmtStart) {
        this.balanceAmtStart = balanceAmtStart;
    }

    public Long getBalanceAmtEnd() {
        return balanceAmtEnd;
    }

    public void setBalanceAmtEnd(Long balanceAmtEnd) {
        this.balanceAmtEnd = balanceAmtEnd;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}
