package com.pajk.plutus.biz.conf;

import com.alibaba.dubbo.config.spring.ReferenceBean;
import com.pajk.filegw.api.FileTokenService;
import com.pajk.griffin.client.api.dubbo.FileService;
import com.pajk.idgen.IDGenService;
import com.pajk.kylin.api.service.AppResourceService;
import com.pajk.kylin.api.service.PermissionService;
import com.pajk.kylin.api.service.SellerService;
import com.pajk.taskcenter.client.service.FlowService;
import com.pajk.user.api.UserService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by fuyongda on 2017/12/11.
 * Modified by fuyongda on 2017/12/11.
 */
@Configuration
public class DubboConsumerConfig {

    @Value("${public.dubbo.version}")
    private String consumerVersion;

    @Value("${dubbo.consumer.timeout}")
    private int commonTimeOut = 3000;

    private final int httpTimeOut = 10000;

    private boolean commonCheck = false;

    private int commonRetires = 0;

    @Value("${rocketmq.domain.name}")
    private String rocketMqDomainName;

    @Value("${rocketmq.domain.group}")
    private String rocketMqDomainGroup;


    /* ----------  MQ发消息服务 ----------------*/

//    @Bean(initMethod = "init", destroyMethod = "destroy")
//    public MsgSenderService msgSenderService() {
//        MsgSenderService msgSender = new MsgSenderService();
//        msgSender.setNameServer(rocketMqDomainName);
//        msgSender.setGroup(rocketMqDomainGroup);
//        return msgSender;
//    }

    @Bean
    public ReferenceBean<SellerService> sellerService() {
        ReferenceBean<SellerService> rb = new ReferenceBean<>();
        rb.setVersion(consumerVersion);
        rb.setInterface(SellerService.class);
        rb.setCheck(commonCheck);
        rb.setRetries(commonRetires);
        rb.setTimeout(commonTimeOut);
        return rb;
    }

    @Bean
    public ReferenceBean<FileTokenService> fileTokenService() {
        ReferenceBean<FileTokenService> rb = new ReferenceBean<>();
        rb.setVersion(consumerVersion);
        rb.setInterface(FileTokenService.class);
        rb.setCheck(commonCheck);
        rb.setRetries(commonRetires);
        rb.setTimeout(commonTimeOut);
        return rb;
    }

    @Bean
    public ReferenceBean<PermissionService> permissionService() {
        ReferenceBean<PermissionService> rb = new ReferenceBean<>();
        rb.setVersion(consumerVersion);
        rb.setInterface(PermissionService.class);
        rb.setCheck(commonCheck);
        rb.setRetries(commonRetires);
        rb.setTimeout(commonTimeOut);
        return rb;
    }

    @Bean
    public ReferenceBean<UserService> userService() {
        ReferenceBean<UserService> rb = new ReferenceBean<>();
        rb.setVersion(consumerVersion);
        rb.setInterface(UserService.class);
        rb.setCheck(commonCheck);
        rb.setRetries(commonRetires);
        rb.setTimeout(commonTimeOut);
        return rb;
    }

    @Bean
    public ReferenceBean<IDGenService> globalIdGenerator() {
        ReferenceBean<IDGenService> ref = new ReferenceBean<>();
        ref.setVersion(consumerVersion);
        ref.setInterface(IDGenService.class);
        ref.setTimeout(commonTimeOut);
        ref.setCheck(commonCheck);
        ref.setRetries(commonRetires);
        return ref;
    }

    @Bean
    public ReferenceBean<AppResourceService> appResourceService() {
        ReferenceBean<AppResourceService> rb = new ReferenceBean<>();
        rb.setVersion(consumerVersion);
        rb.setInterface(AppResourceService.class);
        rb.setCheck(commonCheck);
        rb.setRetries(commonRetires);
        rb.setTimeout(httpTimeOut);
        return rb;
    }

    @Bean
    public ReferenceBean<FileService> fileService() {
        ReferenceBean<FileService> rb = new ReferenceBean<>();
        rb.setVersion(consumerVersion);
        rb.setInterface(FileService.class);
        rb.setCheck(commonCheck);
        rb.setRetries(commonRetires);
        rb.setTimeout(httpTimeOut);
        return rb;
    }


    @Bean
    public ReferenceBean<FlowService> flowService() {
        final ReferenceBean<FlowService> ref = new ReferenceBean<>();
        ref.setVersion(consumerVersion);
        ref.setInterface(FlowService.class);
        ref.setCheck(commonCheck);
        ref.setRetries(commonRetires);
        ref.setTimeout(httpTimeOut);
        return ref;
    }

}
