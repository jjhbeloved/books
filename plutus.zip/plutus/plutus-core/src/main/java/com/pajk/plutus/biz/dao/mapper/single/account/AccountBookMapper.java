package com.pajk.plutus.biz.dao.mapper.single.account;

import com.pajk.plutus.biz.model.mapper.single.account.AccountBookDAO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookUpdateOPT;
import com.pajk.plutus.biz.model.query.account.BookPageQuery;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by  guguangming on 2017/12/15
 **/
public interface AccountBookMapper {

    int create(AccountBookDAO bookDAO);

    List<AccountBookDAO> pageQuery(BookPageQuery bookPageQuery);

    int pageQueryCount(BookPageQuery bookPageQuery);

    List<AccountBookDAO> queryBySeller(@Param("sellerId") long sellerId);

    AccountBookDAO queryBySellerAndType(@Param("sellerId") long sellerId,
                                          @Param("bookType") int bookType);

    AccountBookDAO queryValidBookBySeller(@Param("sellerId") long sellerId,
                                          @Param("bookType") int bookType);

    int updateByOPT(AccountBookUpdateOPT accountBookUpdateOPT);

    AccountBookDAO queryBookBySellerAndBookId(@Param("sellerId")long sellerId, @Param("id")long id);

}
