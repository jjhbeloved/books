package com.pajk.plutus.biz.service.web;

import com.pajk.plutus.biz.common.util.CommonUtil;
import com.pajk.plutus.biz.common.util.ResultUtil;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.manager.permission.AuthResourceProperties;
import com.pajk.plutus.biz.manager.permission.UserUtil;
import com.pajk.plutus.biz.model.param.restapi.*;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * Created by  guguangming on 2017/12/13
 **/
@RestController("depositController")
@RequestMapping("/plutus/deposit")
public class DepositController extends AbstractWebController  {

    private static final Logger logger = LoggerFactory.getLogger(DepositController.class);

    private static final int LENGTH_500 = 500;
    private static final String VOUCHER = "opt.voucher";
    private static final String ACCOUNT = "opt.account";
    private static final String NO_FLOW_VOUCHER = "opt.noflow.voucher";
    private static final String UPDATE = "update";

    @Autowired
    private VoucherManager voucherManager;


    /**
     * 修改保证金合同金额
     *
     * @param param {@link com.pajk.plutus.biz.model.param.restapi.UpdateContractAmtParam}
     * @return ResultDTO<VoidEntity>
     */
    @RequestMapping(value = "/updateContractAmt", method = RequestMethod.POST)
    public ResultDTO<VoidEntity> updateContractAmt(@Valid @RequestBody UpdateContractAmtParam param) {
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);

        logger.info("[updateContractAmt] param={}, userInfo={}",param, userParam);

        if (!CommonUtil.isValidSellerId(param.getSellerId())) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        if (param.getUpdateContractAmt() <= 0L || param.getUpdateContractAmt() <= param.getBaseContractAmt()) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }
        if (StringUtils.length(param.getRemark()) > LENGTH_500) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        return wrapper(() ->
                        voucherManager.updateContractAmt(param.getSellerId(), param.getAccountBookId(),
                                param.getBaseContractAmt(), param.getUpdateContractAmt(), param.getRemark(), userParam)
                , ACCOUNT, UPDATE);
    }

    /**
     * 商管手动补齐缴费
     *
     * @param param {@link com.pajk.plutus.biz.model.param.restapi.AddBalanceAmtParam}
     * @return ResultDTO<String>
     */
    @RequestMapping(value = "/addBalanceAmt", method = RequestMethod.POST)
    public ResultDTO<String> addBalanceAmt(@Valid @RequestBody AddBalanceAmtParam param) {
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);

        logger.info("[addBalanceAmt]   param={}, userInfo={}",param, userParam);

        if (!CommonUtil.isValidSellerId(param.getSellerId())) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        if (StringUtils.length(param.getRemark()) > LENGTH_500) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        if (0 >= param.getAmount()) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        return wrapper(() ->
                        voucherManager.addBalanceAmt(param.getSellerId(), param.getAccountBookId(), param.getAmount(),
                                param.getRemark(), userParam)
                , NO_FLOW_VOUCHER, UPDATE);
    }

    /**
     * 财务审核缴费单
     *
     * @param param {@link com.pajk.plutus.biz.model.param.restapi.AuditPaymentParam}
     * @return ResultDTO<VoidEntity>
     */
    @RequestMapping(value = "/financeAuditPayment", method = RequestMethod.POST)
    public ResultDTO<VoidEntity> financeAuditPayment(@Valid @RequestBody AuditPaymentParam param) {
        String path = "deposit/financeAuditPayment";
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        userParam.setPath(path);

        logger.info("[financeAuditPayment]   param={}, userInfo={}",param, userParam);

        if (!CommonUtil.isValidSellerId(param.getSellerId()) || !CommonUtil.isValidVoucherId(param.getVoucherId())) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        if (StringUtils.length(param.getRemark()) > LENGTH_500) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        return wrapper(() ->
                        voucherManager.auditPayment(param.getSellerId(), param.getVoucherId(), param.getTransitionKey(),
                                param.getNodeKey(), param.getRemark(), userParam)
                , VOUCHER, UPDATE);
    }


    /**
     * 商管新建违规单
     *
     * @param param {@link com.pajk.plutus.biz.model.param.restapi.CreatePunishParam}
     * @return ResultDTO<VoidEntity>
     */
    @RequestMapping(value = "/createPunish", method = RequestMethod.POST)
    public ResultDTO<VoidEntity> createPunish(@Valid @RequestBody CreatePunishParam param) {
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);

        logger.info("[createPunish]   param={}, userInfo={}",param, userParam);

        if (!CommonUtil.isValidSellerId(param.getSellerId())) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        VoucherSubType subType = VoucherSubType.valueOf(param.getVoucherSubType());
        if (VoucherSubType.UNKNOWN.isEquals(subType)) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        if (0 >= param.getExpectAmt()) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        if (StringUtils.length(param.getCreateRemark()) > LENGTH_500) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        if(StringUtils.isNotBlank(param.getCreateFile()) && !CommonUtil.checkFile(param.getCreateFile())){
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        return wrapper(() ->
                        voucherManager.createPunish(param.getSellerId(), subType, param.getExpectAmt(), param.getCreateFile(),
                                param.getCreateRemark(), userParam)
                , NO_FLOW_VOUCHER, UPDATE);
    }

    /**
     * 删除违规单
     *
     * @param param {@link com.pajk.plutus.biz.model.param.restapi.DealPunishParam}
     * @return ResultDTO<VoidEntity>
     */
    @RequestMapping(value = "/deletePunish", method = RequestMethod.POST)
    public ResultDTO<VoidEntity> deletePunish(@Valid @RequestBody DealPunishParam param) {
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);

        logger.info("[deletePunish]   param={}, userInfo={}",param, userParam);
        if (!CommonUtil.isValidSellerId(param.getSellerId()) || !CommonUtil.isValidVoucherId(param.getVoucherId())) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        return wrapper(() ->
                        voucherManager.deletePunish(param.getSellerId(), param.getVoucherId(), userParam),
                NO_FLOW_VOUCHER, UPDATE);

    }


    /**
     * 提交违规单
     *
     * @param param {@link com.pajk.plutus.biz.model.param.restapi.DealPunishParam}
     * @return ResultDTO<VoidEntity>
     */
    @RequestMapping(value = "/submitPunish", method = RequestMethod.POST)
    public ResultDTO<VoidEntity> submitPunish(@Valid @RequestBody DealPunishParam param) {
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        logger.info("[submitPunish] param={}, userInfo={}",param, userParam);

        if (!CommonUtil.isValidSellerId(param.getSellerId()) || !CommonUtil.isValidVoucherId(param.getVoucherId())) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        return wrapper(() ->
                        voucherManager.submitPunish(param.getSellerId(), param.getVoucherId(), userParam)
                , NO_FLOW_VOUCHER, UPDATE);
    }


    /**
     * 商管审核违规单
     *
     * @param param {@link com.pajk.plutus.biz.model.param.restapi.AuditPunishParam}
     * @return ResultDTO<VoidEntity>
     */
    @RequestMapping(value = "/auditPunish", method = RequestMethod.POST)
    public ResultDTO<VoidEntity> auditPunish(@Valid @RequestBody AuditPunishParam param) {
        String path = "deposit/auditPunish";
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        userParam.setPath(path);
        logger.info("[auditPunish] param={}, userInfo={}",param, userParam);
        if (!CommonUtil.isValidSellerId(param.getSellerId()) || !CommonUtil.isValidVoucherId(param.getVoucherId())) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        if (StringUtils.length(param.getRemark()) > LENGTH_500) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        return wrapper(() ->
                        voucherManager.auditPunish(param.getSellerId(), param.getVoucherId(), param.getTransitionKey(),
                                param.getNodeKey(), param.getRemark(), userParam)
                , VOUCHER, UPDATE);
    }

}
