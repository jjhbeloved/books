package com.pajk.plutus.biz.manager.permission;

import com.alibaba.fastjson.JSONObject;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.kylin.api.service.PermissionService;
import com.pajk.kylin.api.service.UserSellerService;
import com.pajk.kylin.apigw.model.domain.UserInfoDTO;
import com.pajk.plutus.biz.exceptions.BaseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author david
 * @since created by on 17/11/10 10:06
 */
@Component
public class UserManger {

    private final Logger logger = LoggerFactory.getLogger(UserManger.class);

    @Autowired
    private PermissionService permissionService;




    /**
     * 获取当前用户角色,
     * todo 后期要改掉 必须携带 appId
     *
     * @return 角色
     */
    public String getCurrentUserRole() {
        long userId = UserUtil.getCurrentUser().getId();
        return getCurrentUserRole(userId, null);
    }


    /**
     * 获取当前用户角色
     *
     * @param userId 用户ID
     * @return 角色
     */
    public String getCurrentUserRole(long userId, Long appId) {
        // 从 kylin 获取用户当前角色
        KyCallResult<String> result = permissionService.getCurRole(userId, appId);
        if (result == null || !result.isSuccess()) {
            String errorMsg = JSONObject.toJSONString(result);
            logger.warn("get user role fail. userId:{}, out:{}", userId, errorMsg);
            throw new BaseException(BaseException.NO_PERMISSION_ERROR, "获取用户角色失败. userId:" + userId + ", out:" + errorMsg);
        }
        return result.getModel();
    }
}
