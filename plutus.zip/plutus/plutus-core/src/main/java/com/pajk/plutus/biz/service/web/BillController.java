package com.pajk.plutus.biz.service.web;

import com.pajk.plutus.biz.common.util.ResultUtil;
import com.pajk.plutus.biz.exceptions.BaseException;
import com.pajk.plutus.biz.manager.BillManager;
import com.pajk.plutus.biz.manager.permission.AuthResourceProperties;
import com.pajk.plutus.biz.manager.permission.UserManger;
import com.pajk.plutus.biz.manager.permission.UserUtil;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.biz.model.query.bill.BillLogDTO;
import com.pajk.plutus.biz.model.query.bill.InvoiceInfoDTO;
import com.pajk.plutus.biz.model.query.bill.PaymentInfoDTO;
import com.pajk.plutus.biz.model.query.bill.RemarkDTO;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Objects;

/**
 * Created by arjaylv on 2017/12/13.
 *
 * @author arjaylv
 */
@RestController("billController")
@RequestMapping(value = "/plutus/bill")
public class BillController extends AbstractWebController {
    private static final Logger logger = LoggerFactory.getLogger(BillController.class);

    private static final String OPT_GROUP = "opt.bill";
    private static final String OPT_ACT = "update";

    private static final int MAX_REMARK_COUNT = 500;
    private static final int MAX_CONFIRM_STRING_LENGTH = 100;

    @Autowired
    private BillManager billManager;

    @Autowired
    private UserManger userManger;

    private BillLogDTO buildBillLog() {
        String role = userManger.getCurrentUserRole();

        // 1. 获取角色并校验
        if (Objects.isNull(role)) {
            throw new BaseException(ErrorCode.NO_PERMISSION_TO_OPT.getCode(),
                    ErrorCode.NO_PERMISSION_TO_OPT.getDesc());
        }
        // 2. 获取用户信息
        String userName = UserUtil.getUserName();
        if (StringUtils.isBlank(userName)) {
            logger.warn("{}'s userName is blank", role);
            throw new BaseException(ErrorCode.NO_PERMISSION_TO_OPT.getCode(),
                    ErrorCode.NO_PERMISSION_TO_OPT.getDesc());
        }

        BillLogDTO billLogDTO = new BillLogDTO();
        billLogDTO.setOperatorId(UserUtil.getUserId());
        billLogDTO.setRole(role);
        billLogDTO.setOperatorName(userName);

        return billLogDTO;
    }

    /**
     * 确认/驳回账单
     *
     * @param remarkDTO 备注数据
     * @return 返回结果
     */
    @RequestMapping(value = "/confirmSettlement", method = RequestMethod.POST)
    public ResultDTO<VoidEntity> confirmSettlement(@Valid @RequestBody RemarkDTO remarkDTO) {
        String path = "bill/confirmSettlement";

        if (StringUtils.length(remarkDTO.getRemark()) > MAX_REMARK_COUNT) {
            return ResultUtil.returnResultDTO(ErrorCode.REMARK_TOO_LONG);
        }

        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        userParam.setPath(path);

        return wrapper(() -> {
            BillLogDTO billLogDTO = buildBillLog();
            billLogDTO.setRemark(remarkDTO.getRemark());
            return billManager.confirmOnlyRemark(remarkDTO.getBillId(), remarkDTO.getButtonKey(), billLogDTO, userParam);
        }, OPT_GROUP, OPT_ACT);
    }

    /**
     * 确认开票
     *
     * @param invoiceInfoDTO 发票数据
     * @return 返回结果
     */
    @RequestMapping(value = "/confirmInvoice", method = RequestMethod.POST)
    public ResultDTO<VoidEntity> confirmInvoice(@Valid @RequestBody InvoiceInfoDTO invoiceInfoDTO) {
        String path = "bill/confirmInvoice";

        if (invoiceInfoDTO.getInvoiceAmt() == null) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        if (invoiceInfoDTO.getInvoiceTaxAmt() == null) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        if (StringUtils.isBlank(invoiceInfoDTO.getInvoiceId())
                || StringUtils.length(invoiceInfoDTO.getInvoiceId()) > MAX_CONFIRM_STRING_LENGTH) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        if (StringUtils.isBlank(invoiceInfoDTO.getInvoiceTrackingNumber())
                || StringUtils.length(invoiceInfoDTO.getInvoiceTrackingNumber()) > MAX_CONFIRM_STRING_LENGTH) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        userParam.setPath(path);

        return wrapper(() -> {
            BillLogDTO billLogDTO = buildBillLog();

            return billManager.confirmInvoice(invoiceInfoDTO, billLogDTO, userParam, false);
        }, OPT_GROUP, OPT_ACT);
    }

    /**
     * 确认/驳回收票
     *
     * @param remarkDTO 备注数据
     * @return 返回结果
     */
    @RequestMapping(value = "/receiveInvoice", method = RequestMethod.POST)
    public ResultDTO<VoidEntity> receiveInvoice(@Valid @RequestBody RemarkDTO remarkDTO) {
        String path = "bill/receiveInvoice";

        if (StringUtils.length(remarkDTO.getRemark()) > MAX_REMARK_COUNT) {
            return ResultUtil.returnResultDTO(ErrorCode.REMARK_TOO_LONG);
        }

        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        userParam.setPath(path);

        return wrapper(() -> {
            BillLogDTO billLogDTO = buildBillLog();

            billLogDTO.setRemark(remarkDTO.getRemark());
            return billManager.receiveInvoice(remarkDTO.getBillId(), remarkDTO.getButtonKey(), billLogDTO, userParam);
        }, OPT_GROUP, OPT_ACT);
    }

    /**
     * 确认付款
     *
     * @param paymentInfoDTO 付款数据
     * @return 返回数据
     */
    @RequestMapping(value = "/confirmPayment", method = RequestMethod.POST)
    public ResultDTO<VoidEntity> confirmPayment(@Valid @RequestBody PaymentInfoDTO paymentInfoDTO) {
        String path = "bill/confirmPayment";

        if (StringUtils.isBlank(paymentInfoDTO.getPaymentNo())) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        if (StringUtils.length(paymentInfoDTO.getPaymentNo()) > MAX_CONFIRM_STRING_LENGTH) {
            return ResultUtil.returnResultDTO(ErrorCode.PAYMENT_NO_TOO_LONG);
        }

        if (StringUtils.length(paymentInfoDTO.getPaymentFileId()) > MAX_CONFIRM_STRING_LENGTH) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        if (StringUtils.length(paymentInfoDTO.getPaymentFileName()) > MAX_CONFIRM_STRING_LENGTH) {
            return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
        }

        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        userParam.setPath(path);

        return wrapper(() -> {
            BillLogDTO billLogDTO = buildBillLog();

            return billManager.confirmPayment(paymentInfoDTO, billLogDTO, userParam, false);
        }, OPT_GROUP, OPT_ACT);
    }

    /**
     * 确认/驳回收款
     *
     * @param remarkDTO 备注数据
     * @return 返回结果
     */
    @RequestMapping(value = "/confirmReceivePayment", method = RequestMethod.POST)
    public ResultDTO<VoidEntity> confirmReceivePayment(@Valid @RequestBody RemarkDTO remarkDTO) {
        String path = "bill/confirmReceivePayment";

        if (StringUtils.length(remarkDTO.getRemark()) > MAX_REMARK_COUNT) {
            return ResultUtil.returnResultDTO(ErrorCode.REMARK_TOO_LONG);
        }

        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        userParam.setPath(path);

        return wrapper(() -> {
            BillLogDTO billLogDTO = buildBillLog();
            billLogDTO.setRemark(remarkDTO.getRemark());
            return billManager.confirmReceivePayment(remarkDTO.getBillId(), remarkDTO.getButtonKey(), billLogDTO, userParam);
        }, OPT_GROUP, OPT_ACT);
    }

}
