package com.pajk.plutus.biz.model.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by lizhijun on 2017/12/17.
 */
public class VoucherSubTypeDO extends BaseDO {

    private static final long serialVersionUID = 1928656610242046716L;

    private int type;
    private String name;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
