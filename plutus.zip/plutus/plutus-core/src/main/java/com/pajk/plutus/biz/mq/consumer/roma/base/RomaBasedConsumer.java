package com.pajk.plutus.biz.mq.consumer.roma.base;

import com.pajk.plutus.biz.exceptions.RomaException;
import com.pajk.roma.consumer.RomaMessageProcessor;
import com.pajk.roma.consumer.RomaMqConsumerConcurrentlyImpl;
import com.pajk.roma.consumer.RomaMsgConsumer;
import com.pajk.roma.message.RomaDbMessage;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * Created by fanhuafeng on 17/2/27.
 * Modify by fanhuafeng on 17/2/27
 */
public abstract class RomaBasedConsumer {

    private static final Logger logger = LoggerFactory.getLogger(RomaBasedConsumer.class);

    private RomaMsgConsumer romaMsgConsumer;

    private String groupName;

    @Value("${rocketmq.roma.domain.name}")
    private String addr;

    private int minThreadNum = 5;

    private int maxThreadNum = 10;

    private String instanceName;

    //格式db/topics.table.field or db/topics.table
    private String subscribeExpr;

    public void init() throws Exception {
        romaMsgConsumer = new RomaMqConsumerConcurrentlyImpl();
        romaMsgConsumer.setRomaGroupName(groupName);
        romaMsgConsumer.setServerAddr(addr);
        romaMsgConsumer.setConsumeThreadMin(minThreadNum);
        romaMsgConsumer.setConsumeThreadMax(maxThreadNum);

        String[] segs = StringUtils.split(subscribeExpr, '.');
        if (segs.length < 2) {
            throw new RomaException("please check romaMsgConsumer.subscribeExpr");
        }
        if (segs.length == 2) {
            romaMsgConsumer.subscribe(segs[0], segs[1], null);

        } else {
            romaMsgConsumer.subscribe(segs[0], segs[1], segs[2]);
        }
        romaMsgConsumer.registerMessageProcessor(genRomaMessageProcessor());

        try {
            romaMsgConsumer.setInstanceName(instanceName != null ? instanceName : "MC_FINANCE_ROMA_CONSUMER-"
                    + InetAddress.getLocalHost().getHostName());
        } catch (UnknownHostException e) {
            logger.error("getHostName error", e);
        }
        romaMsgConsumer.start();
        logger.info(" [ROMA] consumer start! subExpression={},group={}", subscribeExpr, groupName);
    }

    public abstract RomaMessageProcessor genRomaMessageProcessor();

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public void setMinThreadNum(int minThreadNum) {
        this.minThreadNum = minThreadNum;
    }

    public void setMaxThreadNum(int maxThreadNum) {
        this.maxThreadNum = maxThreadNum;
    }

    public void setSubscribeExpr(String subscribeExpr) {
        this.subscribeExpr = subscribeExpr;
    }

    public String getSubscribeExpr() {
        return subscribeExpr;
    }

    public void setInstanceName(String instanceName) {
        this.instanceName = instanceName;
    }

    protected void convertFromMsg(RomaDbMessage.RomaDbData changedData,
                                  Consumer<RomaDbMessage.RomaDbData.FieldData> consumer) {
        changedData.getFieldsValueList().forEach(consumer);
    }

    protected String digest(RomaDbMessage.RomaDbData msg) {
        return "eventType:" + msg.getEventType() + "==>" + msg.getFieldsValueList().stream().map(
                fd -> fd.getFieldName() + ":[" + fd.getOldValue() + "->"
                        + fd.getNewValue() + "]").collect(Collectors.joining(","));
    }

}
