package com.pajk.plutus.biz.manager;

import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.biz.model.query.account.VoucherPageQuery;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;

import java.util.Date;

/**
 * Created by lizhijun on 2017/12/17.
 */
public interface VoucherManager {

    /**
     * 查询单据详情
     *
     * @param voucherId 单据id
     * @return ResultDTO<VoucherDO>
     */
    ResultDTO<VoucherDO> queryVoucherDetail(long sellerId, String voucherId, UserParam userParam);

    /**
     * 分页查询违规单
     *
     * @param voucherPageQuery 查询参数
     * @return PageResultDTO<VoucherDO>
     */
    PageResultDTO<VoucherDO> pageQueryVoucher(VoucherPageQuery voucherPageQuery, UserParam userParam);

    /**
     * 删除违规单
     *
     * @param voucherId 违规单Id
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> deletePunish(long sellerId, String voucherId, UserParam userParam);

    /**
     * 创建违规单
     *
     * @param sellerId       商户ID
     * @param voucherSubType 单据子类型
     * @param expectAmt      金额
     * @param createFile     附件key
     * @param createRemark   备注
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> createPunish(long sellerId, VoucherSubType voucherSubType, long expectAmt,
                                       String createFile, String createRemark, UserParam userParam);


    /**
     * 提交违规单
     *
     * @param sellerId  卖家ID
     * @param voucherId 违规单ID
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> submitPunish(long sellerId, String voucherId, UserParam userParam);


    /**
     * 审核违规单（一级、二级）
     *
     * @param sellerId      卖家ID
     * @param voucherId     违规单ID
     * @param transitionKey 操作
     * @param nodeKey       节点
     * @param remark        备注
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> auditPunish(long sellerId, String voucherId, String transitionKey,
                                      String nodeKey, String remark, UserParam userParam);

    /**
     *  商家同意或者申述违规单,同意则立即扣余额, 申述则会进入申述中流程
     * @param sellerId       商家id
     * @param voucherId      单据id
     * @param transitionKey  操作
     * @param nodeKey        节点
     * @param evidenceRemark 备注
     * @param evidenceFile   文件
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> sellerDealPunish(long sellerId, String voucherId, String transitionKey, String nodeKey,
                                           String evidenceRemark, String evidenceFile, UserParam userParam);

    /**
     * 修改合同保证金 ,通过传入原始和修改后的价格进行,通过原始价格进行修改. 同时会创建一个合同缴费的缴费单
     * @param sellerId 商家id
     * @param accountBookId  账本id
     * @param baseContractAmt 合同当前金额
     * @param updateContractAmt  希望修改的合同金额
     * @param remark    备注
     * @param userParam  用户参数信息
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> updateContractAmt(long sellerId, long accountBookId, long baseContractAmt,
                                            long updateContractAmt, String remark, UserParam userParam);

    /**
     * 商家确认缴费
     *
     * @param sellerId      商户id
     * @param voucherId     单据id
     * @param transitionKey 操作
     * @param nodeKey       节点
     * @param remark        备注
     * @param evidenceFlow  银行流水
     * @param evidenceFile  证据文件
     * @return ResultDTO<VoidEntity> 返回是否操作成功
     */
    ResultDTO<VoidEntity> sellerConfirmPayment(long sellerId, String voucherId, String transitionKey,
                                               String nodeKey, String remark, String evidenceFlow,
                                               String evidenceFile, UserParam userParam);

    /**
     * 审核缴费单(财务确认收到款项进行审核)
     * @param sellerId  商户id
     * @param voucherId  单据id
     * @param transitionKey 操作
     * @param nodeKey   节点
     * @param remark    备注
     * @param userParam  用户信息
     * @return ResultDTO<VoidEntity> 返回是否操作成功
     */
    ResultDTO<VoidEntity> auditPayment(long sellerId, String voucherId,
                                       String transitionKey, String nodeKey, String remark, UserParam userParam);

    /**
     * 根据违规发货记录生成违规单
     *
     * @param startTime 创建日期查询起始值（包含）
     * @param endTime   创建日期查询截止值（不包含）
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> autoCreatePunish(Date startTime, Date endTime);

    /**
     * 自动同意缴费单(t+4)
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> autoAgreePunish();

    /**
     * 商管创建补齐缴费 如果补齐金额和接口传值不匹配 则提示
     *
     * @param sellerId      商户id
     * @param accountBookId 账本id
     * @param amount        补齐金额
     * @param remark        备注
     * @param userParam     UserParam
     * @return ResultDTO<String>
     */
    ResultDTO<String> addBalanceAmt(long sellerId, long accountBookId, long amount, String remark, UserParam userParam);

    /**
     * 根据所有的完成违规单自动创建补齐保证金的缴费单
     *
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> batchAddBalanceAmt();

}
