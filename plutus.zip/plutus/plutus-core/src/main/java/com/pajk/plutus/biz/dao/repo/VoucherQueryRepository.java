package com.pajk.plutus.biz.dao.repo;

import com.pajk.plutus.biz.model.account.StatementDO;
import com.pajk.plutus.biz.model.query.account.VoucherPageQuery;
import com.pajk.plutus.biz.model.query.voucher.VoucherDeliveryPageQuery;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.model.voucher.VoucherDeliveryDO;

import java.util.List;
import java.util.Optional;

/**
 * Created by lizhijun on 2017/12/17.
 */
public interface VoucherQueryRepository {

    Optional<VoucherDO> queryVoucherById(long sellerId, String voucherId);

    Optional<VoucherDeliveryDO> queryVoucherDeliveryByVoucherId(String voucherId);

    Optional<List<VoucherDO>> pageQueryVoucher(VoucherPageQuery voucherPageQuery);

    int queryVoucherCount(VoucherPageQuery voucherPageQuery);

    /**
     * 根据条件查询违规发货订单数量
     * @param pageQuery     查询条件
     * @return  符合条件的数量
     */
    int queryCount(VoucherDeliveryPageQuery pageQuery);

    /**
     * 根据条件查询违规发货订单
     * @param pageQuery     查询条件
     * @return 符合条件的数据
     */
    Optional<List<VoucherDeliveryDO>> pageQueryVoucherDelivery(VoucherDeliveryPageQuery pageQuery);

    Optional<StatementDO> queryStatementByVoucher(String outType, String voucherId);
}
