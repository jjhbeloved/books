package com.pajk.plutus.biz.model.bill;

import com.google.common.collect.Lists;
import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.List;

/**
 * @author david
 * @since created by on 17/12/14 10:44
 */
public class ConfirmInfoDO extends BaseDO {

    private static final long serialVersionUID = -3238846522329496789L;

    private List<FileInfoDO> fileInfo = Lists.newLinkedList();

    private String remark;

    public List<FileInfoDO> getFileInfo() {
        return fileInfo;
    }

    public void setFileInfoDO(List<FileInfoDO> fileInfo) {
        this.fileInfo = fileInfo;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
