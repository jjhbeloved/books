package com.pajk.plutus.biz.model.mapper.single.bill;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * Created by arjaylv on 2017/12/11.
 *
 * @author arjaylv
 */
public class BillLogDAO extends BaseDO {

    private static final long serialVersionUID = -8791870468970682745L;

    private Long id;

    private Date gmtCreated;

    /**
     * 账单id
     */
    private Long billId;

    /**
     * 记录商户操作时的商户id，平安操作时为空
     */
    private Long sellerId;

    /**
     * 操作者id(用户id)
     */
    private String operatorId;

    /**
     * 操作者名称(用户名称)
     */
    private String operatorName;

    /**
     * 操作者角色
     */
    private String role;

    /**
     * 操作描述
     */
    private String desc;

    /**
     * 操作备注
     */
    private String remark;

    /**
     * 操作动作，账单被操作之后的状态
     */
    private String action;

    /**
     * 商户账单确认上传信息、开票填写信息、付款填写信息在这里也保存一份 JSON字符串格式
     */
    private String billInfo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public String getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getBillInfo() {
        return billInfo;
    }

    public void setBillInfo(String billInfo) {
        this.billInfo = billInfo;
    }

}
