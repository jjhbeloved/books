package com.pajk.plutus.biz.dao.mapper.single.account;

import com.pajk.plutus.biz.model.mapper.single.account.AccountDAO;
import org.apache.ibatis.annotations.Param;

/**
 * Created by  guguangming on 2017/12/15
 **/
public interface AccountMapper {

    int create(AccountDAO accountDAO);
    AccountDAO queryBySeller(@Param("sellerId") long sellerId);
}
