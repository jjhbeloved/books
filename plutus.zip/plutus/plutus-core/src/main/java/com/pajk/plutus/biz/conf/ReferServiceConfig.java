package com.pajk.plutus.biz.conf;


import com.alibaba.dubbo.config.spring.ReferenceBean;
import com.pajk.kylin.api.service.*;
import com.pajk.taskcenter.client.service.FlowService;
import com.pajk.user.api.LoginServiceWebExport;
import com.pajk.user.api.UserService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ReferServiceConfig extends DubboConfig {

    @Value("${public.dubbo.version}")
    private String dubboVersion;

    @Bean
    public ReferenceBean<SellerService> sellerService() {
        final ReferenceBean<SellerService> rb = new ReferenceBean<>();
        rb.setVersion(this.dubboVersion);
        rb.setInterface(SellerService.class);
        return rb;
    }

    @Bean
    public ReferenceBean<StoreService> storeService() {
        final ReferenceBean<StoreService> rb = new ReferenceBean<>();
        rb.setVersion(this.dubboVersion);
        rb.setInterface(StoreService.class);
        return rb;
    }

    @Bean
    public ReferenceBean<UserService> userService() {
        final ReferenceBean<UserService> ref = new ReferenceBean<>();
        ref.setVersion(dubboVersion);
        ref.setInterface(UserService.class);
        ref.setTimeout(60000);
        return ref;
    }

    @Bean
    public ReferenceBean<LoginServiceWebExport> loginServiceWebExport() {
        final ReferenceBean<LoginServiceWebExport> ref = new ReferenceBean<>();
        ref.setVersion(dubboVersion);
        ref.setInterface(LoginServiceWebExport.class);
        ref.setTimeout(60000);
        return ref;
    }

    @Bean
    public ReferenceBean<PermissionService> permissionService() {
        final ReferenceBean<PermissionService> rb = new ReferenceBean<>();
        rb.setVersion(this.dubboVersion);
        rb.setInterface(PermissionService.class);
        rb.setTimeout(3000);
        return rb;
    }

    @Bean
    public ReferenceBean<AppResourceService> appResourceService() {
        final ReferenceBean<AppResourceService> rb = new ReferenceBean<>();
        rb.setVersion(this.dubboVersion);
        rb.setInterface(AppResourceService.class);
        rb.setTimeout(6000);
        return rb;
    }

    @Bean
    public ReferenceBean<UserSellerService> userSellerService() {
        final ReferenceBean<UserSellerService> rb = new ReferenceBean<>();
        rb.setVersion(this.dubboVersion);
        rb.setInterface(UserSellerService.class);
        return rb;
    }

    @Bean
    public ReferenceBean<FlowService> flowService() {
        final ReferenceBean<FlowService> ref = new ReferenceBean<>();
        ref.setVersion(dubboVersion);
        ref.setInterface(FlowService.class);
        ref.setTimeout(6000);
        return ref;
    }

}

