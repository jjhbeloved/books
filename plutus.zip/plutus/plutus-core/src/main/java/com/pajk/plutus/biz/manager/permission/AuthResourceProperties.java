package com.pajk.plutus.biz.manager.permission;

public class AuthResourceProperties {

    //权限资源配置
    public final static long APPID = 90036L;

    public final static long DOMAIN_ID = 90036L;

}
