package com.pajk.plutus.biz.mq.consumer.base;

import com.alibaba.rocketmq.client.consumer.DefaultMQPushConsumer;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import com.alibaba.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.pajk.plutus.biz.common.util.HessianUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

/**
 * Created by fuyongda on 2017/12/11.
 * Modified by fuyongda on 2017/12/11.
 */
public abstract class BaseConsumer implements MessageListenerConcurrently {

    private static final Logger logger = LoggerFactory.getLogger(BaseConsumer.class);

    public static final int DEFAULT_RECONSUME_TIMES = 9;

    // 定时消息相关
    // 线上环境：messageDelayLevel=1s 5s 10s 30s 1m 2m 3m 4m 5m 6m 7m 8m 9m 10m 20m 30m 40m 50m 1h 2h 6h
    // 开发环境：messageDelayLevel=1s 5s 10s 30s 1m 2m 3m 4m 5m 6m 7m 8m 9m 10m 20m 30m 40m 50m 1h 2h 6h 12h 1d
    private static final int[] DELAY_LEVELS = new int[]{3, 5, 9, 14, 15, 16, 17, 18, 19, 20, 21};
    protected DefaultMQPushConsumer consumer;
    protected String nameServer;
    protected int minConsumeThread = 2;
    protected int maxConsumeThread = 5;
    protected String group;
    protected int maxRetryCount = 10;

    public String getNotifyLog() {
        return "MqConsumerNotifyLog";
    }

    public void init() throws Exception {
        if ("localTest".equals(nameServer)) {
            return;
        }
        if (StringUtils.isBlank(System.getProperty("rocketmq.namesrv.domain"))) {
            System.setProperty("rocketmq.namesrv.domain", nameServer);
        }

        consumer = new DefaultMQPushConsumer(getGroup());
        consumer.setNamesrvAddr(nameServer);
        consumer.setConsumeThreadMin(minConsumeThread);
        consumer.setConsumeThreadMax(maxConsumeThread);
        //可以不设置 设置后可以起多个 消费端
        consumer.setInstanceName(getInstanceName());
        //设置订阅的topic 设置订阅过滤表达式
        consumer.subscribe(getTopic(), getTags());
        try {
            consumer.registerMessageListener(this);
            consumer.start();
        } catch (MQClientException e) {
            logger.error("consumer start error!group={}", group, e);
        }
        logger.info("consumer start! group={}", getGroup());
    }

    public void destroy() {
        if (consumer != null) {
            consumer.shutdown();
            logger.info("consumer shutdown! group={}", group);
        }
    }

    /**
     * 基类实现消息监听接口，加上打印metaq监控日志的方法
     */
    @Override
    public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
        long startTime = System.currentTimeMillis();
        logger.info("receive_message:{}", msgs == null ? "0" : Integer.toString(msgs.size()));
        if (CollectionUtils.isEmpty(msgs)) {
            logger.error("receive empty msg!");
            return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
        }
        final int reconsumeTimes = msgs.get(0).getReconsumeTimes();
        if (reconsumeTimes >= maxRetryCount) {
            logger.error("reconsumeTimes > {} msgs:{} context:{}"
                    , maxRetryCount, msgs, context);
        }
        context.setDelayLevelWhenNextConsume(getDelayLevelWhenNextConsume(reconsumeTimes));
        boolean ret = true;
        for (MessageExt message : msgs) {
            if (null == message) {
                continue;
            }
            if (!doConsumeMessage(decodeMsg(message), message.getReconsumeTimes())) {
                ret = false;
            }
        }
        ConsumeConcurrentlyStatus status = ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
        if (!ret) {
            status = ConsumeConcurrentlyStatus.RECONSUME_LATER;
        }
        logger.info("ConsumeConcurrentlyStatus:{}|cost:{}", status, System.currentTimeMillis() - startTime);
        return status;
    }

    //---这个私有方法没人用。。
    private String getKey(String topic, String tags) {
        return topic + "_" + tags;
    }

    /**
     * 根据重试次数设置重新消费延迟时间
     * 1s 10s 30s 2m 10m 30m 1h 2h 12h 1d
     *
     * @param reconsumeTimes 重试的次数
     * @return level级别
     */
    public int getDelayLevelWhenNextConsume(int reconsumeTimes) {
        if (reconsumeTimes >= DELAY_LEVELS.length) {
            return DELAY_LEVELS[DELAY_LEVELS.length - 1];
        }
        return DELAY_LEVELS[reconsumeTimes];
    }

    private Serializable decodeMsg(MessageExt msg) {
        try {
            //1.反序列化
            return HessianUtils.decode(msg.getBody());
        } catch (IOException e) {
            logger.error("反序列化出错!" + e.getMessage(), e);
            return null;
        }
    }

    public void setNameServer(String nameServer) {
        this.nameServer = nameServer;
    }

    public void setMinConsumeThread(int minConsumeThread) {
        this.minConsumeThread = minConsumeThread;
    }

    public void setMaxConsumeThread(int maxConsumeThread) {
        this.maxConsumeThread = maxConsumeThread;
    }

    public String getGroup() {
        return group + "_" + getTopic() + "_" + getTags();
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public abstract String getTopic();

    public abstract String getTags();

    /**
     * @param message
     * @param reconsumeTimes 订阅次数
     * @return
     */
    public abstract boolean doConsumeMessage(Serializable message, int reconsumeTimes);

    public String getInstanceName() {
        return "plutus" + "_" + getTopic() + "_" + getTags();
    }

}
