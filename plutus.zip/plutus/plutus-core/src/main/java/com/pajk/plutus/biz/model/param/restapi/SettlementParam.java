package com.pajk.plutus.biz.model.param.restapi;

import com.pajk.thunderbird.domain.result.BaseDO;

import javax.validation.constraints.NotNull;

/**
 * @author david
 * @since created by on 17/12/21 15:31
 */
public class SettlementParam extends BaseDO {

    private static final long serialVersionUID = 1849051011361416383L;


    private Long sellerId;

    @NotNull
    private Long billId;

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }
}
