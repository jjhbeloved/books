package com.pajk.plutus.biz.model.process;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * 按钮操作相关
 *
 * Created by fuyongda on 2017/12/20.
 * Modified by fuyongda on 2017/12/20.
 */
public class TransitionDO extends BaseDO {

    private static final long serialVersionUID = 4388621710672785714L;

    /**
     * 按钮名
     */
    private String transitionName;

    /**
     * 流程操作参数
     */
    private String transitionKey;

    /**
     * 操作红色部分提示说明
     */
    private String tips;

    public String getTransitionName() {
        return transitionName;
    }

    public void setTransitionName(String transitionName) {
        this.transitionName = transitionName;
    }

    public String getTransitionKey() {
        return transitionKey;
    }

    public void setTransitionKey(String transitionKey) {
        this.transitionKey = transitionKey;
    }

    public String getTips() {
        return tips;
    }

    public void setTips(String tips) {
        this.tips = tips;
    }

}
