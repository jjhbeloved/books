package com.pajk.plutus.biz.model.bill;

import com.pajk.thunderbird.domain.result.BaseDO;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * @author david
 * @since created by on 17/12/14 10:59
 */
public class FileInfoDO extends BaseDO {

    private static final long serialVersionUID = 6974713543996785481L;

    private String confirmFileId;

    private String confirmFileName;

    public String getConfirmFileId() {
        return confirmFileId;
    }

    public void setConfirmFileId(String confirmFileId) {
        this.confirmFileId = confirmFileId;
    }

    public String getConfirmFileName() {
        return confirmFileName;
    }

    public void setConfirmFileName(String confirmFileName) {
        this.confirmFileName = confirmFileName;
    }

    @Override
    public String toString(){
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
