package com.pajk.plutus.biz.model.account;


import com.pajk.plutus.client.model.enums.account.StatementOutType;
import com.pajk.plutus.client.model.enums.account.StatementStatus;
import com.pajk.plutus.client.model.enums.account.SubjectEnum;
import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * 财务应收应付账单表
 */
public class StatementDO extends BaseDO {

    private static final long serialVersionUID = 515142119517674452L;

    /**
     * 主键id
     */
    private long id;

    /**
     * 创建时间
     */
    private Date gmtCreated;

    /**
     * 更新时间
     */
    private Date gmtModified;

    /**
     * 版本号
     */
    private int version;

    /**
     * 卖家id
     */
    private long sellerId;

    /**
     * 状态
     */
    private StatementStatus status;

    /**
     * 外部业务类型 如商城财务系统账单表fc_voucher
     */
    private StatementOutType outType;

    /**
     * 外部业务id
     */
    private String outId;

    /**
     * 财务系统对应记录主键id
     */
    private String financeId;

    /**
     * 科目
     */
    private SubjectEnum subject;

    /**
     * 应收时间
     */
    private Date firstTime;
    /**
     * 应付时间
     */
    private Date secondTime;
    /**
     * 平台应收
     */
    private Long platformReceivable;
    /**
     * 平台应收税费
     */
    private Long platformReceivableTax;
    /**
     * 平台应付
     */
    private Long platformPayable;
    /**
     * 平台应付税费
     */
    private Long platformPayableTax;
    /**
     * 平台实收
     */
    private Long platformReceipts;
    /**
     * 平台实收税费
     */
    private Long platformReceiptsTax;
    /**
     * 平台实付
     */
    private Long platformPaid;
    /**
     * 平台实付税费
     */
    private Long platformPaidTax;
    /**
     * 描述
     */
    private String msg;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public StatementStatus getStatus() {
        return status;
    }

    public void setStatus(StatementStatus status) {
        this.status = status;
    }

    public StatementOutType getOutType() {
        return outType;
    }

    public void setOutType(StatementOutType outType) {
        this.outType = outType;
    }

    public String getOutId() {
        return outId;
    }

    public void setOutId(String outId) {
        this.outId = outId;
    }

    public String getFinanceId() {
        return financeId;
    }

    public void setFinanceId(String financeId) {
        this.financeId = financeId;
    }

    public SubjectEnum getSubject() {
        return subject;
    }

    public void setSubject(SubjectEnum subject) {
        this.subject = subject;
    }

    public Date getFirstTime() {
        return firstTime;
    }

    public void setFirstTime(Date firstTime) {
        this.firstTime = firstTime;
    }

    public Date getSecondTime() {
        return secondTime;
    }

    public void setSecondTime(Date secondTime) {
        this.secondTime = secondTime;
    }

    public Long getPlatformReceivable() {
        return platformReceivable;
    }

    public void setPlatformReceivable(Long platformReceivable) {
        this.platformReceivable = platformReceivable;
    }

    public Long getPlatformReceivableTax() {
        return platformReceivableTax;
    }

    public void setPlatformReceivableTax(Long platformReceivableTax) {
        this.platformReceivableTax = platformReceivableTax;
    }

    public Long getPlatformPayable() {
        return platformPayable;
    }

    public void setPlatformPayable(Long platformPayable) {
        this.platformPayable = platformPayable;
    }

    public Long getPlatformPayableTax() {
        return platformPayableTax;
    }

    public void setPlatformPayableTax(Long platformPayableTax) {
        this.platformPayableTax = platformPayableTax;
    }

    public Long getPlatformReceipts() {
        return platformReceipts;
    }

    public void setPlatformReceipts(Long platformReceipts) {
        this.platformReceipts = platformReceipts;
    }

    public Long getPlatformReceiptsTax() {
        return platformReceiptsTax;
    }

    public void setPlatformReceiptsTax(Long platformReceiptsTax) {
        this.platformReceiptsTax = platformReceiptsTax;
    }

    public Long getPlatformPaid() {
        return platformPaid;
    }

    public void setPlatformPaid(Long platformPaid) {
        this.platformPaid = platformPaid;
    }

    public Long getPlatformPaidTax() {
        return platformPaidTax;
    }

    public void setPlatformPaidTax(Long platformPaidTax) {
        this.platformPaidTax = platformPaidTax;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
