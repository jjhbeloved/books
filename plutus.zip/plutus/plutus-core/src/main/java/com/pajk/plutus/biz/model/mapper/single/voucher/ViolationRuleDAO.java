package com.pajk.plutus.biz.model.mapper.single.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * 违规规则表
 */
public class ViolationRuleDAO extends BaseDO {

    private static final long serialVersionUID = 524088639169006235L;

    /**
     * 主键id
     */
    private long id;

    /**
     * 创建时间
     */
    private Date gmtCreated;

    /**
     * 更新时间
     */
    private Date gmtModified;

    /**
     * 版本号
     */
    private int version;

    /**
     * 是否有效 0 无效 1 有效
     */
    private int status;

    /**
     * 类型 ,发货延迟1 送达延迟 2
     */
    private int ruleType;

    /**
     * 0 免责 1不免责
     */
    private int isDeal;

    /**
     * 规则优先级 211~300 免责 111~200 短时间特殊处理 10~100通用兜底
     */
    private int level;

    /**
     * 支付模式 在线支付1 或货到付款2
     */
    private int payMode;

    /**
     * 订单模式 如b2c 或者o2o
     */
    private String tradeMode;

    /**
     * 结算模式 1 佣金 2 结算价
     */
    private int statementMode;

    /**
     * 计算的日期离当前多少天 8 = T+7 ,拉取订单数据过滤条件
     */
    private int intervalDay;

    /**
     * 规则适用订单确认起始时间时间(在线支付支付时间 cod下单时间)
     */
    private Date tradeTimeStart;

    /**
     * 规则适用订单确认结束时间时间(在线支付支付时间 cod下单时间)
     */
    private Date tradeTimeEnd;

    /**
     * 规则适用商户,多个seller,逗号隔开(不能超过50个)
     */
    private String sellerIds;

    /**
     * sku的type|subType 单个
     */
    private String skuType;

    /**
     * 退款_商品_货到付款现金_商家收款(分)
     * 不含邮、不含税
     */
    private String uProvCode;

    /**
     * 商家收款:佣金商品销售总金额(分)
     * 平台收款:毛利商品销售总金额(分)
     */
    private String uCityCode;

    /**
     * 商家收款:退款_佣金商品销售总金额(分)
     * 平台收款:退款_毛利商品销售总金额(分)
     */
    private String uAreaCode;

    /**
     * 商家收款:退款_商品佣金_总金额(分)
     * 平台收款:退款_毛利商品_毛利额(分)
     */
    private String uProv;

    /**
     * 结算商品销售总金额(分)
     */
    private String uCity;

    /**
     * 退款_结算商品销售总金额(分)
     */
    private String uArea;

    /**
     * 省编号 (发货地址)
     */
    private String sProvCode;

    /**
     * 市编号 (发货地址)
     */
    private String sCityCode;

    /**
     * 区编号 (发货地址)
     */
    private String sAreaCode;

    /**
     * 省 (发货地址)
     */
    private String sProv;

    /**
     * 市 (发货地址)
     */
    private String sCity;

    /**
     * 区 (发货地址)
     */
    private String sArea;

    /**
     * 物流最晚发货可使用分钟数 或最晚送达时间可使用分钟数 阀值,
     */
    private long latestTime;

    /**
     * 最小处罚金额(单位分)
     */
    private long minMoney;

    /**
     * 最大处罚金额(单位分)
     */
    private long maxMoney;

    /**
     * 处罚万分比率 如30% 那么值是 3000
     */
    private long punishRate;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getRuleType() {
        return ruleType;
    }

    public void setRuleType(int ruleType) {
        this.ruleType = ruleType;
    }

    public int getIsDeal() {
        return isDeal;
    }

    public void setIsDeal(int isDeal) {
        this.isDeal = isDeal;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getPayMode() {
        return payMode;
    }

    public void setPayMode(int payMode) {
        this.payMode = payMode;
    }

    public String getTradeMode() {
        return tradeMode;
    }

    public void setTradeMode(String tradeMode) {
        this.tradeMode = tradeMode;
    }

    public int getStatementMode() {
        return statementMode;
    }

    public void setStatementMode(int statementMode) {
        this.statementMode = statementMode;
    }

    public int getIntervalDay() {
        return intervalDay;
    }

    public void setIntervalDay(int intervalDay) {
        this.intervalDay = intervalDay;
    }

    public Date getTradeTimeStart() {
        return tradeTimeStart;
    }

    public void setTradeTimeStart(Date tradeTimeStart) {
        this.tradeTimeStart = tradeTimeStart;
    }

    public Date getTradeTimeEnd() {
        return tradeTimeEnd;
    }

    public void setTradeTimeEnd(Date tradeTimeEnd) {
        this.tradeTimeEnd = tradeTimeEnd;
    }

    public String getSellerIds() {
        return sellerIds;
    }

    public void setSellerIds(String sellerIds) {
        this.sellerIds = sellerIds;
    }

    public String getSkuType() {
        return skuType;
    }

    public void setSkuType(String skuType) {
        this.skuType = skuType;
    }

    public String getuProvCode() {
        return uProvCode;
    }

    public void setuProvCode(String uProvCode) {
        this.uProvCode = uProvCode;
    }

    public String getuCityCode() {
        return uCityCode;
    }

    public void setuCityCode(String uCityCode) {
        this.uCityCode = uCityCode;
    }

    public String getuAreaCode() {
        return uAreaCode;
    }

    public void setuAreaCode(String uAreaCode) {
        this.uAreaCode = uAreaCode;
    }

    public String getuProv() {
        return uProv;
    }

    public void setuProv(String uProv) {
        this.uProv = uProv;
    }

    public String getuCity() {
        return uCity;
    }

    public void setuCity(String uCity) {
        this.uCity = uCity;
    }

    public String getuArea() {
        return uArea;
    }

    public void setuArea(String uArea) {
        this.uArea = uArea;
    }

    public String getsProvCode() {
        return sProvCode;
    }

    public void setsProvCode(String sProvCode) {
        this.sProvCode = sProvCode;
    }

    public String getsCityCode() {
        return sCityCode;
    }

    public void setsCityCode(String sCityCode) {
        this.sCityCode = sCityCode;
    }

    public String getsAreaCode() {
        return sAreaCode;
    }

    public void setsAreaCode(String sAreaCode) {
        this.sAreaCode = sAreaCode;
    }

    public String getsProv() {
        return sProv;
    }

    public void setsProv(String sProv) {
        this.sProv = sProv;
    }

    public String getsCity() {
        return sCity;
    }

    public void setsCity(String sCity) {
        this.sCity = sCity;
    }

    public String getsArea() {
        return sArea;
    }

    public void setsArea(String sArea) {
        this.sArea = sArea;
    }

    public long getLatestTime() {
        return latestTime;
    }

    public void setLatestTime(long latestTime) {
        this.latestTime = latestTime;
    }

    public long getMinMoney() {
        return minMoney;
    }

    public void setMinMoney(long minMoney) {
        this.minMoney = minMoney;
    }

    public long getMaxMoney() {
        return maxMoney;
    }

    public void setMaxMoney(long maxMoney) {
        this.maxMoney = maxMoney;
    }

    public long getPunishRate() {
        return punishRate;
    }

    public void setPunishRate(long punishRate) {
        this.punishRate = punishRate;
    }

}
