package com.pajk.plutus.biz.manager.impl;

import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyBatchResult;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.common.util.JsonUtil;
import com.pajk.plutus.biz.common.util.ResultUtil;
import com.pajk.plutus.biz.common.util.TimeUtils;
import com.pajk.plutus.biz.dao.repo.AccountQueryRepository;
import com.pajk.plutus.biz.dao.repo.AccountRepository;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.manager.TransactionWrapper;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.account.AccountBookFlowDO;
import com.pajk.plutus.biz.model.account.AccountDO;
import com.pajk.plutus.biz.model.query.account.BookFlowPageQuery;
import com.pajk.plutus.biz.model.query.account.BookPageQuery;
import com.pajk.plutus.client.model.enums.account.BookFlowSubType;
import com.pajk.plutus.client.model.enums.account.BookFlowType;
import com.pajk.plutus.client.model.enums.account.BookType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by lizhijun on 2017/12/17.
 */
@Component
public class AccountManagerImpl extends AbstractManagerImpl implements AccountManager, TransactionWrapper {

    @Autowired
    private AccountQueryRepository accountQueryRepository;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private ControlCache controlCache;

    @Override
    public PageResultDTO<AccountBookDO> pageQueryBook(BookPageQuery bookPageQuery){
        int total = accountQueryRepository.queryBookCount(bookPageQuery);
        PageResultDTO<AccountBookDO> pageResultDTO = new PageResultDTO<>();
        pageResultDTO.setPageNo(bookPageQuery.getPageNo());
        pageResultDTO.setPageSize(bookPageQuery.getPageSize());
        if (0 >= total) {
            return pageResultDTO;
        }
        pageResultDTO.setTotalCount(total);

        Optional<List<AccountBookDO>> optional = accountQueryRepository.pageQueryBook(bookPageQuery);

        pageResultDTO.setModel(optional.orElseGet(LinkedList::new));

        return pageResultDTO;
    }

    @Override
    public ResultDTO<AccountBookDO> queryBookBySeller(long sellerId, BookType bookType){
        Optional<List<AccountBookDO>> optional = accountQueryRepository.queryBookBySeller(sellerId);
        ResultDTO<AccountBookDO> resultDTO = new ResultDTO<>();
        if (optional.isPresent()){
            AccountBookDO bookResult = optional.get().stream().
                    filter(bookDO -> bookType.isEquals(bookDO.getBookType())).findFirst().orElse(null);

            if(null !=  bookResult){
                resultDTO.setModel(bookResult);
                return resultDTO;
            }

        }
        return ResultUtil.returnResultDTO(ErrorCode.BOOK_NOT_EXISTS);
    }

    @Override
    public ResultDTO<Long> queryMustAddAmt(long sellerId, long bookId) {

        BookFlowPageQuery pageQuery = new BookFlowPageQuery();
        pageQuery.setSellerId(sellerId);
        pageQuery.setBookId(bookId);
        pageQuery.setHasWriteOff(false);
        List<Integer> flowTypes = new LinkedList<>();
        flowTypes.add(BookFlowType.VIOLATION.getCode());
        pageQuery.setFlowTypes(flowTypes);
        Date endDate = new Date();
        pageQuery.setStatementEnd(endDate);
        int span = controlCache.getAccountBookFlowWriteOffQueryDaySpan();
        pageQuery.setStatementStart(TimeUtils.addDate(endDate,-span));

        int total = accountQueryRepository.queryBookFlowCount(pageQuery);
        long amount = 0L;
        ResultDTO<Long> resultDTO = new ResultDTO<>();
        if(total <= 0){
            resultDTO.setModel(0L);
            return resultDTO;
        }

        int pageSize = 1000;
        int index = total % pageSize == 0 ? total / pageSize : total / pageSize + 1;
        pageQuery.setPageSize(pageSize);
        for (int i =0 ; i < index ; i++){
            pageQuery.setPageNo(i + 1);
            Optional<List<AccountBookFlowDO>> optional = accountQueryRepository.pageQueryBookFlow(pageQuery);
            if(optional.isPresent()){
                amount += optional.get().stream().mapToLong(AccountBookFlowDO::getAmount).sum();
            }
        }
        resultDTO.setModel(Math.abs(amount));
        return resultDTO;
    }

    @Override
    public ResultDTO<VoidEntity> doWriteOff(long bookFlowId) {

        Optional<AccountBookFlowDO> bookFlowDOOption = accountQueryRepository.queryBookFlowById(bookFlowId);
        if(!bookFlowDOOption.isPresent()){
            return ResultUtil.returnResultDTO(ErrorCode.WRITE_OFF_FLOW_NOT_EXISTS);
        }
        AccountBookFlowDO bookFlowDO = bookFlowDOOption.get();
        if(!BookFlowSubType.PAY_IN_BACK_DEPOSIT.isEquals(bookFlowDO.getFlowSubType())){
            return new ResultDTO<>();
        }

        int total = accountQueryRepository.queryBookFlowCountByWriteOffId(
                bookFlowDO.getBookType().getCode(),bookFlowDO.getOutType().getCode(),String.valueOf(bookFlowDO.getOutId()));
        if(total <= 0 ){
            logger.warn("[doWriteOff] fail,count={} , bookFlowId={}",total,bookFlowId);
            return ResultUtil.returnResultDTO(ErrorCode.WRITE_OFF_FLOW_NOT_EXISTS);
        }
        int pageSize= 1000;
        int index = total % pageSize == 0 ? total / pageSize : total / pageSize + 1;
        List<Long> ids = new LinkedList<>();
        for (int i =0 ; i < index ; i++){
            Optional<List<Long>> optional = accountQueryRepository
                    .queryBookFlowIdsByWriteOffId(bookFlowDO.getBookType().getCode(),
                            bookFlowDO.getOutType().getCode(), String.valueOf(bookFlowDO.getOutId()), i+1 , pageSize);
            optional.ifPresent(ids::addAll);
        }

        return transactionWrapper(() -> {
            accountRepository.updateWriteOffToFinish(bookFlowId,bookFlowDO.getVersion(),ids,pageSize);
            return new ResultDTO<>();
        }, "account.doWriteOff");
    }

    @Override
    public PageResultDTO<AccountBookFlowDO> pageQueryBookFlow(BookFlowPageQuery bookFlowPageQuery){
        PageResultDTO<AccountBookFlowDO> pageResult = new PageResultDTO<>();
        pageResult.setPageNo(bookFlowPageQuery.getPageNo());
        pageResult.setPageSize(bookFlowPageQuery.getPageSize());
        //查询都是完成了流水  通过给到gmt_statement来走索引
        if (null == bookFlowPageQuery.getStatementEnd() && null == bookFlowPageQuery.getStatementStart()){
            Date date = new Date();
            bookFlowPageQuery.setStatementEnd(date);
            bookFlowPageQuery.setStatementStart(TimeUtils.addDate(date,-controlCache.getAccountBookFlowDefaultQueryDaySpan()));
        }
        int count = accountQueryRepository.queryBookFlowCount(bookFlowPageQuery);
        pageResult.setTotalCount(count);

        accountQueryRepository.pageQueryBookFlow(bookFlowPageQuery).ifPresent(pageResult::setModel);

        return pageResult;
    }


    /**
     * 根据seller创建账户 账本(保证金,积分,馈赠金,年费)
     */
    @Override
    public ResultDTO<VoidEntity> createAccount(long sellerId){
        KyCallResult<SellerDO> kyCallResult = sellerService.getSellerById(sellerId);
        if(!kyCallResult.isSuccess()){
            return  ResultUtil.returnResultDTO(ErrorCode.SELLER_NOT_EXISTS);
        }

        Optional<AccountDO> optionalAccountDO = accountQueryRepository.queryAccountBySeller(sellerId);

        Map<BookType,AccountBookDO> bookDOMap = new HashMap<>() ;
        AccountDO accountDO;
        if(optionalAccountDO.isPresent()){
            accountDO = optionalAccountDO.get();
            Optional<List<AccountBookDO>> optionalBookDO = accountQueryRepository.queryBookBySeller(sellerId);
            optionalBookDO.ifPresent(bookDOs -> bookDOMap.putAll(bookDOs.stream().collect(Collectors.toMap(AccountBookDO::getBookType,sellerDO->sellerDO))));
        }else{
            accountDO = new AccountDO();
            accountDO.setSellerId(sellerId);
            accountDO.setName(kyCallResult.getModel().getName());
        }
        List<AccountBookDO> bookDOs = new LinkedList<>();
        if(!bookDOMap.containsKey(BookType.DEPOSIT)){
            bookDOs.add(buildBook(sellerId, BookType.DEPOSIT.getCode()));
        }
        if(!bookDOMap.containsKey(BookType.GIFT)){
            bookDOs.add(buildBook(sellerId, BookType.GIFT.getCode()));
        }
        if(!bookDOMap.containsKey(BookType.INTEGRATION)){
            bookDOs.add(buildBook(sellerId, BookType.INTEGRATION.getCode()));
        }
        if(!bookDOMap.containsKey(BookType.ANNUAL_FEE)){
            bookDOs.add(buildBook(sellerId, BookType.ANNUAL_FEE.getCode()));
        }
        if(CollectionUtils.isEmpty(bookDOs)){
            return ResultUtil.returnResultDTO(ErrorCode.SUCCESS);
        }
        AccountDO finalAccountDO = accountDO;

        // TODO: 2017/12/21 失败打出kv报警
        return transactionWrapper(() -> {
            if(finalAccountDO.getId() <= 0L ){
                accountRepository.createAccountAndBook(finalAccountDO,bookDOs);
            }else{
                accountRepository.createAccountBook(bookDOs);
            }
            return new ResultDTO<>();
        }, "account.createAccount");
    }

    @Override
    public ResultDTO<VoidEntity> createAccountByAllSellers(){
        // TODO: 2017/12/21 确定查询所有有效的商户 or 全部商户
        KyBatchResult<SellerDO> allSeller = sellerService.getAllSellers();

        if(!allSeller.isSuccess()){
            logger.warn("query all seller fail");
            return  ResultUtil.returnResultDTO(ErrorCode.SELLER_NOT_EXISTS);
        }

        allSeller.getModel().forEach(seller -> {
            ResultDTO<VoidEntity> resultDTO = createAccount(seller.getId());
            if(!ErrorCode.SUCCESS.eq(resultDTO.getResultCode())){
                logger.warn("[CreateAccount] By SellerId:{} FAIL, resultDTO is {}",
                        seller.getId(), JsonUtil.obj2Str(resultDTO));
            }else{
                logger.info("[CreateAccount] By SellerId:{} SUCCESS", seller.getId());
            }
        });

        return new ResultDTO<>();
    }

    private AccountBookDO buildBook(long sellerId, int bookType){
        AccountBookDO bookDO = new AccountBookDO();
        bookDO.setSellerId(sellerId);
        bookDO.setContractAmt(0L);
        bookDO.setActualContractAmt(0L);
        bookDO.setBalanceAmt(0L);
        bookDO.setFreezingAmt(0L);
        bookDO.setBookType(BookType.valueOf(bookType));
        return bookDO;
    }

}
