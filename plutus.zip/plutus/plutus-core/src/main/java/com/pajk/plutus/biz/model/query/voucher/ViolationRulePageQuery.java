package com.pajk.plutus.biz.model.query.voucher;

import com.pajk.plutus.biz.model.query.PageQuery;

/**
 * Created by cuidongchao on 2017/12/17.
 */
public class ViolationRulePageQuery extends PageQuery {

    /**
     * 支付模式 在线支付1 或货到付款2
     */
    private Integer payMode;

    public Integer getPayMode() {
        return payMode;
    }

    public void setPayMode(Integer payMode) {
        this.payMode = payMode;
    }
}
