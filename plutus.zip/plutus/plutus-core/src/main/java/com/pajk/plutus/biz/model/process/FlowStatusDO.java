package com.pajk.plutus.biz.model.process;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * 页面查询列表的下拉框的状态
 *
 * Created by fuyongda on 2017/12/18.
 * Modified by fuyongda on 2017/12/18.
 */
public class FlowStatusDO extends BaseDO {

    private static final long serialVersionUID = -1848806835460337911L;

    /**
     * 状态的key，擎天柱是nodeKey，诺曼底是nodeCatKey，多个的话用"|"隔开
     */
    private String key;

    /**
     * 中文描述
     */
    private String name;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
