package com.pajk.plutus.biz.service.gw;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.plutus.biz.common.aop.GwLogger;
import com.pajk.plutus.biz.common.util.CommonUtil;
import com.pajk.plutus.biz.common.util.JsonUtil;
import com.pajk.plutus.biz.common.util.TimeUtils;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.AccountManager;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.account.AccountBookFlowDO;
import com.pajk.plutus.biz.model.enums.FlowTypeEnum;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.biz.model.process.FlowStatusDO;
import com.pajk.plutus.biz.model.query.account.BookFlowPageQuery;
import com.pajk.plutus.biz.model.query.account.VoucherPageQuery;
import com.pajk.plutus.biz.model.voucher.PaymentPropDO;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.model.voucher.VoucherDeliveryDO;
import com.pajk.plutus.client.api.gw.DepositQueryGWService;
import com.pajk.plutus.client.model.enums.account.BookFlowType;
import com.pajk.plutus.client.model.enums.account.BookType;
import com.pajk.plutus.client.model.enums.trade.PayMode;
import com.pajk.plutus.client.model.enums.voucher.VoucherButton;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.account.AccountBookFlowGW;
import com.pajk.plutus.client.model.result.gw.account.AccountBookGW;
import com.pajk.plutus.client.model.result.gw.account.PageAccountBookFlowGW;
import com.pajk.plutus.client.model.result.gw.bill.ButtonGW;
import com.pajk.plutus.client.model.result.gw.process.AuditFlowGW;
import com.pajk.plutus.client.model.result.gw.process.BatchNodeCatKeyGW;
import com.pajk.plutus.client.model.result.gw.process.NodeCatKeyGW;
import com.pajk.plutus.client.model.result.gw.process.TransitionGW;
import com.pajk.plutus.client.model.result.gw.voucher.*;
import com.pajk.taskcenter.client.model.dto.NodeDTO;
import com.pajk.taskcenter.client.model.dto.TransitionDTO;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import net.pocrd.dubboext.DubboExtProperty;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by guguangming on 2017/12/13
 */
@Service
@GwLogger
public class DepositQueryGWServiceImpl extends AbstractGwServiceImpl implements DepositQueryGWService {

    private static final Logger logger = LoggerFactory.getLogger(DepositQueryGWServiceImpl.class);
    private static final String VOUCHER = "nmd.voucher";
    private static final String ACCOUNT = "nmd.voucher";
    @Autowired
    private VoucherManager voucherManager;

    @Autowired
    private AccountManager accountManager;

    @Autowired
    private ControlCache controlCache;

    private static final int MAX_SIZE = 10000;
    private static final int MAX_PAGE_SIZE = 100;

    private static final String QUERY = "query";
    private static final String FILE_NAME = "fileName";
    private static final String FILE_KEY = "fileKey";

    @Override
    public PageAccountBookFlowGW pageQuerySellerBookFlow(long appId, long userId, long sellerId, int flowType,
                                                         String startTime, String endTime, int pageNo, int pageSize) {

        ErrorCode errorCode = CommonUtil.checkPage(pageNo, pageSize, MAX_PAGE_SIZE, MAX_SIZE);
        if (!ErrorCode.SUCCESS.eq(errorCode)) {
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }
        BookFlowPageQuery pageQuery = new BookFlowPageQuery();
        pageQuery.setPageNo(pageNo);
        pageQuery.setPageSize(pageSize);
        if (flowType < 0) {
            pageQuery.setFlowTypes(BookFlowType.getCanShowList().stream().
                    map(BookFlowType::getCode).collect(Collectors.toList()));
        } else {
            if (BookFlowType.UNKNOWN.isEquals(BookFlowType.valueOf(flowType))) {
                DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
                return null;
            }
            List<Integer> flowTypes = new LinkedList<>();
            flowTypes.add(flowType);
            pageQuery.setFlowTypes(flowTypes);
        }
        pageQuery.setSellerId(sellerId);

        Date start = TimeUtils.parse(startTime);
        Date end = TimeUtils.parse(endTime);

        if(null != start && null != end){
            if(end.getTime() < start.getTime()){
                DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
                return null;
            }
        }
        pageQuery.setStatementStart(start);
        pageQuery.setStatementEnd(end);

        return gwWrapper(() -> {
            PageResultDTO<AccountBookFlowDO> pageResultDTO = accountManager.pageQueryBookFlow(pageQuery);
            PageAccountBookFlowGW flowGW = new PageAccountBookFlowGW();
            flowGW.pageNo = pageNo;
            flowGW.pageSize = pageSize;
            flowGW.totalCount = pageResultDTO.getTotalCount();
            flowGW.depositFlows = toInfoBookFlowList(pageResultDTO.getModel());
            return flowGW;
        }, userId, sellerId, appId, ACCOUNT, QUERY);

    }

    @Override
    public AccountBookGW querySellerAccountBook(long appId, long userId, long sellerId) {
        return gwWrapper(() -> {
            ResultDTO<AccountBookDO> result = accountManager.queryBookBySeller(sellerId, BookType.DEPOSIT);
            if (ErrorCode.SUCCESS.eq(result.getResultCode())) {
                return toInfoAccountBook(result.getModel());
            }
            DubboExtProperty.setErrorCode(JkApiCode.BOOK_NOT_EXISTS);
            return null;

        }, userId, sellerId, appId, ACCOUNT, QUERY);
    }

    @Override
    public VoucherGW querySellerVoucher(long domainId, long appId, long userId, long sellerId, String voucherId) {
        UserParam userParam = new UserParam(appId, userId, domainId);
        if(!CommonUtil.isValidVoucherId(voucherId)){
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }
        return gwWrapper(() -> {
            ResultDTO<VoucherDO> resultDTO = voucherManager.queryVoucherDetail(sellerId, voucherId, userParam);
            if (!checkVoucherResultDTO(resultDTO)) {
                return null;
            }
            return buildVoucherGW(domainId, userId, resultDTO.getModel());
        }, userId, sellerId, appId, VOUCHER, QUERY);
    }

    @Override
    public VoucherGW querySellerOptVoucher(long domainId, long appId, long userId, long sellerId, String voucherId) {
        UserParam userParam = new UserParam(appId, userId, domainId);
        if(!CommonUtil.isValidVoucherId(voucherId)){
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }
        return gwWrapper(() -> {
            ResultDTO<VoucherDO> resultDTO = voucherManager.queryVoucherDetail(sellerId, voucherId, userParam);
            if (!checkVoucherResultDTO(resultDTO)) {
                return null;
            }
            VoucherDO voucherDO = resultDTO.getModel();
            VoucherGW voucherGW = buildVoucherGW(domainId, userId, voucherDO);
            mergePathAndTransition(appId, userId, voucherGW, voucherDO);
            return voucherGW;
        }, userId, sellerId, appId, VOUCHER, QUERY);
    }


    @Override
    public PageVoucherGW pageQuerySellerVoucher(long appId, long userId, long sellerId, String voucherId,
                                                String nodeCatKey, int voucherType, int voucherSubType,
                                                String commitStart, String commitEnd, int pageNo, int pageSize) {
        UserParam userParam = new UserParam(appId, userId);
        ErrorCode errorCode = CommonUtil.checkPage(pageNo, pageSize, MAX_PAGE_SIZE, MAX_SIZE);

        if (!ErrorCode.SUCCESS.eq(errorCode)) {
            DubboExtProperty.setErrorCode(JkApiCode.QUERY_INTERVAL_OVER_THRESHOLD);
            return null;
        }
        if(StringUtils.isNotBlank(voucherId) && !CommonUtil.isValidVoucherId(voucherId)){
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }
        VoucherType voucherTypeEnum = VoucherType.valueOf(voucherType);
        if (VoucherType.UNKNOWN.isEquals(voucherType)) {
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }

        if (-1 != voucherSubType) {
            VoucherSubType subTypeEnum = VoucherSubType.valueOf(voucherSubType);
            if (VoucherSubType.UNKNOWN.isEquals(subTypeEnum)) {
                DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
                return null;
            }
        }

        Date commitStartDate = TimeUtils.parse(commitStart, TimeUtils.SIMPLE_DATA_FORMAT);
        Date commitEndDate = TimeUtils.parse(commitEnd, TimeUtils.SIMPLE_DATA_FORMAT);
        if (null != commitEndDate) {
            commitEndDate = TimeUtils.getEndOfDate(commitEndDate);
        }

        if (null != commitStartDate && null != commitEndDate) {
            if (commitEndDate.getTime() < commitStartDate.getTime()) {
                DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
                return null;
            }
        } else {
            Date endDate = new Date();
            commitEndDate = endDate;
            int span = controlCache.getVoucherPageQueryDaySpan();
            commitStartDate = TimeUtils.getBeginOfDate(TimeUtils.addDate(endDate, -span));
        }

        VoucherPageQuery voucherPageQuery = toInfoPageQueryParam(sellerId, voucherId, nodeCatKey,
                voucherTypeEnum, voucherSubType, commitStartDate, commitEndDate, pageNo, pageSize);
        return gwWrapper(() -> {
            PageResultDTO<VoucherDO> pageResultDTO = voucherManager.pageQueryVoucher(voucherPageQuery, userParam);
            String role = getCurrentUserRole(userId, appId);
            PageVoucherGW pageVoucherGW = new PageVoucherGW();
            pageVoucherGW.pageNo = pageResultDTO.getPageNo();
            pageVoucherGW.pageSize = pageResultDTO.getPageSize();
            pageVoucherGW.totalCount = pageResultDTO.getTotalCount();
            pageVoucherGW.voucherInfos = pageResultDTO.getModel().stream().
                    map(voucherDO -> toInfoVoucherSummary(voucherDO, role)).collect(Collectors.toList());
            return pageVoucherGW;
        }, userId, sellerId, appId, VOUCHER, QUERY, null);
    }

    @Override
    public BatchNodeCatKeyGW queryStatusByType(long appId, long userId, long sellerId, int voucherType) {
        FlowTypeEnum flowTypeEnum = FlowTypeEnum.valueOfCode(VoucherType.valueOf(voucherType).name().toLowerCase());
        if(FlowTypeEnum.UNKNOWN.isEquals(flowTypeEnum)){
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }
        return gwWrapper(() -> {
            BatchResultDTO<FlowStatusDO> batchResultDTO = batchQueryFlowStatus(flowTypeEnum);
            if (!batchResultDTO.isSuccess()) {
                DubboExtProperty.setErrorCode(JkApiCode.EXCEPTION);
                return null;
            }

            List<NodeCatKeyGW> nodeKeys = batchResultDTO.getModel().stream()
                    .map(this::toInfoNodeCatKeyGW).collect(Collectors.toList());

            BatchNodeCatKeyGW batchNodeCatKeyGW = new BatchNodeCatKeyGW();
            batchNodeCatKeyGW.nodeKeys = nodeKeys;
            return batchNodeCatKeyGW;
        }, userId, sellerId, appId, VOUCHER, QUERY);
    }

    @Override
    public BatchVoucherSubTypeGW queryVoucherSubType(long appId, long userId, long sellerId, int voucherType,
                                                     boolean isCanHandleCreate) {
        if (VoucherType.UNKNOWN.isEquals(VoucherType.valueOf(voucherType))) {
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }

        return gwWrapper(() -> {
            List<VoucherSubType> subTypes = VoucherSubType.getListByType(voucherType, isCanHandleCreate);

            List<VoucherSubTypeGW> voucherSubTypeGWS = subTypes.stream().map(voucherSubType -> {
                VoucherSubTypeGW subTypeGW = new VoucherSubTypeGW();
                subTypeGW.name = voucherSubType.getDesc();
                subTypeGW.type = voucherSubType.getCode();
                return subTypeGW;
            }).collect(Collectors.toList());

            BatchVoucherSubTypeGW batchVoucherSubTypeGW = new BatchVoucherSubTypeGW();
            batchVoucherSubTypeGW.voucherSubTypes = voucherSubTypeGWS;
            return batchVoucherSubTypeGW;

        }, userId, sellerId, appId, VOUCHER, QUERY);
    }

    private boolean checkVoucherResultDTO(ResultDTO<VoucherDO> resultDTO) {
        if (!resultDTO.isSuccess()) {
            if (ErrorCode.VOUCHER_NOT_EXISTS.eq(resultDTO.getResultCode())) {
                DubboExtProperty.setErrorCode(JkApiCode.VOUCHER_NOT_EXISTS);
                return false;
            } else if (ErrorCode.VOUCHER_DELIVERY_NOT_EXISTS.eq(resultDTO.getResultCode())) {
                DubboExtProperty.setErrorCode(JkApiCode.VOUCHER_DELIVERY_NOT_EXISTS);
                return false;
            } else{
                DubboExtProperty.setErrorCode(JkApiCode.EXCEPTION);
                return false;
            }
        }
        return true;
    }

    private VoucherGW buildVoucherGW(long domainId, long userId, VoucherDO voucherDO) {
        VoucherType voucherType = voucherDO.getVoucherType();
        VoucherSubType voucherSubType = voucherDO.getVoucherSubType();

        VoucherGW voucherGW = new VoucherGW();
        voucherGW.voucherId = voucherDO.getVoucherId();
        voucherGW.voucherType = voucherType.getDesc();
        voucherGW.voucherSubType = voucherSubType.getDesc();
        voucherGW.amount = voucherDO.getExpectAmt(); //应缴(扣)金额(单位分)
        voucherGW.nodeKey = voucherDO.getNodeKey();
        voucherGW.createRemark = voucherDO.getCreateRemark();
        voucherGW.evidenceRemark = voucherDO.getEvidenceRemark();

        String procName = voucherDO.getVoucherSubType().getProc().getCode();
        AppResourceDO appResourceDO = getAppResource(procName, voucherDO.getNodeKey());
        if (null != appResourceDO) {
            voucherGW.nodeCatKeyName = appResourceDO.key3;
        }

        voucherGW.createFiles = buildFileInfoGW(domainId, userId, voucherDO.getCreateFile());
        voucherGW.evidenceFiles = buildFileInfoGW(domainId, userId, voucherDO.getEvidenceFile());
        if (VoucherType.PAYMENT.isEquals(voucherType)) {
            voucherGW.paymentProp = toPaymentPropGW(voucherDO.getPaymentPropDO());
        } else if (VoucherType.VIOLATION.isEquals(voucherType) &&
                VoucherSubType.DELAY_DELIVERY_VIOLATION.isEquals(voucherSubType)) {
            voucherGW.tradeDeliveryProp = toVoucherDeliveryGW(voucherDO.getVoucherDeliveryDO());
        }

        long procInstId = NumberUtils.toLong(voucherDO.getProcInstId());
        BatchResultDTO<AuditFlowGW> batchResultDTO = batchQueryAuditFlow(procInstId, procName);
        if (batchResultDTO.isSuccess()) {
            voucherGW.auditFlows = batchResultDTO.getModel();
        }

        return voucherGW;
    }

    private VoucherSummaryGW toInfoVoucherSummary(VoucherDO voucherDO, String role) {
        VoucherSummaryGW summaryGW = new VoucherSummaryGW();
        summaryGW.voucherType = voucherDO.getVoucherType().getDesc();
        summaryGW.amount = voucherDO.getExpectAmt();
        summaryGW.voucherId = voucherDO.getVoucherId();
        summaryGW.voucherType = voucherDO.getVoucherType().getDesc();
        summaryGW.voucherSubType = voucherDO.getVoucherSubType().getDesc();
        summaryGW.procStartTime = TimeUtils.format(voucherDO.getProcStartTime(),TimeUtils.SIMPLE_DATA_FORMAT);
        summaryGW.keyStr = voucherDO.getObjId();

        String procName = voucherDO.getVoucherSubType().getProc().getCode();
        String nodeKey = voucherDO.getNodeKey();
        AppResourceDO resource = getAppResource(procName, nodeKey);
        if (!Objects.isNull(resource)) {
            summaryGW.nodeCatKeyName = resource.val1;

            List<ButtonGW> buttons = new LinkedList<>();
            if (StringUtils.equals(role, voucherDO.getRole())) {
                ButtonGW buttonGw = new ButtonGW();
                buttonGw.name = resource.key3;
                buttonGw.path = VoucherButton.GW_OPT.getCode();
                buttons.add(buttonGw);
            }
            summaryGW.buttons = buttons;
        }

        return summaryGW;
    }

    private VoucherPageQuery toInfoPageQueryParam(long sellerId, String voucherId, String status,
                                                  VoucherType voucherTypeEnum, int voucherSubType,
                                                  Date commitStartDate, Date commitEndDate, int pageNo, int pageSize) {
        VoucherPageQuery pageQuery = new VoucherPageQuery();
        pageQuery.setSellerId(sellerId);
        if (!StringUtils.isEmpty(voucherId)) {
            pageQuery.setVoucherId(voucherId);
        }
        if(StringUtils.isNotBlank(status) && !"all".equals(status)) {
            pageQuery.setNodeCatKeys(Arrays.asList(status.split("\\|")));
        }
        pageQuery.setVoucherType(voucherTypeEnum.getCode());
        if (-1 != voucherSubType) {
            pageQuery.setVoucherSubType(voucherSubType);
        }
        pageQuery.setCommitStart(commitStartDate);
        pageQuery.setCommitEnd(commitEndDate);
        pageQuery.setPageNo(pageNo);
        pageQuery.setPageSize(pageSize);
        return pageQuery;
    }

    private List<FileInfoGW>  buildFileInfoGW(long domainId, long userId, String fileJson) {
        List<FileInfoGW> list = new LinkedList<>();

        if (StringUtils.isNotBlank(fileJson)) {
            JSONArray ja = null;
            try {
                ja = JSONArray.parseArray(fileJson);
            } catch (Exception e) {
                logger.warn("JSONArray.parseArray fail, str is {}", fileJson, e);
            }

            if (null != ja) {
                ja.forEach(n -> {
                    JSONObject jo = (JSONObject) n;
                    FileInfoGW fileInfoGW = new FileInfoGW();

                    String fileName = jo.getString(FILE_NAME);
                    fileInfoGW.fileName = fileName;
                    fileInfoGW.fileKey = buildFileUrl(domainId, userId, jo.getString(FILE_KEY), fileName);
                    list.add(fileInfoGW);
                });
            }
        }

        return list;
    }

    private PaymentPropGW toPaymentPropGW(PaymentPropDO paymentPropDO) {
        if (null == paymentPropDO) {
            return null;
        }

        PaymentPropGW paymentPropGW = new PaymentPropGW();
        paymentPropGW.evidenceFlow = paymentPropDO.getEvidenceFlow();
        return paymentPropGW;
    }

    private VoucherDeliveryGW toVoucherDeliveryGW(VoucherDeliveryDO voucherDeliveryDO) {
        if (null == voucherDeliveryDO) {
            return null;
        }

        VoucherDeliveryGW voucherDeliveryGW = new VoucherDeliveryGW();
        voucherDeliveryGW.tradeId = voucherDeliveryDO.getTradeId();
        voucherDeliveryGW.lgTime = TimeUtils.format(voucherDeliveryDO.getLgTime());
        voucherDeliveryGW.deliveryTime = TimeUtils.format(voucherDeliveryDO.getDeliveryTime());
        voucherDeliveryGW.trackingNumber = voucherDeliveryDO.getTrackingNumber();
        if(null != voucherDeliveryDO.getCompanyId()){
            voucherDeliveryGW.companyId = String.valueOf(voucherDeliveryDO.getCompanyId());
        }
        voucherDeliveryGW.companyName = voucherDeliveryDO.getCompanyName();
        voucherDeliveryGW.address = voucherDeliveryDO.getuProv() + voucherDeliveryDO.getuCity();
        voucherDeliveryGW.amount = voucherDeliveryDO.getAmount();

        if (PayMode.PAY_ONLINE.isEquals(voucherDeliveryDO.getPayMode())) {
            voucherDeliveryGW.payTime = TimeUtils.format(voucherDeliveryDO.getPayTime());
        } else if (PayMode.CASH_ON_DELIVERY.isEquals(voucherDeliveryDO.getPayMode())) {
            voucherDeliveryGW.payTime = TimeUtils.format(voucherDeliveryDO.getCreateTime());
        }
        voucherDeliveryGW.payMode = PayMode.valueOf(voucherDeliveryDO.getPayMode()).name();

        return voucherDeliveryGW;
    }

    private void mergePathAndTransition(long appId, long userId, VoucherGW voucherGW, VoucherDO voucherDO) {
        ResultDTO<String> roleResultDTO = queryRole(appId, userId);
        if (!roleResultDTO.isSuccess()) {
            return;
        }

        String role = roleResultDTO.getModel();
        if (StringUtils.isBlank(role) || !role.equals(voucherDO.getRole())) {
            return;
        }

        NodeDTO nodeDTO = getNodeInfo(NumberUtils.toLong(voucherDO.getProcInstId()), voucherDO.getNodeKey());
        if (null == nodeDTO) {
            return;
        }

        voucherGW.apiName = nodeDTO.getPath();

        String procName = voucherDO.getVoucherSubType().getProc().getCode();
        ResultDTO<String> resultDTO1 = queryNodeTip(procName, voucherDO.getNodeKey());

        List<TransitionDTO> transitionDTOList = nodeDTO.getTransitionDTOList();
        if (!CollectionUtils.isEmpty(transitionDTOList)) {
            JSONObject tipJsonObject = new JSONObject();
            if (resultDTO1.isSuccess()) {
                tipJsonObject = JsonUtil.parseJSONObject(resultDTO1.getModel());
            }

            JSONObject finalTipJsonObject = tipJsonObject;
            voucherGW.flowButtons = transitionDTOList.stream()
                    .map(n -> buildTransitionGW(n, finalTipJsonObject)).collect(Collectors.toList());
        }
    }

    private TransitionGW buildTransitionGW(TransitionDTO transitionDTO, JSONObject jsonObject) {
        if (null == transitionDTO) {
            return null;
        }

        TransitionGW transitionGW = new TransitionGW();
        transitionGW.transitionKey = transitionDTO.getTransitionKey();
        transitionGW.transitionName = transitionDTO.getTransitionName();
        transitionGW.tips = jsonObject.getString(transitionDTO.getTransitionKey());
        return transitionGW;
    }

    private List<AccountBookFlowGW> toInfoBookFlowList(List<AccountBookFlowDO> flowDOs) {
        return flowDOs.stream().map(this::toInfoBookFlow).collect(Collectors.toList());
    }

    private AccountBookFlowGW toInfoBookFlow(AccountBookFlowDO flowDO) {
        AccountBookFlowGW flowGW = new AccountBookFlowGW();
        flowGW.amount = flowDO.getAmount();
        flowGW.flowType = flowDO.getFlowType().getDesc();
        flowGW.gmtFinish = TimeUtils.format(flowDO.getGmtStatement());
        flowGW.voucherId = flowDO.getOutId();
        return flowGW;
    }

    private AccountBookGW toInfoAccountBook(AccountBookDO bookDO) {
        AccountBookGW bookGW = new AccountBookGW();
        bookGW.balanceAmt = bookDO.getBalanceAmt();
        bookGW.contractAmt = bookDO.getContractAmt();
        bookGW.sellerId = bookDO.getSellerId();
        bookGW.sellerName = getSellerName(bookDO.getSellerId());
        return bookGW;

    }

    private NodeCatKeyGW toInfoNodeCatKeyGW(FlowStatusDO flowStatusDO) {
        if (null == flowStatusDO) {
            return null;
        }

        NodeCatKeyGW nodeCatKeyGW = new NodeCatKeyGW();
        nodeCatKeyGW.key = flowStatusDO.getKey();
        nodeCatKeyGW.name = flowStatusDO.getName();
        return nodeCatKeyGW;
    }

}
