package com.pajk.plutus.biz.task;

import com.pajk.hawaii.client.JobExecutionContext;
import com.pajk.hawaii.client.JobListener;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by lizhijun on 2017/12/24.
 */
@Component("autoAgreePunishListener")
public class AutoAgreePunishListener implements JobListener {
    private static final Logger logger = LoggerFactory.getLogger(VoucherDeliveryToVoucherListener.class);

    @Autowired
    private VoucherManager voucherManager;

    @Override
    public void execute(JobExecutionContext context) {
        logger.info("start to execute job: name={}, taskId={}, time={}, param={}",
                getName(), context.getTaskId(), context.getFireTime(), context.getParameter());

        try {
            ResultDTO<VoidEntity> resultDTO = voucherManager.autoAgreePunish();
            if (ErrorCode.SUCCESS.eq(resultDTO.getResultCode())) {
                context.success();
            } else {
                context.failed();
            }
        } catch (Exception e) {
            logger.warn("[AutoAgreePunishListener] execute occurs error:", e);
            context.failed();
        }
        logger.info("end of job: name={}, taskId={}, time={}, param={}",
                getName(), context.getTaskId(), context.getFireTime(), context.getParameter());

    }

    @Override
    public String getName() {
        return AutoAgreePunishListener.class.getName();
    }
}
