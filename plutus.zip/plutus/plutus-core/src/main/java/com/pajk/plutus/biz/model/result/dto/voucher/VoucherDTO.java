package com.pajk.plutus.biz.model.result.dto.voucher;

import com.pajk.plutus.biz.model.result.dto.account.AuditFlowDTO;
import com.pajk.plutus.biz.model.result.dto.process.TransitionDTO;
import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.List;

/**
 * Created by  guguangming on 2017/12/13
 **/
public class VoucherDTO extends BaseDO {

    private static final long serialVersionUID = 5928656610242046766L;

    private long sellerId;

    private String sellerName;

    private String voucherId;

    private String voucherType ;

    private String voucherSubType;

    private long amount;

    private String nodeKeyName;

    private String nodeKey;

    private String createRemark;

    private List<FileInfoDTO> createFiles;

    private String evidenceRemark;

    private List<FileInfoDTO> evidenceFiles;

    private VoucherDeliveryDTO voucherDelivery;

    private PaymentPropDTO paymentProp;

    private List<AuditFlowDTO> auditFlows;

    private List<TransitionDTO> flowButtons;

    private String apiName;

    public String getApiName() {
        return apiName;
    }

    public void setApiName(String apiName) {
        this.apiName = apiName;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public String getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(String voucherId) {
        this.voucherId = voucherId;
    }

    public String getVoucherType() {
        return voucherType;
    }

    public void setVoucherType(String voucherType) {
        this.voucherType = voucherType;
    }

    public String getVoucherSubType() {
        return voucherSubType;
    }

    public void setVoucherSubType(String voucherSubType) {
        this.voucherSubType = voucherSubType;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public String getNodeKeyName() {
        return nodeKeyName;
    }

    public void setNodeKeyName(String nodeKeyName) {
        this.nodeKeyName = nodeKeyName;
    }

    public String getNodeKey() {
        return nodeKey;
    }

    public void setNodeKey(String nodeKey) {
        this.nodeKey = nodeKey;
    }

    public String getCreateRemark() {
        return createRemark;
    }

    public void setCreateRemark(String createRemark) {
        this.createRemark = createRemark;
    }

    public List<FileInfoDTO> getCreateFiles() {
        return createFiles;
    }

    public void setCreateFiles(List<FileInfoDTO> createFiles) {
        this.createFiles = createFiles;
    }

    public String getEvidenceRemark() {
        return evidenceRemark;
    }

    public void setEvidenceRemark(String evidenceRemark) {
        this.evidenceRemark = evidenceRemark;
    }

    public List<FileInfoDTO> getEvidenceFiles() {
        return evidenceFiles;
    }

    public void setEvidenceFiles(List<FileInfoDTO> evidenceFiles) {
        this.evidenceFiles = evidenceFiles;
    }

    public VoucherDeliveryDTO getVoucherDelivery() {
        return voucherDelivery;
    }

    public void setVoucherDelivery(VoucherDeliveryDTO voucherDelivery) {
        this.voucherDelivery = voucherDelivery;
    }

    public PaymentPropDTO getPaymentProp() {
        return paymentProp;
    }

    public void setPaymentProp(PaymentPropDTO paymentProp) {
        this.paymentProp = paymentProp;
    }

    public List<AuditFlowDTO> getAuditFlows() {
        return auditFlows;
    }

    public void setAuditFlows(List<AuditFlowDTO> auditFlows) {
        this.auditFlows = auditFlows;
    }

    public List<TransitionDTO> getFlowButtons() {
        return flowButtons;
    }

    public void setFlowButtons(List<TransitionDTO> flowButtons) {
        this.flowButtons = flowButtons;
    }

}
