package com.pajk.plutus.biz.model.roma;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by fanhuafeng on 17/2/27.
 * Modify by fanhuafeng on 17/2/27
 */
public class ValueChange {

    public static final String SEPARATOR = "->";

    private String oldValue;

    private String newValue;

    public ValueChange() {
    }

    public ValueChange(String oldValue, String newValue) {
        this.oldValue = oldValue;
        this.newValue = newValue;
    }

    public boolean isChanged() {
        return !StringUtils.equals(oldValue, newValue);
    }

    public String getOldValue() {
        return oldValue;
    }

    public void setOldValue(String oldValue) {
        this.oldValue = oldValue;
    }

    public String getNewValue() {
        return newValue;
    }

    public void setNewValue(String newValue) {
        this.newValue = newValue;
    }

    @Override
    public String toString() {
        return (StringUtils.isBlank(oldValue) ? "null" : oldValue) + SEPARATOR +
                (StringUtils.isBlank(newValue) ? "null" : newValue);
    }

}
