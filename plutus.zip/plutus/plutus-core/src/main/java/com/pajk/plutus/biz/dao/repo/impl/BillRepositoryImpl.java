package com.pajk.plutus.biz.dao.repo.impl;

import com.alibaba.fastjson.JSONObject;
import com.pajk.plutus.biz.dao.mapper.single.bill.*;
import com.pajk.plutus.biz.dao.mapper.single.voucher.StatementMapper;
import com.pajk.plutus.biz.dao.repo.BillRepository;
import com.pajk.plutus.biz.model.bill.*;
import com.pajk.plutus.biz.model.mapper.single.bill.*;
import com.pajk.plutus.biz.model.mapper.single.voucher.StatementDAO;
import com.pajk.plutus.biz.model.mapper.single.voucher.StatementUpdateOPT;
import com.pajk.plutus.client.model.enums.account.StatementOutType;
import com.pajk.plutus.client.model.enums.account.StatementStatus;
import com.pajk.plutus.client.model.enums.account.SubjectEnum;
import com.pajk.plutus.client.model.enums.bill.SettlementType;
import com.pajk.plutus.client.model.enums.trade.PayToType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Created by arjaylv on 2017/12/13.
 *
 * @author arjaylv
 */
@Repository
@Transactional(value = "transactionManager", rollbackFor = Exception.class)
public class BillRepositoryImpl implements BillRepository {

    @Autowired
    private BillSettlementMapper billSettlementMapper;

    @Autowired
    private BillSettlementItemMapper billSettlementItemMapper;

    @Autowired
    private InvoiceInfoSnapshotMapper invoiceInfoSnapshotMapper;

    @Autowired
    private AccountInfoSnapshotMapper accountInfoSnapshotMapper;

    @Autowired
    private BillLogMapper billLogMapper;

    @Autowired
    private StatementMapper statementMapper;

    /**
     * 确认收票
     */
    private static final String CONFIRM = "confirm";

    /**
     * 待开票的流程节点
     */
    private static final List<String> INVOICENODEKEYS = Arrays.asList("PAInvoice", "sellerInvoice", "supplierInvoice");

    /**
     * 确认收款的流程节点线
     */
    private static final List<String> RECEIPTEDTRANSITIONKEYS = Arrays.asList("PAReceipted", "sellerReceipted", "supplierReceipted");

    @Override
    public void updateConfirmSettlement(BillSettlementDO billSettlementDO) {
        BillSettlementDAO billSettlementDAO = createBillSettlementDAO(billSettlementDO);
        billSettlementDAO.setActualBillAmt(billSettlementDO.getActualBillAmt());
        ConfirmInfoDO confirmInfoDO = billSettlementDO.getConfirmInfoDO();
        if (!Objects.isNull(confirmInfoDO)) {
            String confirmInfo = JSONObject.toJSONString(confirmInfoDO);
            billSettlementDAO.setConfirmInfo(confirmInfo);
        }
        List<BillSettlementItemDAO> billSettlementItemDAOS = createBillSettlementItemDAOS(billSettlementDO.getBillSettlementItemDOS());
        billSettlementMapper.updateConfirm(billSettlementDAO);
        billSettlementItemDAOS.forEach(billSettlementItemDAO -> billSettlementItemMapper.updateAmt(billSettlementItemDAO));
        billSettlementDO.setInvoiceInfoDO(null);
        billSettlementDO.setPaymentInfoDOS(null);
        BillLogDO billLogDO = createBillLogDO(billSettlementDO);
        logBill(billLogDO);
    }

    @Override
    public void updateConfirmInvoice(BillSettlementDO billSettlementDO, SellerInvoiceInfoDO sellerInvoiceInfoDO) {
        BillSettlementDAO billSettlementDAO = createBillSettlementDAO(billSettlementDO);
        InvoiceInfoDO invoiceInfoDO = billSettlementDO.getInvoiceInfoDO();
        if (!Objects.isNull(invoiceInfoDO)) {
            String confirmInfo = JSONObject.toJSONString(invoiceInfoDO);
            billSettlementDAO.setInvoiceInfo(confirmInfo);
        }
        billSettlementMapper.updateConfirm(billSettlementDAO);
        billSettlementDO.setConfirmInfoDO(null);
        billSettlementDO.setPaymentInfoDOS(null);
        BillLogDO billLogDO = createBillLogDO(billSettlementDO);
        logBill(billLogDO);

        if (!Objects.isNull(sellerInvoiceInfoDO)) {
            InvoiceInfoSnapshotDAO invoiceInfoSnapshotDAO = createInvoiceInfoSnapshotDAO(billSettlementDO.getId(), sellerInvoiceInfoDO);
            invoiceInfoSnapshotMapper.insert(invoiceInfoSnapshotDAO);
        }
    }

    @Override
    public void updateReceiveInvoice(BillSettlementDO billSettlementDO) {
        updateConfirmOnlyRemark(billSettlementDO);

        // 更新应收应付账本税额
        if (CONFIRM.equals(billSettlementDO.getButtonKey())) {
            StatementDAO statementDAO = statementMapper.queryByOutId(StatementOutType.FC_BILL.getCode(),
                    String.valueOf(billSettlementDO.getBillNo()));
            if (statementDAO == null) {
                return;
            }

            StatementUpdateOPT statementUpdateOPT = new StatementUpdateOPT();
            statementUpdateOPT.setId(statementDAO.getId());
            statementUpdateOPT.setVersion(statementDAO.getVersion());
            statementUpdateOPT.setSellerId(statementDAO.getSellerId());
            if (SettlementType.PA_PAY.isEquals(billSettlementDO.getSettlementType())) {
                statementUpdateOPT.setPlatformPayableTax(billSettlementDO.getInvoiceInfoDO().getInvoiceTax());
                statementUpdateOPT.setPlatformPaid(billSettlementDO.getInvoiceInfoDO().getInvoiceAmt());
                statementUpdateOPT.setPlatformPaidTax(billSettlementDO.getInvoiceInfoDO().getInvoiceTax());
            } else if (SettlementType.PA_RECEIPT.isEquals(billSettlementDO.getSettlementType())) {
                statementUpdateOPT.setPlatformReceivableTax(billSettlementDO.getInvoiceInfoDO().getInvoiceTax());
                statementUpdateOPT.setPlatformReceipts(billSettlementDO.getInvoiceInfoDO().getInvoiceAmt());
                statementUpdateOPT.setPlatformReceiptsTax(billSettlementDO.getInvoiceInfoDO().getInvoiceTax());
            }

            statementMapper.updateByOPT(statementUpdateOPT);
        }
    }

    @Override
    public void updateConfirmPayment(BillSettlementDO billSettlementDO, SellerAccountInfoDO sellerAccountInfoDO) {
        BillSettlementDAO billSettlementDAO = createBillSettlementDAO(billSettlementDO);
        List<PaymentInfoDO> paymentInfoDOS = billSettlementDO.getPaymentInfoDOS();
        if (!CollectionUtils.isEmpty(paymentInfoDOS)) {
            String paymentInfo = JSONObject.toJSONString(paymentInfoDOS);
            billSettlementDAO.setPaymentInfo(paymentInfo);
        }
        billSettlementMapper.updateConfirm(billSettlementDAO);
        billSettlementDO.setInvoiceInfoDO(null);
        billSettlementDO.setConfirmInfoDO(null);
        BillLogDO billLogDO = createBillLogDO(billSettlementDO);
        logBill(billLogDO);

        if (!Objects.isNull(sellerAccountInfoDO)) {
            AccountInfoSnapshotDAO accountInfoSnapshotDAO = createAccountInfoSnapshotDAO(billSettlementDO.getId(), sellerAccountInfoDO);
            accountInfoSnapshotMapper.insert(accountInfoSnapshotDAO);
        }
    }

    @Override
    public void updateConfirmReceivePayment(BillSettlementDO billSettlementDO) {
        updateConfirmOnlyRemark(billSettlementDO);

        if (RECEIPTEDTRANSITIONKEYS.contains(billSettlementDO.getButtonKey())) {
            StatementDAO statementDAO = statementMapper.queryByOutId(StatementOutType.FC_BILL.getCode(),
                    String.valueOf(billSettlementDO.getBillNo()));
            if (statementDAO != null) {
                StatementUpdateOPT statementUpdateOPT = new StatementUpdateOPT();
                statementUpdateOPT.setId(statementDAO.getId());
                statementUpdateOPT.setSellerId(statementDAO.getSellerId());
                statementUpdateOPT.setVersion(statementDAO.getVersion());
                statementUpdateOPT.setStatus(StatementStatus.FINISHED.getCode());
                statementMapper.updateByOPT(statementUpdateOPT);
            }
        }
    }

    @Override
    public void updateConfirmOnlyRemark(BillSettlementDO billSettlementDO) {
        BillSettlementDAO billSettlementDAO = createBillSettlementDAO(billSettlementDO);
        billSettlementMapper.updateConfirm(billSettlementDAO);
        BillLogDO billLogDO = createBillLogDO(billSettlementDO);
        billLogDO.setBillInfo(null);
        logBill(billLogDO);

        // 记录应收应付账本
        if (INVOICENODEKEYS.contains(billSettlementDO.getNodeKey())) {
            StatementDAO statementDAO = statementMapper.queryByOutId(StatementOutType.FC_BILL.getCode(),
                    String.valueOf(billSettlementDO.getBillNo()));
            if (statementDAO != null) {
                return;
            }
            statementDAO = new StatementDAO();
            statementDAO.setSellerId(billSettlementDO.getSellerId());
            statementDAO.setStatus(StatementStatus.NO_FINISHED.getCode());
            statementDAO.setOutType(StatementOutType.FC_BILL.getCode());
            statementDAO.setOutId(String.valueOf(billSettlementDO.getBillNo()));
            if (PayToType.PAY_TO_PLATFORM.isEquals(billSettlementDO.getPayToType())
                    && SettlementType.PA_PAY.isEquals(billSettlementDO.getSettlementType())) {
                statementDAO.setSubject(SubjectEnum.ZYMS_PAYF.getCode());
                statementDAO.setPlatformPayable(billSettlementDO.getActualBillAmt());
                statementDAO.setMsg(SubjectEnum.ZYMS_PAYF.getDesc());
            } else if (PayToType.PAY_TO_SELLER.isEquals(billSettlementDO.getPayToType())
                    && SettlementType.PA_PAY.isEquals(billSettlementDO.getSettlementType())) {
                statementDAO.setSubject(SubjectEnum.PTMS_PAYF.getCode());
                statementDAO.setPlatformPayable(billSettlementDO.getActualBillAmt());
                statementDAO.setMsg(SubjectEnum.PTMS_PAYF.getDesc());
            } else if (PayToType.PAY_TO_SELLER.isEquals(billSettlementDO.getPayToType())
                    && SettlementType.PA_RECEIPT.isEquals(billSettlementDO.getSettlementType())) {
                statementDAO.setSubject(SubjectEnum.PTMS_PAYS.getCode());
                statementDAO.setPlatformReceivable(billSettlementDO.getActualBillAmt());
                statementDAO.setMsg(SubjectEnum.PTMS_PAYS.getDesc());
            } else {
                statementDAO.setSubject(SubjectEnum.UNKNOWN.getCode());
            }

            statementMapper.create(statementDAO);
        }
    }

    private void logBill(BillLogDO billLogDO) {
        BillLogDAO billLogDAO = new BillLogDAO();
        billLogDAO.setBillId(billLogDO.getBillId());
        billLogDAO.setSellerId(billLogDO.getSellerId());
        billLogDAO.setOperatorId(billLogDO.getOperatorId());
        billLogDAO.setOperatorName(billLogDO.getOperatorName());
        billLogDAO.setRole(billLogDO.getRole());
        billLogDAO.setDesc(billLogDO.getDesc());
        billLogDAO.setRemark(billLogDO.getRemark());
        billLogDAO.setAction(billLogDO.getAction());

        BillInfoDO billInfoDO = billLogDO.getBillInfo();
        if (!Objects.isNull(billInfoDO)) {
            String billInfo = JSONObject.toJSONString(billInfoDO);
            billLogDAO.setBillInfo(billInfo);
        }
        billLogMapper.insert(billLogDAO);
    }

    private BillSettlementDAO createBillSettlementDAO(BillSettlementDO billSettlementDO) {
        BillSettlementDAO billSettlementDAO = new BillSettlementDAO();
        billSettlementDAO.setId(billSettlementDO.getId());
        billSettlementDAO.setVersion(billSettlementDO.getVersion());
        billSettlementDAO.setSellerId(billSettlementDO.getSellerId());
        billSettlementDAO.setProcInstId(billSettlementDO.getProcInstId());
        billSettlementDAO.setNodeKey(billSettlementDO.getNodeKey());
        billSettlementDAO.setNodeCatKey(billSettlementDO.getNodeCatKey());
        billSettlementDAO.setRole(billSettlementDO.getRole());
        billSettlementDAO.setStartTime(billSettlementDO.getStartTime());
        billSettlementDAO.setFinishTime(billSettlementDO.getFinishTime());
        return billSettlementDAO;
    }

    private BillLogDO createBillLogDO(BillSettlementDO billSettlementDO) {
        BillLogDO billLogDO = billSettlementDO.getBillLogDO();
        billLogDO.setBillId(billSettlementDO.getId());
        billLogDO.setAction(billSettlementDO.getNodeKey());
        BillInfoDO billInfoDO = new BillInfoDO();
        ConfirmInfoDO confirmInfoDO = billSettlementDO.getConfirmInfoDO();
        InvoiceInfoDO invoiceInfoDO = billSettlementDO.getInvoiceInfoDO();
        List<PaymentInfoDO> paymentInfoDOS = billSettlementDO.getPaymentInfoDOS();
        if (Objects.nonNull(confirmInfoDO)) {
            billInfoDO.setConfirmInfo(confirmInfoDO);
        }
        if (Objects.nonNull(invoiceInfoDO)) {
            billInfoDO.setInvoiceInfo(invoiceInfoDO);
        }
        if (!CollectionUtils.isEmpty(paymentInfoDOS)) {
            billInfoDO.setPaymentInfo(paymentInfoDOS);
        }
        billLogDO.setBillInfo(billInfoDO);
        return billLogDO;
    }

    private BillSettlementItemDAO createBillSettlementItemDAO(BillSettlementItemDO billSettlementItemDO) {
        BillSettlementItemDAO billSettlementItemDAO = new BillSettlementItemDAO();
        billSettlementItemDAO.setId(billSettlementItemDO.getId());
        billSettlementItemDAO.setBillId(billSettlementItemDO.getBillId());
        billSettlementItemDAO.setVersion(billSettlementItemDO.getVersion());
        billSettlementItemDAO.setBillType(billSettlementItemDO.getBillType());
        billSettlementItemDAO.setBillAmt(billSettlementItemDO.getBillAmt());
        billSettlementItemDAO.setActualBillAmt(billSettlementItemDO.getActualBillAmt());
        billSettlementItemDAO.setSellerId(billSettlementItemDO.getSellerId());
        return billSettlementItemDAO;
    }

    private List<BillSettlementItemDAO> createBillSettlementItemDAOS(List<BillSettlementItemDO> billSettlementItemDOS) {
        return billSettlementItemDOS
                .stream()
                .map(this::createBillSettlementItemDAO)
                .collect(Collectors.toList());
    }

    private InvoiceInfoSnapshotDAO createInvoiceInfoSnapshotDAO(long billId, SellerInvoiceInfoDO sellerInvoiceInfoDO) {
        InvoiceInfoSnapshotDAO invoiceInfoSnapshotDAO = new InvoiceInfoSnapshotDAO();
        invoiceInfoSnapshotDAO.setBillId(billId);
        invoiceInfoSnapshotDAO.setInvoiceTitle(sellerInvoiceInfoDO.getInvoiceTitle());
        invoiceInfoSnapshotDAO.setContact(sellerInvoiceInfoDO.getContact());
        invoiceInfoSnapshotDAO.setContactTel(sellerInvoiceInfoDO.getContactTel());
        invoiceInfoSnapshotDAO.setTaxpayerNumber(sellerInvoiceInfoDO.getTaxpayerNumber());
        invoiceInfoSnapshotDAO.setAddress(sellerInvoiceInfoDO.getAddress());
        invoiceInfoSnapshotDAO.setInvoiceAddress(sellerInvoiceInfoDO.getInvoiceAddress());
        invoiceInfoSnapshotDAO.setInvoiceTel(sellerInvoiceInfoDO.getInvoiceTel());
        invoiceInfoSnapshotDAO.setInvoiceBankName(sellerInvoiceInfoDO.getInvoiceBankName());
        invoiceInfoSnapshotDAO.setInvoiceBankAccount(sellerInvoiceInfoDO.getInvoiceBankAccount());
        invoiceInfoSnapshotDAO.setInvoiceType(sellerInvoiceInfoDO.getInvoiceType());
        return invoiceInfoSnapshotDAO;
    }

    private AccountInfoSnapshotDAO createAccountInfoSnapshotDAO(long billId, SellerAccountInfoDO sellerAccountInfoDO) {
        AccountInfoSnapshotDAO accountInfoSnapshotDAO = new AccountInfoSnapshotDAO();
        accountInfoSnapshotDAO.setBillId(billId);
        accountInfoSnapshotDAO.setPurchaserAccount(sellerAccountInfoDO.getPurchaserAccount());
        accountInfoSnapshotDAO.setPurchaserAccountName(sellerAccountInfoDO.getPurchaserAccountName());
        accountInfoSnapshotDAO.setPurchaserBankName(sellerAccountInfoDO.getPurchaserBankName());
        return accountInfoSnapshotDAO;
    }

}
