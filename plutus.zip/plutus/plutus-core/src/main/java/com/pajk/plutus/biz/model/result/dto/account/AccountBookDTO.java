package com.pajk.plutus.biz.model.result.dto.account;

import com.pajk.thunderbird.domain.result.BaseDO;


/**
 * Created by  guguangming on 2017/12/13
 **/
public class AccountBookDTO extends BaseDO {
    private static final long serialVersionUID = 4928656610142046766L;
    /**
     * 账本id
     */
    private long accountBookId;
    /**
     * 保证余额
     */
    private long balanceAmt;
    /**
     * 合同金额
     */
    private long contractAmt;
    /**
     * 状态
     */
    private String accountBookStatus;

    /**
     * 状态枚举值
     */
    private int bookStatusCode;

    /**
     * 商户id
     */
    private long sellerId;
    /**
     * 商户名称
     */
    private String sellerName;
    /**
     * 商户类型
     */
    private String sellerType;
    /**
     * 商户状态
     */
    private String sellerStatus;

    public String getAccountBookStatus() {
        return accountBookStatus;
    }

    public void setAccountBookStatus(String accountBookStatus) {
        this.accountBookStatus = accountBookStatus;
    }

    public int getBookStatusCode() {
        return bookStatusCode;
    }

    public void setBookStatusCode(int bookStatusCode) {
        this.bookStatusCode = bookStatusCode;
    }

    public long getAccountBookId() {
        return accountBookId;
    }

    public void setAccountBookId(long accountBookId) {
        this.accountBookId = accountBookId;
    }

    public long getBalanceAmt() {
        return balanceAmt;
    }

    public void setBalanceAmt(long balanceAmt) {
        this.balanceAmt = balanceAmt;
    }

    public long getContractAmt() {
        return contractAmt;
    }

    public void setContractAmt(long contractAmt) {
        this.contractAmt = contractAmt;
    }


    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public String getSellerType() {
        return sellerType;
    }

    public void setSellerType(String sellerType) {
        this.sellerType = sellerType;
    }

    public String getSellerStatus() {
        return sellerStatus;
    }

    public void setSellerStatus(String sellerStatus) {
        this.sellerStatus = sellerStatus;
    }

}
