package com.pajk.plutus.biz.model.mapper.single.bill;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * Created by arjaylv on 2017/12/11.
 *
 * @author arjaylv
 */
public class SellerAccountInfoDAO extends BaseDO {

    private static final long serialVersionUID = -4275772145060864430L;

    private Long id;

    private Date gmtCreated;

    private Date gmtModified;

    private Integer version;

    private Long sellerId;

    /**
     * 状态 0:可用 1:不可用
     */
    private Integer status;

    /**
     * 账户类型 1:收款账户 2:打款账户
     */
    private Integer accountType;

    /**
     * 收款的银行账户
     */
    private String purchaserAccount;

    /**
     * 收款的银行账户名称
     */
    private String purchaserAccountName;

    /**
     * 收款的开户行
     */
    private String purchaserBankName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getAccountType() {
        return accountType;
    }

    public void setAccountType(Integer accountType) {
        this.accountType = accountType;
    }

    public String getPurchaserAccount() {
        return purchaserAccount;
    }

    public void setPurchaserAccount(String purchaserAccount) {
        this.purchaserAccount = purchaserAccount;
    }

    public String getPurchaserAccountName() {
        return purchaserAccountName;
    }

    public void setPurchaserAccountName(String purchaserAccountName) {
        this.purchaserAccountName = purchaserAccountName;
    }

    public String getPurchaserBankName() {
        return purchaserBankName;
    }

    public void setPurchaserBankName(String purchaserBankName) {
        this.purchaserBankName = purchaserBankName;
    }

}
