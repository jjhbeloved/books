package com.pajk.plutus.biz.dao.repo.impl;

import com.pajk.plutus.biz.dao.mapper.single.account.AccountBookFlowMapper;
import com.pajk.plutus.biz.dao.mapper.single.account.AccountBookMapper;
import com.pajk.plutus.biz.dao.mapper.single.voucher.StatementMapper;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherDeliveryMapper;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherLogMapper;
import com.pajk.plutus.biz.dao.mapper.single.voucher.VoucherMapper;
import com.pajk.plutus.biz.dao.repo.VoucherRepository;
import com.pajk.plutus.biz.exceptions.DBException;
import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.account.AccountBookFlowDO;
import com.pajk.plutus.biz.model.account.StatementDO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookFlowDAO;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookFlowUpdateOPT;
import com.pajk.plutus.biz.model.mapper.single.account.AccountBookUpdateOPT;
import com.pajk.plutus.biz.model.mapper.single.voucher.*;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.model.voucher.VoucherDeliveryDO;
import com.pajk.plutus.biz.model.voucher.VoucherLogDO;
import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.client.util.FeatureUtil;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by lizhijun on 2017/12/17.
 */
@Repository
@Transactional(value = "transactionManager", rollbackFor = Exception.class)
public class VoucherRepositoryImpl implements VoucherRepository{

    private static final Logger logger = LoggerFactory.getLogger(VoucherRepositoryImpl.class);

    @Autowired
    private VoucherMapper voucherMapper;

    @Autowired
    private AccountBookMapper accountBookMapper;

    @Autowired
    private AccountBookFlowMapper accountBookFlowMapper;

    @Autowired
    private StatementMapper statementMapper;

    @Autowired
    private VoucherDeliveryMapper deliveryMapper;

    @Autowired
    private VoucherLogMapper voucherLogMapper;


    @Override
    public void deletePunish(VoucherDO voucherDO, VoucherLogDO voucherLog) {
        VoucherUpdateOPT updateOPT = initVoucherUpdateOPT(voucherDO);
        updateOPT.setVoucherId(voucherDO.getVoucherId());
        updateOPT.setIsDeleted(voucherDO.getIsDeleted());
        updateOPT.setNodeKey(voucherDO.getNodeKey());

        voucherLogMapper.create(toVoucherLogDAO(voucherLog));
        int cnt = voucherMapper.updateByOPT(updateOPT);
        if(cnt != 1){
            logger.warn("deletePunish fail. sellerId={}, voucherId={}, version={}"
                    ,voucherDO.getSellerId(), voucherDO.getVoucherId(), voucherDO.getVersion());
            throw new DBException(ErrorCode.C_STORE_DB_FAILED, "deletePunish fail.");
        }
    }

    @Override
    public void createPunish(VoucherDO voucherDO, VoucherLogDO voucherLog) {
        VoucherDAO voucherDAO = toVoucherDAO(voucherDO);
        voucherMapper.create(voucherDAO);
        voucherLog.setVoucherId(NumberUtils.toLong(voucherDAO.getVoucherId()));
        voucherLogMapper.create(toVoucherLogDAO(voucherLog));
    }

    @Override
    public void submitPunish(VoucherDO voucherDO, VoucherLogDO voucherLog) {
        VoucherUpdateOPT updateOPT = initVoucherUpdateOPT(voucherDO);
        updateOPT.setProcInstId(voucherDO.getProcInstId());
        updateOPT.setNodeKey(voucherDO.getNodeKey());
        updateOPT.setNodeCatKey(voucherDO.getNodeCatKey());
        updateOPT.setProcStartTime(voucherDO.getProcStartTime());
        updateOPT.setRole(voucherDO.getRole());
        voucherLogMapper.create(toVoucherLogDAO(voucherLog));
        int count = voucherMapper.updateByOPT(updateOPT);
        if(count != 1){
            logger.warn("submitPunish fail. voucherDO={},", voucherDO);
            throw new DBException(ErrorCode.C_STORE_DB_FAILED," submitPunish fail.");
        }
    }


    @Override
    public void auditPunish(VoucherDO voucherDO, List<AccountBookDO> bookDOS, List<AccountBookFlowDO> accountBookFlowDOS, VoucherLogDO voucherLog) {
        VoucherUpdateOPT updateOPT = initVoucherUpdateOPT(voucherDO);
        updateOPT.setProcInstId(voucherDO.getProcInstId());
        updateOPT.setNodeKey(voucherDO.getNodeKey());
        updateOPT.setNodeCatKey(voucherDO.getNodeCatKey());
        updateOPT.setProcStartTime(voucherDO.getProcStartTime());
        updateOPT.setProcEndTime(voucherDO.getProcEndTime());
        updateOPT.setRole(voucherDO.getRole());
        updateOPT.setPayFlag(voucherDO.getPayFlag());
        updateOPT.setEvidenceRemark(voucherDO.getEvidenceRemark());
        updateOPT.setEvidenceFile(voucherDO.getEvidenceFile());
        updateOPT.setActualAmt(voucherDO.getActualAmt());
        int resultVoucher = voucherMapper.updateByOPT(updateOPT);
        if(resultVoucher != 1){
            logger.warn("auditPunish fail. voucherDO={}, bookDOS={}, accountBookFlowDOS={}",
                    voucherDO, bookDOS, accountBookFlowDOS);
            throw new DBException(ErrorCode.C_STORE_DB_FAILED," auditPunish fail.");
        }
        List<AccountBookFlowDAO> flows = convertBookFlows(accountBookFlowDOS);
        List<AccountBookUpdateOPT> books = convertBookUpdates(bookDOS);
        flows.forEach(accountBookFlowMapper::create);
        books.forEach(bookOpt ->{
            int count = accountBookMapper.updateByOPT(bookOpt);
            if(count != 1){
                logger.warn("auditPunish fail. cause accountBookMapper.updateByOPT voucherDO={}, bookDOS={}, accountBookFlowDOS={}",
                        voucherDO, bookDOS, accountBookFlowDOS);
                throw new DBException(ErrorCode.C_STORE_DB_FAILED," auditPunish fail.");
            }
        });
        voucherLogMapper.create(toVoucherLogDAO(voucherLog));
    }

    @Override
    public void auditPayment(VoucherDO voucherDO, VoucherLogDO voucherLog){
        VoucherUpdateOPT opt = initVoucherUpdateOPT(voucherDO);
        opt.setNodeKey(voucherDO.getNodeKey());
        opt.setNodeCatKey(voucherDO.getNodeCatKey());
        opt.setRole(voucherDO.getRole());
        int c = voucherMapper.updateByOPT(opt);
        if(c != 1){
            throw new DBException(ErrorCode.C_STORE_DB_FAILED," financeAuditPayment fail.");
        }
        voucherLogMapper.create(toVoucherLogDAO(voucherLog));
    }

    @Override
    public void auditPayment(VoucherDO voucherDO, AccountBookDO bookDO, AccountBookFlowDO bookFlowDO, StatementDO statementDO, VoucherLogDO voucherLog) {
        VoucherUpdateOPT opt = initVoucherUpdateOPT(voucherDO);
        opt.setNodeKey(voucherDO.getNodeKey());
        opt.setNodeCatKey(voucherDO.getNodeCatKey());
        opt.setRole(voucherDO.getRole());
        opt.setProcEndTime(voucherDO.getProcEndTime());
        opt.setPayFlag(voucherDO.getPayFlag());
        int a = voucherMapper.updateByOPT(opt);
        if (a != 1) {
            throw new DBException(ErrorCode.C_STORE_DB_FAILED, " auditPayment voucher fail.");
        }
        AccountBookUpdateOPT bookOpt = initBookUpdateOPT(bookDO);
        bookOpt.setBalanceAmt(bookDO.getBalanceAmt());
        //如果是追加保证金需要变更实际合同金
        if(VoucherSubType.ADD_DEPOSIT.isEquals(voucherDO.getVoucherSubType())){
            bookOpt.setActualContractAmt(bookDO.getActualContractAmt() + voucherDO.getActualAmt());
        }

        int b = accountBookMapper.updateByOPT(bookOpt);
        if (b != 1) {
            throw new DBException(ErrorCode.C_STORE_DB_FAILED, " auditPayment book fail.");
        }
        AccountBookFlowUpdateOPT bookFlowOpt = initBookFlowUpdateOPT(bookFlowDO);
        bookFlowOpt.setStatus(bookFlowDO.getStatus().getCode());
        bookFlowOpt.setGmtStatement(bookFlowDO.getGmtStatement());
        int c = accountBookFlowMapper.updateByOPT(bookFlowOpt);
        if (c != 1) {
            throw new DBException(ErrorCode.C_STORE_DB_FAILED, " auditPayment bookFlow fail.");
        }

        StatementUpdateOPT statementUpdateOPT = initStatementUpdateOPT(statementDO);
        statementUpdateOPT.setStatus(statementDO.getStatus().getCode());

        int d = statementMapper.updateByOPT(statementUpdateOPT);
        if (d != 1) {
            throw new DBException(ErrorCode.C_STORE_DB_FAILED, " auditPayment statement fail.");
        }
        voucherLogMapper.create(toVoucherLogDAO(voucherLog));
    }

    @Override
    public void confirmPayment(VoucherDO voucherDO, VoucherLogDO voucherLog){
        VoucherUpdateOPT opt = initVoucherUpdateOPT(voucherDO);
        opt.setNodeKey(voucherDO.getNodeKey());
        opt.setNodeCatKey(voucherDO.getNodeCatKey());
        opt.setRole(voucherDO.getRole());
        opt.setEvidenceRemark(voucherDO.getEvidenceRemark());
        opt.setEvidenceFile(voucherDO.getEvidenceFile());
        opt.setExtPropsStr(FeatureUtil.toString(voucherDO.getExtProps()));
        int a = voucherMapper.updateByOPT(opt);
        if (a != 1) {
            throw new DBException(ErrorCode.C_STORE_DB_FAILED, " confirmPayment voucher fail.");
        }
        voucherLogMapper.create(toVoucherLogDAO(voucherLog));
    }

    @Override
    public void autoCreatePunish(VoucherDO voucherDO, VoucherDeliveryDO voucherDeliveryDO, VoucherLogDO voucherLog) {
        VoucherDAO voucherDAO = this.toVoucherDAO(voucherDO);
        voucherMapper.create(voucherDAO);
        voucherDeliveryDO.setVoucherId(voucherDAO.getVoucherId());
        VoucherDeliveryUpdateOPT updateOPT = initVoucherDeliveryUpdateOPT(voucherDeliveryDO);
        updateOPT.setVoucherId(voucherDeliveryDO.getVoucherId());
        deliveryMapper.updateByOPT(updateOPT);
        voucherLog.setVoucherId(NumberUtils.toLong(voucherDAO.getVoucherId()));
        voucherLogMapper.create(toVoucherLogDAO(voucherLog));

    }

    @Override
    public void updateContractAmt(VoucherDO voucherDO, AccountBookDO bookDO, AccountBookFlowDO bookFlowDO, StatementDO statementDO, long baseContractAmt, VoucherLogDO voucherLog) {
        VoucherUpdateOPT opt = initVoucherUpdateOPT(voucherDO);
        opt.setNodeKey(voucherDO.getNodeKey());
        opt.setNodeCatKey(voucherDO.getNodeCatKey());
        opt.setRole(voucherDO.getRole());
        VoucherDAO voucherDAO = toVoucherDAO(voucherDO);
        voucherMapper.create(voucherDAO);
        AccountBookUpdateOPT bookOpt = initBookUpdateOPT(bookDO);
        bookOpt.setContractAmt(bookDO.getContractAmt());
        bookOpt.setBaseContractAmt(baseContractAmt);
        int b = accountBookMapper.updateByOPT(bookOpt);
        if (b != 1) {
            throw new DBException(ErrorCode.C_STORE_DB_FAILED, " updateContractAmt book fail.");
        }
        bookFlowDO.setOutId(voucherDAO.getVoucherId());
        accountBookFlowMapper.create(convertBookFlow(bookFlowDO));
        statementDO.setOutId(voucherDAO.getVoucherId());
        statementMapper.create(convertStatement(statementDO));
        voucherLog.setVoucherId(NumberUtils.toLong(voucherDAO.getVoucherId()));
        voucherLogMapper.create(toVoucherLogDAO(voucherLog));


    }

    @Override
    public void addBalanceAmt(VoucherDO voucherDO, AccountBookFlowDO bookFlowDO, StatementDO statementDO, List<List<AccountBookFlowDO>> lists, String writeOffType, VoucherLogDO voucherLog) {
        VoucherDAO voucherDAO = toVoucherDAO(voucherDO);
        voucherMapper.create(voucherDAO);
        bookFlowDO.setOutId(voucherDAO.getVoucherId());
        accountBookFlowMapper.create(convertBookFlow(bookFlowDO));
        statementDO.setOutId(voucherDAO.getVoucherId());
        statementMapper.create(convertStatement(statementDO));
        lists.forEach(list ->{
            List<Long> ids = list.stream().map(AccountBookFlowDO::getId).collect(Collectors.toList());
            int count = accountBookFlowMapper.batchUpdateWriteOffId(ids,voucherDAO.getVoucherId(),writeOffType);
            if(count != list.size()){
                throw new DBException(ErrorCode.C_STORE_DB_FAILED, "batchUpdateWriteOffId fail.");
            }
        });
        voucherLog.setVoucherId(NumberUtils.toLong(voucherDAO.getVoucherId()));
        voucherLogMapper.create(toVoucherLogDAO(voucherLog));
    }

    private AccountBookFlowUpdateOPT initBookFlowUpdateOPT(AccountBookFlowDO bookFlowDO){
        AccountBookFlowUpdateOPT updateOPT = new AccountBookFlowUpdateOPT();
        updateOPT.setId(bookFlowDO.getId());
        updateOPT.setVersion(bookFlowDO.getVersion());
        updateOPT.setSellerId(bookFlowDO.getSellerId());
        return updateOPT;
    }

    private AccountBookUpdateOPT initBookUpdateOPT(AccountBookDO bookDO){
        AccountBookUpdateOPT updateOPT = new AccountBookUpdateOPT();
        updateOPT.setId(bookDO.getId());
        updateOPT.setVersion(bookDO.getVersion());
        updateOPT.setSellerId(bookDO.getSellerId());
        return updateOPT;
    }
    private VoucherUpdateOPT initVoucherUpdateOPT(VoucherDO voucherDO) {
        VoucherUpdateOPT updateOPT = new VoucherUpdateOPT();
        updateOPT.setVoucherId(voucherDO.getVoucherId());
        updateOPT.setVersion(voucherDO.getVersion());
        updateOPT.setSellerId(voucherDO.getSellerId());
        return updateOPT;
    }

    private StatementUpdateOPT initStatementUpdateOPT(StatementDO statementDO){
        StatementUpdateOPT updateOPT = new StatementUpdateOPT();
        updateOPT.setId(statementDO.getId());
        updateOPT.setSellerId(statementDO.getSellerId());
        updateOPT.setVersion(statementDO.getVersion());
        return updateOPT;
    }

    private VoucherDAO toVoucherDAO(VoucherDO voucherDO) {
        VoucherDAO dao = new VoucherDAO();
        dao.setVoucherId(voucherDO.getVoucherId());
        dao.setGmtCreated(voucherDO.getGmtCreated());
        dao.setGmtModified(voucherDO.getGmtModified());
        dao.setIsDeleted(voucherDO.getIsDeleted());
        dao.setSellerId(voucherDO.getSellerId());
        dao.setOutId(voucherDO.getOutId());
        dao.setVoucherType(voucherDO.getVoucherType().getCode());
        dao.setVoucherSubType(voucherDO.getVoucherSubType().getCode());
        dao.setExpectAmt(voucherDO.getExpectAmt());
        dao.setActualAmt(voucherDO.getActualAmt());
        dao.setExpectPoint(voucherDO.getExpectPoint());
        dao.setActualPoint(voucherDO.getActualPoint());
        dao.setProcInstId(voucherDO.getProcInstId());
        dao.setNodeKey(voucherDO.getNodeKey());
        dao.setNodeCatKey(voucherDO.getNodeCatKey());
        dao.setRole(voucherDO.getRole());
        dao.setProcStartTime(voucherDO.getProcStartTime());
        dao.setProcEndTime(voucherDO.getProcEndTime());
        dao.setObjType(voucherDO.getObjType());
        dao.setObjId(voucherDO.getObjId());
        dao.setPayFlag(voucherDO.getPayFlag());
        dao.setCreateRemark(voucherDO.getCreateRemark());
        dao.setCreateFile(voucherDO.getCreateFile());
        dao.setEvidenceRemark(voucherDO.getEvidenceRemark());
        dao.setEvidenceFile(voucherDO.getEvidenceFile());
        dao.setExtProps(voucherDO.getExtProps());
        return dao;
    }


    private List<AccountBookFlowDAO> convertBookFlows(List<AccountBookFlowDO> accountBookFlowDOS) {
        List<AccountBookFlowDAO> list = new LinkedList<>();
        if (CollectionUtils.isEmpty(accountBookFlowDOS)) {
            return list;
        }
        return accountBookFlowDOS.stream().map(this::convertBookFlow).collect(Collectors.toList());
    }

    private List<AccountBookUpdateOPT> convertBookUpdates(List<AccountBookDO> bookDOS) {
        List<AccountBookUpdateOPT> list = new LinkedList<>();
        if (CollectionUtils.isEmpty(bookDOS)) {
            return list;
        }
        return bookDOS.stream().map(this::convertBookUpdate).collect(Collectors.toList());
    }

    private AccountBookUpdateOPT convertBookUpdate(AccountBookDO book) {
        AccountBookUpdateOPT updateOPT = new AccountBookUpdateOPT();
        updateOPT.setId(book.getId());
        updateOPT.setBalanceAmt(book.getBalanceAmt());
        updateOPT.setVersion(book.getVersion());
        return updateOPT;
    }

    private AccountBookFlowDAO convertBookFlow (AccountBookFlowDO flowDO){
        AccountBookFlowDAO flow = new AccountBookFlowDAO();
        flow.setBookId(flowDO.getBookId());
        flow.setAmount(flowDO.getAmount());
        flow.setBookType(flowDO.getBookType().getCode());
        flow.setFlowSubType(flowDO.getFlowSubType().getCode());
        flow.setFlowType(flowDO.getFlowType().getCode());
        flow.setGmtStatement(flowDO.getGmtStatement());
        flow.setMsg(flowDO.getMsg());
        flow.setOutId(flowDO.getOutId());
        flow.setOutType(flowDO.getOutType().getCode());
        flow.setSellerId(flowDO.getSellerId());
        flow.setStatus(flowDO.getStatus().getCode());
        flow.setWriteOffId(flowDO.getWriteOffId());
        return flow;
    }

    private StatementDAO convertStatement(StatementDO statementDO){
        StatementDAO statementDAO = new StatementDAO();
        statementDAO.setSellerId(statementDO.getSellerId());
        statementDAO.setFirstTime(statementDO.getFirstTime());
        statementDAO.setSecondTime(statementDO.getSecondTime());
        statementDAO.setStatus(statementDO.getStatus().getCode());
        statementDAO.setOutId(statementDO.getOutId());
        statementDAO.setOutType(statementDO.getOutType().getCode());
        statementDAO.setSubject(statementDO.getSubject().getCode());
        statementDAO.setPlatformReceivable(statementDO.getPlatformReceivable());
        statementDAO.setPlatformReceivableTax(statementDO.getPlatformReceivableTax());
        statementDAO.setPlatformPayable(statementDO.getPlatformPayable());
        statementDAO.setPlatformPayableTax(statementDO.getPlatformPayableTax());
        statementDAO.setPlatformReceipts(statementDO.getPlatformReceipts());
        statementDAO.setPlatformReceiptsTax(statementDO.getPlatformReceiptsTax());
        statementDAO.setPlatformPaid(statementDO.getPlatformPaid());
        statementDAO.setPlatformPaidTax(statementDO.getPlatformPaidTax());
        statementDAO.setMsg(statementDO.getMsg());
        return statementDAO;
    }

    private VoucherDeliveryUpdateOPT initVoucherDeliveryUpdateOPT(VoucherDeliveryDO voucherDeliveryDO) {
        VoucherDeliveryUpdateOPT updateOPT = new VoucherDeliveryUpdateOPT();
        updateOPT.setId(voucherDeliveryDO.getId());
        updateOPT.setVersion(voucherDeliveryDO.getVersion());
        updateOPT.setSellerId(voucherDeliveryDO.getSellerId());

        return updateOPT;
    }

    private VoucherLogDAO toVoucherLogDAO(VoucherLogDO voucherLog) {
        VoucherLogDAO log = new VoucherLogDAO();
        log.setMsg(voucherLog.getMsg());
        log.setOperator(voucherLog.getOperator());
        log.setOptType(voucherLog.getOptType());
        log.setSellerId(voucherLog.getSellerId());
        log.setVoucherId(voucherLog.getVoucherId());
        return log;
    }
}
