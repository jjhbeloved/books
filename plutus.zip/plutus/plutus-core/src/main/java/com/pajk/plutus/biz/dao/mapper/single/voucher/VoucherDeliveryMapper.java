package com.pajk.plutus.biz.dao.mapper.single.voucher;

import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDeliveryDAO;
import com.pajk.plutus.biz.model.mapper.single.voucher.VoucherDeliveryUpdateOPT;
import com.pajk.plutus.biz.model.query.voucher.VoucherDeliveryPageQuery;
import org.apache.ibatis.annotations.Param;

import java.util.List;


/**
 * Created by guguangming on 2017/12/15
 **/
public interface VoucherDeliveryMapper {

    /**
     * 创建
     * @param voucherDeliveryDAO    违规单据违规发货扩展属性
     */
    void create(VoucherDeliveryDAO voucherDeliveryDAO);

    /**
     * 根据单据ID查找
     * @param voucherId 单据ID
     * @return  VoucherDeliveryDAO
     */
    VoucherDeliveryDAO queryByVoucherId(@Param("voucherId") String voucherId);

    /**
     *  查询符合条件的总数量
     * @param pageQuery 查询条件
     * @return  int
     */
    int pageQueryCount(VoucherDeliveryPageQuery pageQuery);

    /**
     *  查询符合条件的数据
     * @param pageQuery 查询条件
     * @return List<VoucherDeliveryDAO>
     */
    List<VoucherDeliveryDAO> pageQuery(VoucherDeliveryPageQuery pageQuery);

    /**
     * 更新
     * @param updateOPT     关键字段
     * @return  返回更新数量
     */
    int updateByOPT(VoucherDeliveryUpdateOPT updateOPT);

}
