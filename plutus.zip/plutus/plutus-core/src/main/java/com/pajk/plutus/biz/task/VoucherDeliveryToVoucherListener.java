package com.pajk.plutus.biz.task;

import com.pajk.hawaii.client.JobExecutionContext;
import com.pajk.hawaii.client.JobListener;
import com.pajk.plutus.biz.common.util.TimeUtils;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.VoucherManager;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * Created by cuidongchao on 2017/12/21.
 *
 * 根据违规发货记录生成违规单的定时任务
 */
@Component("voucherDeliveryToVoucherListener")
public class VoucherDeliveryToVoucherListener implements JobListener {

    private static final Logger logger = LoggerFactory.getLogger(VoucherDeliveryToVoucherListener.class);

    @Autowired
    private VoucherManager voucherManager;

    @Autowired
    private ControlCache controlCache;

    @Override
    public void execute(JobExecutionContext context) {
        logger.info("start to execute job: name={}, taskId={}, time={}, param={}",
                getName(), context.getTaskId(), context.getFireTime(), context.getParameter());

        try {
            Date end = new Date();
            Date begin = TimeUtils.addDate(end, -controlCache.getVoucherDeliveryAutoProcessInterval());
            ResultDTO<VoidEntity> resultDTO = voucherManager.autoCreatePunish(TimeUtils.getBeginOfDate(begin), end);
            if (ErrorCode.SUCCESS.eq(resultDTO.getResultCode())) {
                context.success();
            } else {
                context.failed();
            }
        } catch (Exception e) {
            logger.warn("[VoucherDeliveryToVoucherListener] execute occurs error", e);
            context.failed();
        }
        logger.info("end of job: name={}, taskId={}, time={}, param={}",
                getName(), context.getTaskId(), context.getFireTime(), context.getParameter());

    }

    @Override
    public String getName() {
        return VoucherDeliveryToVoucherListener.class.getName();
    }
}
