package com.pajk.plutus.biz.manager.impl;

import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyBatchResult;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.kylin.api.service.AppResourceService;
import com.pajk.kylin.api.service.SellerService;
import com.pajk.plutus.biz.manager.BillExtManager;
import com.pajk.plutus.biz.model.query.bill.BillStatusDTO;
import com.pajk.plutus.biz.model.query.bill.SellerDTO;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class BillExtManagerImpl implements BillExtManager {

    private Logger logger = LoggerFactory.getLogger(BillExtManagerImpl.class);

    private Splitter splitterKEY = Splitter.on(";").omitEmptyStrings();
    private Splitter splitterValue = Splitter.on(":").omitEmptyStrings();

    private static final String CHANNEL = "all";
    private static final String SOURCE = "procStatus";
    private static final String SYSTEM = "taskcenter";
    private static final String TYPE = "Status";

    private static final String KEY = "bill";

    @Autowired
    private SellerService sellerService;

    @Autowired
    private AppResourceService appResourceService;

    @Override
    public BatchResultDTO<SellerDTO> getSellers() {
        List<SellerDTO> sellerDTOS = Lists.newArrayList();

        BatchResultDTO<SellerDTO> result = new BatchResultDTO<>();

        KyBatchResult<SellerDO> sellerDOKyBatchResult = sellerService.getAllSellers();

        if (!sellerDOKyBatchResult.isSuccess()) {
            return result;
        }

        for (SellerDO sellerDO : sellerDOKyBatchResult.getModel()) {
            SellerDTO sellerDTO = new SellerDTO();
            sellerDTO.setSellerId(sellerDO.getId());
            sellerDTO.setName(sellerDO.getName());
            sellerDTOS.add(sellerDTO);
        }

        result.setModel(sellerDTOS);
        return result;

    }

    @Override
    public BatchResultDTO<BillStatusDTO> getBillStatus() {
        BatchResultDTO<BillStatusDTO> result = new BatchResultDTO<>();
        ArrayList<BillStatusDTO> billStatusDTOS = Lists.newArrayList();

        KyCallResult<AppResourceDO> appResourceResult = appResourceService.getAppResource(SYSTEM, CHANNEL, TYPE, SOURCE, KEY);

        if (!appResourceResult.isSuccess() || null == appResourceResult.getModel()) {
            return result;
        }

        AppResourceDO appResourceDO = appResourceResult.getModel();
        String val = appResourceDO.val;
        List<String> statusList = splitterKEY.splitToList(val);
        for (String str : statusList) {
            BillStatusDTO billStatusDTO = new BillStatusDTO();
            List<String> valueList = splitterValue.splitToList(str);
            billStatusDTO.setStatus(valueList.get(0));
            billStatusDTO.setName(valueList.get(1));
            billStatusDTOS.add(billStatusDTO);
        }

        result.setModel(billStatusDTOS);
        return result;
    }

}
