package com.pajk.plutus.biz.model.mapper.single.voucher;

import com.pajk.plutus.client.util.FeatureUtil;
import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;
import java.util.Map;


/**
 * 单据表
 */
public class VoucherDAO extends BaseDO {

    private static final long serialVersionUID = -956015352360552758L;

    /**
     * 主键id
     */
    private String voucherId;

    /**
     * 创建时间
     */
    private Date gmtCreated;

    /**
     * 更新时间
     */
    private Date gmtModified;

    /**
     * 版本号
     */
    private int version;

    /**
     * 卖家id
     */
    private long sellerId;

    /**
     * 单据id 通过idgen生成
     */
    private String outId;

    /**
     * 单据类型,缴费单(缴钱缴积分)1000, 违规单(扣保证金扣积分)2000 赔偿单(扣保证金扣积分) 3000 清零单(清算保证金和积分)4000
     */
    private int voucherType;

    /**
     * 单据子类型
     */
    private int voucherSubType;

    /**
     * 预期金额(单位分)
     */
    private long expectAmt;

    /**
     * 实际金额(单位分)
     */
    private long actualAmt;

    /**
     * 预期积分
     */
    private long expectPoint;

    /**
     * 实际积分
     */
    private long actualPoint;

    /**
     * 流程引擎返回的流程id
     */
    private String procInstId;

    /**
     * 流程节点
     */
    private String nodeKey;

    /**
     * 流程group
     */
    private String nodeCatKey;

    /**
     * 流程执行的角色
     */
    private String role;

    /**
     * 流程开始时间
     */
    private Date procStartTime;

    /**
     * 流程完成时间
     */
    private Date procEndTime;

    /**
     * 业务类型 如trade ,sku
     */
    private String objType;

    /**
     * 业务实体id
     */
    private String objId;

    /**
     * 0 初始 1 处理中 2 处理完成 10 不需处理 100确认缴费(保证金缴费单)
     */
    private int payFlag;

    /**
     * 发起备注
     */
    private String createRemark;

    /**
     * 发起文件 格式JSON字符串
     */
    private String createFile;

    /**
     * 证据备注
     */
    private String evidenceRemark;

    /**
     * 证据文件 格式JSON字符串
     */
    private String evidenceFile;

    /**
     * 扩展字段 如缴费单银行流水 evidence_flow:(流水号多个隔开)
     */
    private Map<String, String> extProps;

    /**
     *0 正常  1 已经删除
     */
    private int isDeleted;

    public String getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(String voucherId) {
        this.voucherId = voucherId;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }

    public String getOutId() {
        return outId;
    }

    public void setOutId(String outId) {
        this.outId = outId;
    }

    public int getVoucherType() {
        return voucherType;
    }

    public void setVoucherType(int voucherType) {
        this.voucherType = voucherType;
    }

    public int getVoucherSubType() {
        return voucherSubType;
    }

    public void setVoucherSubType(int voucherSubType) {
        this.voucherSubType = voucherSubType;
    }

    public long getExpectAmt() {
        return expectAmt;
    }

    public void setExpectAmt(long expectAmt) {
        this.expectAmt = expectAmt;
    }

    public long getActualAmt() {
        return actualAmt;
    }

    public void setActualAmt(long actualAmt) {
        this.actualAmt = actualAmt;
    }

    public long getExpectPoint() {
        return expectPoint;
    }

    public void setExpectPoint(long expectPoint) {
        this.expectPoint = expectPoint;
    }

    public long getActualPoint() {
        return actualPoint;
    }

    public void setActualPoint(long actualPoint) {
        this.actualPoint = actualPoint;
    }

    public String getProcInstId() {
        return procInstId;
    }

    public void setProcInstId(String procInstId) {
        this.procInstId = procInstId;
    }

    public String getNodeKey() {
        return nodeKey;
    }

    public void setNodeKey(String nodeKey) {
        this.nodeKey = nodeKey;
    }

    public String getNodeCatKey() {
        return nodeCatKey;
    }

    public void setNodeCatKey(String nodeCatKey) {
        this.nodeCatKey = nodeCatKey;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Date getProcStartTime() {
        return procStartTime;
    }

    public void setProcStartTime(Date procStartTime) {
        this.procStartTime = procStartTime;
    }

    public Date getProcEndTime() {
        return procEndTime;
    }

    public void setProcEndTime(Date procEndTime) {
        this.procEndTime = procEndTime;
    }

    public String getObjType() {
        return objType;
    }

    public void setObjType(String objType) {
        this.objType = objType;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public int getPayFlag() {
        return payFlag;
    }

    public void setPayFlag(int payFlag) {
        this.payFlag = payFlag;
    }

    public String getCreateRemark() {
        return createRemark;
    }

    public void setCreateRemark(String createRemark) {
        this.createRemark = createRemark;
    }

    public String getCreateFile() {
        return createFile;
    }

    public void setCreateFile(String createFile) {
        this.createFile = createFile;
    }

    public String getEvidenceRemark() {
        return evidenceRemark;
    }

    public void setEvidenceRemark(String evidenceRemark) {
        this.evidenceRemark = evidenceRemark;
    }

    public String getEvidenceFile() {
        return evidenceFile;
    }

    public void setEvidenceFile(String evidenceFile) {
        this.evidenceFile = evidenceFile;
    }

    public Map<String, String> getExtProps() {
        return extProps;
    }

    public void setExtProps(Map<String, String> extProps) {
        this.extProps = extProps;
    }

    public String getExtPropsStr() {
        return FeatureUtil.toString(this.extProps);
    }

    public void setExtPropsStr(String extPropsStr) {
        this.extProps = FeatureUtil.fromString(extPropsStr);
    }


    public int getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(int isDeleted) {
        this.isDeleted = isDeleted;
    }
}
