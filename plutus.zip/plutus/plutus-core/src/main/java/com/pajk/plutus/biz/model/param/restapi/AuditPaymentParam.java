package com.pajk.plutus.biz.model.param.restapi;

import com.pajk.thunderbird.domain.result.BaseDO;

import javax.validation.constraints.NotNull;

/**
 * Created by lizhijun on 2017/12/19.
 */
public class AuditPaymentParam extends BaseDO {
    private static final long serialVersionUID = 1104075534879000161L;
    @NotNull
    private Long sellerId;
    @NotNull
    private String voucherId;
    @NotNull
    private String nodeKey;
    @NotNull
    private String transitionKey;

    private String remark;

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public String getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(String voucherId) {
        this.voucherId = voucherId;
    }

    public String getNodeKey() {
        return nodeKey;
    }

    public void setNodeKey(String nodeKey) {
        this.nodeKey = nodeKey;
    }

    public String getTransitionKey() {
        return transitionKey;
    }

    public void setTransitionKey(String transitionKey) {
        this.transitionKey = transitionKey;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
