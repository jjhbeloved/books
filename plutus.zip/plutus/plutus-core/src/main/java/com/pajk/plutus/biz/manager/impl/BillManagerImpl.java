package com.pajk.plutus.biz.manager.impl;

import com.alibaba.fastjson.JSON;
import com.google.common.base.Throwables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyBatchResult;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.plutus.biz.common.util.ResultUtil;
import com.pajk.plutus.biz.common.util.ValidateSetUtil;
import com.pajk.plutus.biz.dao.repo.BillRepository;
import com.pajk.plutus.biz.dao.repo.BillSettlementQueryRepository;
import com.pajk.plutus.biz.dao.repo.SellerAccountInfoRepository;
import com.pajk.plutus.biz.dao.repo.SellerInvoiceInfoRepository;
import com.pajk.plutus.biz.manager.BillManager;
import com.pajk.plutus.biz.manager.TransactionWrapper;
import com.pajk.plutus.biz.model.bill.*;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.biz.model.process.TransitionDO;
import com.pajk.plutus.biz.model.query.bill.*;
import com.pajk.plutus.client.model.enums.bill.ProcNameType;
import com.pajk.plutus.client.model.enums.bill.SettlementType;
import com.pajk.plutus.client.model.enums.trade.PayToType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.taskcenter.client.constant.VariableConstant;
import com.pajk.taskcenter.client.model.dto.*;
import com.pajk.taskcenter.client.model.query.BizObjQuery;
import com.pajk.taskcenter.client.model.query.ProcessInstQuery;
import com.pajk.taskcenter.client.model.result.BatchResult;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import static com.google.common.base.Objects.equal;

/**
 * Created by arjaylv on 2017/12/13.
 *
 * @author arjaylv
 */
@Component
public class BillManagerImpl extends AbstractManagerImpl implements BillManager, TransactionWrapper {

    private static final Logger logger = LoggerFactory.getLogger(BillManagerImpl.class);

    /************** 结算单 创建流程默认按钮 **************/
    private static final String CREATE_PROCESS_API = "confirmSettlement";
    private static final String CREATE_PROCESS_T_KEY = "create";
    private static final String CREATE_PROCESS_T_NAME = "确认";
    /**
     * 查询总账，商家收款-平安应付，BillSJSKPAYF，未创建流程时nodeky默认为sellerConfirm
     */
    private static final String SJSKPAYF_DEFAULT_NODE_KEY = "sellerConfirm";
    /**
     * 查询总账，平台收款-平安应付，BillPTSKPAYF，未创建流程时nodeky默认为supplierConfirm
     */
    private static final String PTSKPAYF_DEFAULT_NODE_KEY = "supplierConfirm";
    /**
     * 查询总账，商家收款-平安应收，BillSJSKPAYS，未创建流程时nodeky默认为sellerConfirm
     */
    private static final String SJSKPAYS_DEFAULT_NODE_KEY = "sellerConfirm";

    /************** 结算审批流程 文案中心调用Key **************/
    // 商家收款-平安应付
    private static final String TYPE_SJSKPAYF = "BillSJSKPAYF";
    // 平台收款-平安应付
    private static final String TYPE_PTSKPAYF = "BillPTSKPAYF";
    // 商家收款-平安应收
    private static final String TYPE_SJSKPAYS = "BillSJSKPAYS";

    /************** 结算审批流程 结算类型 **************/
    private static final String PROCESS_BILL_TYPE = "BILL";
    /************** PAJk 商户ID **************/
    private static final long PAJK_SELLER_ID = 1;

    @Autowired
    private BillSettlementQueryRepository billSettlementQueryRepository;

    @Autowired
    private SellerInvoiceInfoRepository sellerInvoiceInfoRepository;

    @Autowired
    private SellerAccountInfoRepository sellerAccountInfoRepository;

    @Autowired
    private BillRepository billRepository;

    @Override
    public BatchResultDTO<ButtonDO> getDefaultButtons() {
        // 如果 procInstId 是null 说明还没有创建流程
        BatchResultDTO<ButtonDO> resultDTO = new BatchResultDTO<>();
        List<ButtonDO> buttonDOS = Lists.newLinkedList();
        ButtonDO buttonDO = new ButtonDO();
        buttonDO.setName(CREATE_PROCESS_T_NAME);
        buttonDO.setKey(CREATE_PROCESS_T_KEY);
        buttonDO.setPath(SYSTEM + "." + CREATE_PROCESS_API);
        buttonDOS.add(buttonDO);
        resultDTO.setModel(buttonDOS);
        return resultDTO;
    }

    @Override
    public BatchResultDTO<ButtonDO> getButtons(long procInstId, String nodeKey) {
        BatchResultDTO<ButtonDO> resultDTO = new BatchResultDTO<>();
        // 如果 procInstId 是null 说明还没有创建流程
        NodeDTO nodeDTO = getNodeInfo(procInstId, nodeKey);
        List<ButtonDO> buttonDOS = toButtonModel(nodeDTO);
        resultDTO.setModel(buttonDOS);
        return resultDTO;
    }

    @Override
    public ResultDTO<BillSettlementDO> querySettlement(long billId) {
        Optional<BillSettlementDO> settlementDOOptional = billSettlementQueryRepository.querySettlementDetailByBillId(billId);
        return settlementDOOptional
                .map(this::addSellerName)
                .map(this::querySettlementOperation)
                .orElse(ResultUtil.returnResultDTO(ErrorCode.BILL_NOT_EXIST));
    }

    @Override
    public ResultDTO<BillSettlementDO> querySettlement(long billId, long sellerId) {

        Optional<BillSettlementDO> settlementDOOptional = billSettlementQueryRepository.querySettlementDetailByBillId(billId, sellerId);
        return settlementDOOptional
                .map(this::addSellerName)
                .map(this::querySettlementOperation)
                .orElse(ResultUtil.returnResultDTO(ErrorCode.BILL_NOT_EXIST));
    }

    @Override
    public ResultDTO<BillSettlementDO> queryConfirmSettlement(long billId) {
        Optional<BillSettlementDO> optional = billSettlementQueryRepository.querySettlementByBillId(billId);
        return optional.map(this::addSellerName)
                .map(this::querySettlementOperation)
                .orElse(ResultUtil.returnResultDTO(ErrorCode.BILL_NOT_EXIST));
    }

    @Override
    public ResultDTO<BillSettlementDO> queryConfirmSettlement(long billId, long sellerId) {
        Optional<BillSettlementDO> optional = billSettlementQueryRepository.querySettlementByBillId(billId, sellerId);
        return optional
                .map(this::addSellerName)
                .map(this::querySettlementOperation)
                .orElse(ResultUtil.returnResultDTO(ErrorCode.BILL_NOT_EXIST));
    }

    @Override
    public ResultDTO<VoidEntity> confirmSettlement(long billId, BillSettlementDTO billSettlementDTO,
                                                   String buttonKey, BillLogDTO billLogDTO, UserParam userParam) {
        // 1. 查询对账单
        Long sellerId = billLogDTO.getSellerId();
        Optional<BillSettlementDO> optional;
        if (Objects.isNull(sellerId)) {
            optional = billSettlementQueryRepository.querySettlementByBillId(billId);
        } else {
            optional = billSettlementQueryRepository.querySettlementByBillId(billId, sellerId);
        }
        if (!optional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.BILL_NOT_EXIST);
        }
        BillSettlementDO billSettlementDO = optional.get();
        // 1.1 校验角色权限是否匹配
        boolean isCreated = Objects.nonNull(billSettlementDO.getProcInstId());
        boolean isGranted = Objects.equals(billLogDTO.getRole(), billSettlementDO.getRole());
        if (isCreated && !isGranted) {
            return ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);
        }
        // 2. 校验数据并转换数据对象
        List<BillSettlementItemDO> billSettlementItemDOS = billSettlementDO.getBillSettlementItemDOS();

        List<BillSettlementItemDTO> billSettlementItemDTOS = billSettlementDTO.getSettlementItems();
        Map<Long, BillSettlementItemDTO> billSettlementItemDTOMap = billSettlementItemDTOS.stream()
                .collect(Collectors.toMap(BillSettlementItemDTO::getId, o -> o));
        List<Object> exceptions = validateAnSetSettlementItem(billSettlementItemDOS, billSettlementItemDTOMap);
        if (!CollectionUtils.isEmpty(exceptions)) {
            return ResultUtil.returnResultDTO(ErrorCode.BILL_ITEM_NOT_EXIST);
        }
        // 3. 判断程执行方式
        String remark = billSettlementDTO.getConfirmRemark();
        ConfirmInfoDO confirmInfoDO = createConfirmInfoDO(billSettlementDTO.getConfirmFileUrl(),
                billSettlementDTO.getConfirmFileName(),
                remark);
        billSettlementDO.setConfirmInfoDO(confirmInfoDO);
        long billAmt = 0L;
        for (BillSettlementItemDO billSettlementItemDO : billSettlementItemDOS) {
            billAmt += billSettlementItemDO.getActualBillAmt();
        }
        billSettlementDO.setActualBillAmt(billAmt);
        BillLogDO billLogDO = billLogDTO2DO(billLogDTO);
        billSettlementDO.setBillLogDO(billLogDO);
        ResultDTO<VoidEntity> resultDTO = invoke(billSettlementDO, buttonKey, true, userParam);
        if (!resultDTO.isSuccess()) {
            return resultDTO;
        }
        // 4. 更新确认对账单库信息
        // 4.1 记录操作记录
        billRepository.updateConfirmSettlement(billSettlementDO);
        return new ResultDTO<>();
    }

    @Override
    public ResultDTO<VoidEntity> confirmInvoice(InvoiceInfoDTO invoiceInfoDTO, BillLogDTO billLogDTO, UserParam userParam, boolean isSellerInvoice) {
        // 1. 查询对账单
        Long sellerId = billLogDTO.getSellerId();
        long billId = invoiceInfoDTO.getBillId();
        Optional<BillSettlementDO> optional;
        if (Objects.isNull(sellerId)) {
            optional = billSettlementQueryRepository.querySettlementByBillId(billId);
        } else {
            optional = billSettlementQueryRepository.querySettlementByBillId(billId, billLogDTO.getSellerId());
        }
        if (!optional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.BILL_NOT_EXIST);
        }
        BillSettlementDO billSettlementDO = optional.get();
        // 1.1 校验角色权限是否匹配
        if (!Objects.equals(billLogDTO.getRole(), billSettlementDO.getRole())) {
            logger.warn("current role is {}, but database's role is {}", billLogDTO.getRole(), billSettlementDO.getRole());
            return ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);
        }
        // 2. 校验数据并转换数据对象
        long actBillAmt = billSettlementDO.getActualBillAmt();
        if (actBillAmt != (invoiceInfoDTO.getInvoiceAmt() + invoiceInfoDTO.getInvoiceTaxAmt())) {
            return ResultUtil.returnResultDTO(ErrorCode.INVOICE_AMT_ERROR);
        }
        // 3. 查询票务信息
        long invoiceSellerId = isSellerInvoice ? PAJK_SELLER_ID : billSettlementDO.getSellerId();
        Optional<SellerInvoiceInfoDO> infoOptional = sellerInvoiceInfoRepository.queryBySellerId(invoiceSellerId);
        InvoiceInfoDO invoiceInfoDO = new InvoiceInfoDO();
        invoiceInfoDO.setInvoiceId(invoiceInfoDTO.getInvoiceId());
        invoiceInfoDO.setInvoiceAmt(invoiceInfoDTO.getInvoiceAmt());
        invoiceInfoDO.setInvoiceTax(invoiceInfoDTO.getInvoiceTaxAmt());
        invoiceInfoDO.setTrackingNumber(invoiceInfoDTO.getInvoiceTrackingNumber());
        billSettlementDO.setInvoiceInfoDO(invoiceInfoDO);
        BillLogDO billLogDO = billLogDTO2DO(billLogDTO);
        billSettlementDO.setBillLogDO(billLogDO);
        // 4. 审批
        ResultDTO<VoidEntity> resultDTO = invoke(billSettlementDO, invoiceInfoDTO.getButtonKey(), false, userParam);
        if (!resultDTO.isSuccess()) {
            return resultDTO;
        }
        // 5. 更新确认对账单库信息
        // 5.1 记录操作记录
        billRepository.updateConfirmInvoice(billSettlementDO, infoOptional.orElse(null));
        return new ResultDTO<>();
    }

    @Override
    public ResultDTO<VoidEntity> receiveInvoice(long billId, String buttonKey, BillLogDTO billLogDTO, UserParam userParam) {
        // 1. 查询对账单
        Long sellerId = billLogDTO.getSellerId();
        Optional<BillSettlementDO> optional;
        if (Objects.isNull(sellerId)) {
            optional = billSettlementQueryRepository.querySettlementByBillId(billId);
        } else {
            optional = billSettlementQueryRepository.querySettlementByBillId(billId, billLogDTO.getSellerId());
        }
        if (!optional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.BILL_NOT_EXIST);
        }
        BillSettlementDO billSettlementDO = optional.get();
        // 2 校验角色权限是否匹配
        if (!Objects.equals(billLogDTO.getRole(), billSettlementDO.getRole())) {
            return ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);
        }
        BillLogDO billLogDO = billLogDTO2DO(billLogDTO);
        billSettlementDO.setBillLogDO(billLogDO);
        ResultDTO<VoidEntity> resultDTO = invoke(billSettlementDO, buttonKey, false, userParam);
        if (!resultDTO.isSuccess()) {
            return resultDTO;
        }
        // 4. 更新确认对账单库信息
        // 4.1 记录操作记录
        billSettlementDO.setButtonKey(buttonKey);
        billRepository.updateReceiveInvoice(billSettlementDO);
        return new ResultDTO<>();
    }

    @Override
    public ResultDTO<VoidEntity> confirmPayment(PaymentInfoDTO paymentInfoDTO, BillLogDTO billLogDTO, UserParam userParam, boolean isSellerPay) {
        // 1. 查询对账单
        Long sellerId = billLogDTO.getSellerId();
        long billId = paymentInfoDTO.getBillId();

        Optional<BillSettlementDO> optional;
        if (Objects.isNull(sellerId)) {
            optional = billSettlementQueryRepository.querySettlementByBillId(billId);
        } else {
            optional = billSettlementQueryRepository.querySettlementByBillId(billId, sellerId);
        }
        if (!optional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.BILL_NOT_EXIST);
        }
        BillSettlementDO billSettlementDO = optional.get();
        // 2 校验角色权限是否匹配
        if (!Objects.equals(billLogDTO.getRole(), billSettlementDO.getRole())) {
            return ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);
        }
        long paymentSellerId = isSellerPay ? PAJK_SELLER_ID : billSettlementDO.getSellerId();
        // 3. 获取商户账号信息
        Optional<SellerAccountInfoDO> infoOptional = sellerAccountInfoRepository.queryBySellerId(paymentSellerId);
        // 4. 校验数据并转换数据对象
        PaymentInfoDO paymentInfoDO = new PaymentInfoDO();
        paymentInfoDO.setPaymentNo(paymentInfoDTO.getPaymentNo());
        paymentInfoDO.setPaymentFileId(paymentInfoDTO.getPaymentFileId());
        paymentInfoDO.setPaymentFileName(paymentInfoDTO.getPaymentFileName());
        List<PaymentInfoDO> paymentInfoDOS = Lists.newArrayList(paymentInfoDO);
        billSettlementDO.setPaymentInfoDOS(paymentInfoDOS);
        BillLogDO billLogDO = billLogDTO2DO(billLogDTO);
        billSettlementDO.setBillLogDO(billLogDO);
        ResultDTO<VoidEntity> resultDTO = invoke(billSettlementDO, paymentInfoDTO.getButtonKey(), false, userParam);
        if (!resultDTO.isSuccess()) {
            return resultDTO;
        }
        // 4. 更新确认对账单库信息
        // 4.1 记录操作记录
        billRepository.updateConfirmPayment(billSettlementDO, infoOptional.orElse(null));
        return new ResultDTO<>();
    }

    @Override
    public ResultDTO<VoidEntity> confirmReceivePayment(long billId, String buttonKey, BillLogDTO billLogDTO, UserParam userParam) {
        // 1. 查询对账单
        Long sellerId = billLogDTO.getSellerId();
        Optional<BillSettlementDO> optional;
        if (Objects.isNull(sellerId)) {
            optional = billSettlementQueryRepository.querySettlementByBillId(billId);
        } else {
            optional = billSettlementQueryRepository.querySettlementByBillId(billId, sellerId);
        }
        if (!optional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.BILL_NOT_EXIST);
        }
        BillSettlementDO billSettlementDO = optional.get();
        // 2. 校验角色权限是否匹配
        if (!Objects.equals(billLogDTO.getRole(), billSettlementDO.getRole())) {
            return ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);
        }
        BillLogDO billLogDO = billLogDTO2DO(billLogDTO);
        billSettlementDO.setBillLogDO(billLogDO);
        ResultDTO<VoidEntity> resultDTO = invoke(billSettlementDO, buttonKey, false, userParam);
        if (!resultDTO.isSuccess()) {
            return resultDTO;
        }
        // 4. 更新确认对账单库信息
        // 4.1 记录操作记录
        billSettlementDO.setButtonKey(buttonKey);
        billRepository.updateConfirmReceivePayment(billSettlementDO);
        return new ResultDTO<>();
    }

    @Override
    public ResultDTO<VoidEntity> confirmOnlyRemark(long billId, String buttonKey, BillLogDTO billLogDTO, UserParam userParam) {
        // 1. 查询对账单
        Long sellerId = billLogDTO.getSellerId();
        Optional<BillSettlementDO> optional;
        if (Objects.isNull(sellerId)) {
            optional = billSettlementQueryRepository.querySettlementByBillId(billId);
        } else {
            optional = billSettlementQueryRepository.querySettlementByBillId(billId, sellerId);
        }
        if (!optional.isPresent()) {
            return ResultUtil.returnResultDTO(ErrorCode.BILL_NOT_EXIST);
        }
        BillSettlementDO billSettlementDO = optional.get();
        // 1.1 校验角色权限是否匹配
        if (!Objects.equals(billLogDTO.getRole(), billSettlementDO.getRole())) {
            return ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);
        }
        BillLogDO billLogDO = billLogDTO2DO(billLogDTO);
        billSettlementDO.setBillLogDO(billLogDO);
        ResultDTO<VoidEntity> resultDTO = invoke(billSettlementDO, buttonKey, false, userParam);
        if (!resultDTO.isSuccess()) {
            return resultDTO;
        }
        // 4. 更新确认对账单库信息
        // 4.1 记录操作记录
        billRepository.updateConfirmOnlyRemark(billSettlementDO);
        return new ResultDTO<>();
    }

    @Override
    public SellerInvoiceInfoDO querySellerInvoiceInfo(long sellerId) {
        // 发票开具要求
        final Optional<SellerInvoiceInfoDO> optionalSellerInvoiceInfoDO = sellerInvoiceInfoRepository
                .queryBySellerId(sellerId, 0);
        return optionalSellerInvoiceInfoDO.orElse(null);
    }

    @Override
    public SellerAccountInfoDO querySellerAccountInfo(long sellerId) {
        final Optional<SellerAccountInfoDO> optionalSellerAccountInfoDO = sellerAccountInfoRepository
                .queryBySellerId(sellerId, 0);
        return optionalSellerAccountInfoDO.orElse(null);
    }

    @Override
    public PageResultDTO<BillSettlementDO> pageQuerySettlementByCondition(String role, int pageNo, int pageSize, Map<String, Object> params) {
        PageResultDTO<BillSettlementDO> settlementDOPage = paging(pageNo, pageSize, params);

        List<BillSettlementDO> billSettlementDOs = settlementDOPage.getModel();
        if (CollectionUtils.isEmpty(billSettlementDOs)) {
            return settlementDOPage;
        }
        List<Long> sellerIdList = billSettlementDOs.stream().map(BillSettlementDO::getSellerId).distinct().collect(Collectors.toList());

        // 获取role匹配的流程node信息
        final Map<Long, NodeDTO> instIdNodeMap = getInstIdNodeMap(billSettlementDOs);
        Map<Long, SellerDO> sellerDOMap = getSellersMap(sellerIdList);
        // 查询流程状态文案
        final Map<String, Map<String, AppResourceDO>> typeNodeCatKeyDescMap = queryAllKeyName();
        // billId与流程节点文案的map
        final Map<Long, AppResourceDO> billIdNodeDescMap = getBillIdNodeDescMap(billSettlementDOs, typeNodeCatKeyDescMap);

        for (BillSettlementDO billSettlementDO : billSettlementDOs) {
            // 获取商家信息
            SellerDO sellerDO = sellerDOMap.get(billSettlementDO.getSellerId());
            // 商家名称
            if (sellerDO != null) {
                billSettlementDO.setSellerName(sellerDO.getName());
            }
            // 根据billId获取对应的文案信息
            final Optional<AppResourceDO> appResourceDO = Optional.ofNullable(billIdNodeDescMap.get(billSettlementDO.getId()));
            // 流程未创建时，role从文案信息中获取
            if (StringUtils.isBlank(billSettlementDO.getRole())) {
                billSettlementDO.setRole(appResourceDO
                        .map(appResource -> appResource.key2)
                        .orElse(null));
            }
            billSettlementDO.setNodeKeyName(appResourceDO
                    .map(appResource -> appResource.val)
                    .orElse(null));

            // billSettlement文案信息，如果当前角色符合，设置按钮
            if (equal(role, billSettlementDO.getRole())) {
                // 填充按钮
                fillCascadeButtons(billSettlementDO, instIdNodeMap, billIdNodeDescMap);
            }
            // 取快照，取发票信息
            SellerInvoiceInfoDO sellerInvoiceInfo = querySellerInvoiceInfo(billSettlementDO.getSellerId());
            billSettlementDO.setSellerInvoiceInfoDO(sellerInvoiceInfo);

            // 账户
            SellerAccountInfoDO sellerAccountInfo = querySellerAccountInfo(billSettlementDO.getSellerId());
            billSettlementDO.setSellerAccountInfoDO(sellerAccountInfo);

        }
        return settlementDOPage;
    }

    private PageResultDTO<BillSettlementDO> paging(int pageNo, int pageSize, Map<String, Object> params) {
        PageResultDTO<BillSettlementDO> pageResultDTO = new PageResultDTO<>();

        int total = billSettlementQueryRepository.count(params);
        pageResultDTO.setPageNo(pageNo);
        pageResultDTO.setPageSize(pageSize);

        if (0 >= total) {
            return pageResultDTO;
        }
        pageResultDTO.setTotalCount(total);
        pageResultDTO.setModel(billSettlementQueryRepository.pageList(pageNo, pageSize, params));
        return pageResultDTO;
    }

    @Override
    public PageResultDTO<BillSettlementDO> pageQuerySettlement(long sellerId, String role,
                                                               String startTime, String endTime,
                                                               int pageNo, int pageSize) {
        // billSettlement基础信息，查询bill_settlement及相关表
        final Map<String, Object> params = Maps.newHashMap();
        params.put("startTime", startTime);
        params.put("endTime", endTime);
        params.put("sellerId", sellerId);
        final PageResultDTO<BillSettlementDO> billSettlementDOPage = paging(pageNo, pageSize, params);
        List<BillSettlementDO> billSettlementDOs = billSettlementDOPage.getModel();
        if (CollectionUtils.isEmpty(billSettlementDOs)) {
            return billSettlementDOPage;
        }

        // billSettlement文案信息，查询流程状态文案
        final Map<String, Map<String, AppResourceDO>> typeNodeCatKeyDescMap = queryAllKeyName();
        // billId与流程节点文案的map
        final Map<Long, AppResourceDO> billIdNodeDescMap = getBillIdNodeDescMap(billSettlementDOs, typeNodeCatKeyDescMap);
        // 填充所有bill的nodeCatKeyName
        billSettlementDOs.forEach(billSettlementDO -> fillNodeCatKeyName(billSettlementDO, billIdNodeDescMap));

        // 过滤当前role的billSettlement，获取与当前role对应的billSettlement
        final List<BillSettlementDO> matchingIdBillSettlementDOs = billSettlementDOs.stream()
                // 获取与当前role匹配的记录
                .filter(billSettlementDO -> Objects.equals(billSettlementDO.getRole(), role))
                .collect(Collectors.toList());

        // 为当前role的billSettlement增加流程操作按钮信息，获取role匹配的billSettlement的流程node信息
        final Map<Long, NodeDTO> instIdNodeMap = getInstIdNodeMap(matchingIdBillSettlementDOs);
        // 填充操作按钮信息
        matchingIdBillSettlementDOs.forEach(billSettlementDO -> fillCascadeButtons(billSettlementDO, instIdNodeMap, billIdNodeDescMap));
        return billSettlementDOPage;
    }

    /**
     * 查询 配置中心所有 结算相关流程定义
     *
     * @return 文案封装数据
     */
    private Map<String, Map<String, AppResourceDO>> queryAllKeyName() {
        // 商家收款-平安应付
        final List<AppResourceDO> appSJSKPAYF = getAppResource(KY_SYSTEM, CHANNEL, TYPE_SJSKPAYF, PROC_DEF_SOURCE);
        // 平台收款-平安应付
        final List<AppResourceDO> appPTSKPAYF = getAppResource(KY_SYSTEM, CHANNEL, TYPE_PTSKPAYF, PROC_DEF_SOURCE);
        // 商家收款-平安应收
        final List<AppResourceDO> appSJSKPAYS = getAppResource(KY_SYSTEM, CHANNEL, TYPE_SJSKPAYS, PROC_DEF_SOURCE);

        // 过滤keyName、val1和key3非空白的配置记录
        final Predicate<AppResourceDO> appResourceFilter = appResourceDO -> !StringUtils.isBlank(appResourceDO.keyName);
        final Collector<AppResourceDO, ?, Map<String, AppResourceDO>> collector = Collectors.toMap(
                o -> o.keyName,
                o -> o,
                (oldVal, newVal) -> newVal);

        final Map<String, Map<String, AppResourceDO>> typeNodeCatKeyDescMap = Maps.newHashMap();
        typeNodeCatKeyDescMap.put(TYPE_SJSKPAYF, appSJSKPAYF.stream()
                .filter(appResourceFilter)
                .collect(collector));
        typeNodeCatKeyDescMap.put(TYPE_PTSKPAYF, appPTSKPAYF.stream()
                .filter(appResourceFilter)
                .collect(collector));
        typeNodeCatKeyDescMap.put(TYPE_SJSKPAYS, appSJSKPAYS.stream()
                .filter(appResourceFilter)
                .collect(collector));
        return typeNodeCatKeyDescMap;
    }

    private Map<Long, AppResourceDO> getBillIdNodeDescMap(List<BillSettlementDO> billSettlementDOs,
                                                          Map<String, Map<String, AppResourceDO>> typeNodeCatKeyDescMap) {
        final Map<Long, AppResourceDO> billIdNodeDescMap = Maps.newHashMap();
        for (BillSettlementDO billSettlementDO : billSettlementDOs) {
            final long billId = billSettlementDO.getId();
            final AppResourceDO appResourceDO = getBillIdNodeDesc(billSettlementDO, typeNodeCatKeyDescMap);
            billIdNodeDescMap.put(billId, appResourceDO);
        }
        return billIdNodeDescMap;
    }

    private AppResourceDO getBillIdNodeDesc(BillSettlementDO billSettlementDO,
                                            Map<String, Map<String, AppResourceDO>> typeNodeCatKeyDescMap) {
        AppResourceDO appResourceDO = new AppResourceDO();

        // 如果流程未创建，nodeKey使用默认值
        final int settlementType = billSettlementDO.getSettlementType();
        final int payToType = billSettlementDO.getPayToType();

        if (settlementType == SettlementType.PA_PAY.getCode()) {
            if (payToType == PayToType.PAY_TO_PLATFORM.getCode()) {
                // 账单流程未创建时，直接根据固定映射关系来获取nodeKey
                final String nodeKey = billSettlementDO.getProcInstId() == null ?
                        PTSKPAYF_DEFAULT_NODE_KEY : billSettlementDO.getNodeKey();
                appResourceDO = typeNodeCatKeyDescMap.get(BillManagerImpl.TYPE_PTSKPAYF).get(nodeKey);
            } else if (payToType == PayToType.PAY_TO_SELLER.getCode()) {
                // 账单流程未创建时，直接根据固定映射关系来获取nodeKey
                final String nodeKey = billSettlementDO.getProcInstId() == null ?
                        SJSKPAYF_DEFAULT_NODE_KEY : billSettlementDO.getNodeKey();
                appResourceDO = typeNodeCatKeyDescMap.get(BillManagerImpl.TYPE_SJSKPAYF).get(nodeKey);
            }
        } else if (settlementType == SettlementType.PA_RECEIPT.getCode()) {
            if (payToType == PayToType.PAY_TO_SELLER.getCode()) {
                // 账单流程未创建时，直接根据固定映射关系来获取nodeKey
                final String nodeKey = billSettlementDO.getProcInstId() == null ?
                        SJSKPAYS_DEFAULT_NODE_KEY : billSettlementDO.getNodeKey();
                appResourceDO = typeNodeCatKeyDescMap.get(BillManagerImpl.TYPE_SJSKPAYS).get(nodeKey);
            }
        }

        return appResourceDO;
    }

    private AppResourceDO getBillIdNodeDesc(TaskInstDTO taskInstDTO,
                                            Map<String, Map<String, AppResourceDO>> typeNodeCatKeyDescMap) {
        AppResourceDO appResourceDO;
        String nodeKey = taskInstDTO.getNodeKey();
        appResourceDO = typeNodeCatKeyDescMap.get(BillManagerImpl.TYPE_PTSKPAYF).get(nodeKey);
        if (appResourceDO == null) {
            appResourceDO = typeNodeCatKeyDescMap.get(BillManagerImpl.TYPE_SJSKPAYF).get(nodeKey);
        }
        // 账单流程未创建时，直接根据固定映射关系来获取nodeKey
        if (appResourceDO == null) {
            appResourceDO = typeNodeCatKeyDescMap.get(BillManagerImpl.TYPE_SJSKPAYS).get(nodeKey);
        }
        return appResourceDO;
    }

    private void fillNodeCatKeyName(BillSettlementDO billSettlementDO, Map<Long, AppResourceDO> billIdNodeDescMap) {
        final long billId = billSettlementDO.getId();
        // 根据billId获取对应的文案信息
        final Optional<AppResourceDO> appResourceDO = Optional.ofNullable(billIdNodeDescMap.get(billId));

        // 设置nodeCatKeyName
        billSettlementDO.setNodeCatKeyName(appResourceDO
                .map(appResource -> appResource.val1)
                .orElse(null)
        );

        // 流程未创建时，流程信息从文案信息中获取
        if (StringUtils.isBlank(billSettlementDO.getRole())) {
            billSettlementDO.setNodeKey(appResourceDO.map(appResource -> appResource.keyName).orElse(null));
            billSettlementDO.setNodeCatKey(appResourceDO.map(appResource -> appResource.key1).orElse(null));
            billSettlementDO.setRole(appResourceDO.map(appResource -> appResource.key2).orElse(null));
        }
    }

    private void fillCascadeButtons(BillSettlementDO billSettlementDO, Map<Long, NodeDTO> instIdNodeMap,
                                    Map<Long, AppResourceDO> billIdNodeDescMap) {
        final List<CascadeButtonDO> cascadeButtonDOs;
        final boolean instProcCreated = billSettlementDO.getProcInstId() != null;
        final String buttonName = Optional.ofNullable(billIdNodeDescMap.get(billSettlementDO.getId()))
                .map(appResourceDO -> appResourceDO.key3)
                .orElse(null);
        final NodeDTO nodeDTO = Optional.ofNullable(billSettlementDO.getProcInstId())
                .map(instIdNodeMap::get)
                .orElse(null);

        cascadeButtonDOs = toCascadeButtonModel(instProcCreated, nodeDTO, buttonName);

        billSettlementDO.setCascadeButtonDOs(cascadeButtonDOs);
    }

    private Map<Long, NodeDTO> getInstIdNodeMap(List<BillSettlementDO> billSettlementDOs) {
        final List<ProcessInstQuery> processInstQueries = billSettlementDOs
                .stream()
                .filter(billSettlementDO -> Objects.nonNull(billSettlementDO.getProcInstId()))
                .map(this::toProcessInstQuery)
                .collect(Collectors.toList());


        if (CollectionUtils.isEmpty(processInstQueries)) {
            return new HashMap<>();
        }

        List<GetNodeInfoResultDTO> getNodeInfoResultDTOS = getNodeInfoList(processInstQueries);
        return getNodeInfoResultDTOS.stream()
                // 仅处理获取成功的node信息
                .filter(GetNodeInfoResultDTO::isSuccess)
                .filter(result -> result.getNodeDTO() != null)
                .collect(Collectors.toMap(
                        GetNodeInfoResultDTO::getProcInstId,
                        GetNodeInfoResultDTO::getNodeDTO,
                        (oldVal, newVal) -> newVal
                ));
    }

    private ProcessInstQuery toProcessInstQuery(BillSettlementDO billSettlementDO) {
        final ProcessInstQuery processInstQuery = new ProcessInstQuery();
        processInstQuery.setProcInstId(billSettlementDO.getProcInstId());
        processInstQuery.setNodeKey(billSettlementDO.getNodeKey());
        return processInstQuery;
    }

    private List<ButtonDO> toButtonModel(NodeDTO nodeDTO) {
        final List<ButtonDO> buttonDOS = Lists.newLinkedList();
        ValidateSetUtil.validateNonNullSet(nodeDTO, param -> {
            final String path = param.getPath();
            List<TransitionDTO> transitionDTOS = param.getTransitionDTOList();
            ValidateSetUtil.setIfListNotEmpty(transitionDTOS, p -> {
                ButtonDO buttonDO = new ButtonDO();
                buttonDO.setName(p.getTransitionName());
                buttonDO.setKey(p.getTransitionKey());
                buttonDO.setPath(path);
                buttonDOS.add(buttonDO);
            });
        });
        return buttonDOS;
    }

    private List<CascadeButtonDO> toCascadeButtonModel(boolean instProcCreated, NodeDTO nodeDTO, String buttonName) {
        final CascadeButtonDO cascadeButtonDO = new CascadeButtonDO();
        cascadeButtonDO.setName(buttonName);

        // 没有获取到流程信息
        if (nodeDTO == null) {
            // 没有创建流程，处于流程初始状态，使用初始状态按钮信息
            if (!instProcCreated) {
                final TransitionDO transitionDO = new TransitionDO();
                transitionDO.setTransitionKey("confirm");
                transitionDO.setTransitionName("确认");
                cascadeButtonDO.setTransitions(Lists.newArrayList(transitionDO));
            }
            // 已创建流程，但是角色不匹配没有获取到流程信息
            else {
                cascadeButtonDO.setTransitions(Lists.newArrayList());
            }

            return Lists.newArrayList(cascadeButtonDO);
        }

        cascadeButtonDO.setPath(nodeDTO.getPath());
        final List<TransitionDO> transitionDOs = Optional.ofNullable(nodeDTO.getTransitionDTOList())
                .map(Collection::stream)
                .map(transitionDTOStream -> transitionDTOStream
                        .map(transitionDTO -> {
                            final TransitionDO transitionDO = new TransitionDO();
                            transitionDO.setTransitionKey(transitionDTO.getTransitionKey());
                            transitionDO.setTransitionName(transitionDTO.getTransitionName());
                            return transitionDO;
                        }))
                .map(transitionDOStream -> transitionDOStream.collect(Collectors.toList()))
                .orElse(Lists.newLinkedList());
        cascadeButtonDO.setTransitions(transitionDOs);

        return Lists.newArrayList(cascadeButtonDO);
    }

    private BillLogDO billLogDTO2DO(BillLogDTO billLogDTO) {
        BillLogDO billLogDO = new BillLogDO();
        billLogDO.setOperatorId(billLogDTO.getOperatorId());
        billLogDO.setOperatorName(billLogDTO.getOperatorName());
        billLogDO.setSellerId(billLogDTO.getSellerId());
        billLogDO.setRole(billLogDTO.getRole());
        billLogDO.setDesc(billLogDTO.getDesc());
        billLogDO.setRole(billLogDTO.getRole());
        billLogDO.setRemark(billLogDTO.getRemark());
        return billLogDO;
    }

    /**
     * 获取商户名
     *
     * @param sellerId 商户ID
     * @return 商户名
     */
    private String getSellerName(long sellerId) {
        KyCallResult<SellerDO> kyCallResult = sellerService.getSellerById(sellerId);
        if (!kyCallResult.isSuccess()) {
            logger.warn("sellerId:{} not found name. code:{}, msg:{}",
                    sellerId, kyCallResult.getErrorCode(), kyCallResult.getErrorMsg());
            return null;
        }
        return kyCallResult.getModel().getName();
    }

    private BillSettlementDO addSellerName(BillSettlementDO billSettlementDO) {
        long sellerId = billSettlementDO.getSellerId();
        String name = getSellerName(sellerId);
        billSettlementDO.setSellerName(name);
        return billSettlementDO;
    }

    /**
     * 校验是否存在明细表单
     *
     * @param billSettlementItemDOS    结算单 明细表单
     * @param billSettlementItemDTOMap 传入确认的 结算单 明细表单
     * @return List<T>.isEmpty() 代表不存在
     */
    private List<Object> validateAnSetSettlementItem(List<BillSettlementItemDO> billSettlementItemDOS,
                                                     Map<Long, BillSettlementItemDTO> billSettlementItemDTOMap) {
        List<Object> exceptions = Lists.newLinkedList();
        billSettlementItemDOS.forEach(billSettlementItemDO -> {
            long id = billSettlementItemDO.getId();
            BillSettlementItemDTO billSettlementItemDTO = billSettlementItemDTOMap.get(id);
            if (Objects.isNull(billSettlementItemDTO)) {
                exceptions.add(id);
            } else {
                long actualBillAmt = billSettlementItemDTO.getActualBillAmt();
                billSettlementItemDO.setActualBillAmt(actualBillAmt);
            }
        });
        return exceptions;
    }

    /**
     * 创建确认单信息
     *
     * @param fileId   tfs文件ID
     * @param fileName tfs文件名
     * @param remark   描述
     * @return 对象
     */
    private ConfirmInfoDO createConfirmInfoDO(String fileId, String fileName, String remark) {
        ConfirmInfoDO confirmInfoDO = new ConfirmInfoDO();
        List<FileInfoDO> fileInfoDOS = Lists.newLinkedList();
        FileInfoDO fileInfoDO = new FileInfoDO();
        fileInfoDO.setConfirmFileId(fileId);
        fileInfoDO.setConfirmFileName(fileName);
        fileInfoDOS.add(fileInfoDO);
        confirmInfoDO.setFileInfoDO(fileInfoDOS);
        confirmInfoDO.setRemark(remark);
        return confirmInfoDO;
    }

    private void setNodeInfo(BillSettlementDO billSettlementDO, boolean endFlag, TaskInstDTO taskInstDTO, String buttonKey, String role) {
        if (endFlag) {
            billSettlementDO.setNodeKey(buttonKey);
            billSettlementDO.setNodeCatKey(buttonKey);
            billSettlementDO.setRole(role);
            billSettlementDO.setFinishTime(new Date());
        } else {
            billSettlementDO.setNodeKey(taskInstDTO.getNodeKey());
            billSettlementDO.setNodeCatKey(taskInstDTO.getNodeCatKey());
            billSettlementDO.setRole(taskInstDTO.getRole());
        }
    }

    /**
     * @param billSettlementDO 账单数据
     * @param buttonKey        流程引擎执行方向
     * @param include          是否自动创建流程
     * @return ResultDTO<VoidEntity>
     */
    private ResultDTO<VoidEntity> invoke(BillSettlementDO billSettlementDO, String buttonKey, boolean include, UserParam userParam) {
        Long procInstId = billSettlementDO.getProcInstId();
        int payToType = billSettlementDO.getPayToType();
        int settlementType = billSettlementDO.getSettlementType();
        long billId = billSettlementDO.getId();
        BillLogDO billLogDO = billSettlementDO.getBillLogDO();
        String strBillId = String.valueOf(billId);
        String strUserId = billLogDO.getOperatorId();
        String role = billLogDO.getRole();
        long billAmt = billSettlementDO.getActualBillAmt();
        String remark = billLogDO.getRemark();

        TaskInstDTO taskInstDTO;
        boolean endFlag;
        if (Objects.isNull(procInstId)) {
            if (include) {
                String name = ProcNameType.createProcName(payToType, settlementType);
                ResultDTO<CreateProcInstResultDTO> resultDTO = createProcess(name, strBillId, PROCESS_BILL_TYPE);
                if (!resultDTO.isSuccess()) {
                    return ResultUtil.returnResultDTO(resultDTO.getResultCode(), resultDTO.getResultMsg());
                }
                CreateProcInstResultDTO createProcInstResultDTO = resultDTO.getModel();
                billSettlementDO.setProcInstId(createProcInstResultDTO.getProcInstId());
                // 这里流程定义来保证只会有一个 nextNode
                endFlag = createProcInstResultDTO.getEndFlag();
                taskInstDTO = createProcInstResultDTO.getTaskInstDTOList().get(0);
                billSettlementDO.setStartTime(new Date());
            } else {
                logger.warn("process must have procInstId when include is true.");
                return ResultUtil.returnResultDTO(ErrorCode.PARAM_ERROR);
            }
        } else {
            String nodeKey = billSettlementDO.getNodeKey();

            ResultDTO<VoidEntity> checkError = checkPreAuditProcess(userParam.getAppId(), userParam.getUserId(),
                    role, nodeKey, procInstId, nodeKey, buttonKey, userParam.getPath());

            if (!ErrorCode.SUCCESS.eq(checkError.getResultCode())) {
                if (ErrorCode.STATUS_NOT_MATCH.eq(checkError.getResultCode())) {
                    return ResultUtil.returnResultDTO(ErrorCode.STATUS_NOT_MATCH);
                } else {
                    return ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);
                }
            }

            // 1 校验按钮是否符合节点信息
            if (!isContainButtonKey(procInstId, nodeKey, buttonKey)) {
                logger.info("流程procInstId:{},节点:{}不存在{}按钮", procInstId, nodeKey, buttonKey);
                return ResultUtil.returnResultDTO(ErrorCode.NO_PERMISSION_TO_OPT);
            }
            // 2 审批流程
            Map<String, Object> variableMap = Maps.newHashMap();
            variableMap.put(VariableConstant.TMP_AMOUNT, billAmt);
            ResultDTO<CompleteTaskResultDTO> resultDTO = completeTask(procInstId, nodeKey, buttonKey,
                    role, variableMap,
                    strUserId, remark);
            if (!resultDTO.isSuccess()) {
                return ResultUtil.returnResultDTO(resultDTO.getResultCode(), resultDTO.getResultMsg());
            }
            CompleteTaskResultDTO taskResultDTO = resultDTO.getModel();
            endFlag = taskResultDTO.getEndFlag();
            taskInstDTO = taskResultDTO.getTaskInstDTOList().get(0);
        }
        setNodeInfo(billSettlementDO, endFlag, taskInstDTO, buttonKey, role);
        return new ResultDTO<>();
    }

    /**
     * 查询操作记录
     *
     * @param billSettlementDO 账单数据
     * @return ResultDTO<BillSettlementDO>
     */
    private ResultDTO<BillSettlementDO> querySettlementOperation(BillSettlementDO billSettlementDO) {
        ResultDTO<BillSettlementDO> result = new ResultDTO<>();
        // 操作记录
        List<SettlementOperationDO> operationList = getOperationList(billSettlementDO);
        billSettlementDO.setSettlementOperationDOS(operationList);
        result.setModel(billSettlementDO);
        return result;
    }

    private List<SettlementOperationDO> getOperationList(BillSettlementDO billSettlementDO) {
        BizObjQuery bizObjQuery = new BizObjQuery();
        List<SettlementOperationDO> settlementOperationDOList = Lists.newArrayList();
        try {
            if (Objects.isNull(billSettlementDO.getProcInstId())) {
                return Collections.emptyList();
            }
            bizObjQuery.setProcInstId(billSettlementDO.getProcInstId());
            BatchResult<TaskInstDTO> instDTOBatchResult = flowService.getFinishedActInstList(bizObjQuery);
            if (!instDTOBatchResult.isSuccess()) {
                logger.warn("failed to get task inst ,procInstId:{},caused:{}", billSettlementDO.getProcInstId(), JSON.toJSON(instDTOBatchResult));
                return Lists.newArrayList();
            }

            // 查询流程状态文案
            final Map<String, Map<String, AppResourceDO>> typeNodeCatKeyDescMap = queryAllKeyName();

            List<TaskInstDTO> taskInstDTOList = instDTOBatchResult.getModel();
            for (TaskInstDTO taskInstDTO : taskInstDTOList) {
                SettlementOperationDO operationDO = new SettlementOperationDO();
                AppResourceDO appResourceDO = this.getBillIdNodeDesc(taskInstDTO, typeNodeCatKeyDescMap);
                if (appResourceDO != null) {
                    operationDO.setOperationRole(appResourceDO.val2);
                    operationDO.setOperationDesc(appResourceDO.val3);
                }

                operationDO.setOperationMemo(taskInstDTO.getApprovalMemo());
                operationDO.setOperationEndTime(taskInstDTO.getEndTime());
                operationDO.setOperationStartTime(taskInstDTO.getStartTime());
                operationDO.setOperationVote(taskInstDTO.getApprovalVote());
                settlementOperationDOList.add(operationDO);
            }

            Collections.reverse(settlementOperationDOList);

            return settlementOperationDOList;
        } catch (Exception e) {
            logger.warn("failed to get task inst,caused:{}", Throwables.getStackTraceAsString(e));
            return Lists.newArrayList();
        }
    }

    private Map<Long, SellerDO> getSellersMap(List<Long> sellerIdList) {
        // 批量获取商家信息
        KyBatchResult<SellerDO> sellerListResult = sellerService.getSellersByIds(sellerIdList);
        // map
        return sellerListResult.getModel().stream().collect(Collectors.toMap(
                SellerDO::getId,
                sellerDo -> sellerDo,
                (oldVal, newVal) -> newVal
        ));
    }

}
