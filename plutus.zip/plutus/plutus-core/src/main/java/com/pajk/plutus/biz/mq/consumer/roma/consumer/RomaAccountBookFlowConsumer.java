package com.pajk.plutus.biz.mq.consumer.roma.consumer;

import com.alibaba.rocketmq.common.message.MessageExt;
import com.google.common.collect.Sets;
import com.pajk.plutus.biz.exceptions.RomaIgnoreException;
import com.pajk.plutus.biz.model.roma.RomaBookFlowInfo;
import com.pajk.plutus.biz.model.roma.ValueChange;
import com.pajk.plutus.biz.mq.consumer.roma.base.AbstractEventBusConsumer;
import com.pajk.plutus.client.model.enums.account.BookFlowStatus;
import com.pajk.roma.message.RomaDbMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Set;
import java.util.StringJoiner;

/**
 * Created by lizhijun on 2017/12/17.
 */
@Component("romaAccountBookFlowConsumer")
public class RomaAccountBookFlowConsumer extends AbstractEventBusConsumer<RomaBookFlowInfo> {
    private static final Logger logger = LoggerFactory.getLogger(RomaAccountBookFlowConsumer.class);
    public static final String SELECTOR_PREFIX = "bookFlowStatus_";
    private static final String SUBSCRIBE = "roma_mcfinance.fc_account_book_flow";
    private static final String CONSUMER_GROUP = "ROMA-PLUTUS-ACCOUNT-BOOK-FLOW";

    protected static final Set<String> selectorKeys = Sets.newHashSet(
            statusChangeRule(BookFlowStatus.NO_FINISHED, BookFlowStatus.FINISHED)         // 0 -> 1
    );

    @PostConstruct
    @Override
    public void init() throws Exception {
        logger.info("RomaAccountBookFlowConsumer init SUBSCRIBE={}, CONSUMER_GROUP={}", SUBSCRIBE, CONSUMER_GROUP);
        super.setSubscribeExpr(SUBSCRIBE);
        super.setGroupName(CONSUMER_GROUP);
        //instanceName是否需要不同
        super.init();
    }

    @Override
    public RomaBookFlowInfo transform(RomaDbMessage.RomaDbData msg, MessageExt msgExt, Object context) throws RomaIgnoreException {
        RomaBookFlowInfo info = new RomaBookFlowInfo(msg);
        info.setReconsumeTimes(msgExt.getReconsumeTimes());
        return info;
    }

    @Override
    public boolean isSelectorRegistered(String key) {
        return selectorKeys.contains(key);
    }

    @Override
    public String selector(RomaBookFlowInfo romaBookFlowInfo) {
        return SELECTOR_PREFIX + romaBookFlowInfo.getStatus().toString();

    }

    private static String statusChangeRule(BookFlowStatus from, BookFlowStatus to) {
        StringJoiner sj = new StringJoiner(ValueChange.SEPARATOR);
        sj.add(from == null ? "null" :  Integer.toString(from.getCode()))
                .add(to == null ? "null" : Integer.toString(to.getCode()));
        return SELECTOR_PREFIX + sj.toString();
    }
}
