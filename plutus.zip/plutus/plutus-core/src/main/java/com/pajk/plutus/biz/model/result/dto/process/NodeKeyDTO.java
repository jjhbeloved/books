package com.pajk.plutus.biz.model.result.dto.process;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by lizhijun on 2017/12/14.
 */
public class NodeKeyDTO extends BaseDO {
    private static final long serialVersionUID = 5928656645142041266L;

    private String key;
    private String name;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
