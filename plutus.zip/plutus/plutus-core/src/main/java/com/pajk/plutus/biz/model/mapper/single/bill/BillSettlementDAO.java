package com.pajk.plutus.biz.model.mapper.single.bill;

import com.pajk.thunderbird.domain.result.BaseDO;

import java.util.Date;

/**
 * Created by arjaylv on 2017/12/11.
 *
 * @author arjaylv
 */
public class BillSettlementDAO extends BaseDO {

    private static final long serialVersionUID = 2327942161379875136L;

    private Long id;

    private Date gmtCreated;

    private Date gmtModified;

    private Integer version;

    private Long sellerId;

    /**
     * 单据编号 idgen生成
     */
    private Long billNo;

    /**
     * 统计月份(默认每个月的1号)
     */
    private Date month;

    /**
     * 收款方式、合作模式 1:平台收款 2:商家收款
     */
    private Integer payToType;

    /**
     * 结算类型 1:平安应收 2:平安应付
     */
    private Integer settlementType;

    /**
     * 对账总金额(分)
     */
    private Long billAmt;

    /**
     * 实际确认对账总金额(分)
     */
    private Long actualBillAmt;

    /**
     * 流程返回的实例id
     */
    private Long procInstId;

    /**
     * 账单状态
     */
    private String nodeKey;

    /**
     * 商户看到的节点
     */
    private String nodeCatKey;

    /**
     * 当前状态可执行角色
     */
    private String role;

    /**
     * 流程开始时间
     */
    private Date startTime;

    /**
     * 流程完成时间
     */
    private Date finishTime;

    /**
     * 商户账单确认上传的附件信息 JSON字符串格式
     */
    private String confirmInfo;

    /**
     * 确认支付时提交的相关信息 JSON字符串格式
     */
    private String paymentInfo;

    /**
     * 发票信息 JSON字符串格式
     */
    private String invoiceInfo;

    /**
     * 扩展字段
     */
    private String extProps;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Long getBillNo() {
        return billNo;
    }

    public void setBillNo(Long billNo) {
        this.billNo = billNo;
    }

    public Date getMonth() {
        return month;
    }

    public void setMonth(Date month) {
        this.month = month;
    }

    public Integer getPayToType() {
        return payToType;
    }

    public void setPayToType(Integer payToType) {
        this.payToType = payToType;
    }

    public Integer getSettlementType() {
        return settlementType;
    }

    public void setSettlementType(Integer settlementType) {
        this.settlementType = settlementType;
    }

    public Long getBillAmt() {
        return billAmt;
    }

    public void setBillAmt(Long billAmt) {
        this.billAmt = billAmt;
    }

    public Long getActualBillAmt() {
        return actualBillAmt;
    }

    public void setActualBillAmt(Long actualBillAmt) {
        this.actualBillAmt = actualBillAmt;
    }

    public Long getProcInstId() {
        return procInstId;
    }

    public void setProcInstId(Long procInstId) {
        this.procInstId = procInstId;
    }

    public String getNodeKey() {
        return nodeKey;
    }

    public void setNodeKey(String nodeKey) {
        this.nodeKey = nodeKey;
    }

    public String getNodeCatKey() {
        return nodeCatKey;
    }

    public void setNodeCatKey(String nodeCatKey) {
        this.nodeCatKey = nodeCatKey;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(Date finishTime) {
        this.finishTime = finishTime;
    }

    public String getConfirmInfo() {
        return confirmInfo;
    }

    public void setConfirmInfo(String confirmInfo) {
        this.confirmInfo = confirmInfo;
    }

    public String getPaymentInfo() {
        return paymentInfo;
    }

    public void setPaymentInfo(String paymentInfo) {
        this.paymentInfo = paymentInfo;
    }

    public String getInvoiceInfo() {
        return invoiceInfo;
    }

    public void setInvoiceInfo(String invoiceInfo) {
        this.invoiceInfo = invoiceInfo;
    }

    public String getExtProps() {
        return extProps;
    }

    public void setExtProps(String extProps) {
        this.extProps = extProps;
    }

}
