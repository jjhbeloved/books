package com.pajk.plutus.biz.service.web;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.pajk.plutus.biz.common.util.CommonUtil;
import com.pajk.plutus.biz.common.util.ResultUtil;
import com.pajk.plutus.biz.common.util.TimeUtils;
import com.pajk.plutus.biz.common.util.ValidateSetUtil;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.exceptions.BaseException;
import com.pajk.plutus.biz.manager.BillExtManager;
import com.pajk.plutus.biz.manager.BillManager;
import com.pajk.plutus.biz.manager.permission.AuthResourceProperties;
import com.pajk.plutus.biz.manager.permission.UserManger;
import com.pajk.plutus.biz.manager.permission.UserUtil;
import com.pajk.plutus.biz.model.bill.*;
import com.pajk.plutus.biz.model.param.restapi.PageQuerySettlementParam;
import com.pajk.plutus.biz.model.param.restapi.SettlementParam;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.biz.model.process.TransitionDO;
import com.pajk.plutus.biz.model.query.bill.*;
import com.pajk.plutus.biz.model.result.dto.process.TransitionDTO;
import com.pajk.plutus.client.model.enums.bill.BillType;
import com.pajk.plutus.client.model.enums.bill.SettlementType;
import com.pajk.plutus.client.model.enums.trade.PayToType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;


/**
 * Created by arjaylv on 2017/12/13.
 *
 * @author arjaylv
 */
@RestController("billQueryController")
@RequestMapping(value = "/plutus/billQuery")
public class BillQueryController extends AbstractWebController {
    private static final Logger logger = LoggerFactory.getLogger(BillQueryController.class);

    private static final String OPT_GROUP = "opt.bill";
    private static final String OPT_ACT = "query";

    @Autowired
    private BillManager billManager;

    @Autowired
    private BillExtManager billExtManager;

    @Autowired
    private UserManger userManger;

    @Autowired
    private ControlCache controlCache;

    /**
     * 平安对账-总账-确认/驳回账单-查询
     *
     * @param settlementParam 查询参数
     * @return 账单信息
     */
    @RequestMapping(value = "/queryConfirmSettlement", method = RequestMethod.POST)
    public ResultDTO<BillSettlementDTO> queryConfirmSettlement(@Valid @RequestBody SettlementParam settlementParam) {
        logger.info("[queryConfirmSettlement] params ={}", settlementParam);

        return wrapper(() -> doQueryConfirmSettlement(settlementParam), OPT_GROUP, OPT_ACT);
    }

    /**
     * 查询商户列表，依赖调用kylin系统获取商户信息
     *
     * @return 商户列表
     */
    @RequestMapping(value = "/batchQuerySeller", method = RequestMethod.POST)
    public BatchResultDTO<SellerDTO> batchQuerySeller() {
        return batchWrapper(() -> billExtManager.getSellers(), OPT_GROUP, OPT_ACT);
    }

    /**
     * 查询账单状态下拉列表，通过查询文案中心nodeKey的配置获取
     *
     * @return 状态列表
     */
    @RequestMapping(value = "/batchQueryBillStatus", method = RequestMethod.POST)
    public BatchResultDTO<BillStatusDTO> batchQueryBillStatus() {
        return batchWrapper(() -> billExtManager.getBillStatus(), OPT_GROUP, OPT_ACT);
    }

    /**
     * 平安对账-总账-查询列表 pageQuerySettlement
     *
     * @param pageQuerySettlementParam 查询参数
     * @return 分页数据
     */
    @RequestMapping(value = "/pageQuerySettlement", method = RequestMethod.POST)
    public PageResultDTO<BillSettlementDTO> pageQuerySettlement(
            @Valid @RequestBody PageQuerySettlementParam pageQuerySettlementParam) {
        logger.info("[pageQuerySettlement] params ={}", pageQuerySettlementParam);
        Map<String, Object> params = Maps.newHashMap();

        Date startMonth = TimeUtils.parse(pageQuerySettlementParam.getStartTime(), TimeUtils.MONTH_FORMAT);
        Date endMonth = TimeUtils.parse(pageQuerySettlementParam.getEndTime(), TimeUtils.MONTH_FORMAT);
        int daySpan = controlCache.getBillSettlementQueryDaySpan();
        int dayInterval = controlCache.getBillSettlementQueryDayInterval();
        ErrorCode errorCode = CommonUtil.checkQueryTime(startMonth, endMonth, daySpan, dayInterval);

        if (!ErrorCode.SUCCESS.eq(errorCode)) {
            return ResultUtil.returnPageResultDTO(errorCode);
        }
        params.put("startTime", TimeUtils.format(startMonth, TimeUtils.SIMPLE_DATA_FORMAT));
        params.put("endTime", TimeUtils.format(endMonth, TimeUtils.SIMPLE_DATA_FORMAT));

        if (Objects.nonNull(pageQuerySettlementParam.getSellerId())) {
            params.put("sellerId", pageQuerySettlementParam.getSellerId());
        }
        if (StringUtils.isNotBlank(pageQuerySettlementParam.getNodeKey())
                && !StringUtils.equals(pageQuerySettlementParam.getNodeKey(), "all")) {
            params.put("nodeKey", pageQuerySettlementParam.getNodeKey());
        }

        return pageWrapper(() -> {
            String role = userManger.getCurrentUserRole();

            PageResultDTO<BillSettlementDO> pageResultDTO = billManager.pageQuerySettlementByCondition(role, pageQuerySettlementParam.getPageNo(),
                    pageQuerySettlementParam.getPageSize(),
                    params);
            if (!pageResultDTO.isSuccess()) {
                return ResultUtil.returnPageResultDTO(pageResultDTO.getResultCode(), pageResultDTO.getResultMsg());
            }
            List<BillSettlementDO> billSettlementDOS = pageResultDTO.getModel();
            PageResultDTO<BillSettlementDTO> pageResult = new PageResultDTO<>();
            pageResult.setPageNo(pageResultDTO.getPageNo());
            pageResult.setPageSize(pageResultDTO.getPageSize());
            pageResult.setTotalCount(pageResultDTO.getTotalCount());
            pageResult.setModel(billSettlementDOS
                    .stream()
                    .map(this::toDTO)
                    .collect(Collectors.toList())
            );
            return pageResult;
        }, OPT_GROUP, OPT_ACT);
    }

    /**
     * 平安对账-明细-查询
     *
     * @param settlementParam 请求参数
     * @return 明细信息
     */
    @RequestMapping(value = "/querySettlement", method = RequestMethod.POST)
    public ResultDTO<BillSettlementDTO> querySettlement(@Valid @RequestBody SettlementParam settlementParam) {
        return wrapper(() -> {
            ResultDTO<BillSettlementDO> resultDTO = billManager.querySettlement(settlementParam.getBillId());
            BillSettlementDO billSettlementDO = resultDTO.getModel();
            billSettlementDO.setId(null);
            return new ResultDTO<>(toDTO(billSettlementDO));
        }, OPT_GROUP, OPT_ACT);
    }

    private BillSettlementDTO toDTO(BillSettlementDO settlementDO) {
        BillSettlementDTO billSettlementDTO = new BillSettlementDTO();
        billSettlementDTO.setBillId(settlementDO.getId());
        billSettlementDTO.setSellerId(settlementDO.getSellerId());
        billSettlementDTO.setSellerName(settlementDO.getSellerName());
        billSettlementDTO.setMonth(new DateTime(settlementDO.getMonth()).toString("yyyy-MM"));
        billSettlementDTO.setNodeKeyName(settlementDO.getNodeKeyName());
        billSettlementDTO.setSettlementType(SettlementType.valueOf(settlementDO.getSettlementType()).name());

        billSettlementDTO.setPayToType(PayToType.valueOf(settlementDO.getPayToType()).name());
        billSettlementDTO.setBillAmt(settlementDO.getBillAmt());
        billSettlementDTO.setActualBillAmt(settlementDO.getActualBillAmt());

        // 支付信息
        List<PaymentInfoDO> paymentInfoDOS = settlementDO.getPaymentInfoDOS();
        if (!CollectionUtils.isEmpty(paymentInfoDOS)) {
            PaymentInfoDO paymentInfoDO = paymentInfoDOS.get(0);
            billSettlementDTO.setPaymentNo(paymentInfoDO.getPaymentNo());
            billSettlementDTO.setPaymentFileName(paymentInfoDO.getPaymentFileName());
            billSettlementDTO.setPaymentFileUrl(this.getFilePath(paymentInfoDO.getPaymentFileId(), paymentInfoDO.getPaymentFileName()));
        }

        // 发票信息
        InvoiceInfoDO invoiceInfoDO = settlementDO.getInvoiceInfoDO();
        if (invoiceInfoDO != null) {
            billSettlementDTO.setInvoiceTaxAmt(invoiceInfoDO.getInvoiceTax());
            billSettlementDTO.setInvoiceId(invoiceInfoDO.getInvoiceId());
            billSettlementDTO.setInvoiceAmt(invoiceInfoDO.getInvoiceAmt());
            billSettlementDTO.setInvoiceId(invoiceInfoDO.getInvoiceId());
            billSettlementDTO.setInvoiceTrackingNumber(invoiceInfoDO.getTrackingNumber());
        }

        // 发票信息
        billSettlementDTO.setInvoice(toDTO(settlementDO.getSellerInvoiceInfoDO()));

        // 账号信息
        billSettlementDTO.setAccount(toDTO(settlementDO.getSellerAccountInfoDO()));
        // 确认信息
        ValidateSetUtil.validateNonNullSet(settlementDO.getConfirmInfoDO(), param -> {
            billSettlementDTO.setConfirmRemark(param.getRemark());
            ValidateSetUtil.setFirstIfListNotEmpty(param.getFileInfo(), p -> {
                billSettlementDTO.setConfirmFileUrl(getFilePath(p.getConfirmFileId(), p.getConfirmFileName()));
                billSettlementDTO.setConfirmFileName(p.getConfirmFileName());
            });
        });
        // 发票快照信息
        InvoiceInfoSnapshotDO invoiceInfoSnapshotDO = settlementDO.getInvoiceInfoSnapshotDO();
        if (invoiceInfoSnapshotDO != null) {
            billSettlementDTO.setInvoiceSnapshot(toDTO(invoiceInfoSnapshotDO));
        }

        // 账户快照信息
        AccountInfoSnapshotDO accountInfoSnapshotDO = settlementDO.getAccountInfoSnapshotDO();
        if (accountInfoSnapshotDO != null) {
            billSettlementDTO.setAccountSnapshot(toDTO(accountInfoSnapshotDO));
        }

        // 操作记录
        billSettlementDTO.setSettlementOperations(toOperationDTO(settlementDO.getSettlementOperationDOS()));
        // 单据明细
        billSettlementDTO.setSettlementItems(toDTO(settlementDO.getBillSettlementItemDOS()));

        // 按钮
        billSettlementDTO.setActionButtons(toButtonDTO(settlementDO.getCascadeButtonDOs()));

        return billSettlementDTO;
    }

    private String getFilePath(String fileId, String fileName) {
        UserParam userParam = buildUserParam(UserUtil.getCurrentUser(),
                AuthResourceProperties.APPID, AuthResourceProperties.DOMAIN_ID);
        ResultDTO<String> fileResult = buildFileUrl(userParam.getDomainId(), userParam.getUserId(), fileId, fileName);
        if (fileResult.isSuccess()) {
            return fileResult.getModel();
        }
        return "";
    }

    private List<ButtonDTO> toButtonDTO(List<CascadeButtonDO> cascadeButtonDOs) {
        List<ButtonDTO> buttonDTOS = Lists.newArrayList();
        if (!CollectionUtils.isEmpty(cascadeButtonDOs)) {
            for (CascadeButtonDO cascadeButtonDO : cascadeButtonDOs) {
                ButtonDTO buttonDTO = new ButtonDTO();

                List<TransitionDTO> transitions = Lists.newArrayList();
                if (!CollectionUtils.isEmpty(cascadeButtonDO.getTransitions())) {
                    for (TransitionDO transitionDO : cascadeButtonDO.getTransitions()) {
                        TransitionDTO transitionDTO = new TransitionDTO();
                        transitionDTO.setTransitionKey(transitionDO.getTransitionKey());
                        transitionDTO.setTips(transitionDO.getTips());
                        transitionDTO.setTransitionName(transitionDO.getTransitionName());
                        transitions.add(transitionDTO);
                    }
                }
                buttonDTO.setName(cascadeButtonDO.getName());
                buttonDTO.setPath(cascadeButtonDO.getPath());
                buttonDTO.setTransitions(transitions);

                buttonDTOS.add(buttonDTO);
            }
        }
        return buttonDTOS;
    }

    private AccountSnapshotDTO toDTO(AccountInfoSnapshotDO accountInfoSnapshotDO) {
        AccountSnapshotDTO accountSnapshotDTO = new AccountSnapshotDTO();
        accountSnapshotDTO.setPurchaserAccount(accountInfoSnapshotDO.getPurchaserAccount());
        accountSnapshotDTO.setPurchaserAccountName(accountInfoSnapshotDO.getPurchaserAccountName());
        accountSnapshotDTO.setPurchaserBankName(accountInfoSnapshotDO.getPurchaserBankName());
        return accountSnapshotDTO;
    }

    private InvoiceSnapshotDTO toDTO(InvoiceInfoSnapshotDO invoiceInfoSnapshotDO) {
        InvoiceSnapshotDTO invoiceDTO = new InvoiceSnapshotDTO();
        invoiceDTO.setInvoiceTel(invoiceInfoSnapshotDO.getInvoiceTel());
        invoiceDTO.setInvoiceTitle(invoiceInfoSnapshotDO.getInvoiceTitle());
        invoiceDTO.setInvoiceBankName(invoiceInfoSnapshotDO.getInvoiceBankName());
        invoiceDTO.setInvoiceBankAccount(invoiceInfoSnapshotDO.getInvoiceBankAccount());
        invoiceDTO.setTaxpayerNumber(invoiceInfoSnapshotDO.getTaxpayerNumber());
        invoiceDTO.setInvoiceAddress(invoiceInfoSnapshotDO.getInvoiceAddress());
        invoiceDTO.setAddress(invoiceInfoSnapshotDO.getAddress());
        invoiceDTO.setContactTel(invoiceInfoSnapshotDO.getContactTel());
        invoiceDTO.setContact(invoiceInfoSnapshotDO.getContact());
        return invoiceDTO;
    }

    private List<SettlementOperationDTO> toOperationDTO(List<SettlementOperationDO> settlementOperationDOS) {
        List<SettlementOperationDTO> settlementOperationDTOS = Lists.newArrayList();

        for (SettlementOperationDO settlementOperationDO : settlementOperationDOS) {
            SettlementOperationDTO settlementOperationDTO = new SettlementOperationDTO();
            if (StringUtils.isBlank(settlementOperationDO.getOperationVote())) {
                continue;
            }
            settlementOperationDTO.setOperationDesc(settlementOperationDO.getOperationDesc());
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            settlementOperationDTO.setOperationEndTime(simpleDateFormat.format(settlementOperationDO.getOperationEndTime()));
            settlementOperationDTO.setOperationMemo(settlementOperationDO.getOperationMemo());
            settlementOperationDTO.setOperationRole(settlementOperationDO.getOperationRole());
            settlementOperationDTO.setOperationVote(settlementOperationDO.getOperationVote());
            settlementOperationDTO.setOperationStartTime(simpleDateFormat.format(settlementOperationDO.getOperationStartTime()));

            settlementOperationDTOS.add(settlementOperationDTO);
        }
        return settlementOperationDTOS;
    }

    private List<BillSettlementItemDTO> toDTO(List<BillSettlementItemDO> billSettlementItemDOS) {
        List<BillSettlementItemDTO> itemDTOList = Lists.newArrayList();

        for (BillSettlementItemDO settlementItemDO : billSettlementItemDOS) {
            BillSettlementItemDTO settlementItemDTO = new BillSettlementItemDTO();
            settlementItemDTO.setSellerId(settlementItemDO.getSellerId());
            settlementItemDTO.setId(settlementItemDO.getId());
            settlementItemDTO.setBillType(BillType.valueOf(settlementItemDO.getBillType()).name());
            settlementItemDTO.setBillAmt(settlementItemDO.getBillAmt());
            settlementItemDTO.setActualBillAmt(settlementItemDO.getActualBillAmt());
            settlementItemDTO.setBillId(settlementItemDO.getBillId());

            itemDTOList.add(settlementItemDTO);
        }
        return itemDTOList;
    }

    private InvoiceDTO toDTO(SellerInvoiceInfoDO sellerInvoiceInfoDO) {
        if (sellerInvoiceInfoDO == null) {
            return null;
        }
        InvoiceDTO invoiceDTO = new InvoiceDTO();
        invoiceDTO.setInvoiceTel(sellerInvoiceInfoDO.getInvoiceTel());
        invoiceDTO.setInvoiceTitle(sellerInvoiceInfoDO.getInvoiceTitle());
        invoiceDTO.setInvoiceBankAccount(sellerInvoiceInfoDO.getInvoiceBankAccount());
        invoiceDTO.setTaxpayerNumber(sellerInvoiceInfoDO.getTaxpayerNumber());
        invoiceDTO.setInvoiceAddress(sellerInvoiceInfoDO.getInvoiceAddress());
        invoiceDTO.setAddress(sellerInvoiceInfoDO.getAddress());
        invoiceDTO.setContactTel(sellerInvoiceInfoDO.getContactTel());
        invoiceDTO.setContact(sellerInvoiceInfoDO.getContact());
        invoiceDTO.setInvoiceBankName(sellerInvoiceInfoDO.getInvoiceBankName());
        return invoiceDTO;
    }

    private AccountDTO toDTO(SellerAccountInfoDO sellerAccountInfoDO) {
        if (sellerAccountInfoDO == null) {
            return null;
        }
        AccountDTO accountDTO = new AccountDTO();
        accountDTO.setPurchaserBankName(sellerAccountInfoDO.getPurchaserBankName());
        accountDTO.setPurchaserAccountName(sellerAccountInfoDO.getPurchaserAccountName());
        accountDTO.setPurchaserAccount(sellerAccountInfoDO.getPurchaserAccount());
        return accountDTO;
    }

    private List<ButtonDTO> copyToButtonDTO(List<ButtonDO> buttonDOs) {
        List<ButtonDTO> buttonDTOs = new ArrayList<>();
        buttonDOs.forEach(buttonDO -> {
            ButtonDTO buttonDTO = new ButtonDTO();
            BeanUtils.copyProperties(buttonDO, buttonDTO);
            buttonDTOs.add(buttonDTO);
        });
        return buttonDTOs;
    }

    private ResultDTO<BillSettlementDTO> doQueryConfirmSettlement(SettlementParam settlementParam) {
        ResultDTO<BillSettlementDO> resultDO = billManager.queryConfirmSettlement(settlementParam.getBillId());
        if (!resultDO.isSuccess()) {
            throw new BaseException(resultDO.getResultCode(), resultDO.getResultMsg());
        }
        ResultDTO<BillSettlementDTO> resultDTO = new ResultDTO<>();

        BillSettlementDTO billSettlementDTO = toDTO(resultDO.getModel());
        String curRole = userManger.getCurrentUserRole();
        BillSettlementDO settlementDO = resultDO.getModel();
        Long procInstId = settlementDO.getProcInstId();
        String dataRole = settlementDO.getRole();
        if (Objects.nonNull(procInstId)) { // 此 流程必定有流程ID
            if (Objects.equals(dataRole, curRole)) {    // 只有 角色相当才显示按钮
                // 动态当前流程可以使用的按钮组
                List<ButtonDO> buttonDOS = billManager.getButtons(settlementDO.getProcInstId(), settlementDO.getNodeKey()).getModel();
                List<ButtonDTO> buttonDTOs = copyToButtonDTO(buttonDOS);
                billSettlementDTO.setActionButtons(buttonDTOs);
            }
        }
        resultDTO.setModel(billSettlementDTO);
        return resultDTO;
    }

}
