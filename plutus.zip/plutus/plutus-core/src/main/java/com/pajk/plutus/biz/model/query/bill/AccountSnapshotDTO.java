package com.pajk.plutus.biz.model.query.bill;

/**
 * 快照
 */
public class AccountSnapshotDTO extends AccountDTO {

}
