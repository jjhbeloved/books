package com.pajk.plutus.biz.model.query.bill;

import java.io.Serializable;

/**
 * @author sunjin
 * @since created by on 17/12/14 00:58
 */
public class BillSettlementItemDTO implements Serializable {

    private static final Long serialVersionUID = -7948108629050932178L;

    private Long id;

    private Long sellerId;

    /**
     * 账单id
     */
    private Long billId;

    /**
     * 单据类型：
     * ITEM_COMMISSION_AMT:商品佣金_总金额
     * ITEM_SETTLEMENT_PROFIT_AMT:结算商品利润_总金额
     * PA_ITEM_AMT:平安承担商品金额合计
     * PA_POST_AMT:平安承担邮费金额合计
     * PA_TAX_AMT:平安承担关税金额合计
     * POST_OTHER_AMT:平安承担其它费用
     * ITEM_COST:应付商品成本合计
     * POST_AMT:应付邮费合计
     * TAX_AMT:应付关税合计
     * SELLER_COD_AMT:商家自收货到付款现金_商品
     */
    private String billType;

    /**
     * 单据金额(分)
     */
    private Long billAmt;

    /**
     * 实际确认单据金额(分)
     */
    private Long actualBillAmt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public String getBillType() {
        return billType;
    }

    public void setBillType(String billType) {
        this.billType = billType;
    }

    public Long getBillAmt() {
        return billAmt;
    }

    public void setBillAmt(Long billAmt) {
        this.billAmt = billAmt;
    }

    public Long getActualBillAmt() {
        return actualBillAmt;
    }

    public void setActualBillAmt(Long actualBillAmt) {
        this.actualBillAmt = actualBillAmt;
    }
}
