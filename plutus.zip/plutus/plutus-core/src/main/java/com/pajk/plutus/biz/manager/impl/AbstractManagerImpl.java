package com.pajk.plutus.biz.manager.impl;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyBatchResult;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.kylin.api.service.AppResourceService;
import com.pajk.kylin.api.service.PermissionService;
import com.pajk.kylin.api.service.SellerService;
import com.pajk.plutus.biz.common.util.JsonUtil;
import com.pajk.plutus.biz.common.util.ResultUtil;
import com.pajk.plutus.biz.manager.AbstractTaskService;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.taskcenter.client.constant.VariableConstant;
import com.pajk.taskcenter.client.model.dto.*;
import com.pajk.taskcenter.client.model.result.BatchResult;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by fuyongda on 2017/12/19.
 * Modified by fuyongda on 2017/12/19.
 */
public abstract class AbstractManagerImpl extends AbstractTaskService {

    private static final Logger logger = LoggerFactory.getLogger(AbstractManagerImpl.class);

    protected static final String SYSTEM = "plutus";
    protected static final String KY_SYSTEM = "taskcenter";
    protected static final String CHANNEL = "all";
    protected static final String PROC_DEF_SOURCE = "procDef";

    @Autowired
    protected AppResourceService appResourceService;

    @Autowired
    protected PermissionService permissionService;

    @Autowired
    protected SellerService sellerService;

    /**
     * 根据商户id列表查询商户
     *
     * @param ids
     * @return Map<Long,SellerDO>
     */
    protected Map<Long, SellerDO> getSellers(List<Long> ids) {
        KyBatchResult<SellerDO> batchResult = sellerService.getSellersByIds(ids);
        if (batchResult.isSuccess()) {
            return batchResult.getModel().stream().collect(Collectors.toMap(SellerDO::getId, sellerDO -> sellerDO));
        }
        return new HashMap<>();
    }

    /**
     * 获取文案配置列表
     *
     * @param system  系统
     * @param channel 渠道
     * @param type    类型
     * @param source  源
     * @return 配置列表
     */
    protected List<AppResourceDO> getAppResource(String system, String channel, String type, String source) {
        KyBatchResult<AppResourceDO> kyBatchResult = appResourceService.getAppResource(system, channel, type, source);
        logger.info("appResourceService.getAppResource, system:{}, channel:{}, type:{}, source:{}, kyBatchResult is {}",
                system, channel, type, source, JsonUtil.obj2Str(kyBatchResult));

        if (kyBatchResult.isSuccess()) {
            return kyBatchResult.getModel();
        } else {
            return Collections.emptyList();
        }
    }

    /**
     * 获取文案配置
     *
     * @param system  系统
     * @param channel 渠道
     * @param type    类型
     * @param source  源
     * @param key     主key
     * @return 配置
     */
    protected AppResourceDO getAppResource(String system, String channel, String type, String source, String key) {
        KyCallResult<AppResourceDO> kyCallResult = appResourceService.getAppResource(system, channel, type, source, key);
        logger.info("appResourceService.getAppResource, system:{}, channel:{}, type:{}, source:{}, key:{}, result:{}",
                system, channel, type, source, key, JsonUtil.obj2Str(kyCallResult));

        if (kyCallResult.isSuccess()) {
            return kyCallResult.getModel();
        } else {
            return null;
        }
    }

    /**
     * 审批前置检查接口
     *
     * @param dbRole        当前单据数据库角色
     * @param dbNodeKey     当前单据数据库节点
     * @param procInstId    当前单据流程id
     * @param nodeKey       当前执行流程的nodeKey
     * @param transitionKey 当前需要执行流程节点下的操作
     * @return ResultDTO<VoidEntity> 是否正确
     */
    protected ResultDTO<VoidEntity> checkPreAuditProcess(long appId, long userId, String dbRole, String dbNodeKey,long procInstId ,
                                                         String nodeKey, String transitionKey, String path) {

        ResultDTO<String> resultDTO = queryRole(appId, userId);
        if (!ErrorCode.SUCCESS.eq(resultDTO.getResultCode())) {
            return ResultUtil.returnResultDTO(resultDTO.getResultCode(), resultDTO.getResultMsg());
        }
        if (!StringUtils.equals(resultDTO.getModel(), dbRole)) {
            return ResultUtil.returnResultDTO(ErrorCode.FLOW_ROLE_NOT_MATCH);
        }

        if (!StringUtils.equals(nodeKey, dbNodeKey)) {
            return ResultUtil.returnResultDTO(ErrorCode.STATUS_NOT_MATCH);
        }

        NodeDTO nodeDTO = getNodeInfo(procInstId, nodeKey);
        if (Objects.isNull(nodeDTO)) {
            return ResultUtil.returnResultDTO(ErrorCode.FLOW_OPT_NOT_MATCH);
        }
        if(!StringUtils.equals(path,nodeDTO.getPath())){
            return ResultUtil.returnResultDTO(ErrorCode.FLOW_OPT_NOT_MATCH);
        }

        boolean matchTransition = isContainButtonKey(nodeDTO, nodeKey, transitionKey);
        if (!matchTransition) {
            return ResultUtil.returnResultDTO(ErrorCode.FLOW_OPT_NOT_MATCH);
        }
        return ResultUtil.returnResultDTO(ErrorCode.SUCCESS);

    }

    /**
     * 校验流程节点是否包括按钮值
     *
     * @param procInstId 流程节点
     * @param nodeKey    节点值
     * @param buttonKey  按钮值
     * @return true包含/false不包含
     */
    protected boolean isContainButtonKey(long procInstId, String nodeKey, String buttonKey) {
        NodeDTO nodeDTO = getNodeInfo(procInstId, nodeKey);
        if (Objects.isNull(nodeDTO)) {
            return false;
        } else {
            return isContainButtonKey(nodeDTO, nodeKey, buttonKey);
        }
    }

    protected boolean isContainButtonKey(NodeDTO nodeDTO, String nodeKey, String buttonKey) {
        List<TransitionDTO> transitionDTOS = nodeDTO.getTransitionDTOList();
        return !CollectionUtils.isEmpty(transitionDTOS) &&
                transitionDTOS.stream().anyMatch(
                        transitionDTO -> StringUtils.equals(buttonKey, transitionDTO.getTransitionKey()));
    }



    /**
     * 创建流程
     *
     * @param name    流程名
     * @param objId   实例ID
     * @param objType 实例类型
     * @return
     */
    protected ResultDTO<CreateProcInstResultDTO> createProcess(String name, String objId, String objType) {
        Map<String, Object> params = Maps.newHashMap();
        params.put(VariableConstant.BIZ_OBJ_ID, objId);
        params.put(VariableConstant.BIZ_OBJ_TYPE, objType);

        ProcessParamDTO processParamDTO = new ProcessParamDTO();
        processParamDTO.setProcName(name);
        processParamDTO.setVariableMap(params);

        List<ProcessParamDTO> processes = Lists.newArrayList(processParamDTO);
        try {
            BatchResult<CreateProcInstResultDTO> batchResultDTO = flowService.createProcess(processes);

            if(!batchResultDTO.isSuccess()){
                logger.warn("create process fail, code:{}, msg:{}, input:{}.",
                        batchResultDTO.getErrorCode(), batchResultDTO.getErrorMsg(),
                        JsonUtil.obj2Str(processParamDTO));
                return ResultUtil.returnResultDTO(ErrorCode.PROCESS_CREATE);
            }

            CreateProcInstResultDTO instResultDTO = batchResultDTO.getModel().get(0);
            if (!instResultDTO.isSuccess()) {
                logger.warn("create process fail, had created, code:{}, msg:{}, input:{}.",
                        instResultDTO.getErrorCode(), instResultDTO.getErrorMsg(), JsonUtil.obj2Str(processParamDTO) );
                return ResultUtil.returnResultDTO(ErrorCode.PROCESS_CREATE);
            }
            return new ResultDTO<>(instResultDTO);

        } catch (Exception e) {
            logger.error("create process {} exception ", JSONObject.toJSONString(processParamDTO), e);
            return ResultUtil.returnResultDTO(ErrorCode.PROCESS_CREATE);
        }
    }

    /**
     * 系统审核流程
     *
     * @param procInstId    流程实例id
     * @param nodeKey       流程节点
     * @param transitionKey 流程操作
     * @param variableMap   流程参数
     * @param remark        流程备注
     * @return
     */
    protected ResultDTO<CompleteTaskResultDTO> completeState(long procInstId, String nodeKey, String transitionKey,
                                                             Map<String, Object> variableMap, String remark) {
        String logTag = "[completeState]";
        TaskParamDTO taskParamDTO = buildTaskParam(procInstId, nodeKey, transitionKey, variableMap, remark);
        try {
            CompleteTaskResultDTO result = flowService.completeState(taskParamDTO);
            if (result.isSuccess()) {
                return new ResultDTO<>(result);
            }

            // TODO: 2017/12/23 待定是否能重入调用
            return completeTask(result, taskParamDTO, logTag);
        } catch (Exception e) {
            logger.error("{} {} exception ", logTag, JSONObject.toJSONString(taskParamDTO), e);
            return ResultUtil.returnResultDTO(ErrorCode.EXCEPTION);
        }
    }

    /**
     * 审批流程
     *
     * @param procInstId    流程ID
     * @param nodeKey       节点
     * @param transitionKey 按钮值
     * @param role          角色
     * @param variableMap   参数变量
     * @param userId        用户ID
     * @param remark        备注
     * @return 结果
     */
    protected ResultDTO<CompleteTaskResultDTO> completeTask(long procInstId, String nodeKey, String transitionKey, String role,
                                                            Map<String, Object> variableMap, String userId, String remark) {
        String logTag = "[completeTask]";
        TaskParamDTO taskParamDTO = buildTaskParam(procInstId, nodeKey, transitionKey, variableMap, remark);
        taskParamDTO.setRole(role);
        taskParamDTO.setApprovalId(userId);
        List<TaskParamDTO> taskParamDTOList = Lists.newArrayList(taskParamDTO);
        try {
            BatchResult<CompleteTaskResultDTO> batchResultDTO = flowService.completeTask(taskParamDTOList);
            if (batchResultDTO.isSuccess()) {
                CompleteTaskResultDTO result = batchResultDTO.getModel().get(0);
                if (result.isSuccess()) {
                    return new ResultDTO<>(result);
                }
                return completeTask(result, taskParamDTO, logTag);
            }
            logger.warn("{} invoke process fail, code:{}, msg:{}, input:{}.",
                    logTag, batchResultDTO.getErrorCode(), batchResultDTO.getErrorMsg(),
                    JSONObject.toJSONString(taskParamDTO));
            return ResultUtil.returnResultDTO(ErrorCode.PROCESS_COMPLETE);
        } catch (Exception e) {
            logger.error("{} {} exception ", logTag, JSONObject.toJSONString(taskParamDTO), e);
            return ResultUtil.returnResultDTO(ErrorCode.EXCEPTION);
        }
    }

    private ResultDTO<CompleteTaskResultDTO> completeTask(CompleteTaskResultDTO result, TaskParamDTO taskParamDTO, String logTag) {

        logger.warn("{} process fail, code:{}, msg:{}, input:{}.",
                logTag, result.getErrorCode(), result.getErrorMsg(),
                JSONObject.toJSONString(taskParamDTO));
        if (com.pajk.taskcenter.client.model.result.ErrorCode.NODE_EXECUTED_ERROR.getCode() == result.getErrorCode()) {
            return nodeEnter(taskParamDTO);
        }
        return ResultUtil.returnResultDTO(ErrorCode.PROCESS_COMPLETE);
    }

    private ResultDTO<CompleteTaskResultDTO> nodeEnter(TaskParamDTO taskParamDTO) {
        try {
            CompleteTaskResultDTO result = flowService.nodeEnter(taskParamDTO, true);
            if (result.isSuccess()) {
                return new ResultDTO<>(result);
            }
            logger.warn("[nodeEnter] process fail, code:{}, msg:{}, input:{}.",
                    result.getErrorCode(), result.getErrorMsg(),
                    JSONObject.toJSONString(taskParamDTO));
            return ResultUtil.returnResultDTO(ErrorCode.PROCESS_COMPLETE);
        } catch (Exception e) {
            logger.error("[nodeEnter] error, in:{} exception ", JSONObject.toJSONString(taskParamDTO), e);
            return ResultUtil.returnResultDTO(ErrorCode.PROCESS_COMPLETE);
        }
    }

    private TaskParamDTO buildTaskParam(long procInstId, String nodeKey, String transitionKey,
                                        Map<String, Object> variableMap, String remark) {
        TaskParamDTO taskParamDTO = new TaskParamDTO();
        taskParamDTO.setProcInstId(procInstId);
        taskParamDTO.setNodeKey(nodeKey);
        taskParamDTO.setTransitionKey(transitionKey);
        taskParamDTO.setApprovalMemo(remark);
        taskParamDTO.setVariableMap(variableMap);
        return taskParamDTO;

    }

    /**
     * 获取用户角色
     *
     * @param appId  appId
     * @param userId 用户id
     * @return ResultDTO<String>
     */
    protected ResultDTO<String> queryRole(long appId, Long userId) {
        KyCallResult<String> kyCallResult = permissionService.getCurRole(userId, appId);
        logger.info("permissionService.getCurRole, userId is {}, appId is {}, kyCallResult is {}",
                userId, appId, JsonUtil.obj2Str(kyCallResult));
        if (!kyCallResult.isSuccess()) {
            return ResultUtil.returnResultDTO(ErrorCode.QUERY_ROLE_FAIL);
        }

        ResultDTO<String> resultDTO = new ResultDTO<>();
        resultDTO.setModel(kyCallResult.getModel());
        return resultDTO;
    }

}
