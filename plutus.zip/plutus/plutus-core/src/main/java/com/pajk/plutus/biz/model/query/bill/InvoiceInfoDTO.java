package com.pajk.plutus.biz.model.query.bill;

import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author sunjin
 * @since created by on 17/12/14 10:45
 */
public class InvoiceInfoDTO implements Serializable {

    private static final long serialVersionUID = -2228529706839842098L;

    private Long sellerId;
    @NotNull
    private Long billId;
    @NotNull
    private Long invoiceAmt;
    @NotNull
    private Long invoiceTaxAmt;
    @NotBlank
    private String invoiceTrackingNumber;
    @NotBlank
    private String invoiceId;

    @NotBlank
    private String buttonKey;

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Long getInvoiceAmt() {
        return invoiceAmt;
    }

    public void setInvoiceAmt(Long invoiceAmt) {
        this.invoiceAmt = invoiceAmt;
    }

    public Long getInvoiceTaxAmt() {
        return invoiceTaxAmt;
    }

    public void setInvoiceTaxAmt(Long invoiceTaxAmt) {
        this.invoiceTaxAmt = invoiceTaxAmt;
    }

    public String getInvoiceTrackingNumber() {
        return invoiceTrackingNumber;
    }

    public void setInvoiceTrackingNumber(String invoiceTrackingNumber) {
        this.invoiceTrackingNumber = invoiceTrackingNumber;
    }

    public String getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(String invoiceId) {
        this.invoiceId = invoiceId;
    }

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public String getButtonKey() {
        return buttonKey;
    }

    public void setButtonKey(String buttonKey) {
        this.buttonKey = buttonKey;
    }
}
