package com.pajk.plutus.biz.common.aop;

/**
 * Created by fanhuafeng on 17/3/27.
 * Modify by fanhuafeng on 17/3/27
 */
public enum  ThrowableLogLevel {
    NO,
    TRACE,
    DEBUG,
    INFO,
    WARN,
    ERROR,
    ;
}
