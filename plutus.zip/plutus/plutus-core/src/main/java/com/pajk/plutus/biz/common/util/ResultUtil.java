package com.pajk.plutus.biz.common.util;

import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;

import java.io.Serializable;

/**
 * Created by fanhuafeng on 17/4/14.
 * Modify by fanhuafeng on 17/4/14
 * 针对返回错误信息的接口
 */
public class ResultUtil {

    private ResultUtil() {
    }

    public static <T extends Serializable> ResultDTO<T> returnResultDTO(int code, String msg) {
        ResultDTO<T> result = new ResultDTO<>();
        result.setResultCode(code);
        result.setResultMsg(msg);
        return result;
    }

    public static <T extends Serializable> ResultDTO<T> returnResultDTO(ResultDTO resultDTO) {
        ResultDTO<T> result = new ResultDTO<>();
        result.setResultCode(resultDTO.getResultCode());
        result.setResultMsg(resultDTO.getResultMsg());
        return result;
    }

    public static <T extends Serializable> ResultDTO<T> returnResultDTO(ErrorCode errorCode) {
        ResultDTO<T> result = new ResultDTO<>();
        result.setResultCode(errorCode.getCode());
        result.setResultMsg(errorCode.getDesc());
        return result;
    }

    public static <T extends Serializable> BatchResultDTO<T> returnBatchResultDTO(ErrorCode errorCode) {
        BatchResultDTO<T> result = new BatchResultDTO<>();
        result.setResultCode(errorCode.getCode());
        result.setResultMsg(errorCode.getDesc());
        return result;
    }

    public static <T extends Serializable> PageResultDTO<T> returnPageResultDTO(int code, String msg) {
        PageResultDTO<T> result = new PageResultDTO<>();
        result.setResultCode(code);
        result.setResultMsg(msg);
        return result;
    }

    public static <T extends Serializable> PageResultDTO<T> returnPageResultDTO(ErrorCode errorCode) {
        PageResultDTO<T> result = new PageResultDTO<>();
        result.setResultCode(errorCode.getCode());
        result.setResultMsg(errorCode.getDesc());
        return result;
    }

}
