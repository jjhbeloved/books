package com.pajk.plutus.biz.exceptions;

/**
 * Created by fanhuafeng on 17/2/27.
 * Modify by fanhuafeng on 17/2/27
 */
public class RomaIgnoreException extends Exception {

    private static final long serialVersionUID = 1337715034398555283L;

    public RomaIgnoreException() {
    }

    public RomaIgnoreException(String message) {
        super(message);
    }

}
