package com.pajk.plutus.biz.model.result.dto.process;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by lizhijun on 2017/12/15.
 */
public class TransitionDTO extends BaseDO {
    private static final long serialVersionUID = 5928616610176041266L;
    /**
     * 具体流程操作参数
     */
    private String transitionKey;
    /**
     * 按钮具体操作标识,也是调用接口必传的字段
     */
    private String transitionName;
    /**
     * 操作提示说明,操作弹出框红色说明,如果没有不用展示
     */
    private String tips;

    public String getTransitionKey() {
        return transitionKey;
    }

    public void setTransitionKey(String transitionKey) {
        this.transitionKey = transitionKey;
    }

    public String getTransitionName() {
        return transitionName;
    }

    public void setTransitionName(String transitionName) {
        this.transitionName = transitionName;
    }

    public String getTips() {
        return tips;
    }

    public void setTips(String tips) {
        this.tips = tips;
    }
}
