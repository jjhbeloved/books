package com.pajk.plutus.biz.service.gw;

import com.google.common.collect.Lists;
import com.pajk.plutus.biz.common.aop.GwLogger;
import com.pajk.plutus.biz.common.util.CommonUtil;
import com.pajk.plutus.biz.common.util.TimeUtils;
import com.pajk.plutus.biz.common.util.ValidateSetUtil;
import com.pajk.plutus.biz.diamond.ControlCache;
import com.pajk.plutus.biz.manager.BillManager;
import com.pajk.plutus.biz.model.bill.*;
import com.pajk.plutus.client.api.gw.BillQueryGWService;
import com.pajk.plutus.client.model.enums.bill.BillType;
import com.pajk.plutus.client.model.enums.bill.SettlementType;
import com.pajk.plutus.client.model.enums.trade.PayToType;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.bill.*;
import com.pajk.plutus.client.model.result.gw.process.TransitionGW;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import net.pocrd.dubboext.DubboExtProperty;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Created by arjaylv on 2017/12/13.
 *
 * @author arjaylv
 */
@Service
@GwLogger
public class BillQueryGWServiceImpl extends AbstractGwServiceImpl implements BillQueryGWService {

    private static final Logger logger = LoggerFactory.getLogger(BillQueryGWServiceImpl.class);

    private static final String OPT_GROUP = "nmd.bill";
    private static final String OPT_ACT = "query";
    /**
     * 商家从诺曼底查询账单列表，获取的账户信息和发票信息都是PAJK的，使用的sellerId为1
     */
    private static final long PAJK_SELLER_ID = 1L;

    @Autowired
    private BillManager billManager;

    @Autowired
    private ControlCache controlCache;

    @Override
    public SettlementOrderGW querySettlement(long appId, long userId, long domainId,
                                             long sellerId, long billId) {
        return gwWrapper(() -> {
            ResultDTO<BillSettlementDO> resultDTO = billManager.querySettlement(billId, sellerId);
            if (!resultDTO.isSuccess()) {
                DubboExtProperty.setErrorCode(JkApiCode.BILL_NOT_EXIST);
                logger.warn("query confirm settlement fail, code:{}, msg:{}, not found billId:{}.",
                        resultDTO.getResultCode(), resultDTO.getResultMsg(), billId);
                return null;
            }
            BillSettlementDO billSettlementDO = resultDTO.getModel();
            if (CollectionUtils.isEmpty(billSettlementDO.getBillSettlementItemDOS())) {
                DubboExtProperty.setErrorCode(JkApiCode.BILL_ITEM_NOT_EXIST);
                logger.warn("query confirm settlement fail, code:{}, msg:{}, billId:{} item is empty.",
                        resultDTO.getResultCode(), resultDTO.getResultMsg(), billId);
                return null;
            }
            return toSettlementOrderGW(userId, domainId, billSettlementDO);
        }, userId, sellerId, appId, OPT_GROUP, OPT_ACT);
    }

    @Override
    public ConfirmSettlementGW queryConfirmSettlement(long appId, long userId, long domainId,
                                                      long sellerId, long billId) {
        return gwWrapper(() -> {
            ResultDTO<BillSettlementDO> resultDTO = billManager.queryConfirmSettlement(billId, sellerId);
            if (!resultDTO.isSuccess()) {
                DubboExtProperty.setErrorCode(JkApiCode.BILL_NOT_EXIST);
                logger.warn("query confirm settlement fail, code:{}, msg:{}, not found billId:{}.",
                        resultDTO.getResultCode(), resultDTO.getResultMsg(), billId);
                return null;
            }
            BillSettlementDO billSettlementDO = resultDTO.getModel();
            if (CollectionUtils.isEmpty(billSettlementDO.getBillSettlementItemDOS())) {
                DubboExtProperty.setErrorCode(JkApiCode.BILL_ITEM_NOT_EXIST);
                logger.warn("query confirm settlement fail, code:{}, msg:{}, billId:{} item is empty.",
                        resultDTO.getResultCode(), resultDTO.getResultMsg(), billId);
                return null;
            }
            String curRole = getCurrentUserRole(userId, appId);
            String dataRole = billSettlementDO.getRole();
            String nodeKey = billSettlementDO.getNodeKey();

            ConfirmSettlementGW confirmSettlementGW = toConfirmSettlementGW(userId, domainId, billSettlementDO);
            // 动态当前流程可以使用的按钮组
            Long procInstId = billSettlementDO.getProcInstId();
            List<ButtonDO> buttonDOS = Lists.newLinkedList();
            if (Objects.isNull(procInstId)) {
                buttonDOS = billManager.getDefaultButtons().getModel();
            } else {
                if (Objects.equals(dataRole, curRole)) {
                    buttonDOS = billManager.getButtons(procInstId, nodeKey).getModel();
                }
            }
            confirmSettlementGW.actionButtons = toButtonModel(buttonDOS);
            return confirmSettlementGW;
        }, userId, sellerId, appId, OPT_GROUP, OPT_ACT);
    }

    @Override
    public PageSettlementGW pageQuerySettlement(long appId, long userId,
                                                long domainId, long sellerId,
                                                String startTime, String endTime,
                                                int pageNo, int pageSize) {
        // 商家从诺曼底查询账单列表，获取的账户信息和发票信息都是PAJK的，使用的sellerId为1
        if (!CommonUtil.isValidSellerId(sellerId)) {
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }

        Date startMonth = TimeUtils.parse(startTime, TimeUtils.MONTH_FORMAT);
        Date endMonth = TimeUtils.parse(endTime, TimeUtils.MONTH_FORMAT);
        int daySpan = controlCache.getBillSettlementQueryDaySpan();
        int dayInterval = controlCache.getBillSettlementQueryDayInterval();
        ErrorCode errorCode = CommonUtil.checkQueryTime(startMonth, endMonth, daySpan, dayInterval);

        if (ErrorCode.SUCCESS.eq(errorCode)) {
            return gwWrapper(() -> doPageQuerySettlement(appId, userId, domainId, sellerId, startMonth, endMonth, pageNo, pageSize)
                    , userId, sellerId, appId, OPT_GROUP, OPT_ACT);
        }

        if (errorCode.eq(ErrorCode.PARAM_ERROR)) {
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }

        if (ErrorCode.QUERY_TOO_OLD.eq(errorCode)) {
            DubboExtProperty.setErrorCode(JkApiCode.QUERY_TIME_TOO_EARLY);
            return null;
        }

        if (ErrorCode.QUERY_INTERVAL_OVER_THRESHOLD.eq(errorCode)) {
            DubboExtProperty.setErrorCode(JkApiCode.QUERY_INTERVAL_OVER_THRESHOLD);
            return null;
        }

        DubboExtProperty.setErrorCode(JkApiCode.QUERY_TIME_ILLEGAL);
        return null;
    }

    private PageSettlementGW doPageQuerySettlement(long appId, long userId,
                                                   long domainId, long sellerId,
                                                   Date startMonth, Date endMonth,
                                                   int pageNo, int pageSize) {
        final String role = getCurrentUserRole(userId, appId);
        if (StringUtils.isBlank(role)) {
            logger.warn("role is blank,userId:{},appId:{},role:{}", userId, appId, role);
            DubboExtProperty.setErrorCode(JkApiCode.NO_PERMISSION_TO_OPT);
            return null;
        }

        // 商户账单信息
        final PageResultDTO<BillSettlementDO> billSettlementDOPageResultDTO = billManager
                .pageQuerySettlement(sellerId, role, TimeUtils.format(startMonth, TimeUtils.SIMPLE_DATA_FORMAT), TimeUtils.format(endMonth, TimeUtils.SIMPLE_DATA_FORMAT), pageNo, pageSize);
        if (!billSettlementDOPageResultDTO.isSuccess()) {
            setError(billSettlementDOPageResultDTO.getResultCode());
            logger.warn("pageQuerySettlement error,code:{},msg:{}",
                    billSettlementDOPageResultDTO.getResultCode(),
                    billSettlementDOPageResultDTO.getResultMsg());
            return null;
        }
        // 商户账户信息
        final SellerInvoiceInfoDO sellerInvoiceInfoDO = billManager.querySellerInvoiceInfo(PAJK_SELLER_ID);
        // 商户发票信息
        final SellerAccountInfoDO sellerAccountInfoDO = billManager.querySellerAccountInfo(PAJK_SELLER_ID);

        final PageSettlementGW pageSettlementGW = new PageSettlementGW();
        pageSettlementGW.pageNo = pageNo;
        pageSettlementGW.pageSize = pageSize;
        pageSettlementGW.totalCount = billSettlementDOPageResultDTO.getTotalCount();

        pageSettlementGW.settlements = billSettlementDOPageResultDTO.getModel().stream()
                .map(billSettlementDO -> toSettlementModel(domainId, userId, billSettlementDO))
                .collect(Collectors.toList());

        pageSettlementGW.sellerInvoice = toSellerInvoiceModel(sellerInvoiceInfoDO);
        pageSettlementGW.sellerAccount = toSellerAccountModel(sellerAccountInfoDO);

        return pageSettlementGW;
    }

    private SettlementGW toSettlementModel(long domainId, long userId, BillSettlementDO billSettlementDO) {
        final SettlementGW settlementGW = new SettlementGW();
        settlementGW.billId = billSettlementDO.getId();
        final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
        settlementGW.month = sdf.format(billSettlementDO.getMonth());
        settlementGW.settlementType = SettlementType.valueOf(billSettlementDO.getSettlementType()).toString();
        settlementGW.payToType = PayToType.valueOf(billSettlementDO.getPayToType()).toString();
        settlementGW.billAmt = billSettlementDO.getBillAmt();
        settlementGW.actualBillAmt = billSettlementDO.getActualBillAmt();
        settlementGW.nodeCatKeyName = billSettlementDO.getNodeCatKeyName();

        ValidateSetUtil.validateNonNullSet(billSettlementDO.getInvoiceInfoDO(), param -> {
            settlementGW.invoiceId = param.getInvoiceId();
            settlementGW.invoiceAmt = ValidateSetUtil.setIfNon(param.getInvoiceAmt(), 0L);
            settlementGW.invoiceTaxAmt = ValidateSetUtil.setIfNon(param.getInvoiceTax(), 0L);
            settlementGW.invoiceTrackingNumber = param.getTrackingNumber();
        });

        ValidateSetUtil.validateNonNullSet(billSettlementDO.getPaymentInfoDOS(), param -> ValidateSetUtil.setFirstIfListNotEmpty(param, p -> {
            settlementGW.paymentNo = p.getPaymentNo();
            settlementGW.paymentFileName = p.getPaymentFileName();
            settlementGW.paymentFileUrl = buildFileUrl(domainId, userId, p.getPaymentFileId(), p.getPaymentFileName());
        }));

        ValidateSetUtil.validateNonNullSet(billSettlementDO.getInvoiceInfoSnapshotDO(), param -> settlementGW.invoiceSnapshot = toInvoiceSnapshotModel(param));
        ValidateSetUtil.validateNonNullSet(billSettlementDO.getAccountInfoSnapshotDO(), param -> settlementGW.accountSnapshot = toAccountSnapshotModel(param));
        settlementGW.actionButtons = toCascadeButtonModel(billSettlementDO.getCascadeButtonDOs());
        return settlementGW;
    }

    private SellerInvoiceGW toSellerInvoiceModel(SellerInvoiceInfoDO sellerInvoiceInfoDO) {
        if (sellerInvoiceInfoDO == null) {
            return null;
        }

        final SellerInvoiceGW sellerInvoiceGW = new SellerInvoiceGW();
        sellerInvoiceGW.invoiceTitle = sellerInvoiceInfoDO.getInvoiceTitle();
        sellerInvoiceGW.contact = sellerInvoiceInfoDO.getContact();
        sellerInvoiceGW.contactTel = sellerInvoiceInfoDO.getContactTel();
        sellerInvoiceGW.invoiceAddress = sellerInvoiceInfoDO.getInvoiceAddress();
        sellerInvoiceGW.taxpayerNumber = sellerInvoiceInfoDO.getTaxpayerNumber();
        sellerInvoiceGW.invoiceTel = sellerInvoiceInfoDO.getInvoiceTel();
        sellerInvoiceGW.address = sellerInvoiceInfoDO.getAddress();
        sellerInvoiceGW.invoiceBankName = sellerInvoiceInfoDO.getInvoiceBankName();
        sellerInvoiceGW.invoiceBankAccount = sellerInvoiceInfoDO.getInvoiceBankAccount();
        return sellerInvoiceGW;
    }

    private SellerAccountGW toSellerAccountModel(SellerAccountInfoDO sellerAccountInfoDO) {
        if (sellerAccountInfoDO == null) {
            return null;
        }

        final SellerAccountGW sellerAccountGW = new SellerAccountGW();
        sellerAccountGW.purchaserAccount = sellerAccountInfoDO.getPurchaserAccount();
        sellerAccountGW.purchaserAccountName = sellerAccountInfoDO.getPurchaserAccountName();
        sellerAccountGW.purchaserBankName = sellerAccountInfoDO.getPurchaserBankName();
        return sellerAccountGW;
    }

    private InvoiceSnapshotGW toInvoiceSnapshotModel(InvoiceInfoSnapshotDO invoiceInfoSnapshotDO) {
        final InvoiceSnapshotGW invoiceSnapshotGW = new InvoiceSnapshotGW();
        invoiceSnapshotGW.invoiceTitle = invoiceInfoSnapshotDO.getInvoiceTitle();
        invoiceSnapshotGW.contact = invoiceInfoSnapshotDO.getContact();
        invoiceSnapshotGW.contactTel = invoiceInfoSnapshotDO.getContactTel();
        invoiceSnapshotGW.invoiceAddress = invoiceInfoSnapshotDO.getInvoiceAddress();
        invoiceSnapshotGW.taxpayerNumber = invoiceInfoSnapshotDO.getTaxpayerNumber();
        invoiceSnapshotGW.invoiceTel = invoiceInfoSnapshotDO.getInvoiceTel();
        invoiceSnapshotGW.address = invoiceInfoSnapshotDO.getAddress();
        invoiceSnapshotGW.invoiceBankName = invoiceInfoSnapshotDO.getInvoiceBankName();
        invoiceSnapshotGW.invoiceBankAccount = invoiceInfoSnapshotDO.getInvoiceBankAccount();
        return invoiceSnapshotGW;
    }

    private AccountSnapshotGW toAccountSnapshotModel(AccountInfoSnapshotDO accountInfoSnapshotDO) {
        final AccountSnapshotGW accountSnapshotGW = new AccountSnapshotGW();
        accountSnapshotGW.purchaserAccount = accountInfoSnapshotDO.getPurchaserAccount();
        accountSnapshotGW.purchaserAccountName = accountInfoSnapshotDO.getPurchaserAccountName();
        accountSnapshotGW.purchaserBankName = accountInfoSnapshotDO.getPurchaserBankName();
        return accountSnapshotGW;
    }

    private SettlementOperationGW toSettlementOperationModel(SettlementOperationDO settlementOperationDO) {
        SettlementOperationGW settlementOperation = new SettlementOperationGW();
        settlementOperation.operationDesc = settlementOperationDO.getOperationDesc();
        settlementOperation.operationStartTime = TimeUtils.format(settlementOperationDO.getOperationStartTime());
        settlementOperation.operationEndTime = TimeUtils.format(settlementOperationDO.getOperationEndTime());
        settlementOperation.operationRole = settlementOperationDO.getOperationRole();
        settlementOperation.operationVote = settlementOperationDO.getOperationVote();
        settlementOperation.operationMemo = settlementOperationDO.getOperationMemo();
        return settlementOperation;
    }

    private SettlementOrderGW toSettlementOrderGW(long userId, long domainId, BillSettlementDO billSettlementDO) {
        SettlementOrderGW settlementOrderGW = new SettlementOrderGW();
        settlementOrderGW.sellerName = billSettlementDO.getSellerName();
        settlementOrderGW.settlementType = SettlementType.valueOf(billSettlementDO.getSettlementType()).name();
        settlementOrderGW.payToType = PayToType.valueOf(billSettlementDO.getPayToType()).name();
        settlementOrderGW.billAmt = billSettlementDO.getBillAmt();
        settlementOrderGW.actualBillAmt = billSettlementDO.getActualBillAmt();
        List<BillSettlementItemDO> billSettlementItemDOS = billSettlementDO.getBillSettlementItemDOS();
        settlementOrderGW.settlementItems = billSettlementItemDOS
                .stream()
                .map(this::toSettlementItemGW)
                .collect(Collectors.toList());
        ValidateSetUtil.validateNonNullSet(billSettlementDO.getConfirmInfoDO(), param -> {
            settlementOrderGW.confirmRemark = param.getRemark();
            ValidateSetUtil.setFirstIfListNotEmpty(param.getFileInfo(), p -> {
                settlementOrderGW.confirmFileUrl = buildFileUrl(domainId, userId, p.getConfirmFileId(), p.getConfirmFileName());
                settlementOrderGW.confirmFileName = p.getConfirmFileName();
            });
        });
        ValidateSetUtil.validateNonNullSet(billSettlementDO.getInvoiceInfoDO(), param -> {
            settlementOrderGW.invoiceId = param.getInvoiceId();
            settlementOrderGW.invoiceAmt = ValidateSetUtil.setIfNon(param.getInvoiceAmt(), 0L);
            settlementOrderGW.invoiceTaxAmt = ValidateSetUtil.setIfNon(param.getInvoiceTax(), 0L);
            settlementOrderGW.invoiceTrackingNumber = param.getTrackingNumber();
        });
        ValidateSetUtil.setFirstIfListNotEmpty(billSettlementDO.getPaymentInfoDOS(), param -> {
            settlementOrderGW.paymentNo = param.getPaymentNo();
            settlementOrderGW.paymentFileUrl = buildFileUrl(domainId, userId, param.getPaymentFileId(), param.getPaymentFileName());
            settlementOrderGW.paymentFileName = param.getPaymentFileName();
        });
        ValidateSetUtil.validateNonNullSet(billSettlementDO.getInvoiceInfoSnapshotDO(),
                param -> settlementOrderGW.invoiceSnapshot = toInvoiceSnapshotModel(param)
        );
        ValidateSetUtil.validateNonNullSet(billSettlementDO.getAccountInfoSnapshotDO(),
                param -> settlementOrderGW.accountSnapshot = toAccountSnapshotModel(param)
        );
        List<SettlementOperationGW> settlementOperations = Lists.newLinkedList();
        ValidateSetUtil.setIfListNotEmpty(billSettlementDO.getSettlementOperationDOS(),
                param -> {
                    if (StringUtils.isNoneBlank(param.getOperationVote())) {
                        settlementOperations.add(toSettlementOperationModel(param));
                    }
                }
        );
        if (!CollectionUtils.isEmpty(settlementOperations)) {
            settlementOrderGW.settlementOperations = settlementOperations;
        }
        return settlementOrderGW;
    }

    private ConfirmSettlementGW toConfirmSettlementGW(long userId, long domainId, BillSettlementDO billSettlementDO) {
        ConfirmSettlementGW confirmSettlementGW = new ConfirmSettlementGW();
        confirmSettlementGW.sellerName = billSettlementDO.getSellerName();
        confirmSettlementGW.settlementType = SettlementType.valueOf(billSettlementDO.getSettlementType()).name();
        confirmSettlementGW.payToType = PayToType.valueOf(billSettlementDO.getPayToType()).name();
        confirmSettlementGW.billAmt = billSettlementDO.getBillAmt();
        confirmSettlementGW.actualBillAmt = billSettlementDO.getActualBillAmt();
        List<BillSettlementItemDO> billSettlementItemDOS = billSettlementDO.getBillSettlementItemDOS();
        confirmSettlementGW.settlementItems = billSettlementItemDOS
                .stream()
                .map(this::toSettlementItemGW)
                .collect(Collectors.toList());
        ValidateSetUtil.validateNonNullSet(billSettlementDO.getConfirmInfoDO(), param -> {
            confirmSettlementGW.confirmRemark = param.getRemark();
            ValidateSetUtil.setFirstIfListNotEmpty(param.getFileInfo(), p -> {
                confirmSettlementGW.confirmFileUrl = buildFileUrl(domainId, userId, p.getConfirmFileId(), p.getConfirmFileName());
                confirmSettlementGW.confirmFileName = p.getConfirmFileName();
            });
        });
        List<SettlementOperationGW> settlementOperations = Lists.newLinkedList();
        ValidateSetUtil.setIfListNotEmpty(billSettlementDO.getSettlementOperationDOS(),
                param -> {
                    if (StringUtils.isNoneBlank(param.getOperationVote())) {
                        settlementOperations.add(toSettlementOperationModel(param));
                    }
                }
        );
        if (!CollectionUtils.isEmpty(settlementOperations)) {
            confirmSettlementGW.settlementOperations = settlementOperations;
        }
        return confirmSettlementGW;
    }

    private SettlementItemGW toSettlementItemGW(BillSettlementItemDO billSettlementItemDO) {
        SettlementItemGW settlementItemGW = new SettlementItemGW();
        settlementItemGW.id = billSettlementItemDO.getId();
        settlementItemGW.billId = billSettlementItemDO.getBillId();
        settlementItemGW.billType = BillType.valueOf(billSettlementItemDO.getBillType()).name();
        settlementItemGW.billAmt = billSettlementItemDO.getBillAmt();
        settlementItemGW.actualBillAmt = billSettlementItemDO.getActualBillAmt();
        return settlementItemGW;
    }

    private List<ButtonGW> toButtonModel(List<ButtonDO> buttonDOS) {
        return buttonDOS.stream()
                .map(buttonDO -> {
                    ButtonGW buttonGW = new ButtonGW();
                    buttonGW.key = buttonDO.getKey();
                    buttonGW.name = buttonDO.getName();
                    buttonGW.path = buttonDO.getPath();
                    return buttonGW;
                }).collect(Collectors.toList());
    }

    private List<CascadeButtonGW> toCascadeButtonModel(List<CascadeButtonDO> cascadeButtonDOs) {
        if (CollectionUtils.isEmpty(cascadeButtonDOs)) {
            return null;
        }
        return cascadeButtonDOs
                .stream()
                .map(cascadeButtonDO -> {
                    final CascadeButtonGW cascadeButtonGW = new CascadeButtonGW();
                    cascadeButtonGW.name = cascadeButtonDO.getName();
                    cascadeButtonGW.path = cascadeButtonDO.getPath();
                    cascadeButtonGW.transitions = cascadeButtonDO.getTransitions().stream()
                            .map(transitionDO -> {
                                final TransitionGW transitionGW = new TransitionGW();
                                transitionGW.transitionKey = transitionDO.getTransitionKey();
                                transitionGW.transitionName = transitionDO.getTransitionName();
                                return transitionGW;
                            })
                            .collect(Collectors.toList());
                    return cascadeButtonGW;
                })
                .collect(Collectors.toList());
    }

    private void setError(int errorCode) {
        switch (errorCode) {
            case ErrorCode.C_NO_PERMISSION_TO_OPT:
                DubboExtProperty.setErrorCode(JkApiCode.NO_PERMISSION_TO_OPT);
                break;
            case ErrorCode.C_BILL_NOT_EXIST:
                DubboExtProperty.setErrorCode(JkApiCode.BILL_NOT_EXIST);
                break;
            case ErrorCode.C_BILL_ITEM_NOT_EXIST:
                DubboExtProperty.setErrorCode(JkApiCode.BILL_ITEM_NOT_EXIST);
                break;
            case ErrorCode.C_PARAM_ERROR:
                DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
                break;
            default:
                DubboExtProperty.setErrorCode(JkApiCode.EXCEPTION);
                break;
        }
    }

}
