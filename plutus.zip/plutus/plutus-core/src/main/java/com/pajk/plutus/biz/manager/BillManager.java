package com.pajk.plutus.biz.manager;

import com.pajk.plutus.biz.model.bill.BillSettlementDO;
import com.pajk.plutus.biz.model.bill.ButtonDO;
import com.pajk.plutus.biz.model.bill.SellerAccountInfoDO;
import com.pajk.plutus.biz.model.bill.SellerInvoiceInfoDO;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.biz.model.query.bill.BillLogDTO;
import com.pajk.plutus.biz.model.query.bill.BillSettlementDTO;
import com.pajk.plutus.biz.model.query.bill.InvoiceInfoDTO;
import com.pajk.plutus.biz.model.query.bill.PaymentInfoDTO;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;

import java.util.Map;

/**
 * Created by arjaylv on 2017/12/13.
 *
 * @author arjaylv
 */
public interface BillManager {

    /**
     * 获取流程定义下默认按钮列表
     *
     * @return 按钮列表
     */
    BatchResultDTO<ButtonDO> getDefaultButtons();

    /**
     * 动态获取流程定义下一个按钮列表
     *
     * @param procInstId 流程ID
     * @param nodeKey    流程指定节点
     * @return 按钮列表
     */
    BatchResultDTO<ButtonDO> getButtons(long procInstId, String nodeKey);

    /**
     * 平安对账-明细-查询
     *
     * @param billId Id
     * @return 明细信息
     */
    ResultDTO<BillSettlementDO> querySettlement(long billId);

    /**
     * 平安对账-明细-查询
     *
     * @param billId   Id
     * @param sellerId 商户ID
     * @return 明细信息
     */
    ResultDTO<BillSettlementDO> querySettlement(long billId, long sellerId);

    /**
     * 获取结算单简易版
     *
     * @param billId 账单ID
     * @return 结算单明细对象
     */
    ResultDTO<BillSettlementDO> queryConfirmSettlement(long billId);

    /**
     * 获取结算单简易版
     *
     * @param billId   账单ID
     * @param sellerId 商户ID
     * @return 结算单明细对象
     */
    ResultDTO<BillSettlementDO> queryConfirmSettlement(long billId, long sellerId);

    /**
     * 确认账单
     *
     * @param billId            账单id
     * @param billSettlementDTO 账单信息
     * @param buttonKey         任务流程方向
     * @param billLogDTO        账单参数
     * @param userParam         用户参数
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> confirmSettlement(long billId, BillSettlementDTO billSettlementDTO,
                                            String buttonKey, BillLogDTO billLogDTO, UserParam userParam);

    /**
     * 确认开票
     *
     * @param invoiceInfoDTO  发票信息
     * @param billLogDTO      账单参数
     * @param userParam       用户参数
     * @param isSellerInvoice 是否商户开票
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> confirmInvoice(InvoiceInfoDTO invoiceInfoDTO, BillLogDTO billLogDTO, UserParam userParam, boolean isSellerInvoice);

    /**
     * 确认付款
     *
     * @param paymentInfoDTO 付款信息
     * @param billLogDTO     账单参数
     * @param userParam      用户参数
     * @param isSellerPay    是否商户付款
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> confirmPayment(PaymentInfoDTO paymentInfoDTO, BillLogDTO billLogDTO, UserParam userParam, boolean isSellerPay);

    /**
     * 总账-确认/驳回收票
     *
     * @param billId     账单id
     * @param buttonKey  任务流程方向
     * @param billLogDTO 账单参数
     * @param userParam  用户参数
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> receiveInvoice(long billId, String buttonKey, BillLogDTO billLogDTO, UserParam userParam);

    /**
     * 总账-确认/驳回收款
     *
     * @param billId     账单id
     * @param buttonKey  任务流程方向
     * @param billLogDTO 账单参数
     * @param userParam  用户参数
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> confirmReceivePayment(long billId, String buttonKey, BillLogDTO billLogDTO, UserParam userParam);

    /**
     * 确认/驳回账单
     *
     * @param billId     账单id
     * @param buttonKey  任务流程方向
     * @param billLogDTO 账单参数
     * @param userParam  用户参数
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> confirmOnlyRemark(long billId, String buttonKey, BillLogDTO billLogDTO, UserParam userParam);

    /**
     * 查询发票信息
     *
     * @param sellerId 商户id
     * @return SellerInvoiceInfoDO
     */
    SellerInvoiceInfoDO querySellerInvoiceInfo(long sellerId);

    /**
     * 查询付款账户信息
     *
     * @param sellerId 商户id
     * @return SellerAccountInfoDO
     */
    SellerAccountInfoDO querySellerAccountInfo(long sellerId);

    /**
     * 平安对账-商户-查询列表,分页查询
     *
     * @param role     角色
     * @param pageNo   页码
     * @param pageSize 每页显示数量
     * @param params   查询条件
     * @return 分页列表数据
     */
    PageResultDTO<BillSettlementDO> pageQuerySettlementByCondition(String role, int pageNo, int pageSize, Map<String, Object> params);

    /**
     * 分页查询商户对账总账
     *
     * @param sellerId  商户id
     * @param role      角色
     * @param startTime 开始-对账时间
     * @param endTime   结束-对账时间
     * @param pageNo    分页起始页码
     * @param pageSize  分页每页数量
     * @return PageResultDTO<BillSettlementDO>
     */
    PageResultDTO<BillSettlementDO> pageQuerySettlement(long sellerId, String role, String startTime,
                                                        String endTime, int pageNo, int pageSize);
}
