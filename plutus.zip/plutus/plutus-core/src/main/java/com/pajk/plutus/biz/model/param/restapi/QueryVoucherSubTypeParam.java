package com.pajk.plutus.biz.model.param.restapi;

import com.pajk.thunderbird.domain.result.BaseDO;

import javax.validation.constraints.NotNull;

/**
 * Created by lizhijun on 2017/12/19.
 */
public class QueryVoucherSubTypeParam extends BaseDO {
    private static final long serialVersionUID = -413891651321638017L;
    @NotNull
    private Integer voucherType;
    @NotNull
    private Boolean isCanHandleCreate;

    public Integer getVoucherType() {
        return voucherType;
    }

    public void setVoucherType(Integer voucherType) {
        this.voucherType = voucherType;
    }

    public Boolean getIsCanHandleCreate() {
        return isCanHandleCreate;
    }

    public void setIsCanHandleCreate(Boolean canHandleCreate) {
        isCanHandleCreate = canHandleCreate;
    }
}
