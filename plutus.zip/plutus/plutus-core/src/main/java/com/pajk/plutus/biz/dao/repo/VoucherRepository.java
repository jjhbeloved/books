package com.pajk.plutus.biz.dao.repo;

import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.account.AccountBookFlowDO;
import com.pajk.plutus.biz.model.account.StatementDO;
import com.pajk.plutus.biz.model.voucher.VoucherDO;
import com.pajk.plutus.biz.model.voucher.VoucherDeliveryDO;
import com.pajk.plutus.biz.model.voucher.VoucherLogDO;

import java.util.List;

/**
 * Created by lizhijun on 2017/12/17.
 */
public interface VoucherRepository {
    /**
     * 删除违规单
     *
     * @param voucherDO  违规单
     * @param voucherLog
     */
    void deletePunish(VoucherDO voucherDO, VoucherLogDO voucherLog);

    /**
     * 创建违规单
     *
     * @param voucherDO  违规单
     * @param voucherLog 日志
     */
    void createPunish(VoucherDO voucherDO, VoucherLogDO voucherLog);

    /**
     * 更新单据中流程相关信息
     *
     * @param voucherDO  违规单
     * @param voucherLog
     */
    void submitPunish(VoucherDO voucherDO, VoucherLogDO voucherLog);

    /**
     * 更新单据和扣款
     *
     * @param voucherDO        单据信息
     * @param books            账本信息
     * @param accountBookFlows 账本流水
     * @param voucherLog       日志
     */
    void auditPunish(VoucherDO voucherDO, List<AccountBookDO> books, List<AccountBookFlowDO> accountBookFlows, VoucherLogDO voucherLog);

    /**
     * 财务审核缴费更新信息
     *
     * @param voucherDO   单据信息
     * @param bookDO      账本信息
     * @param bookFlowDO  账本流水
     * @param statementDO 财务信息
     * @param voucherLog  日志
     */
    void auditPayment(VoucherDO voucherDO, AccountBookDO bookDO, AccountBookFlowDO bookFlowDO, StatementDO statementDO, VoucherLogDO voucherLog);

    /**
     * 商管
     * @param voucherDO  单据信息
     * @param voucherLog 日志
     */
    void auditPayment(VoucherDO voucherDO, VoucherLogDO voucherLog);

    void confirmPayment(VoucherDO voucherDO, VoucherLogDO voucherLog);

    /**
     * 根据违规订单数据自动创建违规单
     *  @param voucherDO         违规单
     * @param voucherDeliveryDO 违规订单
     * @param voucherLog
     */
    void autoCreatePunish(VoucherDO voucherDO, VoucherDeliveryDO voucherDeliveryDO, VoucherLogDO voucherLog);

    /**
     * 修改合同金额
     *
     * @param voucherDO       单据信息
     * @param bookDO          账本信息
     * @param bookFlowDO      账本流水
     * @param statementDO     财务信息
     * @param baseContractAmt 原始合同金额
     * @param voucherLog      日志
     */
    void updateContractAmt(VoucherDO voucherDO, AccountBookDO bookDO, AccountBookFlowDO bookFlowDO, StatementDO statementDO, long baseContractAmt, VoucherLogDO voucherLog);

    /**
     * 补齐缴费 新增缴费单到voucher表 更新违规单账本流水的销账id
     *  @param voucherDO    对应缴费单
     * @param bookFlowDO   对应对应缴费单流水
     * @param statementDO  对应财务流水
     * @param lists        List<List<AccountBookFlowDO>> 对应销账违规单据集合
     * @param writeOffType 销帐来源类型如fc_voucher
     * @param voucherLog 日志
     */
    void addBalanceAmt(VoucherDO voucherDO, AccountBookFlowDO bookFlowDO, StatementDO statementDO, List<List<AccountBookFlowDO>> lists, String writeOffType, VoucherLogDO voucherLog);

}
