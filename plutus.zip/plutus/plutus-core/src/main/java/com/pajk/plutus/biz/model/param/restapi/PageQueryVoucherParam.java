package com.pajk.plutus.biz.model.param.restapi;

import com.pajk.plutus.client.model.enums.voucher.VoucherSubType;
import com.pajk.plutus.client.model.enums.voucher.VoucherType;
import com.pajk.thunderbird.domain.result.BaseDO;

import javax.validation.constraints.NotNull;

/**
 * Created by lizhijun on 2017/12/19.
 */

public class PageQueryVoucherParam extends BaseDO {

    private static final long serialVersionUID = 7574528990380222908L;

    /**
     * 商家Id
     */
    private Long sellerId;

    /**
     * 单据Id
     */
    private String voucherId;

    /**
     * 单据状态
     */
    @NotNull
    private String nodeKey;

    /**
     * 单据类型
     * {@link VoucherType#getCode()}
     */
    @NotNull
    private Integer voucherType;

    /**
     * 单据子类型
     * {@link VoucherSubType#getCode()}
     */
    @NotNull
    private Integer voucherSubType;

    /**
     * 关键信息
     */
    private String keyStr;

    /**
     * 创建起始时间
     */
    private String createStart;

    /**
     * 创建结束时间
     */
    private String createEnd;

    /**
     * 提交起始时间
     */
    private String commitStart;

    /**
     * 提交结束时间
     */
    private String commitEnd;

    /**
     * 页数 , 1< pageNo <300
     */
    private int pageNo = 1;

    /**
     * 页码  pageSize  *  pageNo <=10000
     */
    private int pageSize = 50;

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public String getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(String voucherId) {
        this.voucherId = voucherId;
    }

    public String getNodeKey() {
        return nodeKey;
    }

    public void setNodeKey(String nodeKey) {
        this.nodeKey = nodeKey;
    }

    public Integer getVoucherType() {
        return voucherType;
    }

    public void setVoucherType(Integer voucherType) {
        this.voucherType = voucherType;
    }

    public Integer getVoucherSubType() {
        return voucherSubType;
    }

    public void setVoucherSubType(Integer voucherSubType) {
        this.voucherSubType = voucherSubType;
    }

    public String getKeyStr() {
        return keyStr;
    }

    public void setKeyStr(String keyStr) {
        this.keyStr = keyStr;
    }

    public String getCreateStart() {
        return createStart;
    }

    public void setCreateStart(String createStart) {
        this.createStart = createStart;
    }

    public String getCreateEnd() {
        return createEnd;
    }

    public void setCreateEnd(String createEnd) {
        this.createEnd = createEnd;
    }

    public String getCommitStart() {
        return commitStart;
    }

    public void setCommitStart(String commitStart) {
        this.commitStart = commitStart;
    }

    public String getCommitEnd() {
        return commitEnd;
    }

    public void setCommitEnd(String commitEnd) {
        this.commitEnd = commitEnd;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

}
