package com.pajk.plutus.biz.model.mapper.single.account;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * Created by guguangming on 2017/12/18.
 */
public class AccountBookUpdateOPT extends BaseDO {

    private static final long serialVersionUID = 495142119527674452L;
    /**************************************************query*****************************************************/

    /**
     * 主键id
     **/
    private long id;

    /**
     * 版本号
     **/
    private int version;

    /**
     * 商户id
     **/
    private long sellerId;

    /**
     * 原始合同金额
     */
    private Long baseContractAmt;

    /**************************************************update*****************************************************/


    /**
     * 账本余额(单位分)
     **/
    private Long balanceAmt;

    /**
     * 账本合同金额(单位分)
     **/
    private Long ContractAmt;
    /**
     * 实收账本合同金额(单位分)
     */
    private Long ActualContractAmt;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public long getSellerId() {
        return sellerId;
    }

    public void setSellerId(long sellerId) {
        this.sellerId = sellerId;
    }


    public Long getBaseContractAmt() {
        return baseContractAmt;
    }

    public void setBaseContractAmt(Long baseContractAmt) {
        this.baseContractAmt = baseContractAmt;
    }

    public Long getBalanceAmt() {
        return balanceAmt;
    }

    public void setBalanceAmt(Long balanceAmt) {
        this.balanceAmt = balanceAmt;
    }

    public Long getContractAmt() {
        return ContractAmt;
    }

    public void setContractAmt(Long contractAmt) {
        ContractAmt = contractAmt;
    }

    public Long getActualContractAmt() {
        return ActualContractAmt;
    }

    public void setActualContractAmt(Long actualContractAmt) {
        ActualContractAmt = actualContractAmt;
    }
}
