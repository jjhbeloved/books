package com.pajk.plutus.biz.service.gw;

import com.google.common.collect.Lists;
import com.pajk.kylin.apigw.model.domain.UserInfoDTO;
import com.pajk.plutus.biz.common.aop.GwLogger;
import com.pajk.plutus.biz.common.util.JsonUtil;
import com.pajk.plutus.biz.manager.BillManager;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.biz.model.query.bill.*;
import com.pajk.plutus.client.api.gw.BillGWService;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.plutus.client.model.result.JkApiCode;
import com.pajk.plutus.client.model.result.gw.VoidGwEntity;
import com.pajk.plutus.client.model.result.gw.bill.SettlementItemConfirmGW;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;
import net.pocrd.dubboext.DubboExtProperty;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by arjaylv on 2017/12/13.
 *
 * @author arjaylv
 */
@Service
@GwLogger
public class BillGWServiceImpl extends AbstractGwServiceImpl implements BillGWService {
    private static final Logger logger = LoggerFactory.getLogger(BillGWServiceImpl.class);

    private static final String OPT_GROUP = "nmd.bill";
    private static final String OPT_ACT = "update";

    private static final int MAX_REMARK_COUNT = 500;
    private static final int MAX_CONFIRM_STRING_LENGTH = 100;

    @Autowired
    private BillManager billManager;

    @Override
    public VoidGwEntity confirmSettlement(long appId, long userId,
                                          long sellerId, long billId,
                                          List<SettlementItemConfirmGW> settlementItemConfirms,
                                          String buttonKey,
                                          String confirmFileId, String confirmFileName, String confirmRemark) {
        String path = "plutus.confirmSettlement";

        if (StringUtils.length(confirmFileId) > MAX_CONFIRM_STRING_LENGTH) {
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }

        if (StringUtils.length(confirmFileName) > MAX_CONFIRM_STRING_LENGTH) {
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }

        if (StringUtils.length(confirmRemark) > MAX_REMARK_COUNT) {
            DubboExtProperty.setErrorCode(JkApiCode.REMARK_TOO_LONG);
            return null;
        }

        List<BillSettlementItemDTO> billSettlementItemDTOS = Lists.newLinkedList();
        for (SettlementItemConfirmGW settlementItemConfirmGW : settlementItemConfirms) {
            long id = settlementItemConfirmGW.id;
            long actualBillAmt = settlementItemConfirmGW.actualBillAmt;
            BillSettlementItemDTO billSettlementItemDTO = new BillSettlementItemDTO();
            billSettlementItemDTO.setId(id);
            billSettlementItemDTO.setActualBillAmt(actualBillAmt);
            billSettlementItemDTOS.add(billSettlementItemDTO);
        }

        UserParam userParam = new UserParam(appId, userId);
        userParam.setPath(path);

        return gwWrapper(() -> {
            BillLogDTO billLogDTO = new BillLogDTO();
            if (!isIncludeUserAndSet(appId, userId, billLogDTO)) {
                return null;
            }
            BillSettlementDTO billSettlementDTO = new BillSettlementDTO();
            billSettlementDTO.setSettlementItems(billSettlementItemDTOS);
            billSettlementDTO.setConfirmFileName(confirmFileName);
            billSettlementDTO.setConfirmFileUrl(confirmFileId);
            billSettlementDTO.setConfirmRemark(confirmRemark);

            billLogDTO.setSellerId(sellerId);
            billLogDTO.setRemark(confirmRemark);
            ResultDTO<VoidEntity> resultDTO = billManager.confirmSettlement(billId, billSettlementDTO, buttonKey, billLogDTO, userParam);
            if (!resultDTO.isSuccess()) {
                setError(resultDTO.getResultCode());
                logger.warn("confirm settlement fail. error:{}", JsonUtil.obj2Str(resultDTO));
                return null;
            }
            return new VoidGwEntity();
        }, userId, sellerId, appId, OPT_GROUP, OPT_ACT);
    }

    @Override
    public VoidGwEntity confirmInvoice(long appId, long userId,
                                       long sellerId, long billId,
                                       long invoiceAmt, long invoiceTaxAmt, String invoiceTrackingNumber, String invoiceId,
                                       String buttonKey) {
        String path = "plutus.confirmInvoice";

        if (StringUtils.length(invoiceId) > MAX_CONFIRM_STRING_LENGTH) {
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }

        if (StringUtils.length(invoiceTrackingNumber) > MAX_CONFIRM_STRING_LENGTH) {
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }

        UserParam userParam = new UserParam(appId, userId);
        userParam.setPath(path);

        return gwWrapper(() -> {
            BillLogDTO billLogDTO = new BillLogDTO();
            if (!isIncludeUserAndSet(appId, userId, billLogDTO)) {
                return null;
            }
            InvoiceInfoDTO invoiceInfoDTO = new InvoiceInfoDTO();
            invoiceInfoDTO.setInvoiceAmt(invoiceAmt);
            invoiceInfoDTO.setInvoiceTaxAmt(invoiceTaxAmt);
            invoiceInfoDTO.setInvoiceTrackingNumber(invoiceTrackingNumber);
            invoiceInfoDTO.setInvoiceId(invoiceId);
            invoiceInfoDTO.setBillId(billId);
            invoiceInfoDTO.setButtonKey(buttonKey);

            billLogDTO.setSellerId(sellerId);
            ResultDTO<VoidEntity> resultDTO = billManager.confirmInvoice(invoiceInfoDTO, billLogDTO, userParam, true);
            if (!resultDTO.isSuccess()) {
                setError(resultDTO.getResultCode());
                logger.warn("confirm invoice fail. error:{}", JsonUtil.obj2Str(resultDTO));
                return null;
            }
            return new VoidGwEntity();
        }, userId, sellerId, appId, OPT_GROUP, OPT_ACT);
    }

    @Override
    public VoidGwEntity receiveInvoice(long appId, long userId,
                                       long sellerId, long billId,
                                       String buttonKey, String remark) {
        String path = "plutus.receiveInvoice";

        if (StringUtils.length(remark) > MAX_REMARK_COUNT) {
            DubboExtProperty.setErrorCode(JkApiCode.REMARK_TOO_LONG);
            return null;
        }

        UserParam userParam = new UserParam(appId, userId);
        userParam.setPath(path);

        return gwWrapper(() -> {
                    BillLogDTO billLogDTO = new BillLogDTO();
                    if (!isIncludeUserAndSet(appId, userId, billLogDTO)) {
                        return null;
                    }

                    billLogDTO.setSellerId(sellerId);
                    billLogDTO.setRemark(remark);
                    ResultDTO<VoidEntity> resultDTO = billManager.receiveInvoice(billId, buttonKey, billLogDTO, userParam);
                    if (!resultDTO.isSuccess()) {
                        setError(resultDTO.getResultCode());
                        logger.warn("receive invoice fail. error:{}", JsonUtil.obj2Str(resultDTO));
                        return null;
                    }
                    return new VoidGwEntity();
                },
                userId, sellerId, appId, OPT_GROUP, OPT_ACT);
    }

    @Override
    public VoidGwEntity confirmPayment(long appId, long userId,
                                       long sellerId, long billId,
                                       String paymentNo, String buttonKey,
                                       String paymentFileId, String paymentFileName) {
        String path = "plutus.confirmPayment";

        if (StringUtils.length(paymentNo) > MAX_CONFIRM_STRING_LENGTH) {
            DubboExtProperty.setErrorCode(JkApiCode.PAYMENT_NO_TOO_LONG);
            return null;
        }

        if (StringUtils.length(paymentFileId) > MAX_CONFIRM_STRING_LENGTH) {
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }

        if (StringUtils.length(paymentFileName) > MAX_CONFIRM_STRING_LENGTH) {
            DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
            return null;
        }

        UserParam userParam = new UserParam(appId, userId);
        userParam.setPath(path);

        return gwWrapper(() -> {
            BillLogDTO billLogDTO = new BillLogDTO();
            if (!isIncludeUserAndSet(appId, userId, billLogDTO)) {
                return null;
            }
            PaymentInfoDTO paymentInfoDTO = new PaymentInfoDTO();
            paymentInfoDTO.setPaymentNo(paymentNo);
            paymentInfoDTO.setPaymentFileId(paymentFileId);
            paymentInfoDTO.setPaymentFileName(paymentFileName);
            paymentInfoDTO.setBillId(billId);
            paymentInfoDTO.setButtonKey(buttonKey);

            billLogDTO.setSellerId(sellerId);
            ResultDTO<VoidEntity> resultDTO = billManager.confirmPayment(paymentInfoDTO, billLogDTO, userParam, true);
            if (!resultDTO.isSuccess()) {
                setError(resultDTO.getResultCode());
                logger.warn("confirm payment fail. error:{}", JsonUtil.obj2Str(resultDTO));
                return null;
            }
            return new VoidGwEntity();
        }, userId, sellerId, appId, OPT_GROUP, OPT_ACT);
    }

    @Override
    public VoidGwEntity confirmReceivePayment(long appId, long userId,
                                              long sellerId, long billId,
                                              String buttonKey, String remark) {
        String path = "plutus.confirmReceivePayment";

        if (StringUtils.length(remark) > MAX_REMARK_COUNT) {
            DubboExtProperty.setErrorCode(JkApiCode.REMARK_TOO_LONG);
            return null;
        }

        UserParam userParam = new UserParam(appId, userId);
        userParam.setPath(path);

        return gwWrapper(() -> {
                    BillLogDTO billLogDTO = new BillLogDTO();
                    if (!isIncludeUserAndSet(appId, userId, billLogDTO)) {
                        return null;
                    }
                    billLogDTO.setSellerId(sellerId);
                    billLogDTO.setRemark(remark);
                    ResultDTO<VoidEntity> resultDTO = billManager.confirmReceivePayment(billId, buttonKey, billLogDTO, userParam);
                    if (!resultDTO.isSuccess()) {
                        setError(resultDTO.getResultCode());
                        logger.warn("confirm receive payment fail. error:{}", JsonUtil.obj2Str(resultDTO));
                        return null;
                    }
                    return new VoidGwEntity();
                },
                userId, sellerId, appId, OPT_GROUP, OPT_ACT);
    }

    private void setError(int errorCode) {
        switch (errorCode) {
            case ErrorCode.C_NO_PERMISSION_TO_OPT:
                DubboExtProperty.setErrorCode(JkApiCode.NO_PERMISSION_TO_OPT);
                break;
            case ErrorCode.C_BILL_NOT_EXIST:
                DubboExtProperty.setErrorCode(JkApiCode.BILL_NOT_EXIST);
                break;
            case ErrorCode.C_BILL_ITEM_NOT_EXIST:
                DubboExtProperty.setErrorCode(JkApiCode.BILL_ITEM_NOT_EXIST);
                break;
            case ErrorCode.C_INVOICE_AMT_ERROR:
                DubboExtProperty.setErrorCode(JkApiCode.INVOICE_AMT_ERROR);
                break;
            case ErrorCode.C_PARAM_ERROR:
                DubboExtProperty.setErrorCode(JkApiCode.PARAM_ERROR);
                break;
            case ErrorCode.C_PROCESS_CREATE:
            case ErrorCode.C_PROCESS_COMPLETE:
            default:
                DubboExtProperty.setErrorCode(JkApiCode.EXCEPTION);
                break;
        }
    }

    private boolean isIncludeUserAndSet(long appId, long userId, BillLogDTO billLogDTO) {
        // 1. 获取角色并校验
        String role = getCurrentUserRole(userId, appId);
        if (StringUtils.isBlank(role)) {
            DubboExtProperty.setErrorCode(JkApiCode.NO_PERMISSION_TO_OPT);
            return false;
        }
        // 2. 获取用户信息
        UserInfoDTO userInfoDTO = getUserInfo(userId);
        if (StringUtils.isBlank(userInfoDTO.loginName)) {
            DubboExtProperty.setErrorCode(JkApiCode.NO_PERMISSION_TO_OPT);
            return false;
        }
        billLogDTO.setOperatorId(String.valueOf(userId));
        billLogDTO.setRole(role);
        billLogDTO.setOperatorName(userInfoDTO.loginName);
        return true;
    }

}
