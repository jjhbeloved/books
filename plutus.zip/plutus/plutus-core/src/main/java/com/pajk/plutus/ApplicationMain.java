package com.pajk.plutus;

import com.alibaba.dubbo.container.Main;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author yuewenxin
 * @version v 0.1 15/9/11 17:00 aaronyue Exp $$
 */
@SpringBootApplication
@ComponentScan
public class ApplicationMain {

    public static void main(String[] args) {
        SpringApplication.run(ApplicationMain.class, args);
        Main.main(null);
        System.out.println(new SimpleDateFormat("[yyyy-MM-dd HH:mm:ss]")
                .format(new Date()) + " Dubbo service server started!");
    }

}
