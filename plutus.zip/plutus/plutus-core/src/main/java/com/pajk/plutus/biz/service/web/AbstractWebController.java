package com.pajk.plutus.biz.service.web;

import com.pajk.filegw.api.FileTokenService;
import com.pajk.filegw.api.TfsGroup;
import com.pajk.kylin.api.model.domain.AppResourceDO;
import com.pajk.kylin.api.model.domain.PermissionCheckDO;
import com.pajk.kylin.api.model.domain.ResourceDO;
import com.pajk.kylin.api.model.domain.SellerDO;
import com.pajk.kylin.api.model.result.KyBatchResult;
import com.pajk.kylin.api.model.result.KyCallResult;
import com.pajk.kylin.api.service.AppResourceService;
import com.pajk.kylin.api.service.PermissionService;
import com.pajk.kylin.api.service.SellerService;
import com.pajk.plutus.biz.common.util.JsonUtil;
import com.pajk.plutus.biz.common.util.ResultUtil;
import com.pajk.plutus.biz.common.util.TimeUtils;
import com.pajk.plutus.biz.common.util.ValidateSetUtil;
import com.pajk.plutus.biz.diamond.ConstantCache;
import com.pajk.plutus.biz.manager.AbstractTaskService;
import com.pajk.plutus.biz.manager.permission.AuthResourceProperties;
import com.pajk.plutus.biz.manager.permission.UserUtil;
import com.pajk.plutus.biz.model.enums.FlowTypeEnum;
import com.pajk.plutus.biz.model.param.transfer.UserParam;
import com.pajk.plutus.biz.model.process.FlowStatusDO;
import com.pajk.plutus.biz.model.result.dto.account.AuditFlowDTO;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.taskcenter.client.model.dto.TaskInstDTO;
import com.pajk.taskcenter.client.model.query.BizObjQuery;
import com.pajk.taskcenter.client.model.result.BatchResult;
import com.pajk.thunderbird.domain.result.BatchResultDTO;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.ResultSupport;
import com.pajk.user.model.User;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * Created by fanhuafeng on 17/12/18.
 * Modify by fanhuafeng on 17/12/18
 */
public abstract class AbstractWebController extends AbstractTaskService {

    private static final Logger logger = LoggerFactory.getLogger(AbstractWebController.class);

    private static final String SYSTEM = "plutus";

    private static final String KY_SYSTEM = "taskcenter";
    private static final String CHANNEL = "all";
    private static final String STATUS = "Status";
    private static final String TIP = "Tip";
    private static final String PROC_DEF_SOURCE = "procDef";
    private static final String PROC_STATUS_SOURCE = "procStatus";
    private static final String PROC_DEF_TIP = "procTip";

    @Autowired
    private PermissionService permissionService;

    @Autowired
    protected SellerService sellerService;

    @Autowired
    private FileTokenService fileTokenService;

    @Autowired
    private ConstantCache constantCache;

    @Autowired
    protected AppResourceService appResourceService;



    UserParam buildUserParam(User user, long appId, long domainId) {
        UserParam param = new UserParam(appId, user.getId(), domainId);
        param.setUserName(user.getName());
        return param;
    }

    protected <T extends Serializable> ResultDTO<T> wrapper(
            Supplier<ResultDTO<T>> supplier, String name, String operation) {
        return wrapper(supplier, name, operation, new ResultDTO<>());
    }

    protected <T extends Serializable> PageResultDTO<T> pageWrapper(
            Supplier<PageResultDTO<T>> supplier, String name, String operation) {
        return wrapper(supplier, name, operation, new PageResultDTO<>());
    }

    protected <T extends Serializable> BatchResultDTO<T> batchWrapper(
            Supplier<BatchResultDTO<T>> supplier, String name, String operation) {
        return wrapper(supplier, name, operation, new BatchResultDTO<>());
    }

    protected boolean hasPermission(long userId, long appId, String name, String operator) {
        String newName = SYSTEM + "." + name;

        ResourceDO resourceDO = new ResourceDO();

        resourceDO.setName(newName);
        resourceDO.setOperation(operator);

        PermissionCheckDO permissionCheckDO = new PermissionCheckDO();

        permissionCheckDO.setApplicationId(appId);
        permissionCheckDO.setUserId(userId);

        permissionCheckDO.setResource(resourceDO);

        KyCallResult<Boolean> result = permissionService.hasPermission(permissionCheckDO);
        return result.isSuccess() && Boolean.TRUE.equals(result.getModel());
    }

    /**
     * 获取文件下载链接
     *
     * @param domainId 域id
     * @param userId   用户id
     * @param fileKey  文件在tfs上的key
     * @param fileName 文件名(包含后缀名)
     * @return ResultDTO<String>  文件下载链接
     */
    ResultDTO<String> buildFileUrl(long domainId, long userId, String fileKey, String fileName) {
        if (StringUtils.isBlank(fileKey)) {
            logger.info("fileKey is blank, domainId={}, userId={}, fileKey={}, fileName={}",
                    domainId, userId, fileKey, fileName);
            return ResultUtil.returnResultDTO(ErrorCode.FILE_NOT_EXIST);
        }
        if (StringUtils.isBlank(fileName)) {
            logger.info("fileName is blank, domainId={}, userId={}, fileKey={}, fileName={}",
                    domainId, userId, fileKey, fileName);
            return ResultUtil.returnResultDTO(ErrorCode.FILE_NAME_IS_EMPTY);
        }

        long age = System.currentTimeMillis() + TimeUtils.ONE_HOUR_MILLISECOND;
        String fileToken = fileTokenService.requestFileToken(domainId, userId, TfsGroup.RESTRICTED, fileKey, age);
        if (StringUtils.isBlank(fileToken)) {
            logger.warn("fileTokenService.requestFileToken fail, domainId={}, userId={}, fileKey={}, fileName={}, " +
                    "age={}", domainId, userId, fileKey, fileName, age);
            return ResultUtil.returnResultDTO(ErrorCode.FILE_TOKEN_NOT_EXIST);
        }

        String fileTokens;
        try {
            fileTokens = URLEncoder.encode(fileToken, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            logger.warn("编码文件令牌:{}发生字符不支持异常，domainId={}, userId={}, fileKey={}, fileName={}, age={}, " +
                    "error:", fileToken, domainId, userId, fileKey, fileName, age, e);
            return ResultUtil.returnResultDTO(ErrorCode.FILE_TOKEN_ENCODE_ERROR);
        }

        ResultDTO<String> resultDTO = new ResultDTO<>();
        resultDTO.setModel(this.buildFileGwUrl(fileTokens, fileName));
        return resultDTO;
    }

    /**
     * 生成filegw的文件下载链接
     *
     * @param fileTokens token
     * @param fileName   文件名(包含后缀名)
     * @return filegwURL
     */
    private String buildFileGwUrl(String fileTokens, String fileName) {
        StringBuilder sb = new StringBuilder(constantCache.getFilegwDomainInner())
                .append("file?token=").append(fileTokens)
                .append("&fileName=").append(fileName);
        return sb.toString();
    }

    ResultDTO<SellerDO> querySeller(long sellerId) {
        KyCallResult<SellerDO> kyCallResult = sellerService.getSellerById(sellerId);
        if (!kyCallResult.isSuccess()) {
            return ResultUtil.returnResultDTO(ErrorCode.SELLER_NOT_EXISTS);
        }

        ResultDTO<SellerDO> resultDTO = new ResultDTO<>();
        resultDTO.setModel(kyCallResult.getModel());
        return resultDTO;
    }

    private <T extends ResultSupport> T wrapper(Supplier<T> supplier,
                                                String name, String operation, T defaultValue) {
        defaultValue.setResultCode(ErrorCode.NO_PERMISSION_TO_OPT.getCode());
        defaultValue.setResultMsg(ErrorCode.NO_PERMISSION_TO_OPT.getDesc());

        long appId = AuthResourceProperties.APPID;

        User user = UserUtil.getCurrentUser();
        if (null == user) {
            return defaultValue;
        }

        try {

            boolean permission = hasPermission(user.getId(), appId, name, operation);

            if (!permission) {
                return defaultValue;
            } else {
                return supplier.get();
            }

        } catch (Exception e) {
            logger.error("webWrapper {}:{} Exception. userId={}, appId={}, e:", name, operation, user.getId(), appId, e);

            defaultValue.setResultCode(ErrorCode.EXCEPTION.getCode());
            defaultValue.setResultMsg(ErrorCode.EXCEPTION.getDesc());
            return defaultValue;
        }
    }

    /**
     * 获取文案中心值
     *
     * @param procName 流程模板名字
     * @param nodeKey  nodeKey
     * @return AppResourceDO
     */
    protected AppResourceDO getAppResource(String procName, String nodeKey) {
        return getAppResource(KY_SYSTEM, CHANNEL, procName, PROC_DEF_SOURCE, nodeKey);
    }

    /**
     * 获取文案配置列表
     *
     * @param system  系统
     * @param channel 渠道
     * @param type    类型
     * @param source  源
     * @return 配置列表
     */
    protected List<AppResourceDO> getAppResource(String system, String channel, String type, String source) {
        KyBatchResult<AppResourceDO> kyBatchResult = appResourceService.getAppResource(system, channel, type, source);
        logger.info("appResourceService.getAppResource, system:{}, channel:{}, type:{}, source:{}, kyBatchResult is {}",
                system, channel, type, source, JsonUtil.obj2Str(kyBatchResult));

        if (kyBatchResult.isSuccess()) {
            return kyBatchResult.getModel();
        } else {
            return Collections.emptyList();
        }
    }

    /**
     * 获取文案配置
     *
     * @param system  系统
     * @param channel 渠道
     * @param type    类型
     * @param source  源
     * @param key     主key
     * @return 配置
     */
    protected AppResourceDO getAppResource(String system, String channel, String type, String source, String key) {
        KyCallResult<AppResourceDO> kyCallResult = appResourceService.getAppResource(system, channel, type, source, key);
        logger.info("appResourceService.getAppResource, system:{}, channel:{}, type:{}, source:{}, key:{}, result:{}",
                system, channel, type, source, key, JsonUtil.obj2Str(kyCallResult));

        if (kyCallResult.isSuccess()) {
            return kyCallResult.getModel();
        } else {
            return null;
        }
    }

    /**
     * 根据流程类型查询状态下拉列表
     *
     * @param flowTypeEnum 流程类型
     * @return BatchResultDTO<FlowStatusDO>
     */
    BatchResultDTO<FlowStatusDO> batchQueryFlowStatus(FlowTypeEnum flowTypeEnum) {
        AppResourceDO appResource = getAppResource(KY_SYSTEM, CHANNEL, STATUS, PROC_STATUS_SOURCE, flowTypeEnum.getCode());
        if (Objects.isNull(appResource)) {
            return ResultUtil.returnBatchResultDTO(ErrorCode.QUERY_APP_RESOURCE_FAIL);
        }

        String status = appResource.val;
        if (StringUtils.isBlank(status)) {
            return ResultUtil.returnBatchResultDTO(ErrorCode.FLOW_STATUS_NOT_EXIST);
        }

        String[] tmp = status.split(";");
        List<FlowStatusDO> list = Arrays.stream(tmp).map(n -> {
            FlowStatusDO flowStatusDO = new FlowStatusDO();
            String[] arr = n.split(":");
            flowStatusDO.setKey(arr[0]);
            flowStatusDO.setName(arr[1]);
            return flowStatusDO;
        }).collect(Collectors.toList());

        BatchResultDTO<FlowStatusDO> batchResultDTO = new BatchResultDTO<>();
        batchResultDTO.setModel(list);
        return batchResultDTO;
    }

    /**
     * 获取用户角色
     *
     * @param appId  appId
     * @param userId 用户id
     * @return 用户角色
     */
    String queryRole(long appId, long userId) {
        KyCallResult<String> kyCallResult = permissionService.getCurRole(userId, appId);
        logger.info("permissionService.getCurRole, userId is {}, appId is {}, kyCallResult is {}",
                userId, appId, JsonUtil.obj2Str(kyCallResult));
        if (!kyCallResult.isSuccess()) {
            return null;
        } else {
            return kyCallResult.getModel();
        }
    }

    /**
     * 查询弹框文字提示的JSON字符串
     *
     * @param procName 流程模板名字
     * @param nodeKey  nodeKey
     * @return ResultDTO<String>
     */
    ResultDTO<String> queryNodeTip(String procName, String nodeKey) {
        String type = procName + TIP;
        AppResourceDO appResource = getAppResource(KY_SYSTEM, CHANNEL, type, PROC_DEF_TIP, nodeKey);
        if (Objects.isNull(appResource)) {
            return ResultUtil.returnResultDTO(ErrorCode.QUERY_APP_RESOURCE_FAIL);
        }

        ResultDTO<String> resultDTO = new ResultDTO<>();
        resultDTO.setModel(appResource.val);
        return resultDTO;
    }

    /**
     * 查询一个流程实例的审批记录
     *
     * @param procInstId 流程实例id
     * @param procName   流程模板名字
     * @return BatchResultDTO<AuditFlowDTO>
     */
    BatchResultDTO<AuditFlowDTO> batchQueryAuditFlow(long procInstId, String procName) {
        BizObjQuery bizObjQuery = new BizObjQuery();
        bizObjQuery.setProcInstId(procInstId);
        BatchResult<TaskInstDTO> batchResult = flowService.getFinishedActInstList(bizObjQuery);
        if (!batchResult.isSuccess()) {
            return ResultUtil.returnBatchResultDTO(ErrorCode.QUERY_AUDIT_FLOW_FAIL);
        }
        List<AppResourceDO> appResourceDOS = getAppResource(KY_SYSTEM, CHANNEL, procName, PROC_DEF_SOURCE);

        List<AuditFlowDTO> list = new LinkedList<>();
        List<TaskInstDTO> taskInstDTOS = batchResult.getModel();
        ValidateSetUtil.setIfListNotEmpty(taskInstDTOS, param -> {
            if (StringUtils.isBlank(param.getApprovalVote())) {
                return;
            }

            AuditFlowDTO auditFlowDTO = new AuditFlowDTO();
            auditFlowDTO.setAllocatingTime(TimeUtils.format(param.getStartTime()));
            auditFlowDTO.setAuditTime(TimeUtils.format(param.getEndTime()));
            auditFlowDTO.setRemark(param.getApprovalMemo());
            auditFlowDTO.setTransitionName(param.getApprovalVote());
            appResourceDOS.stream()
                    .filter(m -> Objects.equals(m.keyName, param.getNodeKey()))
                    .findFirst()
                    .ifPresent(appResourceDO -> {
                        // 扩展值2是角色名称
                        auditFlowDTO.setRole(appResourceDO.val2);
                        // 扩展值3是审批记录的文案
                        auditFlowDTO.setNodeKeyDesc(appResourceDO.val3);
                    });

            list.add(auditFlowDTO);
        });

        BatchResultDTO<AuditFlowDTO> batchResultDTO = new BatchResultDTO<>();
        batchResultDTO.setModel(list);
        return batchResultDTO;
    }

}
