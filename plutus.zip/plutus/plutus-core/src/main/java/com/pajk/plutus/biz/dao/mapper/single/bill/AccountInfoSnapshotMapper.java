package com.pajk.plutus.biz.dao.mapper.single.bill;

import com.pajk.plutus.biz.model.mapper.single.bill.AccountInfoSnapshotDAO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by arjaylv on 2017/12/11.
 *
 * @author arjaylv
 */
public interface AccountInfoSnapshotMapper {

    int insert(AccountInfoSnapshotDAO accountInfoSnapshotDAO);

    List<AccountInfoSnapshotDAO> queryByBillId(@Param("billId") long billId);

    /**
     * 根据账单id列表批量查询账户信息快照，按创建时间升序排列
     *
     * @param billIds
     * @return
     */
    List<AccountInfoSnapshotDAO> queryByBillIds(@Param("billIds") List<Long> billIds);
}
