package com.pajk.plutus.biz.conf;

import com.alibaba.druid.filter.stat.StatFilter;
import com.alibaba.druid.pool.DruidDataSource;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

/**
 * Created by fanhuafeng on 16/5/31.
 * Modify by fanhuafeng on 16/5/31
 */
@Configuration
@EnableTransactionManagement
@MapperScan(basePackages = {"com.pajk.plutus.biz.dao.mapper"}, sqlSessionFactoryRef = "sqlSessionFactory")
public class MyBatisConfig {

    private static final Logger logger = LoggerFactory.getLogger(MyBatisConfig.class);

    @Value(value = "classpath:bill-mybatis-config.xml")
    private Resource configLocation;

    @Value("${plutus.mcfinance.url}")
    String url;
    @Value("${plutus.mcfinance.username}")
    String username;
    @Value("${plutus.mcfinance.password}")
    String password;
    @Value("${datasource.maxActive}")
    int maxActive;
    @Value("${datasource.initialSize}")
    int initialSize;
    @Value("${datasource.maxWait}")
    int maxWait;
    @Value("${datasource.minIdle}")
    int minIdle;

    @Bean(name = "sqlSessionFactory")
    public SqlSessionFactoryBean sqlSessionFactory(@Qualifier("mcDataSource") DataSource mcDataSource) {
        SqlSessionFactoryBean ssfb = new SqlSessionFactoryBean();
        ssfb.setConfigLocation(configLocation);
        ssfb.setDataSource(mcDataSource);
        return ssfb;
    }

    @Bean(name = "transactionManager")
    public PlatformTransactionManager transactionManager(
            @Qualifier("mcDataSource") DataSource mcDataSource) {
        return new DataSourceTransactionManager(mcDataSource);
    }

    @Primary
    @Bean(name = "mcDataSource", initMethod = "init", destroyMethod = "close")
    public DruidDataSource dataSource() throws SQLException {
        logger.info("db connection pool maxActive:{}", maxActive);

        DruidDataSource ds = new DruidDataSource();
        ds.setUrl(url);
        ds.setUsername(username);
        ds.setPassword(password);
        ds.setValidationQuery("select 1");
        ds.setFilters("config");

        if (0 < maxActive) {
            ds.setMaxActive(maxActive);
        }
        if (0 < initialSize) {
            ds.setInitialSize(initialSize);
        }
        if (0 < maxWait) {
            ds.setMaxWait((long) maxWait);
        }
        if (0 < minIdle) {
            ds.setMinIdle(minIdle);
        }

        ds.setTimeBetweenEvictionRunsMillis(60000L);
        ds.setMinEvictableIdleTimeMillis(300000L);
        ds.setTestWhileIdle(true);
        ds.setTestOnBorrow(false);
        ds.setTestOnReturn(false);
        ds.setPoolPreparedStatements(true);
        ds.setMaxPoolPreparedStatementPerConnectionSize(20);
        Properties properties = new Properties();
        properties.put("config.decrypt", "true");
        ds.setConnectProperties(properties);
        StatFilter statFilter = new StatFilter();
        statFilter.setSlowSqlMillis(10000L);
        statFilter.setMergeSql(true);
        statFilter.setLogSlowSql(true);
        ArrayList filterList = new ArrayList();
        filterList.add(statFilter);
        ds.setProxyFilters(filterList);
        return ds;
    }

}
