package com.pajk.plutus.biz.manager;

import com.pajk.plutus.biz.exceptions.DBException;
import com.pajk.plutus.client.model.result.ErrorCode;
import com.pajk.thunderbird.domain.result.ResultDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;

import java.io.Serializable;
import java.util.function.Supplier;

/**
 * Created by fanhuafeng on 17/3/27.
 * Modify by fanhuafeng on 17/3/27
 */
public interface TransactionWrapper {

    Logger logger = LoggerFactory.getLogger(TransactionWrapper.class);

    default <T extends Serializable> ResultDTO<T> transactionWrapper(
            Supplier<ResultDTO<T>> supplier, String msg){
        ResultDTO<T> result = new ResultDTO<>();
        try{
            return supplier.get();
        }catch (DBException e){
            logger.error("[TransactionWrapper]{} DBException. e:", msg, e);
            result.setResultCode(e.getCode());
            result.setResultMsg(e.getMessage());
        }catch (DataIntegrityViolationException e){
            logger.warn("[TransactionWrapper]{} DataIntegrityViolationException. e:", msg, e);
            result.setResultCode(ErrorCode.C_STORE_DB_FAILED);
            result.setResultMsg(msg+"  DataIntegrityViolationException !");
        }
        catch (Exception e){
            logger.error("[TransactionWrapper]{} OtherException. e:", msg, e);
            result.setResultCode(ErrorCode.C_STORE_DB_FAILED);
            result.setResultMsg(msg+" fail!");
        }
        return result;
    }
}
