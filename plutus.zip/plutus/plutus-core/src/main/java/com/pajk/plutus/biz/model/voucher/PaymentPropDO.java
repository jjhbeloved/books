package com.pajk.plutus.biz.model.voucher;

import com.pajk.thunderbird.domain.result.BaseDO;

/**
 * 缴费单相关属性
 *
 * Created by fuyongda on 2017/12/19.
 * Modified by fuyongda on 2017/12/19.
 */
public class PaymentPropDO extends BaseDO {

    private static final long serialVersionUID = -1851161718680261253L;

    /**
     * 银行流水
     */
    private String evidenceFlow;

    public String getEvidenceFlow() {
        return evidenceFlow;
    }

    public void setEvidenceFlow(String evidenceFlow) {
        this.evidenceFlow = evidenceFlow;
    }

}
