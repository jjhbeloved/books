package com.pajk.plutus.biz.common.util;

import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Objects;

/**
 * @author david
 * @since created by on 17/12/14 11:14
 */
public class ValidateSetUtil {

    public static <T> void validateNonNullSet(T param, Callback<T> callback) {
        if (Objects.nonNull(param)) {
            callback.done(param);
        }
    }

    public static <T> void setFirstIfListNotEmpty(List<T> params, Callback<T> callback) {
        if (!CollectionUtils.isEmpty(params)) {
            callback.done(params.get(0));
        }
    }

    public static <T> void setIfListNotEmpty(List<T> params, Callback<T> callback) {
        if (!CollectionUtils.isEmpty(params)) {
            params.forEach(callback::done);
        }
    }

    public static <T> T setIfNon(T value, T defaultValue) {
        if (Objects.isNull(value)) {
            return defaultValue;
        }
        return value;
    }

    public interface Callback<T> {
        /**
         * 回调函数
         */
        void done(T param);
    }
}
