package com.pajk.plutus.biz.common.aop;

import java.lang.annotation.*;

/**
 * Created by fanhuafeng on 17/3/27.
 * Modify by fanhuafeng on 17/3/27
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ClassLogger {

    /**
     * 定义 打印捕获到异常的日志级别, 默认warn
     */
    ThrowableLogLevel throwExceptionLogLevel() default ThrowableLogLevel.WARN;

    /**
     * 定义 打印参数结果集数据长度
     */
    int argsMaxLength() default 2000;

    /**
     * 定义 打印返回结果集数据长度
     */
    int returnObjMaxLength() default 2000;

    /**
     * 定义 在日志中打上超时标记的超时时间. 单位毫秒
     */
    long timeOut() default 300;

}
