package com.pajk.plutus.biz.manager;

import com.pajk.plutus.biz.model.account.AccountBookDO;
import com.pajk.plutus.biz.model.account.AccountBookFlowDO;
import com.pajk.plutus.biz.model.query.account.BookFlowPageQuery;
import com.pajk.plutus.biz.model.query.account.BookPageQuery;
import com.pajk.plutus.client.model.enums.account.BookType;
import com.pajk.thunderbird.domain.result.PageResultDTO;
import com.pajk.thunderbird.domain.result.ResultDTO;
import com.pajk.thunderbird.domain.result.VoidEntity;

/**
 * Created by lizhijun on 2017/12/17.
 */
public interface AccountManager {

    /**
     * 批量查询账本
     * @param bookPageQuery 分页参数
     * @return PageResultDTO<AccountBookDO>
     */
    PageResultDTO<AccountBookDO> pageQueryBook(BookPageQuery bookPageQuery);

    /**
     * 通过商户及类型查询账本
     * @param sellerId 商户id
     * @param bookType 账本类型
     * @return ResultDTO<AccountBookDO>
     */
    ResultDTO<AccountBookDO> queryBookBySeller(long sellerId, BookType bookType);

    /**
     * 查询应该补齐的金额 (已完成的违规单总金额)
     * @param sellerId 商户id
     * @param bookId   账本id
     * @return ResultDTO<Long>
     */
    ResultDTO<Long> queryMustAddAmt(long sellerId, long bookId);

    /**
     * 进行销帐
     * @param bookFlowId 账本流水id
     * @return 返回销帐结果
     */
    ResultDTO<VoidEntity> doWriteOff(long bookFlowId);

    /**
     * 查询已经完成扣减的流水
     * @param bookFlowPageQuery 分页参数
     * @return PageResultDTO<AccountBookFlowDO>
     */
    PageResultDTO<AccountBookFlowDO> pageQueryBookFlow(BookFlowPageQuery bookFlowPageQuery);

    /**
     * 通过商户id 创建账户账本信息
     * @param sellerId 商户id
     * @return  ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> createAccount(long sellerId);

    /**
     * 通过拉取所有的商户进行初始化创建账户账本信息(包含已关店的商户)
     * @return ResultDTO<VoidEntity>
     */
    ResultDTO<VoidEntity> createAccountByAllSellers();

}
